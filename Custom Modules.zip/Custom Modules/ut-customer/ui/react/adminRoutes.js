import { Kyc, KycCreate, KycEdit } from './pages/admin/KYC';
import React from 'react';
import {
    Route,
    Switch
} from 'react-router';
import {
    getLink
} from 'ut-front-react/routerHelper';
import registerRoutes from './adminRegisterRoutes';
import {
    hot
} from 'react-hot-loader';

registerRoutes();

export default hot(module)(() =>
    <Switch>
        <Route exact path={getLink('ut-customer:kyc')} component={Kyc} />
        <Route exact path={getLink('ut-customer:kycCreate')} component={KycCreate} />
        <Route exact path={getLink('ut-customer:kycEdit')} component={KycEdit} />
    </Switch>
);
