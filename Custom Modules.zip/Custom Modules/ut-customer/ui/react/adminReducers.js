import kycList from './pages/admin/KYC/Listing/reducers';
import kyc from './pages/admin/KYC/KYC/reducers';

export default {
    kycList,
    kyc
};
