import React from 'react';
import reducer from './adminReducers';
import businessUnits from './containers/BusinessUnits';
import CustomerRoutes from './adminRoutes';

export function ui() {
    return {
        'container.BusinessUnits': () => businessUnits,
        reducer: () => reducer,
        route: async() => <CustomerRoutes key='utCustomer' />
    };
};
