import { registerRoute } from 'ut-front-react/routerHelper';

const registerRoutes = () => {
    const mainRoute = 'ut-customer:home';
    registerRoute(mainRoute).path('/customer');

    registerRoute('ut-customer:kyc').path('kyc').parent(mainRoute);
    registerRoute('ut-customer:kycCreate').path('create/:customerType').parent('ut-customer:kyc');
    registerRoute('ut-customer:kycEdit').path('edit/:customerType/:id').parent('ut-customer:kyc');

    return mainRoute;
};

export default registerRoutes;
