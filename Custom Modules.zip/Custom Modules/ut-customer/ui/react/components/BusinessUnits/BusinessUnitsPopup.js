import React, { PropTypes, Component } from 'react';
import classnames from 'classnames';
import Popup from 'ut-front-react/components/Popup';
import Searchbox from 'ut-front-react/components/SearchBox';
import TreeView from './TreeView';
import SearchResult from './SearchResult';
import BusinessUnit from './BusinessUnit';
import {
    POPUP_MIN_OFFSETS,
    POPUP_HEADER_HEIGHT,
    POPUP_FOOTER_HEIGHT,
    POPUP_PADDING
} from 'ut-front-react/components/Popup/config';
import {
    SEARCHBOX_HEIGHT,
    TREEVIEW_OFFSET,
    TREEVIEW_TITLE,
    TREEVIEW_PADDING,
    SELECTED_UNIT_HEIGHT,
    SELECTED_UNITS_HEIGHT
} from './config';
import styles from './styles.css';

export default class BusinessUnitsPopup extends Component {
    constructor(props) {
        super(props);

        const selected = (props.selected.id) ? props.selected : null;
        this.state = {
            selected,
            showSearchResult: false,
            treeViewHeight: null
        };

        this.onTreeViewClick = this.onTreeViewClick.bind(this);
        this.onBusinessUnitSelect = this.onBusinessUnitSelect.bind(this);
        this.onSearch = this.onSearch.bind(this);
        this.updateTreeViewHeight = this.updateTreeViewHeight.bind(this);
    }

    componentWillMount() {
        document.addEventListener('resize', this.updateTreeViewHeight);
    }

    componentDidMount() {
        this.updateTreeViewHeight();
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.isOpen && !nextProps.isOpen) {
            this.setState({
                showSearchResult: false
            });
        }
    }

    componentWillUnmount() {
        document.removeEventListener('resize', this.updateTreeViewHeight);
    }

    onTreeViewClick(selected) {
        this.setState({
            selected
        });
    }

    onBusinessUnitSelect() {
        this.props.onSelect(this.state.selected);
    }

    onSearch(organizationName) {
        this.props.onSearch(organizationName);

        this.setState({
            showSearchResult: true
        });
    }

    updateTreeViewHeight() {
        const { multiSelect } = this.props;
        const popupContentMaxheight = window.innerHeight - POPUP_MIN_OFFSETS - POPUP_HEADER_HEIGHT - POPUP_FOOTER_HEIGHT - 2 * POPUP_PADDING;
        const selectedHeight = multiSelect ? SELECTED_UNITS_HEIGHT : SELECTED_UNIT_HEIGHT;

        const treeViewHeight = popupContentMaxheight - SEARCHBOX_HEIGHT - 2 * TREEVIEW_OFFSET - 2 * TREEVIEW_PADDING - TREEVIEW_TITLE - selectedHeight;

        this.setState({
            treeViewHeight
        });
    }

    get searchResult() {
        const { filteredUnits, noResultsText, disableIds } = this.props;

        if (filteredUnits.length) {
            return filteredUnits.map((unit, index) => {
                const { id, title, parents } = unit;
                const disabled = disableIds.indexOf(id) >= 0;
                return (
                    <SearchResult
                        key={index}
                        id={id}
                        title={title}
                        parents={parents}
                        disabled={disabled}
                        selected={this.state.selected && id === this.state.selected.id}
                        onClick={this.onTreeViewClick}
                    />
                );
            });
        } else {
            return noResultsText;
        }
    }

    get actionButtons() {
        const { actionButtons, closePopup } = this.props;
        const { selected } = this.state;

        if (!actionButtons) {
            return [{
                name: 'select',
                label: 'Select',
                disabled: selected === null,
                styleType: 'primaryDialog',
                onClick: this.onBusinessUnitSelect
            }, {
                name: 'cancel',
                label: 'Cancel',
                styleType: 'secondaryDialog',
                onClick: closePopup
            }];
        }

        return actionButtons;
    }

    get selected() {
        const { multiSelect } = this.props;
        const { selected } = this.state;

        if (multiSelect && Array.isArray(selected)) {
            return selected.map((unit, index) => {
                const { id, title } = unit;

                return (
                    <BusinessUnit
                        key={index}
                        id={id}
                        title={title}
                    />
                );
            });
        }

        return (
            <BusinessUnit
                id={selected.id}
                title={selected.title}
            />
        );
    }

    render() {
        const {
            isOpen,
            closeOnEsc,
            className,
            header,
            title,
            searchable,
            multiSelect,
            businessUnits,
            businessUnitsFlat,
            filteredUnits,
            closePopup,
            disableIds
        } = this.props;

        const { showSearchResult, selected, treeViewHeight } = this.state;

        return (
            <Popup
                isOpen={isOpen}
                className={classnames(styles.BusinessUnitsPopup, className)}
                closeOnEsc={closeOnEsc}
                header={header}
                footer={{actionButtons: this.actionButtons}}
                closePopup={closePopup}
            >
                {searchable && <Searchbox
                    placeholder='Search Business Units'
                    onSearch={this.onSearch}
                />}
                {showSearchResult ? <div
                    className={classnames(styles.searchResults, { [styles.noResults]: filteredUnits.length === 0 })}
                >
                    {this.searchResult}
                </div> : <TreeView
                    title={{ text: title }}
                    multiSelect={multiSelect}
                    maxHeight={treeViewHeight}
                    tree={businessUnits}
                    flatTree={businessUnitsFlat}
                    selected={selected}
                    onClick={this.onTreeViewClick}
                    disableIds={disableIds}
                />}
                {selected && <div className={styles.selectedUnits}>
                    {this.selected}
                </div>}
            </Popup>
        );
    }
};

BusinessUnitsPopup.defaultProps = {
    header: {
        text: 'Visible to Business Unit'
    },
    title: 'You can select only one Business Unit.',
    multiSelect: false,
    searchable: false,
    noResultsText: 'No results',
    disableIds: []
};

BusinessUnitsPopup.propTypes = {
    isOpen: PropTypes.bool,
    multiSelect: PropTypes.bool,
    searchable: PropTypes.bool,
    selected: PropTypes.object,
    title: PropTypes.string,
    closeOnEsc: PropTypes.bool,
    className: PropTypes.string,
    header: PropTypes.shape({
        text: PropTypes.string,
        className: PropTypes.string
    }),
    actionButtons: PropTypes.array,
    businessUnits: PropTypes.array,
    businessUnitsFlat: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
    filteredUnits: PropTypes.array,
    noResultsText: PropTypes.string,
    closePopup: PropTypes.func,
    onSelect: PropTypes.func,
    onSearch: PropTypes.func,
    disableIds: PropTypes.array
};
