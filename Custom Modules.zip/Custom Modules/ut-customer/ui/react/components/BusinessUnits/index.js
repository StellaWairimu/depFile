import React, { PropTypes } from 'react';
import BusinessUnitsBox from './BusinessUnitsBox';
import BusinessUnitsPopup from './BusinessUnitsPopup';

const BusinessUnits = ({
    type,
    required,
    disabled,
    searchable,
    multiSelect,
    error,
    hint,
    isPopupOpen,
    businessUnits,
    businessUnitsFlat,
    filteredUnits,
    selected,
    showSelected,
    togglePopup,
    onSearch,
    onSelect,
    disableIds
}) => {
    return (
        <div>
            <BusinessUnitsBox
                required={required}
                button={{
                    title: 'Select',
                    disabled: disabled,
                    onClick: togglePopup
                }}
                selected={selected}
                error={error}
                showSelected={showSelected}
                hint={hint}
            />
            {isPopupOpen && <BusinessUnitsPopup
                isOpen={isPopupOpen}
                type={type}
                searchable={searchable}
                multiSelect={multiSelect}
                selected={selected}
                businessUnits={businessUnits}
                businessUnitsFlat={businessUnitsFlat}
                filteredUnits={filteredUnits}
                onSearch={onSearch}
                onSelect={onSelect}
                closePopup={togglePopup}
                disableIds={disableIds}
            />}
        </div>
    );
};

BusinessUnits.defaultProps = {
    multiSelect: false,
    onSelect: () => {}
};

BusinessUnits.propTypes = {
    type: PropTypes.string,
    required: PropTypes.bool,
    disabled: PropTypes.bool,
    searchable: PropTypes.bool,
    multiSelect: PropTypes.bool,
    error: PropTypes.string,
    hint: PropTypes.string,
    isPopupOpen: PropTypes.bool,
    businessUnits: PropTypes.array,
    businessUnitsFlat: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
    filteredUnits: PropTypes.array,
    selected: PropTypes.object,
    showSelected: PropTypes.bool,
    togglePopup: PropTypes.func,
    onSelect: PropTypes.func,
    onSearch: PropTypes.func,
    disableIds: PropTypes.array
};

export default BusinessUnits;
