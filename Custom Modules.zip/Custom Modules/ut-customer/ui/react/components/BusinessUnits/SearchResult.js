import React, { PropTypes } from 'react';
import classnames from 'classnames';
import RadioButton from './RadioButton';
import styles from './styles.css';

const SearchResult = ({
    className,
    id,
    type,
    title,
    parents,
    selected,
    onClick,
    disabled
}) => {
    return (
        <div className={classnames(className, styles.searchResult)}>
            {parents && <div>{parents}</div>}
            <RadioButton
                label={{ text: title }}
                selected={selected}
                disabled={disabled}
                onClick={() => { onClick({ id, title }); }}
            />
        </div>
    );
};

SearchResult.propTypes = {
    className: PropTypes.string,
    id: PropTypes.string,
    type: PropTypes.string,
    title: PropTypes.string,
    parents: PropTypes.string,
    selected: PropTypes.object,
    onClick: PropTypes.func,
    disabled: PropTypes.bool
};

export default SearchResult;
