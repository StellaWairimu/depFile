export const SEARCHBOX_HEIGHT = 30;
export const TREEVIEW_OFFSET = 20;
export const TREEVIEW_TITLE = 50;
export const SELECTED_UNIT_HEIGHT = 30;
export const SELECTED_UNITS_HEIGHT = 40;
export const TREEVIEW_PADDING = 20;
