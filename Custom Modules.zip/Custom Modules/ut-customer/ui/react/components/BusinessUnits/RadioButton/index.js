import React, { PropTypes } from 'react';
import classnames from 'classnames';
import styles from './styles.css';

const RadioButton = ({
    className,
    label,
    selected,
    disabled,
    onClick
}) => {
    return (
        <div className={classnames(styles.labeledRadioButton, className)} onClick={!disabled && onClick}>
            <div className={classnames(styles.radioButton, selected && styles.on, disabled && styles.disabled)}>
                {selected && <div className={styles.radioButtonHandle} />}
            </div>
            <span className={classnames(styles.radioLabel, label.className, disabled && styles.disabled)}>{label.text}</span>
        </div>
    );
};

RadioButton.propTypes = {
    className: PropTypes.string,
    label: PropTypes.object,
    selected: PropTypes.bool,
    disabled: PropTypes.bool,
    onClick: PropTypes.func
};

RadioButton.defaultProps = {
    disabled: false
};

export default RadioButton;
