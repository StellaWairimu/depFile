import React, { PropTypes } from 'react';
import classnames from 'classnames';
import styles from './styles.css';

const BusinessUnit = ({
    className,
    title,
    onClick
}) => {
    return (
        <span className={classnames(className, styles.businessUnit)}>{title}</span>
    );
};

BusinessUnit.propTypes = {
    className: PropTypes.string,
    title: PropTypes.string,
    onClick: PropTypes.func
};

export default BusinessUnit;
