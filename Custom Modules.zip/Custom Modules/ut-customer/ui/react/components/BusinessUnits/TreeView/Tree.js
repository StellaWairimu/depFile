import React, { Component, PropTypes } from 'react';
import classnames from 'classnames';
import find from 'lodash.find';
import RadioButton from '../RadioButton';
import Checkbox from 'ut-front-react/components/Input/CheckboxNew';
import { DEFAULT_OFFSET } from './config';
import styles from './styles.css';

export default class Tree extends Component {
    constructor(props) {
        super(props);

        this.state = {
            expanded: props.expandedNodes && props.expandedNodes.indexOf(props.tree.id) !== -1
        };

        this.onClick = this.onClick.bind(this);
        this.toggleExpand = this.toggleExpand.bind(this);
    }

    onClick() {
        this.props.onClick(this.props.tree);
    }

    toggleExpand() {
        this.setState({
            expanded: !this.state.expanded
        });
    }

    get childNodes() {
        const { tree, className, selected, multiSelect, nestLevel, onClick, expandedNodes, disableIds } = this.props;
        const { expanded } = this.state;

        if (tree.children) {
            return tree.children.map((child, index) => {
                return (
                    <Tree
                        key={index}
                        className={className}
                        multiSelect={multiSelect}
                        expandable={!!child.children}
                        expandedNodes={expandedNodes}
                        expanded={expanded}
                        selected={selected}
                        nestLevel={nestLevel + 1}
                        tree={child}
                        disableIds={disableIds}
                        onClick={onClick}
                    />
                );
            });
        }
    }

    get offsetLeft() {
        return `${DEFAULT_OFFSET}px`;
    }

    get leftButton() {
        const { tree, selected, disableIds } = this.props;
        const { id, title } = tree;
        const disabled = disableIds.indexOf(id) >= 0;

        if (Array.isArray(selected)) {
            return (
                <Checkbox
                    label={title}
                    checked={!!find(selected, { id })}
                    disabled={disabled}
                    handleChange={this.onClick}
                />
            );
        }

        return (
            <RadioButton
                selected={selected && selected.id === id}
                label={{text: title}}
                disabled={disabled}
                onClick={this.onClick}
            />
        );
    }

    render() {
        const { className, expandable } = this.props;
        const { expanded } = this.state;

        return (
            <div style={{ marginLeft: this.offsetLeft }} className={className}>
                <div className={styles.itemContainer}>
                    <div className={classnames(styles.expandIconContainer, {[styles.hidden]: !expandable})} onClick={this.toggleExpand}>
                        {!expanded && <div className={styles.expandIconVl} />}
                        <div className={styles.expandIconHl} />
                    </div>
                    {this.leftButton}
                </div>
                {expanded && this.childNodes}
            </div>
        );
    }
}

Tree.defaultProps = {
    nestLevel: 0,
    expandable: true,
    expandedNodes: [],
    disableIds: []
};

Tree.propTypes = {
    className: PropTypes.string,
    tree: PropTypes.object,
    selected: PropTypes.object,
    nestLevel: PropTypes.number,
    multiSelect: PropTypes.bool,
    expandable: PropTypes.bool,
    expandedNodes: PropTypes.array,
    disableIds: PropTypes.array,
    onClick: PropTypes.func
};
