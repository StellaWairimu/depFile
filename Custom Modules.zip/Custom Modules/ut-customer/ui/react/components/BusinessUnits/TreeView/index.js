import React, { Component, PropTypes } from 'react';
import classnames from 'classnames';
import Tree from './Tree';
import styles from './styles.css';

export default class TreeView extends Component {
    constructor(props) {
        super(props);

        this.expanded = [];

        const selected = props.selected;
        let stateSelected = selected;

        if (selected && props.multiSelect) {
            this.expanded.push(selected.id);
            if (props.multiSelect) {
                stateSelected = [selected];
            }
        }

        this.state = {
            selected: stateSelected,
            expanded: []
        };

        this.getExpanded = this.getExpanded.bind(this);
        this.onTreeViewClick = this.onTreeViewClick.bind(this);
    }

    getExpanded(id) {
        const parent = this.props.flatTree[id] ? this.props.flatTree[id].parent : null;

        if (this.expanded.indexOf(id) === -1 && id) {
            this.expanded = this.expanded.concat(id);
        }

        parent && this.getExpanded(parent);

        return this.expanded;
    }

    onTreeViewClick(node) {
        const { multiSelect, onClick } = this.props;
        let selected = node;

        if (multiSelect) {
            selected = this.state.selected.concat(selected);
        }
        this.setState({
            selected
        });

        onClick(selected);
    }

    get trees() {
        const { tree, multiSelect, disableIds } = this.props;

        if (tree.length > 1) {
            return tree.map((treeItem, index) => {
                return (
                    <Tree
                        key={index}
                        multiSelect={multiSelect}
                        expandedNodes={this.props.expanded || this.getExpanded(treeItem.id)}
                        selected={this.state.selected}
                        tree={treeItem}
                        disableIds={disableIds}
                        onClick={this.onTreeViewClick}
                    />
                );
            });
        }

        return (
            <Tree
                multiSelect={multiSelect}
                expandedNodes={this.props.expanded || this.getExpanded(tree[0].id)}
                selected={this.state.selected}
                tree={tree[0]}
                disableIds={disableIds}
                onClick={this.onTreeViewClick}
            />
        );
    }

    render() {
        const {
            className,
            treeViewClassName,
            title,
            maxHeight
        } = this.props;

        return (
            <div className={className}>
                {title && <div className={classnames(styles.treeViewTitle, title.className)}>{title.text}</div>}
                <div style={{ maxHeight: `${maxHeight}px` }} className={classnames(styles.treeView, treeViewClassName)}>
                    {this.trees}
                </div>
            </div>
        );
    }
}

TreeView.propTypes = {
    className: PropTypes.string,
    title: PropTypes.shape({
        className: PropTypes.string,
        text: PropTypes.string
    }),
    flatTree: PropTypes.shape({
        id: PropTypes.string,
        parent: PropTypes.string
    }),
    multiSelect: PropTypes.bool,
    treeViewClassName: PropTypes.string,
    maxHeight: PropTypes.number,
    tree: PropTypes.array,
    selected: PropTypes.object,
    expanded: PropTypes.array,
    onClick: PropTypes.func,
    disableIds: PropTypes.array
};
