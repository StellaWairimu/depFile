export const DEFAULT_OFFSET = 15;
