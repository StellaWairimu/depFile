import React, { PropTypes, Component } from 'react';
import classnames from 'classnames';
import BusinessUnit from './BusinessUnit';
import styles from './styles.css';

export default class BusinessUnitsBox extends Component {
    get title() {
        const { title, required } = this.props;

        return required ? title + ' *' : title;
    }

    get selectedBusinessUnits() {
        const { selected } = this.props;

        if (Array.isArray(selected)) {
            return selected.map((unit, index) => {
                return (
                    <BusinessUnit
                        key={index}
                        id={unit.id}
                        title={unit.title}
                    />
                );
            });
        }

        return (
            <BusinessUnit
                id={selected.id}
                title={selected.title}
            />
        );
    }

    get content() {
        const { showSelected, error, selected, defaultTitle } = this.props;

        if (error) {
            return <div className={styles.hasError}>{error}</div>;
        } else if (showSelected && Object.keys(selected).length !== 0) {
            return this.selectedBusinessUnits;
        }

        return defaultTitle;
    }

    render() {
        const { className, button, hint } = this.props;
        const { title, disabled, onClick } = button;

        return (
            <div className={classnames(className, styles.businessUnitsBox)}>
                <div className={styles.header}>
                    <span className={styles.title}>{this.title}</span>
                    {button.onClick && <span
                        className={classnames(styles.headerButton, button.className, { [styles.disabled]: !!disabled })}
                        onClick={!disabled && onClick}
                    >
                        {title}
                    </span>}
                </div>
                <div className={styles.container}>
                    {this.content}
                </div>
                {hint && <div className={styles.hint}>
                    {hint}
                </div>}
            </div>
        );
    }
};

BusinessUnitsBox.defaultProps = {
    button: {},
    title: 'Business Unit',
    defaultTitle: 'No business unit is selected.',
    multiSelect: false
};

BusinessUnitsBox.propTypes = {
    className: PropTypes.string,
    title: PropTypes.string,
    defaultTitle: PropTypes.string,
    required: PropTypes.bool,
    error: PropTypes.string,
    hint: PropTypes.string,
    selected: PropTypes.oneOfType([
        PropTypes.object,
        PropTypes.array
    ]),
    showSelected: PropTypes.bool,
    button: PropTypes.shape({
        className: PropTypes.string,
        title: PropTypes.string,
        disabled: PropTypes.bool,
        onClick: PropTypes.func
    })
};
