import React, { Component, PropTypes } from 'react';
import Popup from 'ut-front-react/components/Popup';
import Input from 'ut-front-react/components/Input';
import Checkbox from 'ut-front-react/components/Input/CheckboxNew';
import styles from './style.css';

export default class BusinessUnitDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            searchValue: '',
            selectedUnitId: props.selectedId
        };
        this.selectUnit = this.selectUnit.bind(this);
        this.closeDialog = this.closeDialog.bind(this);
        this.handleSelectUnit = this.handleSelectUnit.bind(this);
        this.onSearchInputChange = this.onSearchInputChange.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        if (!this.props.open && nextProps.open && this.state.selectedUnitId !== nextProps.selectedId) {
            this.setState({
                selectedUnitId: nextProps.selectedId
            });
        }
    }

    get dialogButtons() {
        const { selectedUnitId } = this.state;
        return [
            {
                label: 'Select',
                styleType: 'primaryDialog',
                disabled: !selectedUnitId,
                onClick: this.selectUnit
            },
            {
                label: 'Close',
                styleType: 'secondaryDialog',
                onClick: this.closeDialog
            }
        ];
    }

    onSearchInputChange({ value }) {
        this.setState({
            searchValue: value
        });
    }

    handleSelectUnit({ value, checked }) {
        this.setState({
            selectedUnitId: checked ? value : ''
        });
    }

    selectUnit() {
        this.props.selectUnit(this.state.selectedUnitId);
        this.closeDialog();
    }

    closeDialog() {
        this.setState({
            searchValue: '',
            selectedUnitId: this.props.selectedId || ''
        }, this.props.closeDialog);
    }

    get filteredUnits() {
        const { searchValue } = this.state;
        const { data } = this.props;
        return !searchValue ? data : data.filter(unit => {
            return unit.get('title').toLowerCase().indexOf(searchValue.toLowerCase()) > -1;
        });
    }

    render() {
        const { selectedUnitId } = this.state;
        const { open } = this.props;

        return (
            <Popup
                isOpen={open}
                header={{text: 'Visibility to Business Unit', closePopup: this.closeDialog}}
                footer={{actionButtons: this.dialogButtons}}
                closePopup={this.closeDialog}
                closeOnEsc
            >
                <div>
                    <Input
                        value={this.state.searchValue}
                        placeholder='Search Business Unit'
                        onChange={this.onSearchInputChange}
                    />
                </div>
                <div className={styles.businessUnitsMessage}>You can select only one business unit.</div>
                <div className={styles.unitsContainer}>
                    {this.filteredUnits.map(item => {
                        return (
                            <Checkbox
                                key={item.get('id')}
                                label={item.get('title')}
                                value={item.get('id')}
                                checked={item.get('id') === selectedUnitId}
                                fullWidth
                                handleChange={this.handleSelectUnit}
                            />
                        );
                    })}
                </div>
            </Popup>
        );
    }
}

BusinessUnitDialog.propTypes = {
    data: PropTypes.object, // immutable List
    open: PropTypes.bool,
    selectedId: PropTypes.string,
    selectUnit: PropTypes.func,
    closeDialog: PropTypes.func
};
