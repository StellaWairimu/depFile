import React, { Component, PropTypes } from 'react';
import TitledContentBox from '../TitledContentBox';
import BusinessUnitDialog from './BusinessUnitDialog';
import style from './style.css';

export default class BusinessUnitInput extends Component {
    constructor() {
        super();

        this.state = {
            open: false
        };

        this.toggleDialog = this.toggleDialog.bind(this);
    }

    get boxMessage() {
        if (!this.props.isValid && this.props.errorMessage) {
            return this.props.errorMessage;
        }
        const selectedUnit = this.props.data.find(unit => unit.get('id') === this.props.selectedId);
        return selectedUnit ? selectedUnit.get('title') : 'Choose business unit';
    }

    toggleDialog() {
        this.setState({
            open: !this.state.open
        });
    }

    render() {
        const { isValid } = this.props;
        const boxMessageClassName = isValid ? '' : style.errorBoxMessage;
        return (
            <TitledContentBox
                title={this.props.title}
                headerButton={this.props.headerButton}
                onHeaderButtonClick={this.toggleDialog}
                inputs={[]}
            >
                <div className={boxMessageClassName}>
                    {this.boxMessage}
                </div>
                <BusinessUnitDialog
                    data={this.props.data}
                    open={this.state.open}
                    selectedId={this.props.selectedId}
                    selectUnit={this.props.selectUnit}
                    closeDialog={this.toggleDialog}
                />
            </TitledContentBox>
        );
    }
};

BusinessUnitInput.propTypes = {
    title: PropTypes.string,
    data: PropTypes.object, // immutable List
    selectedId: PropTypes.string,
    selectUnit: PropTypes.func,
    isValid: PropTypes.bool,
    errorMessage: PropTypes.string,
    headerButton: PropTypes.string
};
