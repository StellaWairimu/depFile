ALTER PROCEDURE [customerTest].[customer.mChStatusChange] --returns deviceIds for all or for specific installationId of the user
    @isMCHDisabled bit = 1 -- the id of the user, that the hash is related to
AS

MERGE INTO core.configuration AS target
USING
    (VALUES
        ('DisableCustomerM/C', @isMCHDisabled, 'DisableCustomerM/C')
    ) AS source ([key], value, description)
ON target.[key] = source.[key]
WHEN MATCHED THEN
UPDATE SET value = @isMCHDisabled

WHEN NOT MATCHED BY TARGET THEN
INSERT ([key], value, description)
VALUES ([key], @isMCHDisabled, description);
