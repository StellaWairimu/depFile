ALTER PROCEDURE [customerTest].[customer.returnAllowPhonePrefix] --a procedure returning phone number prefixes for self registration
AS
SELECT 'phonePrefix' AS resultSetName, 1 AS single
SELECT REPLACE (c.phonePrefix, '+', '') AS phonePrefix FROM customer.mno m
JOIN core.country c ON m.countryId = c.countryId
JOIN core.configuration cc ON cc.[value] = m.mnoId
WHERE m.ut5Key IS NOT NULL
AND c.phonePrefix IS NOT NULL
AND cc.[key] = 'mnoSelfAdd'
