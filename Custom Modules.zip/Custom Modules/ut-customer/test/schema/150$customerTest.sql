CREATE SCHEMA [customerTest]
