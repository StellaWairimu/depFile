const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const customerMethods = require('ut-test/lib/methods/customer');
const customerParams = require('ut-test/lib/requestParams/customer');
const userConstants = require('ut-test/lib/constants/user').constants();
const userMethods = require('ut-test/lib/methods/user');
const USERNAME = 'orgVisibility' + userConstants.USERNAME;
const REJECTREASON = 'rejected organization reason';
let stdPolicy;

module.exports = function test() {
    return {
        organizationVisibility: function(test, bus, run) {
            /**
             * Organization 1 with the following hierarchy: Main organization --> parent organization --> organization 1.
             * User with admin rights in organization 1.
             * Verify that this user cannot get/create/edit/update/delete/lock/approve/reject/discard an organization on the same hierarchy level as his own org.
             * Verify that this user cannot get/edit/delete/lock/approve/reject/discard the parent organization of his organization.
             */
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                // fetch std input policy
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                userMethods.addRole('add role successfully', context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                // create a SA user
                userMethods.addUser('add admin user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve admin user', context => context['add admin user'].person.actorId),
                userMethods.grantAction('grant admin rights to user', context => context['add admin user'].person.actorId),
                // add parent organization and organization 1 which is its child. Assign org 1 to a new user with admin rights.
                customerMethods.addOrganization('add parent organization', (context) => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, customerConstants.ORGNAME + 'parent'),
                customerMethods.approveOrganization('approve parent organization', (context) => context['add parent organization']['organization.info'][0].actorId),
                customerMethods.addOrganization('add organization 1', (context) => {
                    return {
                        parent: [context['add parent organization']['organization.info'][0].actorId]
                    };
                }, customerConstants.ORGNAME + 1),
                customerMethods.approveOrganization('approve organization 1', (context) => context['add organization 1']['organization.info'][0].actorId),
                userMethods.addUser('add user in org 1', context => {
                    return {
                        object: context['add organization 1']['organization.info'][0].actorId,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['add organization 1']['organization.info'][0].actorId
                    };
                }, USERNAME + 1),
                userMethods.approveUser('approve add user in org 1', context => context['add user in org 1'].person.actorId),
                userMethods.grantAction('grant admin rights to user', context => context['add user in org 1'].person.actorId),
                userMethods.logout('logout admin user', context => context.login['identity.check'].sessionId),
                userMethods.login('login user 1', USERNAME + 1, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                // add
                commonFunc.createStep('customer.organization.add', 'unsuccessfully add organization - same hierarchy level as logged user org', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME + 2
                        },
                        parent: [context['add parent organization']['organization.info'][0].actorId]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                }),
                userMethods.logout('logout user 1', context => context['login user 1']['identity.check'].sessionId),
                userMethods.login('login admin 1', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                // Add organization 2 which is with the same hierarchy level as organization 1
                customerMethods.addOrganization('add organization 2', (context) => {
                    return {
                        parent: [context['add parent organization']['organization.info'][0].actorId]
                    };
                }, customerConstants.ORGNAME + 2),
                userMethods.logout('logout admin 1', context => context['login admin 1']['identity.check'].sessionId),
                userMethods.login('login user 2', USERNAME + 1, userConstants.USERPASSWORD, userConstants.TIMEZONE),
                // get
                commonFunc.createStep('customer.organization.get', 'unsuccessfully get organization - same hierarchy level as logged user org', (context) => {
                    return {
                        actorId: context['add organization 2']['organization.info'][0].actorId
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                }),
                commonFunc.createStep('customer.organization.get', 'unsuccessfully get parent organization', (context) => {
                    return {
                        actorId: context['add parent organization']['organization.info'][0].actorId
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                }),
                // approve
                commonFunc.createStep('customer.organization.approve', 'unsuccessfully approve organization - same hierarchy level as logged user org', (context) => {
                    return {
                        actorId: context['add organization 2']['organization.info'][0].actorId
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                }),
                userMethods.logout('logout user 2', context => context['login user 2']['identity.check'].sessionId),
                userMethods.login('login admin 2', USERNAME, userConstants.USERPASSWORD, userConstants.TIMEZONE),
                customerMethods.approveOrganization('approve organization 2', (context) => context['add organization 2']['organization.info'][0].actorId),
                userMethods.logout('logout admin 2', context => context['login admin 2']['identity.check'].sessionId),
                userMethods.login('login user 3', USERNAME + 1, userConstants.USERPASSWORD, userConstants.TIMEZONE),
                // edit
                commonFunc.createStep('customer.organization.edit', 'unsuccessfully edit organization - same hierarchy level as logged user org', (context) => customerParams.editOrganizationParams(context, context => {
                    return {
                        actorId: context['add organization 2']['organization.info'][0].actorId
                    };
                }, customerConstants.ORGNAME + '2updated'), null,
                (error, assert) => {
                    assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                }),
                commonFunc.createStep('customer.organization.edit', 'unsuccessfully edit parent organization', (context) => customerParams.editOrganizationParams(context, context => {
                    return {
                        actorId: context['add parent organization']['organization.info'][0].actorId
                    };
                }, customerConstants.ORGNAME + 'parent updated'), null,
                (error, assert) => {
                    assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                }),
                // lock
                commonFunc.createStep('customer.organization.lock', 'unsuccessfully lock organization - same hierarchy level as logged user org', (context) => {
                    return {
                        actorIdList: [context['add organization 2']['organization.info'][0].actorId],
                        isEnabled: false
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                }),
                commonFunc.createStep('customer.organization.lock', 'unsuccessfully lock parent organization', (context) => {
                    return {
                        actorIdList: [context['add parent organization']['organization.info'][0].actorId],
                        isEnabled: false
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                }),
                // delete
                commonFunc.createStep('customer.organization.delete', 'unsuccessfully delete organization - same hierarchy level as logged user org',
                    (context) => customerParams.removeOrganizationParams(context, context => [context['add organization 2']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                        assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                    }),
                commonFunc.createStep('customer.organization.delete', 'unsuccessfully delete parent organization',
                    (context) => customerParams.removeOrganizationParams(context, context => [context['add parent organization']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                        assert.equals(error.type, 'customer.cannotDeleteHasOrganizations', 'return failure - cannot delete organization with children');
                    }),
                userMethods.logout('logout user 3', context => context['login user 3']['identity.check'].sessionId),
                userMethods.login('login admin 3', USERNAME, userConstants.USERPASSWORD, userConstants.TIMEZONE),
                customerMethods.editOrganization('edit organization 2', (context) => {
                    return {
                        actorId: context['add organization 2']['organization.info'][0].actorId
                    };
                }, customerConstants.ORGNAME + '2edited'),
                customerMethods.editOrganization('edit parent organization', (context) => {
                    return {
                        actorId: context['add parent organization']['organization.info'][0].actorId
                    };
                }, customerConstants.ORGNAME + 'parent edited'),
                userMethods.logout('logout admin 3', context => context['login admin 3']['identity.check'].sessionId),
                userMethods.login('login user 4', USERNAME + 1, userConstants.USERPASSWORD, userConstants.TIMEZONE),
                // reject
                commonFunc.createStep('customer.organization.reject', 'unsuccessfully reject organization - same hierarchy level as logged user org',
                    (context) => customerParams.rejectOrganizationParams(context, context => context['add organization 2']['organization.info'][0].actorId, REJECTREASON), null,
                    (error, assert) => {
                        assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                    }),
                commonFunc.createStep('customer.organization.reject', 'unsuccessfully reject parent organization',
                    (context) => customerParams.rejectOrganizationParams(context, context => context['add parent organization']['organization.info'][0].actorId, REJECTREASON), null,
                    (error, assert) => {
                        assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                    }),
                userMethods.logout('logout user 4', context => context['login user 4']['identity.check'].sessionId),
                userMethods.login('login admin 4', USERNAME, userConstants.USERPASSWORD, userConstants.TIMEZONE),
                customerMethods.rejectOrganization('reject organization 2', (context) => context['add organization 2']['organization.info'][0].actorId, REJECTREASON),
                customerMethods.rejectOrganization('reject parent organization', (context) => context['add parent organization']['organization.info'][0].actorId, REJECTREASON),
                userMethods.logout('logout admin 4', context => context['login admin 4']['identity.check'].sessionId),
                userMethods.login('login user 5', USERNAME + 1, userConstants.USERPASSWORD, userConstants.TIMEZONE),
                // discard
                commonFunc.createStep('customer.organization.discard', 'unsuccessfully discard organization - same hierarchy level as logged user org',
                    (context) => customerParams.discardOrganizationParams(context, context => context['add organization 2']['organization.info'][0].actorId), null,
                    (error, assert) => {
                        assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                    }),
                commonFunc.createStep('customer.organization.discard', 'unsuccessfully discard parent organization',
                    (context) => customerParams.discardOrganizationParams(context, context => context['add parent organization']['organization.info'][0].actorId), null,
                    (error, assert) => {
                        assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                    }),
                userMethods.logout('logout user 5', context => context['login user 5']['identity.check'].sessionId),
                userMethods.login('login admin 5', USERNAME, userConstants.USERPASSWORD, userConstants.TIMEZONE),
                customerMethods.editOrganization('edit parent organization', (context) => {
                    return {
                        actorId: context['add parent organization']['organization.info'][0].actorId
                    };
                }, customerConstants.ORGNAME + 'parent edited'),
                userMethods.logout('logout admin 5', context => context['login admin 5']['identity.check'].sessionId),
                userMethods.login('login user 6', USERNAME + 1, userConstants.USERPASSWORD, userConstants.TIMEZONE),
                commonFunc.createStep('customer.organization.approve', 'unsuccessfully approve parent organization', (context) => {
                    return {
                        actorId: context['add parent organization']['organization.info'][0].actorId
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, customerConstants.USERSECURITYVIOLATION, 'return failure - action not allowed for this user');
                }),
                userMethods.logout('logout user 6', context => context['login user 6']['identity.check'].sessionId)
            ]);
        }
    };
};
