const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerMethods = require('ut-test/lib/methods/customer');
const customerParams = require('ut-test/lib/requestParams/customer');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const USERNAME = 'getKyc' + userConstants.USERNAME;
const CUSTOMERKYCGET = 'customer.kyc.get';
const RANDOMCONDITIONID = customerConstants.RANDOMCONDITIONID;
const KYCDESCRIPTION = customerConstants.KYCDESCRIPTION;
const TEXTINPUT = 'test';
let stdPolicy;
let orgId1, organizationDepthArray;
let levelId1, levelName1, attributeId1, attributeId2;

module.exports = function test() {
    return {
        getKyc: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('user.user.get', 'get admin details', (context) => {
                    return {
                        actorId: context.login['identity.check'].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, userConstants.ADMINFIRSTNAME).error, null, 'return person');
                    orgId1 = result.memberOF[0].object;
                }),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                customerMethods.fetchCustomerType('fetch customer types'),
                commonFunc.createStep('core.configuration.fetch', 'fetch defaultBu setting', (context) => {
                    return {
                        key: customerConstants.GETBYDEPTHORGANIZATION
                    };
                }, (result, assert) => {
                    const orgDepth = result[0][0].value;
                    organizationDepthArray = Array.apply(null, {length: orgDepth - 1}).map(Number.call, Number);
                    assert.true(typeof result, 'object', 'return result');
                }),
                // Create organization which correspond to the kyc's depth
                {
                    name: 'Create organization by depth',
                    steps: () => organizationDepthArray.map(org => ({
                        name: 'Add and approve organizations',
                        steps: () => [
                            commonFunc.createStep('customer.organization.add', 'add organization',
                                () => ({
                                    organization: {
                                        organizationName: customerConstants.ORGNAME
                                    },
                                    parent: [orgId1]
                                }), (result, assert) => {
                                    orgId1 = result['organization.info'][0].actorId;
                                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                                }
                            ),
                            customerMethods.approveOrganization('approve organization', () => orgId1)
                        ]
                    }))
                },
                commonFunc.createStep('customer.kyc.getForCreate', 'get levels for creating kyc', context => {
                    return {
                        customerType: context['fetch customer types'].customerType[0].customerTypeNumber,
                        organizationId: orgId1
                    };
                }, (result, assert) => {
                    assert.true(result.levels.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateGetForCreateKyc(result.levels).error, null, 'Return all details for already created kyc levels');
                    levelId1 = result.levels[1].itemNameId;
                    levelName1 = result.levels[1].itemNameTranslation;
                }),
                commonFunc.createStep('customer.kycAttribute.list', 'list kyc attributes', context => {
                    return {
                        customerTypeId: context['fetch customer types'].customerType[0].customerTypeNumber
                    };
                }, (result, assert) => {
                    assert.true(result.kycAttributes.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateListKycAttributes(result.kycAttributes).error, null, 'Return all details for kyc attributes');
                    attributeId1 = result.kycAttributes[0].itemNameId;
                    attributeId2 = result.kycAttributes[1].itemNameId;
                }),
                commonFunc.createStep('customer.kyc.add', 'add kyc 1', context => {
                    return {
                        kyc: {
                            display: levelName1,
                            description: KYCDESCRIPTION,
                            customerTypeId: context['fetch customer types'].customerType[0].customerTypeNumber,
                            organizationId: orgId1,
                            itemNameId: levelId1
                        },
                        kycConditionAttribute: [{
                            conditionId: RANDOMCONDITIONID,
                            attributeId: attributeId1
                        },
                        {
                            conditionId: RANDOMCONDITIONID + 1,
                            attributeId: attributeId2
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(result.kyc[0].description, KYCDESCRIPTION, 'return kyc description');
                    assert.equals(customerJoiValidation.validateAddKyc(result.kyc).error, null, 'Return all details after adding a kyc');
                }),
                commonFunc.createStep('customer.kyc.get', 'get kyc successfully', context => customerParams.getKycParams(context, context => context['add kyc 1'].kyc[0].kycId),
                    (result, assert) => {
                        assert.equals(result.kyc[0].description, KYCDESCRIPTION, 'return kyc description');
                        assert.equals(customerJoiValidation.validateGetKyc(result).error, null, 'Return all details for kyc');
                        assert.equals(result.kyc[0].itemNameId, levelId1, 'return correct itemNameId');
                        assert.true(result.kycAttributes.find(attr => attr.attributeId === attributeId1 && attr.conditionId === RANDOMCONDITIONID), 'return attribute 1');
                        assert.true(result.kycAttributes.find(attr => attr.attributeId === attributeId2 && attr.conditionId === RANDOMCONDITIONID + 1), 'return attribute 2');
                        assert.equals(result.kycAttributes.length, 2, 'return 2 kyc attributes');
                    }),
                // NEGATIVE SCENARIOS
                commonFunc.createStep('customer.kyc.get', 'get kyc unsuccessfully - missing kycId', (context) => {
                    return {};
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.get', 'get kyc unsuccessfully - kycId null', context => customerParams.getKycParams(context, context => null), null,
                    (error, assert) => {
                        assert.equals(error.type, 'PortHTTP', 'return joi failure');
                    }),
                commonFunc.createStep('customer.kyc.get', 'get kyc unsuccessfully - kycId string', context => customerParams.getKycParams(context, context => TEXTINPUT), null,
                    (error, assert) => {
                        assert.equals(error.type, 'PortHTTP', 'return joi failure');
                    }),
                commonFunc.createStep('customer.kyc.get', 'get kyc unsuccessfully - kycId empty string', context => customerParams.getKycParams(context, context => ''), null,
                    (error, assert) => {
                        assert.equals(error.type, 'PortHTTP', 'return joi failure');
                    }),
                // MISSING PERMISSIONS
                userMethods.logout('logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('successful login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.kyc.get', 'get kyc unsuccessfully - missing permissions', context => customerParams.getKycParams(context, context =>
                    context['add kyc 1'].kyc[0].kycId), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERKYCGET) > -1, 'Missing permissions for ' + CUSTOMERKYCGET);
                }),
                userMethods.logout('successfully logout new user', (context) => context['successful login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
