const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const documentJoiValidation = require('ut-test/lib/joiValidations/document');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const documentConstants = require('ut-test/lib/constants/document').constants();
const accountJoiValidation = require('ut-test/lib/joiValidations/account');
const userMethods = require('ut-test/lib/methods/user');
const IMEI = commonFunc.generateRandomFixedInteger(15).toString();
const PHONENUMBER = commonFunc.generateRandomFixedInteger(9).toString();
const DOCUMENTNUMBER = documentConstants.DOCUMENTNUMBER.slice(1, 12);
const DOCUMENTNUMBER2 = documentConstants.DOCUMENTNUMBER.slice(5, 14);
const INSTALLATIONID = 'ye7hudhd738qhduqghd29';
const DATEOFBIRTH = customerConstants.DATEOFBIRTH; // random Date > 18 years old
const uri = '/selfregister';
const CHANNELMOBILE = 'mobile';
let customerActorId, customerTypeId, prefixNumber, invalidPrefix;

module.exports = function test({
    config: {
        selfRegisterCustomerAccount = true
    }
}) {
    return {
        selfRegisterCustomer: function(test, bus, run) {
            return run(test, bus, [
                userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                commonFunc.createStep('customerTest.customer.returnAllowPhonePrefix', 'return phone prefix', context => {
                    return {};
                }, (result, assert) => {
                    prefixNumber = result.phonePrefix.phonePrefix;
                    invalidPrefix = 9 + result.phonePrefix.phonePrefix;
                    assert.false(result.phonePrefix === null, 'return null for phone prefix');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + '1self',
                        lastName: customerConstants.LASTNAME,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + PHONENUMBER,
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: IMEI
                        }
                    };
                }, (result, assert) => {
                    customerActorId = result.actorId;
                    assert.equals(result.success, true, 'return success: true');
                }),
                userMethods.loginAdmin('login admin', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('ledger.account.fetch', 'fetch created customer ledger account', (context, util) => {
                    return selfRegisterCustomerAccount ? {
                        filterBy: {
                            ownerId: customerActorId
                        }
                    } : util.skip();
                }, (result, assert) => {
                    assert.true(result.account.length > 0, 'return not empty resultset');
                    assert.equals(accountJoiValidation.validateFetchLedgerAccount(result.account, customerActorId).error, null, 'return ledger account details');
                }),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType.find(customerType => customerType.customerTypeId === customerConstants.INDIVIDUALCUSTOMERTYPEID).customerTypeId;
                }),
                commonFunc.createStep('customer.customer.get', 'Get the newly created customer', (context) => {
                    return {
                        actorId: customerActorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer).error, null, 'return customer details');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME + '1self').error, null, 'return person details');
                    assert.equals(customerJoiValidation.validateGetPhone(result.customerPhone[0], prefixNumber + PHONENUMBER, customerConstants.TYPEIDPERSONAL).error, null, 'return phone details');
                    assert.equals(documentJoiValidation.validateGetDocument(result.documentAttachment).error, null, 'return document attachment details');
                    assert.equals(result.customerAddress[0].lat, customerConstants.LAT.toString(), 'return lat coordinate');
                    assert.equals(result.customerAddress[0].lng, customerConstants.LNG.toString(), 'return lng coordinate');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                }),
                commonFunc.createStep('user.user.get', 'get user hash details of self registered cutomer', (context) => {
                    return {
                        actorId: customerActorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME + '1self').error, null, 'return person');
                    assert.equals(result['user.hash'][0].identifier, prefixNumber + PHONENUMBER, 'return username = customer phone number in user.hash');
                }),
                userMethods.logout('Logout admin user', (context) => context['login admin']['identity.check'].sessionId),
                commonFunc.createStep('identity.check', 'login selfRegistered user', (context) => {
                    return {
                        username: prefixNumber + PHONENUMBER,
                        password: context['self register customer'].token,
                        newPassword: userConstants.ADMINPASSWORD,
                        $http: {uri: userConstants.URI},
                        timezone: userConstants.TIMEZONE,
                        channel: CHANNELMOBILE
                    };
                }, (result, assert) => {
                    // console.log(result);
                    assert.equals(userJoiValidation.validateLogin(result['identity.check']).error, null, 'Return all details after login a user');
                }),
                // commonFunc.createStep('user.secretQuestionAnswer.get', 'get selfRegistered user', (context) => {
                //     return {
                //         actorId: customerActorId
                //     };
                // }, (result, assert) => {
                //     console.log(result);
                // }),
                userMethods.logout('Logout selfRegistered user', (context) => context['login selfRegistered user']['identity.check'].sessionId),
                commonFunc.createStep('identity.check', 'login selfRegistered customer again - trying to change pass and secret question', (context) => {
                    return {
                        username: prefixNumber + PHONENUMBER,
                        password: context['self register customer'].token,
                        newPassword: userConstants.ADMINPASSWORD,
                        $http: {uri: userConstants.URI},
                        timezone: userConstants.TIMEZONE,
                        channel: CHANNELMOBILE
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'identity.invalidCredentials', 'return error - invalid credentials');
                }),
                // commonFunc.createStep('identity.check', 'login selfRegistered customer again - trying to change secret question', (context) => {
                //     return {
                //         username: phoneNumber,
                //         password: userConstants.ADMINPASSWORD,
                //         $http: {uri: userConstants.URI},
                //         timezone: userConstants.TIMEZONE,
                //         channel: CHANNELMOBILE,
                //         secretQuestion: context['self register customer'].secretQuestions[0].itemNameId,
                //         secretAnswer: userConstants.ADMINPASSWORD
                //     };
                // }, null, (error, assert) => {
                //     // console.log(error);
                //     assert.equals(error.type, 'identity.invalidCredentials', 'return error - invalid credentials');
                // }),
                commonFunc.createStep('customer.selfregister', 'self register second customer', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 14,
                        lastName: customerConstants.LASTNAME + 14,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                        documentNumber: DOCUMENTNUMBER + 14,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.success, true, 'return success: true');
                }),
                // commonFunc.createStep('identity.check', 'login second selfRegistered customer - missing secret Question', (context) => {
                //     return {
                //         username: ,
                //         password: context['self register second customer'].token,
                //         newPassword: userConstants.ADMINPASSWORD,
                //         $http: {uri: userConstants.URI},
                //         timezone: userConstants.TIMEZONE,
                //         channel: CHANNELMOBILE,
                //         secretAnswer: userConstants.ADMINPASSWORD
                //     };
                // }, null, (error, assert) => {
                //     // console.log(error);
                //     assert.equals(error.type, 'identity.invalidCredentials', 'return error - invalid credentials');
                // }),
                // commonFunc.createStep('identity.check', 'login second selfRegistered customer - missing secret Answer', (context) => {
                //     return {
                //         username: ,
                //         password: context['self register second customer'].token,
                //         newPassword: userConstants.ADMINPASSWORD,
                //         $http: {uri: userConstants.URI},
                //         timezone: userConstants.TIMEZONE,
                //         channel: CHANNELMOBILE,
                //         secretQuestion: context['self register second customer'].secretQuestions[0].itemNameId
                //     };
                // }, null, (error, assert) => {
                //     // console.log(error);  // add more negative scenarios for secret question and answer
                //     assert.equals(error.type, 'identity.invalidCredentials', 'return error - invalid credentials');
                // }),
                commonFunc.createStep('customer.selfregister', 'self register the same customer again', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 14,
                        lastName: customerConstants.LASTNAME + 14,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.selfAddPersonDuplicate', 'return customer.selfAddPersonDuplicate');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - different customer with the same phoneNumber', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 2,
                        lastName: customerConstants.LASTNAME + 2,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + PHONENUMBER,
                        documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                        documentNumber: DOCUMENTNUMBER,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.selfAddPhoneDuplicate', 'return selfAdd.phone.duplicate');
                }),
                commonFunc.createStep('customer.selfregister', 'self register the same customer data, other phone', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 14,
                        lastName: customerConstants.LASTNAME + 14,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.selfAddPersonDuplicate', 'return selfAdd.person.duplicate');
                }),
                commonFunc.createStep('customer.selfregister', 'self register the same customer data, other phone, imei and document number', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 14,
                        lastName: customerConstants.LASTNAME + 14,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: customerConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER2,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.selfAddPersonDuplicate', 'return selfAdd.person.duplicate');
                }),
                commonFunc.createStep('customer.selfregister', 'self register different customer data, phone and document number, same name and birthdate - female', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 14,
                        lastName: customerConstants.LASTNAME + 14,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERF,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                        documentNumber: DOCUMENTNUMBER2,
                        lat: 14.4973, // customerConstants.LAT,
                        lng: 14.5224, // customerConstants.LNG
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.selfAddPersonDuplicate', 'return selfAdd.person.duplicate');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - no params', (context) => {
                    return {};
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation - no params');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - null params', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: null,
                        lastName: null,
                        dateOfBirth: null,
                        gender: customerConstants.GENDERM,
                        phoneNumber: null,
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: null,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation - null params');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - empty params required', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: '',
                        lastName: '',
                        dateOfBirth: '',
                        gender: customerConstants.GENDERM,
                        phoneNumber: '',
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: '',
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation - empty params');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - empty params non required', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 1,
                        lastName: customerConstants.LASTNAME + 1,
                        dateOfBirth: DATEOFBIRTH,
                        gender: '',
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                        documentNumber: DOCUMENTNUMBER2,
                        countryCode: '',
                        lat: '',
                        lng: '',
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation - empty params');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - no phoneNumber', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME,
                        lastName: customerConstants.LASTNAME,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation - no phoneNumber');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - duplicate IMEI', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 1,
                        lastName: customerConstants.LASTNAME + 1,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 1,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: IMEI
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.selfAddImeiDuplicate', 'return duplicate IMEI');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - missing actorDevice', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 3,
                        lastName: customerConstants.LASTNAME + 3,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 3,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG
                    };
                }, null, (error, assert) => {
                    // console.log(error);
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation - actorDevice is required');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - missing installationId', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 4,
                        lastName: customerConstants.LASTNAME + 4,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 4,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation - installationId is required');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - invalid number installationId', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 5,
                        lastName: customerConstants.LASTNAME + 5,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 5,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: 0,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return installationId must be a string');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - null installationId', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 6,
                        lastName: customerConstants.LASTNAME + 6,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 6,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: null,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return installationId must be a string');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - empty string installationId', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 7,
                        lastName: customerConstants.LASTNAME + 7,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 7,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: '',
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return installationId is not allowed to be empty');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - missing imei', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 8,
                        lastName: customerConstants.LASTNAME + 8,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 8,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation - imei is required');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - invalid number imei', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 9,
                        lastName: customerConstants.LASTNAME + 9,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 9,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: 0
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation - imei must be a string');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - null imei', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 10,
                        lastName: customerConstants.LASTNAME + 10,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 10,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: null
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation - imei must be a string');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - empty string imei', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 11,
                        lastName: customerConstants.LASTNAME + 11,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 11,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: ''
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation - imei is not allowed to be empty');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - string imei', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 12,
                        lastName: customerConstants.LASTNAME + 12,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 12,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: customerConstants.FIRSTNAME
                        }
                    };
                }, null, (error, assert) => {
                    // console.log(error);
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation -');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - string imei with less num', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 12,
                        lastName: customerConstants.LASTNAME + 12,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 12,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(14).toString() // 14 digit
                        }
                    };
                }, null, (error, assert) => {
                    // console.log(error);
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation -');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - string imei with more num', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 13,
                        lastName: customerConstants.LASTNAME + 13,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 13,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(17).toString() // 17 digit
                        }
                    };
                }, null, (error, assert) => {
                    // console.log(error);
                    assert.equals(error.type, 'PortHTTP', 'return joivalidation -');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer - phoneNumber wih wrong prefix', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME + 15,
                        lastName: customerConstants.LASTNAME + 15,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: invalidPrefix + commonFunc.generateRandomFixedInteger(9).toString(),
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER + 15,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: commonFunc.generateRandomFixedInteger(15).toString()
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.unsupportedPhoneNumber', 'return unsupported prefix');
                })
            ]);
        }
    };
};
