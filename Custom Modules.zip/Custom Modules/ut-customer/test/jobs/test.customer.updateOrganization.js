const commonFunc = require('ut-test/lib/methods/commonFunc');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const customerMethods = require('ut-test/lib/methods/customer');
const USERNAME = 'updateOrg' + userConstants.USERNAME;
const ROLENAME = userConstants.ROLENAME;
const ROLEDESCRIPTION = userConstants.ROLEDESCRIPTION;
const ROLENAME2 = ROLENAME + '-2';
const ROLEDESCRIPTION2 = ROLEDESCRIPTION + '-2';
const ORGNAME = customerConstants.ORGNAME;
const ORGNAME2 = ORGNAME + '-2';
const ORGNAME3 = ORGNAME + '-3';
const CODE = commonFunc.generateRandomNumber().toString();
const EXECOFFICER = 'Test executive Officer';
const TRADENAME = 'Some random trade name';
const CAPITAL = customerConstants.CITY1;
const VALIDADDRESS = 'Champs-Élysées, Paris, France';
const VALIDPHONENUBER = (customerConstants.PHONENUMBER).slice(10);
const EMAIL = customerConstants.EMAIL;
const NEWORGNAME = 'new ' + ORGNAME;
const NEWCODE = commonFunc.generateRandomNumber().toString();
const NEWEXECOFFICER = 'new ' + EXECOFFICER;
const NEWTRADENAME = 'new ' + TRADENAME;
const NEWEMAILTYPEID = 'work';
const NEWEMAIL = 'new' + EMAIL;
const NEWCAPITAL = 'COPENHAGEN';
const NEWCURRENCY = 'EUR';
const NEWTIMEZONE = 'GMT+1';
const NEWPRIMARYLANG = '2'; // 2- French
const NEWVALIDPHONENUBER = (customerConstants.NEWPHONENUMBER).slice(10);
const NEWVALIDADDRESS = 'Stroget, Copenhagen, Denmark';
const WRONGORGNAME = commonFunc.generateRandomChars('ABCDEFGHDKJAHKDHKAJHDKH@#$%^&*()_+123456987', 10);
const WRONGEXECOFFICER = commonFunc.generateRandomChars('ABCDEFGHDKJAHKDHKAJHDKH@#$%^&*()_+123456987', 10);
const WRONGTRADENAME = commonFunc.generateRandomChars('ABCDEFGHDKJAHKDHKAJHDKH@#$%^&*()_+123456987', 10);
const WRONGCODE = 'wrong code';
const WRONGCAPITAL = 'wrong capital';
const WRONGCURRENCY = 'wrong currency';
const WRONGTIMEZONE = commonFunc.generateRandomChars('ABCDEFGHDKJAHKDHKAJHDKH@#$%^&*()_+123456987', 4);
const WRONGPRIMARYLANG = commonFunc.generateRandomChars('ABCDEFGHDKJAHKDHKAJHDKH@#$%^&*()_+123456987', 2);
const VERYLONGORGNAME = 'verrrrrrrrrrrrrrrrryyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy looooooooooooooooooooooooooooooooooooonggggggggggggggggggggggggggggg naaaaaaaaaaaaaaaaaaaaaaaaaaaaammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmme';
const NOTPHONETYPEIDWORK = 'not valid type id';
const NOTADDRESSTYPEIDHOME = 'not valid type id';
const WRONGPHONENUBER = commonFunc.generateRandomChars('ABCDEFGHDKJAHKDHKAJHDKH@#$%^&*()_+123456987', 8);
const WRONGADDRESS = commonFunc.generateRandomChars('ABCDEFGHDKJAHKDHKAJHDKH@#$%^&*()_+123456987', 14);
const CUSTOMERORGANIZATIONEDIT = 'customer.organization.edit';
const COUNTRYID = 33;
const WRONGCOUNTRYID = 'wrong country ID ';
let stdPolicy, updateOrgActionId, phoneId1, phoneId2, addressId1;

module.exports = function test() {
    return {
        updateOrganization: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('user.user.get', 'get admin details', (context) => {
                    return {
                        actorId: context.login.person.actorId
                    };
                }, (result, assert) => {
                    // saOrganization = result.memberOF[0].organizationName;
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, userConstants.ADMINFIRSTNAME).error, null, 'Return all detals after get user');
                }),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                userMethods.addRole('add role successfully', (context) => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, ROLENAME, ROLEDESCRIPTION),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                userMethods.addRole('add role 2 successfully', (context) => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, ROLENAME2, ROLEDESCRIPTION2),
                userMethods.approveRole('approve role 2', context => context['add role 2 successfully'].role[0].actorId),
                userMethods.addRole('add role 3 successfully', (context) => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, ROLENAME + 3, ROLEDESCRIPTION + 3),
                userMethods.approveRole('approve role 3', context => context['add role 3 successfully'].role[0].actorId),
                userMethods.addRole('add role with permissions', (context) => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, ROLENAME + 'perm', ROLEDESCRIPTION + 'perm'),
                userMethods.approveRole('approve role 3', context => context['add role with permissions'].role[0].actorId),
                // get system roles
                commonFunc.createStep('user.actionCategory.fetch', 'fetch system roles', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(userJoiValidation.validateFetchSystemCategories(result.categories).error, null, 'return all details for fetch system role categories');
                    assert.equals(userJoiValidation.validateFetchSystemRoles(result.actions).error, null, 'return all details for fetch system roles');
                    const updateOrg = result.actions.find(
                        (action) => (action.actionName).toString().toLowerCase().indexOf(('Edit Business Unit').toLowerCase()) > -1
                    );
                    updateOrgActionId = updateOrg.actionId;
                }),
                commonFunc.createStep('user.actorAction.update', 'Grant role successfully - object user', (context) => {
                    return {
                        actorHierarchy: [{
                            subject: context['add role with permissions'].role[0].actorId,
                            object: updateOrgActionId
                        }]
                    };
                }, (result, assert) => {
                    assert.true(result.length === 0, 'return emtpy array');
                }),
                commonFunc.createStep('customer.organization.add', 'add new organization', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME,
                            isEnabled: 1
                        },
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME, 'return organizationName');
                }),
                customerMethods.approveOrganization('approve add new organization', (context) => context['add new organization']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.add', 'add new organization 2', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME2,
                            isEnabled: 1
                        },
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME2, 'return organizationName');
                }),
                customerMethods.approveOrganization('approve add new organization 2', (context) => context['add new organization 2']['organization.info'][0].actorId),
                // add user 1 - member of main org
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                // add user 2 - member of main org
                userMethods.addUser('add new user 2', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        roles: [context['add role with permissions'].role[0].actorId],
                        defaultRoleId: context['add role with permissions'].role[0].actorId,
                        policyId: stdPolicy,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME + 2),
                userMethods.approveUser('approve user 2', context => context['add new user 2'].person.actorId),
                commonFunc.createStep('customer.organization.add', 'add organization - all details', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME3,
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: CAPITAL,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0
                        },
                        roles: [context['add role successfully'].role[0].actorId],
                        parent: [context['add new organization 2']['organization.info'][0].actorId],
                        email: [{
                            emailTypeId: customerConstants.TYPEIDWORK,
                            value: EMAIL
                        }],
                        phone: [{
                            phoneTypeId: customerConstants.TYPEIDWORK,
                            phoneNumber: VALIDPHONENUBER
                        }],
                        address: [{
                            value: VALIDADDRESS,
                            addressTypeId: customerConstants.TYPEIDHOME
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME3, 'return organizationName');
                    assert.equals(result['organization.info'][0].code, CODE.toString(), 'return code');
                    assert.equals(result['organization.info'][0].executiveOfficer, EXECOFFICER, 'return executiveOfficer');
                    assert.equals(result['organization.info'][0].tradeName, TRADENAME, 'return tradename');
                    assert.equals(result['organization.info'][0].capital, CAPITAL, 'return capital');
                    assert.equals(result['organization.info'][0].currency, customerConstants.CURRENCYBG, 'return currency');
                    assert.equals(result['organization.info'][0].timeZone, userConstants.TIMEZONE, 'return timezone');
                    assert.equals(result['organization.info'][0].primaryLanguageId, userConstants.LANGUAGEID, 'return primaryLanguageId');
                }),
                customerMethods.approveOrganization('approve add organization - all details', (context) => context['add organization - all details']['organization.info'][0].actorId),
                // get organization
                commonFunc.createStep('customer.organization.get', 'get added organization', (context) => {
                    return {
                        actorId: context['add organization - all details']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetAddress(result['organization.address'][0], VALIDADDRESS, customerConstants.TYPEIDHOME).error, null, 'Return all details after getting organization address');
                    assert.equals(customerJoiValidation.validateGetPhone(result['organization.phone'][0], VALIDPHONENUBER, customerConstants.TYPEIDWORK).error, null, 'Return all details after getting organization phone');
                    assert.equals(customerJoiValidation.validateGetEmail(result['organization.email'][0], EMAIL, customerConstants.TYPEIDWORK).error, null, 'Return all details after getting organization email');
                    assert.equals(result['organization.parents'][0].organizationName, ORGNAME2, 'return parent organization');
                    assert.equals(result['organization.roles'][0].name, ROLENAME, 'return organization role');
                }),
                // edit organization
                commonFunc.createStep('customer.organization.edit', 'update organization - recursion', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME,
                            code: NEWCODE,
                            executiveOfficer: NEWEXECOFFICER,
                            tradeName: NEWTRADENAME,
                            capital: NEWCAPITAL,
                            currency: NEWCURRENCY,
                            timeZone: NEWTIMEZONE,
                            primaryLanguageId: NEWPRIMARYLANG,
                            isEnabled: 1
                        },
                        grantedRoles: [context['add role 2 successfully'].role[0].actorId],
                        revokedRoles: [context['add role successfully'].role[0].actorId],
                        parentsAdded: [context['add new organization']['organization.info'][0].actorId, context['get admin details'].memberOF[0].object],
                        parentsRemoved: [context['add new organization 2']['organization.info'][0].actorId],
                        email: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            emailTypeId: NEWEMAILTYPEID,
                            value: NEWEMAIL
                        }],
                        phone: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            phoneTypeId: customerConstants.TYPEIDHOME,
                            phoneNumber: NEWVALIDPHONENUBER,
                            isPrimary: 1
                        }],
                        address: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            value: NEWVALIDADDRESS,
                            addressTypeId: customerConstants.TYPEIDWORK
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.recursion', 'return customer.recursion');
                }),
                // add organization - child of org 2
                customerMethods.addOrganization('add organization 3 - child of org2', (context) => {
                    return {
                        parent: [context['add organization - all details']['organization.info'][0].actorId]
                    };
                }, NEWORGNAME + 'CHILD'),
                // approve org
                customerMethods.approveOrganization('approve child org', (context) => context['add organization 3 - child of org2']['organization.info'][0].actorId),
                // edit org 2 add parent - child => recursion
                commonFunc.createStep('customer.organization.edit', 'update organization - recursion 2', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME,
                            code: NEWCODE,
                            executiveOfficer: NEWEXECOFFICER,
                            tradeName: NEWTRADENAME,
                            capital: NEWCAPITAL,
                            currency: NEWCURRENCY,
                            timeZone: NEWTIMEZONE,
                            primaryLanguageId: NEWPRIMARYLANG,
                            isEnabled: 1
                        },
                        grantedRoles: [context['add role 2 successfully'].role[0].actorId],
                        revokedRoles: [context['add role successfully'].role[0].actorId],
                        parentsAdded: [context['add organization 3 - child of org2']['organization.info'][0].actorId],
                        parentsRemoved: [context['add new organization 2']['organization.info'][0].actorId],
                        email: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            emailTypeId: NEWEMAILTYPEID,
                            value: NEWEMAIL
                        }],
                        phone: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            phoneTypeId: customerConstants.TYPEIDHOME,
                            phoneNumber: NEWVALIDPHONENUBER,
                            isPrimary: 1
                        }],
                        address: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            value: NEWVALIDADDRESS,
                            addressTypeId: customerConstants.TYPEIDWORK
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.recursion', 'return customer.recursion');
                }),
                commonFunc.createStep('customer.organization.edit', 'update organization successfully - all params', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME,
                            code: NEWCODE,
                            executiveOfficer: NEWEXECOFFICER,
                            tradeName: NEWTRADENAME,
                            capital: NEWCAPITAL,
                            currency: NEWCURRENCY,
                            timeZone: NEWTIMEZONE,
                            primaryLanguageId: NEWPRIMARYLANG,
                            isEnabled: 1
                        },
                        grantedRoles: [context['add role 2 successfully'].role[0].actorId],
                        revokedRoles: [context['add role successfully'].role[0].actorId],
                        parentsAdded: [context['add new organization']['organization.info'][0].actorId],
                        parentsRemoved: [context['add new organization 2']['organization.info'][0].actorId],
                        email: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            emailTypeId: NEWEMAILTYPEID,
                            value: NEWEMAIL
                        }],
                        phone: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            phoneTypeId: customerConstants.TYPEIDHOME,
                            phoneNumber: NEWVALIDPHONENUBER,
                            isPrimary: 1
                        }],
                        address: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            value: NEWVALIDADDRESS,
                            addressTypeId: customerConstants.TYPEIDWORK
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditOrganization(result.organization[0]).error, null, 'return all details after editing the organization');
                    assert.equals(result.organization[0].organizationName, NEWORGNAME, 'return organizationName');
                    assert.equals(result.organization[0].code, NEWCODE, 'return code');
                    assert.equals(result.organization[0].executiveOfficer, NEWEXECOFFICER, 'return executiveOfficer');
                    assert.equals(result.organization[0].tradeName, NEWTRADENAME, 'return tradename');
                    assert.equals(result.organization[0].capital, NEWCAPITAL, 'return capital');
                    assert.equals(result.organization[0].currency, NEWCURRENCY, 'return currency');
                    assert.equals(result.organization[0].timeZone, NEWTIMEZONE, 'return timezone');
                    assert.equals(result.organization[0].primaryLanguageId, NEWPRIMARYLANG, 'return primaryLanguageId');
                }),
                customerMethods.approveOrganization('approve update organization successfully - all params', (context) => context['add organization - all details']['organization.info'][0].actorId),
                // get organization
                commonFunc.createStep('customer.organization.get', 'get editted organization - all params', (context) => {
                    return {
                        actorId: context['add organization - all details']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    phoneId1 = result['organization.phone'][0].phoneId;
                    addressId1 = result['organization.address'][0].addressId;
                    assert.equals(customerJoiValidation.validateGetAddress(result['organization.address'][0], NEWVALIDADDRESS, customerConstants.TYPEIDWORK).error, null, 'Return all details after getting organization address');
                    assert.equals(customerJoiValidation.validateGetPhone(result['organization.phone'][0], NEWVALIDPHONENUBER, customerConstants.TYPEIDHOME).error, null, 'Return all details after getting organization phone');
                    assert.equals(customerJoiValidation.validateGetEmail(result['organization.email'][0], NEWEMAIL, customerConstants.TYPEIDWORK).error, null, 'Return all details after getting organization email');
                    assert.equals(result['organization.roles'][0].name, ROLENAME2, 'return organization role');
                }),
                // edit org - phone and address only
                commonFunc.createStep('customer.organization.edit', 'update organization successfully - phone and address only', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME
                        },
                        phone: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            phoneId: context['get editted organization - all params']['organization.phone'][0].phoneId,
                            phoneTypeId: customerConstants.TYPEIDWORK,
                            phoneNumber: VALIDPHONENUBER,
                            statusId: customerConstants.STATUSIDACTIVE,
                            isPrimary: 1
                        }, {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            phoneTypeId: customerConstants.TYPEIDHOME,
                            phoneNumber: NEWVALIDPHONENUBER,
                            statusId: customerConstants.STATUSIDACTIVE,
                            isPrimary: 0
                        }],
                        address: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            addressId: context['get editted organization - all params']['organization.address'][0].addressId,
                            value: NEWVALIDADDRESS + ' - editted',
                            addressTypeId: customerConstants.TYPEIDHOME,
                            statusId: customerConstants.STATUSIDACTIVE
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditOrganization(result.organization[0]).error, null, 'return all details after editing the organization');
                }),
                customerMethods.approveOrganization('approve update organization successfully - phone and address only', (context) => context['add organization - all details']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get editted organization - phone and address', (context) => {
                    return {
                        actorId: context['add organization - all details']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    const arr = result['organization.phone'];
                    const phoneId2Record = arr.find(
                        (el) => el.phoneTypeId === customerConstants.TYPEIDHOME && el.phoneNumber === NEWVALIDPHONENUBER
                    );
                    phoneId2 = phoneId2Record.phoneId;
                    assert.true(phoneId2Record, 'return second phone record');
                    assert.true(arr.find(
                        (el) => el.phoneId === phoneId1 && el.phoneNumber === VALIDPHONENUBER
                    ), 'return updated phone record');
                    assert.equals(customerJoiValidation.validateGetAddress(result['organization.address'][0], NEWVALIDADDRESS + ' - editted', customerConstants.TYPEIDHOME).error, null, 'Return all details after getting organization address');
                }),
                /**
                 * NEGATIVE
                 */
                // edit org - phone and address only - wrong params
                commonFunc.createStep('customer.organization.edit', 'update organization unsuccessfully - phone and address only - wrong params', (context) => {
                    return {
                        aorganization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME
                        },
                        phone: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            phoneId: phoneId2,
                            phoneTypeId: NOTPHONETYPEIDWORK,
                            phoneNumber: WRONGPHONENUBER
                        }],
                        address: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            addressId: addressId1,
                            value: WRONGADDRESS,
                            addressTypeId: NOTADDRESSTYPEIDHOME
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // edit org - phone and address only - missing params
                commonFunc.createStep('customer.organization.edit', 'update organization unsuccessfully - phone and address only - missing typeId', (context) => {
                    return {
                        phone: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            phoneNumber: customerConstants.TYPEIDWORK
                        },
                        address: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            value: NEWVALIDADDRESS
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // edit org - phone and address only - empty params
                commonFunc.createStep('customer.organization.edit', 'update organization unsuccessfully - phone and address only - empty params', (context) => {
                    return {
                        phone: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            phoneNumber: '',
                            phoneTypeId: ''
                        },
                        address: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            value: '',
                            addressTypeId: ''
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // edit org - phone and address only - empty values
                commonFunc.createStep('customer.organization.edit', 'update organization unsuccessfully - phone and address only - empty values', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME
                        },
                        phone: [{
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            phoneId: phoneId1,
                            phoneTypeId: customerConstants.TYPEIDWORK,
                            phoneNumber: '',
                            statusId: customerConstants.STATUSIDACTIVE
                        }, {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            phoneId: phoneId2,
                            phoneTypeId: customerConstants.TYPEIDHOME,
                            phoneNumber: '',
                            statusId: customerConstants.STATUSIDACTIVE
                        }],
                        address: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            addressId: addressId1,
                            value: '',
                            addressTypeId: customerConstants.TYPEIDHOME,
                            statusId: customerConstants.STATUSIDACTIVE
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // edit org - only parent
                commonFunc.createStep('customer.organization.edit', 'update organization successfully - parent only', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME,
                            code: NEWCODE,
                            executiveOfficer: NEWEXECOFFICER,
                            tradeName: NEWTRADENAME,
                            capital: NEWCAPITAL,
                            currency: NEWCURRENCY,
                            timeZone: NEWTIMEZONE,
                            primaryLanguageId: NEWPRIMARYLANG,
                            isEnabled: 1
                        },
                        parentsAdded: [context['add new organization 2']['organization.info'][0].actorId],
                        parentsRemoved: [context['add new organization']['organization.info'][0].actorId]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditOrganization(result.organization[0]).error, null, 'return all details after editing the organization');
                    assert.equals(result.organization[0].organizationName, NEWORGNAME, 'return organizationName');
                }),
                customerMethods.approveOrganization('approve update organization successfully - parent only', (context) => context['add organization - all details']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.add', 'add new organization', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME,
                            isEnabled: 1
                        },
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME, 'return organizationName');
                }),
                customerMethods.approveOrganization('approve add new organization', (context) => context['add new organization']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.add', 'add locked organization', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME2,
                            isEnabled: 0
                        },
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME2, 'return organizationName');
                }),
                // edit org - locked  parent
                commonFunc.createStep('customer.organization.edit', 'update organization- parent locked', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME,
                            code: NEWCODE,
                            executiveOfficer: NEWEXECOFFICER,
                            tradeName: NEWTRADENAME,
                            capital: NEWCAPITAL,
                            currency: NEWCURRENCY,
                            timeZone: NEWTIMEZONE,
                            primaryLanguageId: NEWPRIMARYLANG,
                            isEnabled: 1
                        },
                        parentsAdded: [context['add locked organization']['organization.info'][0].actorId]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.securityViolation', 'return customer.disabledOrDeletedOrganization');
                }),
                commonFunc.createStep('customer.organization.get', 'get editted organization - parent', (context) => {
                    return {
                        actorId: context['add organization - all details']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result['organization.parents'][0].organizationName, ORGNAME2, 'return parent organization');
                }),
                // edit org - only parent
                commonFunc.createStep('customer.organization.edit', 'update organization unsuccessfully - parent only', (context) => {
                    return {
                        parentsAdded: [context['add new organization 2']['organization.info'][0].actorId],
                        parentsRemoved: [context['add new organization']['organization.info'][0].actorId]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.securityViolation', 'return customer.disabledOrDeletedOrganization');
                }),
                // edit org - only roles
                commonFunc.createStep('customer.organization.edit', 'update organization successfully - roles only', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME,
                            code: NEWCODE,
                            executiveOfficer: NEWEXECOFFICER,
                            tradeName: NEWTRADENAME,
                            capital: NEWCAPITAL,
                            currency: NEWCURRENCY,
                            timeZone: NEWTIMEZONE,
                            primaryLanguageId: NEWPRIMARYLANG,
                            isEnabled: 1
                        },
                        grantedRoles: [context['add role successfully'].role[0].actorId],
                        revokedRoles: [context['add role 2 successfully'].role[0].actorId]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditOrganization(result.organization[0]).error, null, 'return all details after editing the organization');
                    assert.equals(result.organization[0].organizationName, NEWORGNAME, 'return organizationName');
                }),
                customerMethods.approveOrganization('approve update organization successfully - roles only', (context) => context['add organization - all details']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get editted organization - roles', (context) => {
                    return {
                        actorId: context['add organization - all details']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after editting the organization');
                    assert.equals(result['organization.roles'][0].name, ROLENAME, 'return role name');
                }),
                // edit org - only roles
                commonFunc.createStep('customer.organization.edit', 'update organization unsuccessfully - grant not visible role', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME,
                            code: NEWCODE,
                            executiveOfficer: NEWEXECOFFICER,
                            tradeName: NEWTRADENAME,
                            capital: NEWCAPITAL,
                            currency: NEWCURRENCY,
                            timeZone: NEWTIMEZONE,
                            primaryLanguageId: NEWPRIMARYLANG,
                            isEnabled: 1
                        },
                        grantedRoles: [context['add role 3 successfully'].role[0].actorId],
                        revokedRoles: [context['add role successfully'].role[0].actorId]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditOrganization(result.organization[0]).error, null, 'return all details after editing the organization');
                }),
                customerMethods.approveOrganization('approve update organization unsuccessfully - grant not visible role', (context) => context['add organization - all details']['organization.info'][0].actorId),
                // edit org - only roles
                commonFunc.createStep('customer.organization.edit', 'update organization unsuccessfully - only roles', (context) => {
                    return {
                        grantedRoles: context['add role 2 successfully'].role[0].actorId,
                        revokedRoles: context['add role successfully'].role[0].actorId
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // edit org - only organization info
                commonFunc.createStep('customer.organization.edit', 'update organization successfully - organization info only', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME + ' editted',
                            code: NEWCODE + '3',
                            executiveOfficer: NEWEXECOFFICER + ' editted',
                            tradeName: NEWTRADENAME + ' editted',
                            capital: NEWCAPITAL,
                            currency: NEWCURRENCY,
                            timeZone: NEWTIMEZONE,
                            primaryLanguageId: NEWPRIMARYLANG,
                            isEnabled: 1,
                            countryId: COUNTRYID
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditOrganization(result.organization[0]).error, null, 'return all details after editing the organization');
                    assert.equals(result.organization[0].organizationName, NEWORGNAME + ' editted', 'return organizationName');
                    assert.equals(result.organization[0].code, (NEWCODE + '3').toString(), 'return code');
                    assert.equals(result.organization[0].executiveOfficer, NEWEXECOFFICER + ' editted', 'return executiveOfficer');
                    assert.equals(result.organization[0].tradeName, NEWTRADENAME + ' editted', 'return tradename');
                    assert.equals(result.organization[0].capital, NEWCAPITAL, 'return capital');
                    assert.equals(result.organization[0].currency, NEWCURRENCY, 'return currency');
                    assert.equals(result.organization[0].timeZone, NEWTIMEZONE, 'return timezone');
                    assert.equals(result.organization[0].primaryLanguageId, NEWPRIMARYLANG, 'return primaryLanguageId');
                    assert.equals(result.organization[0].countryId, COUNTRYID, 'return countryId');
                }),
                customerMethods.approveOrganization('approve update organization successfully - organization info only', (context) => context['add organization - all details']['organization.info'][0].actorId),
                // edit org - missing params
                commonFunc.createStep('customer.organization.edit', 'update organization - missing params', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // edit org - missing params + org name
                commonFunc.createStep('customer.organization.edit', 'update organization - correct org name & missing params', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: ORGNAME3 + ' editted'
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditOrganization(result.organization[0]).error, null, 'return all details after editing the organization');
                    assert.equals(result.organization[0].organizationName, ORGNAME3 + ' editted', 'return organizationName');
                    assert.equals(result.organization[0].code, null, 'return code - null');
                    assert.equals(result.organization[0].executiveOfficer, null, 'return executiveOfficer - null');
                    assert.equals(result.organization[0].tradeName, null, 'return tradename - null');
                    assert.equals(result.organization[0].capital, null, 'return capital - null');
                    assert.equals(result.organization[0].currency, null, 'return currency - null');
                    assert.equals(result.organization[0].timeZone, null, 'return timezone - null');
                    assert.equals(result.organization[0].primaryLanguageId, null, 'return primaryLanguageId - null');
                    assert.equals(result.organization[0].countryId, null, 'return countryId');
                }),
                // edit org - empty params
                customerMethods.approveOrganization('approve update organization - correct org name & missing params', (context) => context['add organization - all details']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.edit', 'update organization successfully - empty string params', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: '',
                            code: '',
                            executiveOfficer: '',
                            tradeName: '',
                            capital: '',
                            currency: '',
                            timeZone: '',
                            primaryLanguageId: '',
                            isEnabled: 1
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // edit org - empty params
                commonFunc.createStep('customer.organization.edit', 'update organization - empty string params + countryId empty', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: '',
                            code: '',
                            executiveOfficer: '',
                            tradeName: '',
                            capital: '',
                            currency: '',
                            timeZone: '',
                            primaryLanguageId: '',
                            isEnabled: 1,
                            countryId: ''
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // edit org - null params
                commonFunc.createStep('customer.organization.edit', 'update organization - null paramas', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: null,
                            code: null,
                            executiveOfficer: null,
                            tradeName: null,
                            capital: null,
                            currency: null,
                            timeZone: null,
                            primaryLanguageId: null,
                            isEnabled: 1,
                            countryId: null
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // edit org - null params
                commonFunc.createStep('customer.organization.edit', 'correct org name, null params and missing isEnabled', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: ORGNAME3,
                            code: null,
                            executiveOfficer: null,
                            tradeName: null,
                            capital: null,
                            currency: null,
                            timeZone: null,
                            primaryLanguageId: null,
                            countryId: null
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditOrganization(result.organization[0]).error, null, 'return all details after editing the organization');
                    assert.equals(result.organization[0].organizationName, ORGNAME3, 'return organizationName');
                    assert.equals(result.organization[0].code, null, 'return code - null');
                    assert.equals(result.organization[0].executiveOfficer, null, 'return executiveOfficer - null');
                    assert.equals(result.organization[0].tradeName, null, 'return tradename - null');
                    assert.equals(result.organization[0].capital, null, 'return capital - null');
                    assert.equals(result.organization[0].currency, null, 'return currency - null');
                    assert.equals(result.organization[0].timeZone, null, 'return timezone - null');
                    assert.equals(result.organization[0].primaryLanguageId, null, 'return primaryLanguageId - null');
                    assert.equals(result.organization[0].countryId, null, 'return countryId - null');
                }),
                customerMethods.approveOrganization('approve correct org name, null params and missing isEnabled', (context) => context['add organization - all details']['organization.info'][0].actorId),
                // edit org - wrong params
                commonFunc.createStep('customer.organization.edit', 'update organization successfully - wrong params', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: WRONGORGNAME,
                            code: WRONGCODE,
                            executiveOfficer: WRONGEXECOFFICER,
                            tradeName: WRONGTRADENAME,
                            capital: WRONGCAPITAL,
                            currency: WRONGCURRENCY,
                            timeZone: WRONGTIMEZONE,
                            primaryLanguageId: WRONGPRIMARYLANG,
                            isEnabled: 1,
                            countryId: WRONGCOUNTRYID
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return failure type');
                }),
                // edit org - very long org name
                commonFunc.createStep('customer.organization.edit', 'update organization successfully - very long org name', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization - all details']['organization.info'][0].actorId,
                            organizationName: VERYLONGORGNAME,
                            code: NEWCODE,
                            executiveOfficer: NEWEXECOFFICER,
                            tradeName: NEWTRADENAME,
                            capital: NEWCAPITAL,
                            currency: NEWCURRENCY,
                            timeZone: NEWTIMEZONE,
                            primaryLanguageId: NEWPRIMARYLANG,
                            isEnabled: 1
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'portSQL', 'return failure type');
                }),
                userMethods.logout('Logout admin user', (context) => context.login['identity.check'].sessionId),
                /**
                 * MISSING PERMISSIONS
                 */
                userMethods.login('Successful login user 1', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.edit', 'update organization successfully - no permissions', (context) => {
                    return {
                        organization: {
                            actorId: context['add new organization']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME + ' editted',
                            code: NEWCODE,
                            isEnabled: 1
                        }
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERORGANIZATIONEDIT) > -1, 'Missing permissions for ' + CUSTOMERORGANIZATIONEDIT);
                }),
                userMethods.logout('Successful logout user 1', (context) => context['Successful login user 1']['identity.check'].sessionId),
                /**
                 * LOGIN USER 2
                 */
                userMethods.login('Successful login user 2', USERNAME + 2, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.edit', 'update organization successfully - as user 2', (context) => {
                    return {
                        organization: {
                            actorId: context['add new organization']['organization.info'][0].actorId,
                            organizationName: NEWORGNAME + ' editted',
                            code: NEWCODE,
                            isEnabled: 1
                        },
                        grantedRoles: [context['add role 2 successfully'].role[0].actorId, context['add role successfully'].role[0].actorId]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditOrganization(result.organization[0]).error, null, 'return all details after editing the organization');
                    assert.equals(result.organization[0].organizationName, NEWORGNAME + ' editted', 'return organizationName');
                    assert.equals(result.organization[0].code, NEWCODE.toString(), 'return code');
                }),
                commonFunc.createStep('customer.organization.get', 'get edited organization - roles', (context) => {
                    return {
                        actorId: context['add new organization']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after editting the organization');
                    assert.true(result['organization.rolesUnapproved'].find(organization => organization.name === ROLENAME), 'return role name');
                    assert.true(result['organization.rolesUnapproved'].find(organization => organization.name === ROLENAME2), 'return role name');
                }),
                userMethods.logout('Successful logout user 2', (context) => context['Successful login user 2']['identity.check'].sessionId)
            ]);
        }
    };
};
