const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const USERNAME = 'addOrg' + userConstants.USERNAME;
const customerMethods = require('ut-test/lib/methods/customer');
const VALIDADDRESS = 'Champs-Élysées, Paris, France';
const CODE = commonFunc.generateRandomNumber().toString();
const VALIDPHONENUBER = customerConstants.PHONENUMBER.slice(6);
const EMAIL = commonFunc.generateRandomEmail();
const TRADENAME = 'SOme random trade name';
const EXECOFFICER = 'Test executive Officer';
const ROLENAME = userConstants.ROLENAME;
const ROLEDESCRIPTION = userConstants.ROLEDESCRIPTION;
// const ORGNAME = customerConstants.ORGNAME;
const ERRTYPE1 = 'portSQL';
const CBSIDNONEX = 999999;
const RANDOMCOUNTRY = 'Iceland';
const COUNTRYID = 33;
const RANDOMCOUNTRYID = commonFunc.generateRandomNumber().toString().slice(7);
const CUSTOMERORGANIZATIONADD = 'customer.organization.add';
let stdPolicy;

module.exports = function test() {
    return {
        addOrganization: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                // fetch std input policy
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                userMethods.addRole('add role successfully', context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                commonFunc.createStep('customer.organization.add', 'add parent organization successfully', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME + 'PARENT ORGANIZATION',
                            isEnabled: 0,
                            isDeleted: 0
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, customerConstants.ORGNAME + 'PARENT ORGANIZATION', 'return organizationName');
                }),
                commonFunc.createStep('customer.organization.add', 'add organization to locked org', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME + 'PARENT ORGANIZATION',
                            isEnabled: 0,
                            isDeleted: 0
                        },
                        parent: [context['add parent organization successfully']['organization.info'][0].actorId]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.disabledOrDeletedOrganization', 'locked parent org');
                }),
                commonFunc.createStep('customer.organization.add', 'add organization data not single', (context) => {
                    return {
                        organization: [{
                            organizationName: customerConstants.ORGNAME + 'PARENT ORGANIZATION',
                            isEnabled: 1,
                            isDeleted: 0
                        }, {
                            organizationName: customerConstants.ORGNAME + 'PARENT ORGANIZATION',
                            isEnabled: 1,
                            isDeleted: 0
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - organization cannot be array');
                }),
                commonFunc.createStep('customer.organization.add', 'add org 1 successfully', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME
                        },
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, customerConstants.ORGNAME, 'return organizationName');
                }),
                customerMethods.approveOrganization('approve organization 1', context => context['add org 1 successfully']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.add', 'add org 2 successfully', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME + 2
                        },
                        parent: [context['add org 1 successfully']['organization.info'][0].actorId]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, customerConstants.ORGNAME + 2, 'return organizationName');
                }),
                customerMethods.approveOrganization('approve organization 2', context => context['add org 2 successfully']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.add', 'add organization - recursion', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME + 2
                        },
                        parent: [context['add org 1 successfully']['organization.info'][0].actorId, context['get admin details'].memberOF[0].object]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.recursion', 'return customer.recursion');
                }),
                commonFunc.createStep('core.cbs.fetch', 'fetch CBS', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.true(typeof result, 'object', 'return result');
                }), {
                    name: 'CBS tests',
                    params: (context, utils) => {
                        if (context['fetch CBS'].cbs.length === 0) {
                            return utils.skip();
                        }
                    },
                    steps: () => [commonFunc.createStep('customer.organization.add', 'add parent organization - to test CBS', (context) => {
                        return {
                            organization: {
                                organizationName: customerConstants.ORGNAME + ' TEST CBS ',
                                isEnabled: 1,
                                isDeleted: 0,
                                cbsId: customerConstants.CBSID
                            }
                        };
                    }, (result, assert) => {
                        assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                        assert.equals(result['organization.info'][0].organizationName, customerConstants.ORGNAME + ' TEST CBS ', 'return organizationName');
                        assert.equals(result['organization.info'][0].cbsId, customerConstants.CBSID, 'return correct cbsId');
                        assert.equals(result['organization.info'][0].cbsName, customerConstants.CBSNAME, 'return correct cbsName');
                    }),
                    commonFunc.createStep('customer.organization.add', 'add organization with cbs empty string', (context) => {
                        return {
                            organization: [{
                                organizationName: customerConstants.ORGNAME + 'PARENT ORGANIZATION',
                                isEnabled: 1,
                                isDeleted: 0,
                                cbsId: ''
                            }]
                        };
                    }, null, (error, assert) => {
                        assert.equals(error.type, 'PortHTTP', 'return joi failure');
                    }),
                    commonFunc.createStep('customer.organization.add', 'add organization with cbs null', (context) => {
                        return {
                            organization: {
                                organizationName: customerConstants.ORGNAME + 'PARENT ORGANIZATION',
                                isEnabled: 1,
                                isDeleted: 0,
                                cbsId: null
                            }
                        };
                    }, (result, assert) => {
                        assert.equals(result['organization.info'][0].cbsId, null, 'return null cbsId');
                    }),
                    commonFunc.createStep('customer.organization.add', 'add organization with cbs non existing - number', (context) => {
                        return {
                            organization: {
                                organizationName: customerConstants.ORGNAME + 'PARENT ORGANIZATION',
                                isEnabled: 1,
                                isDeleted: 0,
                                cbsId: CBSIDNONEX
                            }
                        };
                    }, null, (error, assert) => {
                        assert.equals(error.type, ERRTYPE1, 'return type portSQL');
                    }),
                    commonFunc.createStep('customer.organization.add', 'add organization with cbs non existing - string', (context) => {
                        return {
                            organization: {
                                organizationName: customerConstants.ORGNAME + 'PARENT ORGANIZATION',
                                isEnabled: 1,
                                isDeleted: 0,
                                cbsId: CBSIDNONEX.toString()
                            }
                        };
                    }, null, (error, assert) => {
                        assert.equals(error.type, ERRTYPE1, 'return type portSQL');
                    })]
                }, userMethods.addRole('add role successfully', (context) => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, ROLENAME, ROLEDESCRIPTION),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                commonFunc.createStep('customer.organization.add', 'add organization successfully - all params, roles, phone, email, address', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME,
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0
                        },
                        roles: [context['add role successfully'].role[0].actorId],
                        parent: [context['get admin details'].memberOF[0].object],
                        email: [{
                            emailTypeId: customerConstants.TYPEIDWORK,
                            value: EMAIL
                        }],
                        phone: [{
                            phoneTypeId: customerConstants.TYPEIDPERSONAL,
                            phoneNumber: VALIDPHONENUBER
                        }],
                        address: [{
                            value: VALIDADDRESS,
                            addressTypeId: customerConstants.TYPEIDHOME
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, customerConstants.ORGNAME, 'return organizationName');
                    assert.equals(result['organization.info'][0].executiveOfficer, EXECOFFICER, 'return organization executiveOfficer');
                    assert.equals(result['organization.info'][0].code, CODE, 'return organization code');
                    assert.equals(result['organization.info'][0].tradeName, TRADENAME, 'return organization tradeName');
                    assert.equals(result['organization.info'][0].capital, customerConstants.CITY1, 'return organization capital');
                    assert.equals(result['organization.info'][0].currency, customerConstants.CURRENCYBG, 'return organization currency');
                    assert.equals(result['organization.info'][0].timeZone, userConstants.TIMEZONE, 'return organization timeZone');
                    assert.equals(result['organization.info'][0].primaryLanguageId, userConstants.LANGUAGEID, 'return organization primaryLanguage');
                }),
                commonFunc.createStep('customer.organization.add', 'add organization- duplicated orgName', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME,
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0
                        },
                        roles: [context['add role successfully'].role[0].actorId],
                        parent: [context['get admin details'].memberOF[0].object],
                        email: [{
                            emailTypeId: customerConstants.TYPEIDWORK,
                            value: EMAIL
                        }],
                        phone: [{
                            phoneTypeId: customerConstants.TYPEIDPERSONAL,
                            phoneNumber: VALIDPHONENUBER
                        }],
                        address: [{
                            value: VALIDADDRESS,
                            addressTypeId: customerConstants.TYPEIDHOME
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, customerConstants.ORGNAME, 'return organizationName');
                    assert.equals(result['organization.info'][0].executiveOfficer, EXECOFFICER, 'return organization executiveOfficer');
                    assert.equals(result['organization.info'][0].code, CODE, 'return organization code');
                    assert.equals(result['organization.info'][0].tradeName, TRADENAME, 'return organization tradeName');
                    assert.equals(result['organization.info'][0].capital, customerConstants.CITY1, 'return organization capital');
                    assert.equals(result['organization.info'][0].currency, customerConstants.CURRENCYBG, 'return organization currency');
                    assert.equals(result['organization.info'][0].timeZone, userConstants.TIMEZONE, 'return organization timeZone');
                    assert.equals(result['organization.info'][0].primaryLanguageId, userConstants.LANGUAGEID, 'return organization primaryLanguage');
                }),
                commonFunc.createStep('customer.organization.add', 'add organization unsuccessfully - empty string organizationName', (context) => {
                    return {
                        organization: {
                            organizationName: '',
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.add', 'add org with countryId', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME + ' 1 ',
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0,
                            countryId: COUNTRYID
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, customerConstants.ORGNAME + ' 1 ', 'return correct username');
                    assert.equals(result['organization.info'][0].countryId, 33, 'return correct countryId');
                }),
                commonFunc.createStep('customer.organization.add', 'add org - empty countryId', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME + ' 2 ',
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0,
                            countryId: ''
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.add', 'add org  - countryId null', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME + ' 3 ',
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0,
                            countryId: null
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, customerConstants.ORGNAME + ' 3 ', 'return correct username');
                    assert.equals(result['organization.info'][0].countryId, null, 'return null countryId');
                }),
                commonFunc.createStep('customer.organization.add', 'add org - random countryId', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME + ' 4 ',
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0,
                            countryId: parseInt(RANDOMCOUNTRYID)
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'portSQL', 'return type portSQL');
                }),
                commonFunc.createStep('customer.organization.add', 'add org  - empty string organization code', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME,
                            code: '',
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.add', 'add org  - null organization code', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME,
                            code: null,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, customerConstants.ORGNAME, 'return correct username');
                }),
                commonFunc.createStep('customer.organization.add', 'add org  - missing organization code', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, customerConstants.ORGNAME, 'return correct username');
                    assert.equals(result['organization.info'][0].primaryLanguageId, userConstants.LANGUAGEID, 'return organization primaryLanguage');
                }),
                commonFunc.createStep('customer.organization.add', 'add org - null organization name', (context) => {
                    return {
                        organization: {
                            organizationName: null,
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0,
                            countryId: RANDOMCOUNTRY
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.add', 'add org - missing organization name', (context) => {
                    return {
                        organization: {
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1,
                            isDeleted: 0,
                            countryId: RANDOMCOUNTRY
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.add', 'add organization - empty string non mandatory params', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME,
                            code: CODE,
                            executiveOfficer: '',
                            tradeName: '',
                            capital: '',
                            currency: '',
                            timeZone: '',
                            primaryLanguageId: '',
                            isEnabled: 1,
                            isDeleted: 0
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.add', 'add organization - null non mandatory params', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME,
                            code: CODE,
                            executiveOfficer: '',
                            tradeName: '',
                            capital: '',
                            currency: '',
                            timeZone: '',
                            primaryLanguageId: '',
                            isEnabled: 1,
                            isDeleted: 0
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.add', 'add org  - missing isEnabled', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isDeleted: 0
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, customerConstants.ORGNAME, 'return correct username');
                    assert.equals(result['organization.info'][0].primaryLanguageId, userConstants.LANGUAGEID, 'return organization primaryLanguage');
                }),
                commonFunc.createStep('customer.organization.add', 'add org  - missing isDeleted', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, customerConstants.ORGNAME, 'return correct username');
                    assert.equals(result['organization.info'][0].primaryLanguageId, userConstants.LANGUAGEID, 'return organization primaryLanguage');
                }),
                userMethods.logout('Logout admin user', context => context.login['identity.check'].sessionId),
                /**
                 * MISSING PERMISSIONS CASE
                 */
                userMethods.login('Login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.add', 'add organization unsuccessfully - missing permissions', (context) => {
                    return {
                        organization: {
                            organizationName: customerConstants.ORGNAME,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: customerConstants.CITY1,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: userConstants.LANGUAGEID,
                            isEnabled: 1
                        }
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERORGANIZATIONADD) > -1, 'Missing permissions for ' + CUSTOMERORGANIZATIONADD);
                }),
                userMethods.logout('Logout new user', context => context['Login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
