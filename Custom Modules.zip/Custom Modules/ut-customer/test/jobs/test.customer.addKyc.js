const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerMethods = require('ut-test/lib/methods/customer');
const customerParams = require('ut-test/lib/requestParams/customer');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const userConstants = require('ut-test/lib/constants/user').constants();
const USERNAME = 'addKyc' + userConstants.USERNAME;
const KYCDESCRIPTION = customerConstants.KYCDESCRIPTION;
const RANDOMCONDITIONID = customerConstants.RANDOMCONDITIONID;
const CUSTOMERKYCADD = 'customer.kyc.add';
const STATUSINACTIVE = 'inactive';
const STATUSACTIVE = 'active';
const KYCALREADYEXISTSERROR = 'customer.kycLevelAlreadyExists';
const BRANCHDEPTHERROR = 'customer.branchDepthIsNotCorrect';
const INVALIDATTRIBUTESRROR = 'customer.kycInvalidAttributes';
const TEXTINPUT = 'test';
let stdPolicy;
let customerTypeNumber1, customerType1, customerTypeNumber2;
let orgId1, orgName1, organizationDepthArray;
let levelId1, levelName1, levelId2, levelName2, levelId3, levelName3, levelId1custType2, levelName1custType2;
let attributeId1, attributeName1, attributeId2, attributeName2, attributeIdcustType2;

module.exports = function test() {
    return {
        addKyc: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('user.user.get', 'get admin details', (context) => {
                    return {
                        actorId: context.login['identity.check'].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, userConstants.ADMINFIRSTNAME).error, null, 'return person');
                    orgId1 = result.memberOF[0].object;
                    orgName1 = result.memberOF[0].organizationName;
                }),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeNumber1 = result.customerType[0].customerTypeNumber;
                    customerType1 = result.customerType[0].customerType;
                    customerTypeNumber2 = result.customerType[1].customerTypeNumber;
                }),
                commonFunc.createStep('core.configuration.fetch', 'fetch defaultBu setting', (context) => {
                    return {
                        key: customerConstants.GETBYDEPTHORGANIZATION
                    };
                }, (result, assert) => {
                    const orgDepth = result[0][0].value;
                    organizationDepthArray = Array.apply(null, {length: orgDepth - 1}).map(Number.call, Number);
                    assert.true(typeof result, 'object', 'return result');
                }),
                // Create organization which correspond to the kyc's depth
                {
                    name: 'Create organization by depth',
                    steps: () => organizationDepthArray.map(org => ({
                        name: 'Add and approve organizations',
                        steps: () => [
                            commonFunc.createStep('customer.organization.add', 'add organization',
                                () => ({
                                    organization: {
                                        organizationName: customerConstants.ORGNAME
                                    },
                                    parent: [orgId1]
                                }), (result, assert) => {
                                    orgId1 = result['organization.info'][0].actorId;
                                    orgName1 = result['organization.info'][0].organizationName;
                                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                                }
                            ),
                            customerMethods.approveOrganization('approve organization', () => orgId1)
                        ]
                    }))
                },
                commonFunc.createStep('customer.organization.getByDepth', 'get organizations by depth', context => {
                    return {
                        key: customerConstants.GETBYDEPTHORGANIZATION
                    };
                }, (result, assert) => {
                    assert.true(result.organizations.some(org => org.actorId === orgId1), 'return the newly creted organization');
                    assert.equals(customerJoiValidation.validateGetByDepthOrganization(result.organizations).error, null, 'Return all details after get by depth organizations');
                }),
                commonFunc.createStep('customer.kyc.getForCreate', 'get levels for creating kyc', context => {
                    return {
                        customerType: customerTypeNumber1,
                        organizationId: orgId1
                    };
                }, (result, assert) => {
                    assert.true(result.levels.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateGetForCreateKyc(result.levels).error, null, 'Return all details for kyc levels');
                    levelId1 = result.levels[1].itemNameId;
                    levelName1 = result.levels[1].itemNameTranslation;
                    levelId2 = result.levels[2].itemNameId;
                    levelName2 = result.levels[2].itemNameTranslation;
                    levelId3 = result.levels[3].itemNameId;
                    levelName3 = result.levels[3].itemNameTranslation;
                }),
                commonFunc.createStep('customer.kycAttribute.list', 'list kyc attributes', context => {
                    return {
                        customerTypeId: customerTypeNumber1
                    };
                }, (result, assert) => {
                    assert.true(result.kycAttributes.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateListKycAttributes(result.kycAttributes).error, null, 'Return all details for kyc attributes');
                    attributeId1 = result.kycAttributes[0].itemNameId;
                    attributeName1 = result.kycAttributes[0].itemNameTranslation;
                    attributeId2 = result.kycAttributes[1].itemNameId;
                    attributeName2 = result.kycAttributes[1].itemNameTranslation;
                }),
                commonFunc.createStep('customer.kyc.add', 'add kyc 1', context => {
                    return {
                        kyc: {
                            display: levelName1,
                            description: KYCDESCRIPTION,
                            customerTypeId: customerTypeNumber1,
                            organizationId: orgId1,
                            itemNameId: levelId1
                        },
                        kycConditionAttribute: [{
                            conditionId: RANDOMCONDITIONID,
                            attributeId: attributeId1
                        }, {
                            conditionId: RANDOMCONDITIONID,
                            attributeId: attributeId2
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddKyc(result.kyc).error, null, 'Return all details after adding a kyc');
                    assert.equals(result.kyc[0].description, KYCDESCRIPTION, 'return kyc description');
                    assert.equals(result.kyc[0].display, levelName1, 'return kyc display name');
                    assert.equals(result.kyc[0].statusId, STATUSACTIVE, 'return status ' + STATUSACTIVE);
                    assert.equals(result.kyc[0].customerTypeId, customerTypeNumber1, 'return customer type number');
                    assert.equals(result.kyc[0].organizationId, orgId1, 'return organization id');
                    assert.equals(result.kyc[0].itemNameId, levelId1, 'return level id (itemNameId)');
                }),
                commonFunc.createStep('customer.kyc.get', 'get kyc', (context) => {
                    return {
                        kycId: context['add kyc 1'].kyc[0].kycId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetKyc(result).error, null, 'Return all details for kyc');
                    assert.equals(result.kyc[0].organizationId, orgId1, 'return organization id');
                    assert.equals(result.kyc[0].organizationName, orgName1, 'return organization name');
                    assert.equals(result.kyc[0].customerTypeNumber, customerTypeNumber1, 'return customer type number');
                    assert.equals(result.kyc[0].customerType, customerType1, 'return customer type');
                    assert.true(result.kycAttributes.find(attr => attr.attributeId === attributeId1 && attr.itemNameTranslation === attributeName1 && attr.conditionId === RANDOMCONDITIONID), 'return attribute 1');
                    assert.true(result.kycAttributes.find(attr => attr.attributeId === attributeId2 && attr.itemNameTranslation === attributeName2 && attr.conditionId === RANDOMCONDITIONID), 'return attribute 2');
                }),
                commonFunc.createStep('customer.kyc.getForCreate', 'get levels after adding kyc', context => {
                    return {
                        customerType: customerTypeNumber1,
                        organizationId: orgId1
                    };
                }, (result, assert) => {
                    assert.true(result.levels.length > 0, 'return not empty resultset');
                    assert.false(result.levels.find(level => level.itemNameId === levelId1), 'the level user for the new kyc is not present in the list');
                    assert.equals(customerJoiValidation.validateGetForCreateKyc(result.levels).error, null, 'Return all details for kyc levels');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc rule with the same organization, customerTypeId and level as previously created one', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, KYCALREADYEXISTSERROR, 'Kyc for the selected organization, customerTypeId and level is already created');
                }),
                commonFunc.createStep('customer.kyc.add', 'add kyc 2', context => {
                    return {
                        kyc: {
                            display: levelName2,
                            description: KYCDESCRIPTION + 1,
                            statusId: STATUSINACTIVE, // try creating kyc with inactive status
                            customerTypeId: customerTypeNumber1,
                            organizationId: orgId1,
                            itemNameId: levelId2
                        },
                        kycConditionAttribute: [{
                            conditionId: RANDOMCONDITIONID,
                            attributeId: attributeId1
                        }, {
                            conditionId: RANDOMCONDITIONID,
                            attributeId: attributeId2
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddKyc(result.kyc).error, null, 'Return all details after adding a kyc');
                    assert.equals(result.kyc[0].description, KYCDESCRIPTION + 1, 'return kyc description');
                    assert.equals(result.kyc[0].display, levelName2, 'return kyc display name');
                    assert.equals(result.kyc[0].statusId, STATUSACTIVE, 'return status ' + STATUSACTIVE);
                }),
                // Add kyc - different customer type and attributes
                commonFunc.createStep('customer.kyc.getForCreate', 'get levels for creating kyc 3', context => {
                    return {
                        customerType: customerTypeNumber2,
                        organizationId: orgId1
                    };
                }, (result, assert) => {
                    assert.true(result.levels.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateGetForCreateKyc(result.levels).error, null, 'Return all details for kyc levels');
                    levelId1custType2 = result.levels[0].itemNameId;
                    levelName1custType2 = result.levels[0].itemNameTranslation;
                }),
                commonFunc.createStep('customer.kycAttribute.list', 'list kyc attributes for customer type 2', context => {
                    return {
                        customerTypeId: customerTypeNumber2
                    };
                }, (result, assert) => {
                    assert.true(result.kycAttributes.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateListKycAttributes(result.kycAttributes).error, null, 'Return all details for kyc attributes');
                    attributeIdcustType2 = result.kycAttributes[0].itemNameId;
                }),
                customerMethods.addKyc('add kyc 3', context => {
                    return {
                        display: levelName1custType2,
                        customerTypeId: customerTypeNumber2,
                        organizationId: orgId1,
                        itemNameId: levelId1custType2,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeIdcustType2

                    };
                }, KYCDESCRIPTION + 3),
                // NEGATIVE SCENARIOS
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add kyc - for organization which is not in the correct branch depth', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: context['get admin details'].memberOF[0].object, // organization SG
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.true(error.type === BRANCHDEPTHERROR, 'Cannot create kyc for this branch ' + BRANCHDEPTHERROR);
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add kyc - the attribute is not for the correct customer type', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName3,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId3,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeIdcustType2
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, INVALIDATTRIBUTESRROR, 'invalid attribute - the attribute is not for the correct customer type');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add kyc - the same attribute in 2 conditions', context => {
                    return {
                        kyc: {
                            display: levelName1,
                            description: KYCDESCRIPTION,
                            customerTypeId: customerTypeNumber1,
                            organizationId: orgId1,
                            itemNameId: levelId1
                        },
                        kycConditionAttribute: [{
                            conditionId: RANDOMCONDITIONID,
                            attributeId: attributeId1
                        }, {
                            conditionId: RANDOMCONDITIONID + 1,
                            attributeId: attributeId1
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, KYCALREADYEXISTSERROR, 'cannot insert the same attribute twice');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - missing description', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - description null', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, null), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - description empty string', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, ''), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - missing display', context => customerParams.addKycParams(context, (context) => {
                    return {
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - display null', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: null,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - display empty string', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: '',
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - missing customerTypeId', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - customerTypeId null', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: null,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - customerTypeId empty string', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: '',
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - customerTypeId string', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: TEXTINPUT,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - missing organizationId', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - organizationId null', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: null,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - organizationId empty string', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: '',
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - organizationId empty string', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: TEXTINPUT,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - missing itemNameId', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - itemNameId null', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: null,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - itemNameId empty string', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: '',
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - itemNameId string', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: TEXTINPUT,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - missing conditionId', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - conditionId null', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        attributeId: attributeId1,
                        conditionId: null
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - conditionId empty string', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        attributeId: attributeId1,
                        conditionId: ''
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - conditionId string', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        attributeId: attributeId1,
                        conditionId: TEXTINPUT
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - missing attributeId', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - attributeId null', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        attributeId: null,
                        conditionId: RANDOMCONDITIONID
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - attributeId empty string', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        attributeId: '',
                        conditionId: RANDOMCONDITIONID
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - attributeId string', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        attributeId: TEXTINPUT,
                        conditionId: RANDOMCONDITIONID
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - missing kycConditionAttribute', context => {
                    return {
                        kyc: {
                            display: levelName2,
                            description: KYCDESCRIPTION + 1,
                            statusId: STATUSINACTIVE, // try creating kyc with inactive status
                            customerTypeId: customerTypeNumber1,
                            organizationId: orgId1,
                            itemNameId: levelId2
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add Kyc - missing attribute and condition (kycConditionAttribute - empty array)', context => {
                    return {
                        kyc: {
                            display: levelName2,
                            description: KYCDESCRIPTION + 1,
                            statusId: STATUSINACTIVE, // try creating kyc with inactive status
                            customerTypeId: customerTypeNumber1,
                            organizationId: orgId1,
                            itemNameId: levelId2
                        },
                        kycConditionAttribute: []
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // MISSING PERMISSIONS
                userMethods.logout('logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('successful login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add kyc - missing permission', context => customerParams.addKycParams(context, (context) => {
                    return {
                        display: levelName1,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: levelId1,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERKYCADD) > -1, 'Missing permissions for ' + CUSTOMERKYCADD);
                }),
                userMethods.logout('successfully logout new user', (context) => context['successful login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
