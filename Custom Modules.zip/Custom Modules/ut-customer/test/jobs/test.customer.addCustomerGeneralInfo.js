const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
// var userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const customerParams = require('ut-test/lib/requestParams/customer');
const DATEOFBIRTH = customerConstants.DATEOFBIRTH;
const FUTUREDATE = commonFunc.randomDate(new Date(), new Date(3000, 0, 2));
const PHONETYPEID = customerConstants.TYPEIDPERSONAL;
const PHONENUM = customerConstants.PHONENUMBER.slice(3, -2);
const NEWPHONENUMBER = customerConstants.NEWPHONENUMBER.slice(0, 12);
// const MNOKEY = customerConstants.MNOKEY;
// Address
let customerTypeId, martialId, educationId, employerCategoryId, employmentId, incomeId;

module.exports = function test() {
    return {
        addCustomerGeneralInfo: function(test, bus, run) {
            return run(test, bus, [
                userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                /**
                 * GENERAL INFO TAB
                 */
                // fetch organizations
                commonFunc.createStep('customer.organization.graphFetch', 'fetch child organizations of sa organization', (context) => {
                    return {
                        parentFilter: context['get admin details'].memberOF[0].object
                    };
                }, (result, assert) => {
                    // organizationId = result.organization[0].id;
                    assert.equals(customerJoiValidation.validateFetchOrganizationGraph(result.organization).error, null, 'return organization graph fetch details');
                }),
                commonFunc.createStep('customer.incomeRange.list', 'list incomeRange', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateListIncomeRange(result.incomeRange).error, null, 'Return list incomeRange');
                    incomeId = result.incomeRange[0].incomeRangeId;
                }),
                commonFunc.createStep('customer.maritalStatus.list', 'list martialStatus', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateListMaritalStatus(result.maritalStatus).error, null, 'Return list maritalStatus');
                    martialId = result.maritalStatus[0].maritalStatusId;
                }),
                commonFunc.createStep('customer.education.list', 'list education', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateListEducation(result.education).error, null, 'Return list education');
                    educationId = result.education[0].educationId;
                }),
                commonFunc.createStep('customer.employment.list', 'list employment', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateListEmployment(result.employment).error, null, 'Return list employment');
                    employmentId = result.employment[0].employmentId;
                }),
                commonFunc.createStep('customer.employerCategory.list', 'list employerCategory', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateListEmployerCategory(result.employerCategory).error, null, 'Return list employerCategory');
                    employerCategoryId = result.employerCategory[0].employerCategoryId;
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer successfully - all parameters for General Info tab', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                    assert.equals(result.person.firstName, customerConstants.FIRSTNAME, 'return fisrtName');
                    assert.equals(result.person.middleName, customerConstants.FIRSTNAME, 'return middleName');
                    assert.equals(result.person.lastName, customerConstants.LASTNAME, 'return lastName');
                    assert.equals(result.person.employerName, customerConstants.FIRSTNAME, 'return employerName');
                    assert.equals(result.person.gender, customerConstants.GENDERM, 'return gender');
                    assert.equals(result.person.nationality, customerConstants.NATIONALITY, 'return nationality');
                    assert.equals(result.person.maritalStatusId, martialId, 'return maritalStatusId');
                    assert.equals(result.person.incomeRangeId, incomeId, 'return incomeId');
                    assert.equals(result.person.educationId, educationId, 'return educationId');
                    assert.equals(result.person.employerCategoryId, employerCategoryId, 'return employerCategoryId');
                    assert.equals(result.person.employmentId, employmentId, 'return employmentId');
                    assert.equals(result.person.familyMembers, 1, 'return family members');
                }),
                commonFunc.createStep('customer.customer.get', 'Get a customer with all his details successufully', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add customer successfully - all parameters for General Info tab'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                    assert.equals(result.person.firstName, customerConstants.FIRSTNAME, 'return fisrtName');
                    assert.equals(result.person.middleName, customerConstants.FIRSTNAME, 'return middleName');
                    assert.equals(result.person.lastName, customerConstants.LASTNAME, 'return lastName');
                    assert.equals(result.person.employerName, customerConstants.FIRSTNAME, 'return employerName');
                    assert.equals(result.person.gender, customerConstants.GENDERM, 'return gender');
                    assert.equals(result.person.nationality, customerConstants.NATIONALITY, 'return nationality');
                    assert.equals(result.person.maritalStatusId, martialId, 'return maritalStatusId');
                    assert.equals(result.person.incomeRangeId, incomeId, 'return incomeId');
                    assert.equals(result.person.educationId, educationId, 'return educationId');
                    assert.equals(result.person.employerCategoryId, employerCategoryId, 'return employerCategoryId');
                    assert.equals(result.person.employmentId, employmentId, 'return employmentId');
                    assert.equals(result.person.familyMembers, 1, 'return family members');
                }),
                commonFunc.createStep('customer.customer.add', 'empty gender', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: '',
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null gender', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.gender === null || result.person.gender === undefined, 'no result');
                }),
                commonFunc.createStep('customer.customer.add', 'empty nationalID', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: '',
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null nationalID', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.nationalId === null || result.person.nationalId === undefined, 'no result');
                }),
                commonFunc.createStep('customer.customer.add', 'empty dateOfBirth', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: '',
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null dateOfBirth', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.dateOfBirth === null || result.person.dateOfBirth === undefined, 'no result');
                }),
                commonFunc.createStep('customer.customer.add', 'future dateOfBirth', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: FUTUREDATE,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'customer.wrongDateOfBirth', 'return portsql');
                }),
                commonFunc.createStep('customer.customer.add', 'empty placeOfBirth', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: '',
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null placeOfBirth', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.placeOfBirth === null || result.person.placeOfBirth === undefined, 'no result');
                }),
                commonFunc.createStep('customer.customer.add', 'empty nationality', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: '',
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null nationality', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.nationality === null || result.person.nationality === undefined, 'no result');
                }),
                commonFunc.createStep('customer.customer.add', 'empty educationId', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: '',
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null educationId', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.educationId === null || result.person.educationId === undefined, 'no result');
                }),
                commonFunc.createStep('customer.customer.add', 'empty employerCategoryId', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: '',
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null employerCategoryId', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.employerCategoryId === null || result.person.employerCategoryId === undefined, 'no result');
                }),
                commonFunc.createStep('customer.customer.add', 'empty employerName', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: '',
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null employerName', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.employerName === null || result.person.employerName === undefined, 'no result');
                }),
                commonFunc.createStep('customer.customer.add', 'empty employemnt Date', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: '',
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null employemnt Date', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.employmentDate === null || result.person.employmentDate === undefined, 'no result');
                }),
                commonFunc.createStep('customer.customer.add', 'empty employmentID', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: '',
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null employmentID', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.employmentId === null || result.person.employmentId === undefined, 'no result');
                }),
                commonFunc.createStep('customer.customer.add', 'empty incomeID', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: '',
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null incomeID', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.incomeRangeId === null || result.person.incomeRangeId === undefined, 'no result');
                }),
                commonFunc.createStep('customer.customer.add', 'empty maritalId', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: '',
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null maritalId', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.maritalStatusId === null || result.person.maritalStatusId === undefined, 'no result');
                }),
                commonFunc.createStep('customer.customer.add', 'empty familyMembers', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: ''
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'null familyMembers', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: DATEOFBIRTH,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'validate person details');
                    assert.true(result.person.familyMembers === null || result.person.familyMembers === undefined, 'no result');
                }),
                userMethods.logout('Logout admin user', context => context.login['identity.check'].sessionId)
            ]);
        }
    };
};
