const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userConstants = require('ut-test/lib/constants/user').constants();
const userMethods = require('ut-test/lib/methods/user');
const customerMethods = require('ut-test/lib/methods/customer');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const USERNAME = 'delCust' + userConstants.USERNAME;
const CUSTOMERCUSTOMERREMOVE = 'customer.customer.remove';
let stdPolicy, customerTypeId;

module.exports = function test() {
    return {
        deleteCustomer: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                // fetch std input policy
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                customerMethods.addCustomer('Add customer', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        documentId: customerConstants.NEWDOCUMENTID
                    };
                }),
                customerMethods.addCustomer('Add second customer', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        documentId: customerConstants.NEWDOCUMENTID
                    };
                }),
                customerMethods.getCustomer('Get the newly created customer', context => context['Add customer'].customer.actorId),
                commonFunc.createStep('customer.customer.remove', 'delete customer', (context) => {
                    return {
                        actorId: context['Add customer'].customer.actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateDeleteCustomer(result.customer[0], customerTypeId).error, null, 'Return all details after deleting a customer');
                }),
                commonFunc.createStep('customer.customer.remove', 'delete already deleted customer', (context) => {
                    return {
                        actorId: context['Add customer'].customer.actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateDeleteCustomer(result.customer[0], customerTypeId).error, null, 'Return all details after deleting a customer');
                }),
                commonFunc.createStep('customer.customer.remove', 'delete non existing user - empty string', (context) => {
                    return {
                        actorId: ''
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.remove', 'delete customer - null actorId', (context) => {
                    return {
                        actorId: null
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.remove', 'delete customer - no params', (context) => {
                    return {};
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                userMethods.logout('Logout admin user', context => context.login['identity.check'].sessionId),
                userMethods.login('Login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.customer.remove', 'delete customer without rights for it', (context) => {
                    return {
                        actorId: context['Add second customer'].customer.actorId
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERCUSTOMERREMOVE) > -1, 'Missing Pemissions for ' + CUSTOMERCUSTOMERREMOVE);
                }),
                userMethods.logout('Logout new user', context => context['Login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
