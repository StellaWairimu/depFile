const commonFunc = require('ut-test/lib/methods/commonFunc');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const coreJoiValidation = require('ut-test/lib/joiValidations/core');
const userMethods = require('ut-test/lib/methods/user');
const userParams = require('ut-test/lib/requestParams/user');
const customerMethods = require('ut-test/lib/methods/customer');
const USERNAME = 'getOrg' + userConstants.USERNAME;
const ROLENAME = userConstants.ROLENAME;
const ROLEDESCRIPTION = userConstants.ROLEDESCRIPTION;
const ORGNAME = customerConstants.ORGNAME;
const VALIDADDRESS = 'Champs-Élysées, Paris, France';
const CODE = commonFunc.generateRandomNumber().toString();
const VALIDPHONENUBER = customerConstants.PHONENUMBER.slice(3, -4);
const EMAIL = customerConstants.EMAIL;
const PRIMARYLANG = '12';
const CAPITAL = 'SOFIA';
const TRADENAME = 'SOme random trade name';
const EXECOFFICER = 'Test executive Officer';
const NONEXORGID = commonFunc.generateRandomNumber();
const CUSTOMERORGANIZATIONGET = 'customer.organization.get';
let stdPolicy, parentActorId, roleActorId, addressZone1, addressZone2, addressZone3, addressZone4;

module.exports = function test() {
    return {
        getOrganization: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                // add new user - no rights
                userMethods.addUser('add new user', (context) => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', (context) => context['add new user'].person.actorId),
                commonFunc.createStep('user.role.add', 'add role', (context) => {
                    return {
                        role: {
                            name: ROLENAME,
                            description: ROLEDESCRIPTION
                        },
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, (result, assert) => {
                    roleActorId = result.role[0].actorId;
                    parentActorId = result['role.visibleFor'][0].actorId;
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return role status');
                }),
                userMethods.approveRole('approve role', context => context['add role'].role[0].actorId),
                // add organization
                commonFunc.createStep('core.country.fetch', 'fetch countries', context => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCountry(result.country).error, null, 'Return fetchCountry');
                    const country = result.country.find(
                        (country) => country.countryCode === 'BG'
                    );
                    addressZone1 = country.itemNameId;
                }),
                commonFunc.createStep('core.itemNameByParent.list', 'list itemNameByParent - address1', context => {
                    return {
                        parentItemNameId: addressZone1
                    };
                }, (result, assert) => {
                    assert.equals(coreJoiValidation.validateListItemNameByParent(result.resultSet).error, null, 'Return all details after itemNameByParent');
                }),
                {
                    name: 'More address zones',
                    params: (context, utils) => {
                        if (context['list itemNameByParent - address1'].resultSet.length < 1) {
                            addressZone2 = null;
                            addressZone3 = null;
                            addressZone4 = null;
                            return utils.skip();
                        }
                    },
                    steps: () => [
                        commonFunc.createStep('core.itemNameByParent.list', 'list itemNameByParent - address3', context => {
                            addressZone2 = context['list itemNameByParent - address1'].resultSet[0].itemNameId;
                            return {
                                parentItemNameId: addressZone2
                            };
                        }, (result, assert) => {
                            assert.equals(coreJoiValidation.validateListItemNameByParent(result.resultSet).error, null, 'Return all details after itemNameByParent');
                            addressZone3 = result.resultSet.length > 0 ? result.resultSet[0].itemNameId : null;
                            addressZone4 = null;
                        })
                    ]
                }, commonFunc.createStep('customer.organization.add', 'add organization', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME,
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            capital: CAPITAL,
                            currency: customerConstants.CURRENCYBG,
                            timeZone: userConstants.TIMEZONE,
                            primaryLanguageId: PRIMARYLANG,
                            isEnabled: 1
                        },
                        parent: [context['get admin details'].memberOF[0].object],
                        roles: [context['add role'].role[0].actorId],
                        email: [{
                            emailTypeId: customerConstants.TYPEIDWORK,
                            value: EMAIL
                        }],
                        phone: [{
                            phoneTypeId: customerConstants.TYPEIDWORK,
                            phoneNumber: VALIDPHONENUBER
                        }],
                        address: [{
                            value: VALIDADDRESS,
                            addressTypeId: customerConstants.TYPEIDHOME,
                            addressZone1: addressZone1,
                            addressZone2: addressZone2,
                            addressZone3: addressZone3,
                            addressZone4: addressZone4
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME, 'return organizationName');
                }),
                customerMethods.approveOrganization('approve add organization', (context) => context['add organization']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'Get new organization\'s details', (context) => {
                    return {
                        actorId: context['add organization']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME, 'return org name');
                    assert.equals(result['organization.info'][0].code, CODE, 'return code');
                    assert.equals(result['organization.info'][0].executiveOfficer, EXECOFFICER, 'return executive officer');
                    assert.equals(result['organization.info'][0].tradeName, TRADENAME, 'return tradeName');
                    assert.equals(result['organization.info'][0].capital, CAPITAL, 'return capital');
                    assert.equals(result['organization.info'][0].currency, customerConstants.CURRENCYBG, 'return currency');
                    assert.equals(result['organization.info'][0].timeZone, userConstants.TIMEZONE, 'return timeZone');
                    assert.equals(result['organization.info'][0].primaryLanguageId, PRIMARYLANG, 'return laguage');
                    assert.true(result['organization.info'][0].isEnabled, 'return isEnabled');
                    assert.equals(customerJoiValidation.validateGetEmail(result['organization.email'][0], EMAIL, customerConstants.TYPEIDWORK).error, null, 'return email details');
                    assert.equals(customerJoiValidation.validateGetAddress(result['organization.address'][0], VALIDADDRESS, customerConstants.TYPEIDHOME).error, null, 'return address details');
                    assert.equals(customerJoiValidation.validateGetPhone(result['organization.phone'][0], VALIDPHONENUBER, customerConstants.TYPEIDWORK).error, null, 'return phone details');
                    assert.equals(result['organization.parents'][0].actorId, parentActorId, 'return correct parent');
                    assert.equals(result['organization.roles'][0].actorId, roleActorId, 'no roles for the organization');
                }),
                customerMethods.getOrganization('Get Main org', (context) => context['get admin details'].memberOF[0].object),
                /**
                 * NEGATIVE
                 */
                commonFunc.createStep('customer.organization.get', 'Get with null actorId', (context) => {
                    return {
                        actorId: null
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.get', 'Get with empty string actorId', (context) => {
                    return {
                        actorId: ''
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.get', 'Get with no params', (context) => {
                    return {};
                },
                null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.get', 'Get with non existing org', (context) => {
                    return {
                        actorId: NONEXORGID
                    };
                }, (result, assert) => {
                    assert.same(result['organization.info'], [], 'return empty resultset');
                }),
                customerMethods.addOrganization('add second organization', (context) => {
                    return {};
                }, ORGNAME + 2),
                customerMethods.getOrganization('Get second org that is not visible for the logged user', (context) => context['add second organization']['organization.info'][0].actorId),
                /**
                 * MISSING PERMISSIONS
                 */
                userMethods.logout('Logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('Successful login user 1', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.get', 'Get second org - user has no rights', (context) => {
                    return {
                        actorId: context['add second organization']['organization.info'][0].actorId
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERORGANIZATIONGET) > -1, 'Missing permissions for ' + CUSTOMERORGANIZATIONGET);
                }),
                userMethods.logout('Successful logout user 1', (context) => context['Successful login user 1']['identity.check'].sessionId)]
            );
        }
    };
};
