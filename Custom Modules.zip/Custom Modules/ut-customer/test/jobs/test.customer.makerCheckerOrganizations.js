const commonFunc = require('ut-test/lib/methods/commonFunc');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userConstants = require('ut-test/lib/constants/user').constants();
const coreJoiValidation = require('ut-test/lib/joiValidations/core');
const userMethods = require('ut-test/lib/methods/user');
const userParams = require('ut-test/lib/requestParams/user');
const customerMethods = require('ut-test/lib/methods/customer');
const customerParams = require('ut-test/lib/requestParams/customer');
const MAKERUSERNAME = userConstants.USERNAME + 'maker';
const CHECKERUSERNAME = userConstants.USERNAME + 'checker';
const VIEWERUSERNAME = userConstants.USERNAME + 'viewer';
const USERNAME = 'mChOrg' + userConstants.USERNAME;
const USERPASSWORD = userConstants.USERPASSWORD + 1;
const NEWPASS = USERPASSWORD + 2;
const ROLEMAKERNAME = 'Role Maker' + commonFunc.generateRandomNumber();
const ROLECHECKERNAME = 'Role Checker' + commonFunc.generateRandomNumber();
const ROLEVIEWERNAME = 'Role Viewer' + commonFunc.generateRandomNumber();
const ROLEDESCRIPTION = 'role description';
const REJECTREASON = 'rejected BU';
const ORGANIZATIONADD = 'customer.organization.add';
const ORGANIZATIONEDIT = 'customer.organization.edit';
const ORGANIZATIONAPPROVE = 'customer.organization.approve';
const ORGANIZATIONREJECT = 'customer.organization.reject';
const ORGANIZATIONLOCK = 'customer.organization.lock';
const ERRORORGANIZATIONINVALIDSTATUS = 'customer.organizationInvalidStatus';
const ERRORDISABLEDORDELETEDORGANIZATION = 'user.disabledOrDeletedOrganization';
const ERRORCUSTOMERDISABLEDORDELETEDORGANIZATION = 'customer.disabledOrDeletedOrganization';
const ORGANIZATIONDISCARD = 'customer.organization.discard';
const ORGANIZATIONREMOVE = 'customer.organization.delete';
const VALIDADDRESS = 'Champs-Élysées, Paris, France';
const VALIDPHONENUBER = (customerConstants.PHONENUMBER).slice(10);
const EMAIL = customerConstants.EMAIL;
const BUSINESSUNITNAME = 'Automation_BusinessUnit' + commonFunc.generateRandomNumber();
// Business unit permissions
const VIEWBUPERMISSION = 'View Business Unit';
const LISTBUPERMISSION = 'List Business Units';
const ADDBUPERMISSION = 'Add Business Unit';
const EDITBUPERMISSION = 'Edit Business Unit';
const DELETEBUPERMISSION = 'Delete Business Unit';
const LOCKBUPERMISSION = 'Lock / Unlock Business Unit';
const AUTHORIZEBUCHANGES = 'Authorize Business Unit Changes (Approve/Reject)';
const STATUSNEW = customerConstants.STATUSIDNEW;
const STATUSPENDING = customerConstants.STATUSIDPENDING;
const STATUSAPPROVED = customerConstants.STATUSIDAPPROVED;
const STATUSREJECTED = customerConstants.STATUSIDREJECTED;
let stdPolicy;
let viewBUId, listBUId, addBUId, editBUId, deleteBUId, lockBUId, authorizeBUChangeId, addressZone1, addressZone2;

module.exports = function test() {
    return {
        makerCheckerOrganizations: function(test, bus, run) {
            return run(test, bus, [
                userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                // Fetch std input policy
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                userMethods.addRole('add role successfully', context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                // Get permissions for view, list, edit, add, remove organization and authorize change
                commonFunc.createStep('user.actionCategory.fetch', 'fetch system roles', (context) => { return {}; },
                    (result, assert) => {
                        assert.equals(userJoiValidation.validateFetchSystemCategories(result.categories).error, null, 'return all details for fetch system role categories');
                        assert.equals(userJoiValidation.validateFetchSystemRoles(result.actions).error, null, 'return all details for fetch system roles');
                        viewBUId = result.actions.find(
                            (action) => (action.actionName).toString().toLowerCase().indexOf((VIEWBUPERMISSION).toLowerCase()) > -1
                        ).actionId;
                        listBUId = result.actions.find(
                            (action) => (action.actionName).toString().toLowerCase().indexOf((LISTBUPERMISSION).toLowerCase()) > -1
                        ).actionId;
                        addBUId = result.actions.find(
                            (action) => (action.actionName).toString().toLowerCase().indexOf((ADDBUPERMISSION).toLowerCase()) > -1
                        ).actionId;
                        editBUId = result.actions.find(
                            (action) => (action.actionName).toString().toLowerCase().indexOf((EDITBUPERMISSION).toLowerCase()) > -1
                        ).actionId;
                        deleteBUId = result.actions.find(
                            (action) => (action.actionName).toString().toLowerCase().indexOf((DELETEBUPERMISSION).toLowerCase()) > -1
                        ).actionId;
                        lockBUId = result.actions.find(
                            (action) => (action.actionName).toString().toLowerCase().indexOf((LOCKBUPERMISSION).toLowerCase()) > -1
                        ).actionId;
                        authorizeBUChangeId = result.actions.find(
                            (action) => (action.actionName).toString().toLowerCase().indexOf((AUTHORIZEBUCHANGES).toLowerCase()) > -1
                        ).actionId;
                    }),
                // Add 3 new roles - maker role (add,edit), checker role(authorize change) and viewer role(view, list))
                userMethods.addRole('add role maker', context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy,
                        permissions: [{
                            subject: addBUId,
                            object: '%'
                        }, {
                            subject: editBUId,
                            object: '%'
                        }, {
                            subject: deleteBUId,
                            object: '%'
                        }, {
                            subject: lockBUId,
                            object: '%'
                        }]
                    };
                }, ROLEMAKERNAME, ROLEDESCRIPTION),
                userMethods.addRole('add role checker', context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy,
                        permissions: [{
                            subject: authorizeBUChangeId,
                            object: '%'
                        }]
                    };
                }, ROLECHECKERNAME, ROLEDESCRIPTION),
                userMethods.addRole('add role viewer', context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy,
                        permissions: [{
                            subject: viewBUId,
                            object: '%'
                        }, {
                            subject: listBUId,
                            object: '%'
                        }]
                    };
                }, ROLEVIEWERNAME, ROLEDESCRIPTION),
                // Approve the created roles
                userMethods.approveRole('approve role maker', context => context['add role maker'].role[0].actorId),
                userMethods.approveRole('approve role checker', context => context['add role checker'].role[0].actorId),
                userMethods.approveRole('approve role viewer', context => context['add role viewer'].role[0].actorId),
                // Add and approve 3 new users to serve as maker, checker and viewer of organizations
                userMethods.addUser('add user maker', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        roles: [context['add role maker'].role[0].actorId],
                        defaultRoleId: context['add role maker'].role[0].actorId,
                        policyId: stdPolicy,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, MAKERUSERNAME),
                userMethods.addUser('add user checker', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        roles: [context['add role checker'].role[0].actorId],
                        defaultRoleId: context['add role checker'].role[0].actorId,
                        policyId: stdPolicy,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, CHECKERUSERNAME),
                userMethods.addUser('add user viewer', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        roles: [context['add role viewer'].role[0].actorId],
                        defaultRoleId: context['add role viewer'].role[0].actorId,
                        policyId: stdPolicy,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, VIEWERUSERNAME),
                userMethods.approveUser('approve user maker', context => context['add user maker'].person.actorId),
                userMethods.approveUser('approve user checker', context => context['add user checker'].person.actorId),
                userMethods.approveUser('approve user viewer', context => context['add user viewer'].person.actorId),
                /**
                 * ADD ROLE & USER FOR MAKER/CHEKER - a user with maker AND checker rights at the same time
                 */
                userMethods.addRole('add role maker/checker', context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy,
                        permissions: [{
                            subject: addBUId,
                            object: '%'
                        }, {
                            subject: editBUId,
                            object: '%'
                        }, {
                            subject: deleteBUId,
                            object: '%'
                        }, {
                            subject: lockBUId,
                            object: '%'
                        }, {
                            subject: authorizeBUChangeId,
                            object: '%'
                        }]
                    };
                }, ROLEMAKERNAME + 'checker', ROLEDESCRIPTION),
                userMethods.approveRole('approve role maker/checker', context => context['add role maker/checker'].role[0].actorId),
                userMethods.addUser('add user maker/checker', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        roles: [context['add role maker/checker'].role[0].actorId],
                        defaultRoleId: context['add role maker/checker'].role[0].actorId,
                        policyId: stdPolicy,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, MAKERUSERNAME + 'checker'),
                userMethods.approveUser('approve user maker/checker', context => context['add user maker/checker'].person.actorId),
                // SA scenarios
                customerMethods.addOrganization('add organization parent', (context) => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, BUSINESSUNITNAME + 'PARENT'),
                customerMethods.approveOrganization('approve add organization parent', (context) => context['add organization parent']['organization.info'][0].actorId),
                // Scenario: Add organization. Reject. Descard. Verify the organization no longer exists
                commonFunc.createStep('core.country.fetch', 'fetch countries', context => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCountry(result.country).error, null, 'Return fetchCountry');
                    const country = result.country.find(
                        (country) => country.countryCode === 'BG'
                    );
                    addressZone1 = country.itemNameId;
                }),
                commonFunc.createStep('core.itemNameByParent.list', 'list itemNameByParent - address1', context => {
                    return {
                        parentItemNameId: addressZone1
                    };
                }, (result, assert) => {
                    assert.equals(coreJoiValidation.validateListItemNameByParent(result.resultSet).error, null, 'Return all details after itemNameByParent');
                }),
                {
                    name: 'More address zones',
                    params: (context, utils) => {
                        if (context['list itemNameByParent - address1'].resultSet.length < 1) {
                            addressZone2 = null;
                            return utils.skip();
                        }
                    },
                    steps: () => [
                        commonFunc.createStep('core.itemNameByParent.list', 'list itemNameByParent - address3', context => {
                            addressZone2 = context['list itemNameByParent - address1'].resultSet[0].itemNameId;
                            return {
                                parentItemNameId: addressZone2
                            };
                        }, (result, assert) => {
                            assert.equals(coreJoiValidation.validateListItemNameByParent(result.resultSet).error, null, 'Return all details after itemNameByParent');
                        })
                    ]
                }, commonFunc.createStep('customer.organization.add', 'add organization 1', (context) => customerParams.addOrganizationParams(context, context => {
                    return {
                        role: [context['add role maker'].role[0].actorId],
                        parent: [context['add organization parent']['organization.info'][0].actorId]
                    };
                }, BUSINESSUNITNAME + 1),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + 1, 'return organizationName');
                    assert.equals(result['organization.info'][0].statusId, customerConstants.STATUSIDNEW, 'return status new');
                    assert.equals(result['organization.info'][0].isNew, 1, 'return isNew 1');
                    assert.equals(result['organization.info'][0].isEnabled, false, 'return isEnabled false');
                }),
                customerMethods.rejectOrganization('reject organization 1', (context) => context['add organization 1']['organization.info'][0].actorId, REJECTREASON),
                commonFunc.createStep('customer.organization.get', 'get rejected organization 1 details', (context) => {
                    return {
                        actorId: context['add organization 1']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result['organization.info'][0].statusId, STATUSREJECTED, 'return status ' + STATUSREJECTED);
                    assert.equals(result['organization.info'][0].rejectReason, REJECTREASON, 'return status ' + STATUSREJECTED);
                }),
                customerMethods.discardOrganization('discard organization 1', (context) => context['add organization 1']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get discarded organization 1 details', (context) => {
                    return {
                        actorId: context['add organization 1']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.same(result['organization.info'], [], 'return empty resultset - the organization does not exist');
                }),
                // Scenario: Add organization. Approve. Edit (Add parent and role). Reject. Descard. Verify the organization's details before the edit are displayed.
                customerMethods.addOrganization('add organization 2', (context) => {
                    return {
                        role: [context['add role maker'].role[0].actorId],
                        parent: [context['add organization parent']['organization.info'][0].actorId]
                    };
                }, BUSINESSUNITNAME + 2),
                customerMethods.addOrganization('add organization - to be added as parent for organization 2', (context) => {
                    return {
                        parent: [context['add organization parent']['organization.info'][0].actorId]
                    };
                }, BUSINESSUNITNAME + '2PARENT'),
                customerMethods.approveOrganization('approve organization 2', (context) => context['add organization 2']['organization.info'][0].actorId),
                customerMethods.approveOrganization('approve add organization - to be added as parent for organization 2', (context) => context['add organization - to be added as parent for organization 2']['organization.info'][0].actorId),
                // Try editing the parent of organization 2 - set organization 2 as parent (RECURSION error)
                commonFunc.createStep('customer.organization.edit', 'RECURSSION', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization parent']['organization.info'][0].actorId,
                            organizationName: BUSINESSUNITNAME + 'TEST'
                        },
                        parentsAdded: [context['add organization 2']['organization.info'][0].actorId]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'customer.recursion', 'recursion error');
                }),
                commonFunc.createStep('customer.organization.fetch', 'successfully fetch organization 2 - check parents', (context) => {
                    return {
                        businessUnitId: context['add organization 2']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.equals(result.parent[0].parents, BUSINESSUNITNAME + 'PARENT', 'return only one parent');
                }),
                commonFunc.createStep('customer.organization.get', 'get approved organization 2 details', (context) => {
                    return {
                        actorId: context['add organization 2']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result['organization.parents'][0].organizationName, BUSINESSUNITNAME + 'PARENT', 'return parent organization name');
                    assert.equals(result['organization.parents'].length, 1, 'return only one approved parent organization');
                    assert.equals(result['organization.info'][0].statusId, STATUSAPPROVED, 'return status ' + STATUSAPPROVED);
                    assert.equals(result['organization.roles'][0].name, ROLEMAKERNAME, 'return approved role name');
                    assert.equals(result['organization.roles'].length, 1, 'return only one approved role');
                }),
                commonFunc.createStep('customer.organization.edit', 'edit approved organization 2 - RECURSSION', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization parent']['organization.info'][0].actorId,
                            organizationName: BUSINESSUNITNAME + '2EDITED'
                        },
                        parentsAdded: [context['add organization - to be added as parent for organization 2']['organization.info'][0].actorId]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'customer.recursion', 'recursion error');
                }),
                customerMethods.editOrganization('edit approved organization 2', (context) => {
                    return {
                        actorId: context['add organization 2']['organization.info'][0].actorId,
                        parentsAdded: [context['add organization - to be added as parent for organization 2']['organization.info'][0].actorId],
                        parentsRemoved: [context['add organization parent']['organization.info'][0].actorId],
                        grantedRoles: [context['add role checker'].role[0].actorId]
                    };
                }, BUSINESSUNITNAME + '2EDITED'),
                commonFunc.createStep('customer.organization.get', 'get edited organization 2 details', (context) => {
                    return {
                        actorId: context['add organization 2']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    // In the unapproved resultsets - the final state should be returned. If we add additional role, the unapproved reultset should display the new and the old one(s)
                    assert.equals(result['organization.infoUnapproved'][0].organizationName, BUSINESSUNITNAME + '2EDITED', 'return edited unapproved organization name');
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + '2', 'return approved organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSPENDING, 'return status ' + STATUSPENDING);
                    assert.equals(result['organization.parentsUnapproved'].length, 1, 'return one unapproved parent organizations - final state');
                    assert.true(result['organization.parentsUnapproved'].some(parent => parent.organizationName === BUSINESSUNITNAME + '2PARENT', 'return added parent organization name'));
                    assert.false(result['organization.parentsUnapproved'].some(parent => parent.organizationName === BUSINESSUNITNAME + 'PARENT', 'does not return old parent organization name'));
                    assert.equals(result['organization.parents'].length, 1, 'return only one approved parent organization');
                    assert.equals(result['organization.parents'][0].organizationName, BUSINESSUNITNAME + 'PARENT', 'return approved parent organization name');
                    assert.equals(result['organization.roles'][0].name, ROLEMAKERNAME, 'return approved role name');
                    assert.equals(result['organization.roles'].length, 1, 'return only one approved role');
                    assert.equals(result['organization.rolesUnapproved'].length, 2, 'return two unapproved roles - final state');
                    assert.true(result['organization.rolesUnapproved'].some(parent => parent.name === ROLEMAKERNAME, 'return old role name'));
                    assert.true(result['organization.rolesUnapproved'].some(parent => parent.name === ROLECHECKERNAME, 'return added role name'));
                }),
                commonFunc.createStep('customer.organization.fetch', 'successfully fetch organization 2 - check parents', (context) => {
                    return {
                        businessUnitId: context['add organization 2']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.equals(result.parent[0].parents, BUSINESSUNITNAME + 'PARENT', 'return only one parent');
                }),
                customerMethods.rejectOrganization('reject organization 2', (context) => context['add organization 2']['organization.info'][0].actorId, REJECTREASON),
                commonFunc.createStep('customer.organization.get', 'get edited organization 2 details after reject', (context) => {
                    return {
                        actorId: context['add organization 2']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.infoUnapproved'][0]).error, null, 'return all organization details');
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].statusId, STATUSREJECTED);
                    assert.equals(result['organization.info'][0].rejectReason, REJECTREASON);
                }),
                customerMethods.discardOrganization('discard organization 2', (context) => context['add organization 2']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get edited organization 2 details after discard', (context) => {
                    return {
                        actorId: context['add organization 2']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].statusId, STATUSAPPROVED);
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + '2', 'return approved organization name');
                    assert.equals(result['organization.parents'].length, 1, 'return only one approved parent organization');
                    assert.equals(result['organization.parents'][0].organizationName, BUSINESSUNITNAME + 'PARENT', 'return parent organization name');
                }),
                // Scenarios for remove(delete)
                // Organization 3: Add organization. Approve. Remove. Approve. Verify that the organization is deleted (isDeleted true).
                // Organization 4: Add organization. Approve. Remove. Reject. Discard (and verify that the organization is not deleted). Remove. Reject. Edit. Approve.
                customerMethods.addOrganization('add organization 3', (context) => {
                    return {
                        role: [context['add role maker'].role[0].actorId],
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, BUSINESSUNITNAME + 3),
                customerMethods.addOrganization('add organization 4', (context) => {
                    return {
                        role: [context['add role maker'].role[0].actorId],
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, BUSINESSUNITNAME + 4),
                customerMethods.approveOrganization('approve organization 3', (context) => context['add organization 3']['organization.info'][0].actorId),
                customerMethods.approveOrganization('approve organization 4', (context) => context['add organization 4']['organization.info'][0].actorId),
                customerMethods.removeOrganization('remove organizations 3 and 4', context => [context['add organization 3']['organization.info'][0].actorId, context['add organization 4']['organization.info'][0].actorId]),
                commonFunc.createStep('customer.organization.get', 'get pending for removal organization 4 details', (context) => {
                    return {
                        actorId: context['add organization 4']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].statusId, STATUSPENDING, 'return status ' + STATUSPENDING);
                    assert.equals(result['organization.info'][0].isDeleted, false, 'return isDeleted false in organization.info');
                    assert.equals(result['organization.infoUnapproved'][0].isDeleted, true, 'return isDeleted true in organization.infoUnapproved');
                }),
                customerMethods.approveOrganization('approve pending for removal organization 3', (context) => context['add organization 3']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get approved for removal organization 3 details', (context) => {
                    return {
                        actorId: context['add organization 3']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].statusId, STATUSAPPROVED, 'return status ' + STATUSAPPROVED);
                    assert.equals(result['organization.info'][0].isDeleted, true, 'return isDeleted true in organization.info');
                }),
                customerMethods.rejectOrganization('reject pending for removal organization 4', (context) => context['add organization 4']['organization.info'][0].actorId, REJECTREASON),
                commonFunc.createStep('customer.organization.get', 'get rejected for removal organization 4 details', (context) => {
                    return {
                        actorId: context['add organization 4']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].statusId, STATUSREJECTED, 'return status ' + STATUSREJECTED);
                    assert.equals(result['organization.infoUnapproved'][0].statusId, STATUSREJECTED, 'return status ' + STATUSREJECTED);
                    assert.equals(result['organization.info'][0].isDeleted, false, 'return isDeleted false in organization.info');
                    assert.equals(result['organization.infoUnapproved'][0].isDeleted, true, 'return isDeleted true in organization.infoUnapproved');
                }),
                customerMethods.discardOrganization('discard rejected for removal organization 4', (context) => context['add organization 4']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get discarded for removal organization 4 details', (context) => {
                    return {
                        actorId: context['add organization 4']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].statusId, STATUSAPPROVED, 'return status ' + STATUSAPPROVED);
                    assert.equals(result['organization.info'][0].isDeleted, false, 'return isDeleted false in organization.info');
                }),
                customerMethods.removeOrganization('remove organizations 4', context => [context['add organization 4']['organization.info'][0].actorId]),
                customerMethods.rejectOrganization('reject organization 4', (context) => context['add organization 4']['organization.info'][0].actorId, REJECTREASON),
                customerMethods.editOrganization('edit rejected organization 4', (context) => {
                    return {
                        actorId: context['add organization 4']['organization.info'][0].actorId
                    };
                }, BUSINESSUNITNAME + '4EDITED'),
                commonFunc.createStep('customer.organization.get', 'get organization 4 details', (context) => {
                    return {
                        actorId: context['add organization 4']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.infoUnapproved'][0].organizationName, BUSINESSUNITNAME + '4EDITED', 'return edited organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSPENDING, 'return status ' + STATUSPENDING);
                    assert.equals(result['organization.infoUnapproved'][0].statusId, STATUSPENDING, 'return status ' + STATUSPENDING);
                    assert.equals(result['organization.info'][0].isDeleted, false, 'return isDeleted false in organization.info');
                    assert.equals(result['organization.infoUnapproved'][0].isDeleted, false, 'return isDeleted false in organization.infoUnapproved');
                }),
                customerMethods.approveOrganization('approve organization 4 after remove-reject-edit', (context) => context['add organization 4']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get approved organization 4 details', (context) => {
                    return {
                        actorId: context['add organization 4']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + '4EDITED', 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSAPPROVED, 'return status ' + STATUSAPPROVED);
                    assert.equals(result['organization.info'][0].isDeleted, false, 'return isDeleted false in organization.info');
                }),
                // Scenarios for lock
                customerMethods.addOrganization('add organization L1', (context) => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, BUSINESSUNITNAME + 'L1'),
                customerMethods.addOrganization('add organization L2', (context) => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, BUSINESSUNITNAME + 'L2'),
                customerMethods.approveOrganization('approve organization L1', (context) => context['add organization L1']['organization.info'][0].actorId),
                customerMethods.approveOrganization('approve organization L2', (context) => context['add organization L2']['organization.info'][0].actorId),
                customerMethods.lockOrganization('lock organizations L1 and L2', context => {
                    return {
                        actorIdList: [context['add organization L1']['organization.info'][0].actorId, context['add organization L2']['organization.info'][0].actorId],
                        isEnabled: 0
                    };
                }),
                commonFunc.createStep('customer.organization.get', 'get pending for lock organization L2', (context) => {
                    return {
                        actorId: context['add organization L2']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + 'L2', 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSPENDING, 'return status ' + STATUSPENDING);
                    assert.equals(result['organization.infoUnapproved'][0].isEnabled, false, 'return isEnabled false in organization.infoUnapproved');
                    assert.equals(result['organization.info'][0].isEnabled, true, 'return isEnabled true in organization.info');
                }),
                customerMethods.approveOrganization('approve organization L2', (context) => context['add organization L2']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get locked organization L2', (context) => {
                    return {
                        actorId: context['add organization L2']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + 'L2', 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSAPPROVED, 'return status ' + STATUSAPPROVED);
                    assert.equals(result['organization.info'][0].isEnabled, false, 'return isEnabled false in organization.info');
                }),
                customerMethods.lockOrganization('unlock organization L2', context => {
                    return {
                        actorIdList: [context['add organization L2']['organization.info'][0].actorId],
                        isEnabled: 1
                    };
                }),
                commonFunc.createStep('customer.organization.get', 'get pending for unlock organization L2', (context) => {
                    return {
                        actorId: context['add organization L2']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + 'L2', 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSPENDING, 'return status ' + STATUSPENDING);
                    assert.equals(result['organization.infoUnapproved'][0].isEnabled, true, 'return isEnabled true in organization.infoUnapproved');
                    assert.equals(result['organization.info'][0].isEnabled, false, 'return isEnabled false in organization.info');
                }),
                customerMethods.approveOrganization('approve organization L2', (context) => context['add organization L2']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get unlocked organization L2', (context) => {
                    return {
                        actorId: context['add organization L2']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + 'L2', 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSAPPROVED, 'return status ' + STATUSAPPROVED);
                    assert.equals(result['organization.info'][0].isEnabled, true, 'return isEnabled true in organization.info');
                }),
                // NEGATIVE
                // Negative scenarios for new unapproved organization
                customerMethods.addOrganization('add organization 5', (context) => {
                    return {
                        role: [context['add role maker'].role[0].actorId],
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, BUSINESSUNITNAME + 5),
                commonFunc.createStep('user.user.add', 'unsuccessfully add user for new unapproved organization', (context) => userParams.addUserParams(context, context => {
                    return {
                        object: context['add organization 5']['organization.info'][0].actorId,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['add organization 5']['organization.info'][0].actorId
                    };
                }, USERNAME), null,
                (error, assert) => {
                    assert.equals(error.type, ERRORDISABLEDORDELETEDORGANIZATION, 'return type' + ERRORDISABLEDORDELETEDORGANIZATION);
                }),
                commonFunc.createStep('user.role.add', 'unsuccessfully add role for new unapproved organization', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['add organization 5']['organization.info'][0].actorId],
                        policyId: stdPolicy
                    };
                }, 'ROLE', ROLEDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, userConstants.USERSECURITYVIOLATION, 'return type user.securityViolation'); // first visibility to user is checked in this SP
                }),
                commonFunc.createStep('customer.organization.add', 'unsuccessfully create organization with parent new unapproved organization', (context) => customerParams.addOrganizationParams(context, context => {
                    return {
                        parent: [context['add organization 5']['organization.info'][0].actorId]
                    };
                }, BUSINESSUNITNAME + 'A'), null,
                (error, assert) => {
                    assert.equals(error.type, ERRORCUSTOMERDISABLEDORDELETEDORGANIZATION, 'return type ' + ERRORCUSTOMERDISABLEDORDELETEDORGANIZATION);
                }),
                commonFunc.createStep('customer.organization.edit', 'unsuccessfully edit new unapproved organization 5', (context) => customerParams.editOrganizationParams(context, context => {
                    return {
                        actorId: context['add organization 5']['organization.info'][0].actorId
                    };
                }, BUSINESSUNITNAME + '5 UPDATED'), null,
                (error, assert) => {
                    assert.equals(error.type, ERRORORGANIZATIONINVALIDSTATUS, 'cannot edit new unapproved organization');
                }),
                commonFunc.createStep('customer.organization.delete', 'unsuccessfully remove new unapproved organization 5', (context) => customerParams.removeOrganizationParams(context, context => [context['add organization 5']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                        assert.equals(error.type, ERRORORGANIZATIONINVALIDSTATUS, 'cannot remove new unapproved organization');
                    }),
                commonFunc.createStep('customer.organization.discard', 'unsuccessfully discard new unapproved organization 5', (context) => customerParams.discardOrganizationParams(context, context => context['add organization 5']['organization.info'][0].actorId), null,
                    (error, assert) => {
                        assert.equals(error.type, ERRORORGANIZATIONINVALIDSTATUS, 'cannot discard new unapproved organization');
                    }),
                commonFunc.createStep('customer.organization.lock', 'unsuccessfully lock new unapproved organization 5', (context) => customerParams.lockOrganizationParams(context, context => {
                    return {
                        actorIdList: [context['add organization 5']['organization.info'][0].actorId],
                        isEnabled: 0
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, ERRORORGANIZATIONINVALIDSTATUS, 'cannot lock new unapproved organization');
                }),
                commonFunc.createStep('customer.organization.get', 'get organization 5 details after completing all negative flows for new unapproved organization', (context) => {
                    return {
                        actorId: context['add organization 5']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + '5', 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSNEW, 'return status ' + STATUSNEW);
                    assert.equals(result['organization.info'][0].isNew, 1, 'return isNew 1');
                    assert.equals(result['organization.info'][0].isEnabled, false, 'return isEnabled false');
                    assert.equals(result['organization.info'][0].isDeleted, false, 'return isDeleted false');
                }),
                // Negative scenarios for approved organization
                customerMethods.approveOrganization('approve organization 5', (context) => context['add organization 5']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.reject', 'unsuccessfully reject approved organization 5', (context) => customerParams.rejectOrganizationParams(context, context => context['add organization 5']['organization.info'][0].actorId, REJECTREASON), null,
                    (error, assert) => {
                        assert.equals(error.type, ERRORORGANIZATIONINVALIDSTATUS, 'cannot reject approved organization');
                    }),
                commonFunc.createStep('customer.organization.discard', 'unsuccessfully discard approved organization 5', (context) => customerParams.discardOrganizationParams(context, context => context['add organization 5']['organization.info'][0].actorId), null,
                    (error, assert) => {
                        assert.equals(error.type, ERRORORGANIZATIONINVALIDSTATUS, 'cannot discard approved organization');
                    }),
                commonFunc.createStep('customer.organization.get', 'get organization 5 details after completing all negative flows for approved organization', (context) => {
                    return {
                        actorId: context['add organization 5']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + '5', 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSAPPROVED, 'return status ' + STATUSAPPROVED);
                    assert.equals(result['organization.info'][0].isEnabled, true, 'return isEnabled true');
                    assert.equals(result['organization.info'][0].isDeleted, false, 'return isDeleted false');
                }),
                // Negative scenarios for edited organization (status pending)
                customerMethods.editOrganization('edit approved organization 5', (context) => {
                    return {
                        actorId: context['add organization 5']['organization.info'][0].actorId
                    };
                }, BUSINESSUNITNAME + '5EDITED'),
                commonFunc.createStep('customer.organization.edit', 'unsuccessfully edit edited(pending) organization 5', (context) => customerParams.editOrganizationParams(context, context => {
                    return {
                        actorId: context['add organization 5']['organization.info'][0].actorId
                    };
                }, BUSINESSUNITNAME + '5 UPDATED'), null,
                (error, assert) => {
                    assert.equals(error.type, ERRORORGANIZATIONINVALIDSTATUS, 'cannot edit edited(pending) organization');
                }),
                commonFunc.createStep('customer.organization.delete', 'unsuccessfully remove edited(pending) organization 5', (context) => customerParams.removeOrganizationParams(context, context => [context['add organization 5']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                        assert.equals(error.type, ERRORORGANIZATIONINVALIDSTATUS, 'cannot remove edited(pending) organization');
                    }),
                commonFunc.createStep('customer.organization.discard', 'unsuccessfully discard edited(pending) organization 5', (context) => customerParams.discardOrganizationParams(context, context => context['add organization 5']['organization.info'][0].actorId), null,
                    (error, assert) => {
                        assert.equals(error.type, ERRORORGANIZATIONINVALIDSTATUS, 'cannot discard edited(pending) organization');
                    }),
                commonFunc.createStep('customer.organization.lock', 'unsuccessfully lock edited(pending) organization 5', (context) => customerParams.lockOrganizationParams(context, context => {
                    return {
                        actorIdList: [context['add organization 5']['organization.info'][0].actorId],
                        isEnabled: 0
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, ERRORORGANIZATIONINVALIDSTATUS, 'cannot lock edited(pending) organization');
                }),
                // Verify that the organization details are not changed after executing the negative flows
                commonFunc.createStep('customer.organization.get', 'get organization 5 details after completing all negative flows for edited(pending) organization', (context) => {
                    return {
                        actorId: context['add organization 5']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + '5', 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSPENDING, 'return status ' + STATUSPENDING);
                    assert.equals(result['organization.info'][0].isEnabled, true, 'return isEnabled true');
                    assert.equals(result['organization.info'][0].isDeleted, false, 'return isDeleted false');
                }),
                // Negative scenarios for rejected organization
                customerMethods.rejectOrganization('reject organization 5', (context) => context['add organization 5']['organization.info'][0].actorId, REJECTREASON),
                commonFunc.createStep('customer.organization.approve', 'unsuccessfully approve organization 5', (context) => customerParams.approveOrganizationParams(context, context => context['add organization 5']['organization.info'][0].actorId), null,
                    (error, assert) => {
                        assert.equals(error.type, ERRORORGANIZATIONINVALIDSTATUS, 'cannot approve rejected organization');
                    }),
                // Scenarios for MAKER, CHECKER, VIEWER
                userMethods.logout('logout admin user', context => context.login['identity.check'].sessionId),
                userMethods.login('login user maker', MAKERUSERNAME, USERPASSWORD, userConstants.TIMEZONE, NEWPASS),
                // MAKER: create 5 organizations
                customerMethods.addOrganization('add organization 6', (context) => {
                    return {
                        role: [context['add role maker'].role[0].actorId],
                        parent: [context['add organization parent']['organization.info'][0].actorId]
                    };
                }, BUSINESSUNITNAME + 6),
                customerMethods.addOrganization('add organization 7', (context) => {
                    return {
                        role: [context['add role maker'].role[0].actorId],
                        parent: [context['add organization parent']['organization.info'][0].actorId]
                    };
                }, BUSINESSUNITNAME + 7),
                customerMethods.addOrganization('add organization 8', (context) => {
                    return {
                        role: [context['add role maker'].role[0].actorId],
                        parent: [context['add organization parent']['organization.info'][0].actorId]
                    };
                }, BUSINESSUNITNAME + 8),
                customerMethods.addOrganization('add organization 9', (context) => {
                    return {
                        role: [context['add role maker'].role[0].actorId],
                        parent: [context['add organization parent']['organization.info'][0].actorId]
                    };
                }, BUSINESSUNITNAME + 9),
                // MAKER: unsuccessfully try to approve and reject organization
                commonFunc.createStep('customer.organization.approve', 'unsuccessfully approve organization 6 by maker', (context) => customerParams.approveOrganizationParams(context, context => context['add organization 6']['organization.info'][0].actorId), null,
                    (error, assert) => {
                        assert.true(error.message.indexOf(ORGANIZATIONAPPROVE) > -1, 'Missing permissions for ' + ORGANIZATIONAPPROVE);
                    }),
                commonFunc.createStep('customer.organization.reject', 'unsuccessfully reject organization 6 by maker', (context) => customerParams.rejectOrganizationParams(context, context => context['add organization 6']['organization.info'][0].actorId, REJECTREASON), null,
                    (error, assert) => {
                        assert.true(error.message.indexOf(ORGANIZATIONREJECT) > -1, 'Missing permissions for ' + ORGANIZATIONREJECT);
                    }),
                userMethods.logout('logout maker user', context => context['login user maker']['identity.check'].sessionId),
                userMethods.login('login viewer user', VIEWERUSERNAME, USERPASSWORD, userConstants.TIMEZONE, NEWPASS),
                // VIEWER: Unsuccessfully create, reject and approve organizations - missing permissions
                commonFunc.createStep('customer.organization.add', 'unsuccessfully create organization A by viewer', (context) => customerParams.addOrganizationParams(context, context => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, BUSINESSUNITNAME + 'A'), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(ORGANIZATIONADD) > -1, 'return missing permissions for ' + ORGANIZATIONADD);
                }),
                commonFunc.createStep('customer.organization.approve', 'unsuccessfully approve organization 7', (context) => {
                    return {
                        actorId: context['add organization 7']['organization.info'][0].actorId
                    };
                }, null,
                (error, assert) => {
                    assert.true(error.message.indexOf(ORGANIZATIONAPPROVE) > -1, 'Missing permissions for ' + ORGANIZATIONAPPROVE);
                }),
                commonFunc.createStep('customer.organization.reject', 'unsuccessfully reject organization 7', (context) => {
                    return {
                        actorId: context['add organization 7']['organization.info'][0].actorId,
                        rejectReason: REJECTREASON
                    };
                }, null,
                (error, assert) => {
                    assert.true(error.message.indexOf(ORGANIZATIONREJECT) > -1, 'Missing permissions for ' + ORGANIZATIONREJECT);
                }),
                userMethods.logout('logout viewer user', context => context['login viewer user']['identity.check'].sessionId),
                userMethods.login('login checker user', CHECKERUSERNAME, USERPASSWORD, userConstants.TIMEZONE, NEWPASS),
                // CHECKER: unsuccessfully create an organization - missing permissions
                commonFunc.createStep('customer.organization.add', 'unsuccessfully create organization B', (context) => customerParams.addOrganizationParams(context, context => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, BUSINESSUNITNAME + 'B'), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(ORGANIZATIONADD) > -1, 'return missing permissions for ' + ORGANIZATIONADD);
                }),
                /** CHECKER:
                 * Organization 6 - approve
                 * Organization 7 - approve
                 * Organization 8 - approve
                 * Organization 9 - reject
                 */
                customerMethods.approveOrganization('approve organization 6 by checker', (context) => context['add organization 6']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get approved organization 6', (context) => {
                    return {
                        actorId: context['add organization 6']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + 6, 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSAPPROVED, 'return status ' + STATUSAPPROVED);
                    assert.equals(result['organization.info'][0].isEnabled, true, 'return isEnabled true');
                    assert.equals(result['organization.info'][0].isDeleted, false, 'return isDeleted false');
                }),
                // CHECKER: Successfully fetch and get organization
                commonFunc.createStep('customer.organization.fetch', 'successfully fetch organization 6 by checker', (context) => {
                    return {
                        businessUnitId: context['add organization 6']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.equals(result.parent[0].organizationName, BUSINESSUNITNAME + 6, 'return fetched BU name');
                }),
                customerMethods.getOrganization('successfully get organization 6 by checker', context => context['add organization 6']['organization.info'][0].actorId),
                customerMethods.approveOrganization('approve organization 7 by checker', (context) => context['add organization 7']['organization.info'][0].actorId),
                customerMethods.approveOrganization('approve organization 8 by checker', (context) => context['add organization 8']['organization.info'][0].actorId),
                customerMethods.rejectOrganization('reject organization 9 by checker', (context) => context['add organization 9']['organization.info'][0].actorId, REJECTREASON),
                // CHECKER: unsuccessfully lock, remove, edit and discard organization - missing permissions
                commonFunc.createStep('customer.organization.lock', 'unsuccessfully lock approved organization 6', (context) => customerParams.lockOrganizationParams(context, context => {
                    return {
                        actorIdList: [context['add organization 6']['organization.info'][0].actorId],
                        isEnabled: 0
                    };
                }), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(ORGANIZATIONLOCK) > -1, 'Missing permissions for ' + ORGANIZATIONLOCK);
                }),
                commonFunc.createStep('customer.organization.delete', 'unsuccessfully remove organization 6', (context) => customerParams.removeOrganizationParams(context, context => [context['add organization 6']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                        assert.true(error.message.indexOf(ORGANIZATIONREMOVE) > -1, 'Missing permissions for ' + ORGANIZATIONREMOVE);
                    }),
                commonFunc.createStep('customer.organization.edit', 'unsuccessfully edit edited(pending) organization 5', (context) => customerParams.editOrganizationParams(context, context => {
                    return {
                        actorId: context['add organization 5']['organization.info'][0].actorId
                    };
                }, BUSINESSUNITNAME + '6 UPDATED'), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(ORGANIZATIONEDIT) > -1, 'Missing permissions for ' + ORGANIZATIONEDIT);
                }),
                commonFunc.createStep('customer.organization.discard', 'unsuccessfully discard organization 6', (context) => customerParams.discardOrganizationParams(context, context => context['add organization 6']['organization.info'][0].actorId), null,
                    (error, assert) => {
                        assert.true(error.message.indexOf(ORGANIZATIONDISCARD) > -1, 'Missing permissions for ' + ORGANIZATIONDISCARD);
                    }),
                userMethods.logout('logout checker user', context => context['login checker user']['identity.check'].sessionId),
                userMethods.login('login viewer user', VIEWERUSERNAME, NEWPASS, userConstants.TIMEZONE),
                // VIEWER - unsuccessfully lock, remove and edit organization - missing permissions
                commonFunc.createStep('customer.organization.lock', 'unsuccessfully lock approved organization 6', (context) => customerParams.lockOrganizationParams(context, context => {
                    return {
                        actorIdList: [context['add organization 6']['organization.info'][0].actorId],
                        isEnabled: 0
                    };
                }), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(ORGANIZATIONLOCK) > -1, 'Missing permissions for ' + ORGANIZATIONLOCK);
                }),
                commonFunc.createStep('customer.organization.delete', 'unsuccessfully remove organization 6', (context) => customerParams.removeOrganizationParams(context, context => [context['add organization 6']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                        assert.true(error.message.indexOf(ORGANIZATIONREMOVE) > -1, 'Missing permissions for ' + ORGANIZATIONREMOVE);
                    }),
                commonFunc.createStep('customer.organization.edit', 'unsuccessfully edit edited(pending) organization 5', (context) => customerParams.editOrganizationParams(context, context => {
                    return {
                        actorId: context['add organization 5']['organization.info'][0].actorId
                    };
                }, BUSINESSUNITNAME + '6 UPDATED'), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(ORGANIZATIONEDIT) > -1, 'Missing permissions for ' + ORGANIZATIONEDIT);
                }),
                // VIEWER: Successfully fetch and get organization
                commonFunc.createStep('customer.organization.fetch', 'successfully fetch organization in status approved', (context) => {
                    return {
                        statusId: STATUSAPPROVED
                    };
                }, (result, assert) => {
                    assert.true(result.organization.every(organization => organization.statusId === STATUSAPPROVED));
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                }),
                customerMethods.getOrganization('successfully get organization 6 by viewer', context => context['add organization 6']['organization.info'][0].actorId),
                userMethods.logout('logout viewer user', context => context['login viewer user']['identity.check'].sessionId),
                userMethods.login('login maker user', MAKERUSERNAME, NEWPASS, userConstants.TIMEZONE),
                // MAKER: Successfully fetch and get organization
                commonFunc.createStep('customer.organization.fetch', 'successfully fetch organization 6 by maker', (context) => {
                    return {
                        businessUnitId: context['add organization 6']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.equals(result.parent[0].organizationName, BUSINESSUNITNAME + 6, 'return fetched BU name');
                }),
                customerMethods.getOrganization('successfully get organization 6 by maker', context => context['add organization 6']['organization.info'][0].actorId),
                /** MAKER:
                 * Organization 6 - edit organization (remove parent and revoke role. add phone, address and email)
                 * Organization 7 - remove
                 * Organization 8 - lock
                 * Organization 9 - discard and verify that the organization is removed.
                 */
                commonFunc.createStep('customer.organization.edit', 'edited organization 6 details - remove role and parent, add address, email, phone', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization 6']['organization.info'][0].actorId,
                            organizationName: BUSINESSUNITNAME + '6 UPDATED'
                        },
                        revokedRoles: [context['add role maker'].role[0].actorId],
                        parentsRemoved: [context['add organization parent']['organization.info'][0].actorId],
                        email: [{
                            actorId: context['add organization 6']['organization.info'][0].actorId,
                            emailTypeId: customerConstants.TYPEIDWORK,
                            value: EMAIL
                        }],
                        phone: [{
                            actorId: context['add organization 6']['organization.info'][0].actorId,
                            phoneTypeId: customerConstants.TYPEIDWORK,
                            phoneNumber: VALIDPHONENUBER
                        }],
                        address: [{
                            actorId: context['add organization 6']['organization.info'][0].actorId,
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: VALIDADDRESS
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditOrganization(result.organization[0]).error, null, 'return all details after editing an organization');
                    assert.equals(result.organization[0].organizationName, BUSINESSUNITNAME + '6 UPDATED', 'return organizationName');
                    assert.equals(result.organization[0].statusId, customerConstants.STATUSIDPENDING, 'return status pending');
                }),
                commonFunc.createStep('customer.organization.get', 'get edited organization 6 details', (context) => {
                    return {
                        actorId: context['add organization 6']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result['organization.infoUnapproved'][0].organizationName, BUSINESSUNITNAME + '6 UPDATED', 'return edited unapproved organization name');
                    assert.equals(result['organization.emailUnapproved'][0].value, EMAIL, 'return email');
                    assert.equals(result['organization.addressUnapproved'][0].value, VALIDADDRESS, 'return address');
                    assert.equals(result['organization.phoneUnapproved'][0].phoneNumber, VALIDPHONENUBER, 'return phone number');
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + 6, 'return approved organization name');
                    assert.equals(result['organization.parents'].length, 1, 'return only one approved parent organization');
                    assert.equals(result['organization.parents'][0].organizationName, BUSINESSUNITNAME + 'PARENT', 'return parent organization name');
                    assert.equals(result['organization.roles'][0].name, ROLEMAKERNAME, 'return approved role name');
                    assert.equals(result['organization.roles'].length, 1, 'return only one approved role');
                    assert.same(result['organization.rolesUnapproved'], [], 'return empty resultset for unapproved role');
                    assert.same(result['organization.parentsUnapproved'], [], 'return empty resultset for unapproved parent organization');
                }),
                customerMethods.removeOrganization('remove organizations 7 by maker', context => [context['add organization 7']['organization.info'][0].actorId]),
                customerMethods.lockOrganization('lock organizations 8 by maker', context => {
                    return {
                        actorIdList: [context['add organization 8']['organization.info'][0].actorId, context['add organization L2']['organization.info'][0].actorId],
                        isEnabled: 0
                    };
                }),
                commonFunc.createStep('customer.organization.get', 'get pending for lock organization 8 details', (context) => {
                    return {
                        actorId: context['add organization 8']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + 8, 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSPENDING, 'return status ' + STATUSPENDING);
                    assert.equals(result['organization.infoUnapproved'][0].isEnabled, false, 'return isEnabled false in organization.infoUnapproved');
                    assert.equals(result['organization.info'][0].isEnabled, true, 'return isEnabled true in organization.info');
                }),
                customerMethods.discardOrganization('discard organization 9', (context) => context['add organization 9']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get discarded organization 9 details', (context) => {
                    return {
                        actorId: context['add organization 9']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.same(result['organization.info'], [], 'return empty resultset - the organization does not exist');
                }),
                userMethods.logout('logout maker user', context => context['login maker user']['identity.check'].sessionId),
                userMethods.login('login checker user', CHECKERUSERNAME, NEWPASS, userConstants.TIMEZONE),
                /** CHECKER
                 * Organization 6 - approve edit
                 * Organization 7 - approve removal
                 * Organization 8 - approve lock
                 */
                customerMethods.approveOrganization('approve remove organization 7', (context) => context['add organization 7']['organization.info'][0].actorId),
                customerMethods.approveOrganization('approve lock organization 8', (context) => context['add organization 8']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get approved for lock organization 8 details', (context) => {
                    return {
                        actorId: context['add organization 8']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + 8, 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSAPPROVED, 'return status ' + STATUSAPPROVED);
                    assert.equals(result['organization.info'][0].isEnabled, false, 'return isEnabled false in organization.info');
                }),
                userMethods.logout('logout checker user', context => context['login checker user']['identity.check'].sessionId),
                userMethods.login('login maker user', MAKERUSERNAME, NEWPASS, userConstants.TIMEZONE),
                /** MAKER
                 * Organization 6 - edit - remove phone, email and address
                 * Organization 8 - unlock
                 */
                commonFunc.createStep('customer.organization.edit', 'unsuccessfully edit organization 6 details - remove address and email, edit phone', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization 6']['organization.info'][0].actorId,
                            organizationName: BUSINESSUNITNAME + '6 UPDATED'
                        },
                        phone: [{
                            actorId: context['add organization 6']['organization.info'][0].actorId,
                            phoneTypeId: customerConstants.TYPEIDWORK,
                            phoneNumber: VALIDPHONENUBER + 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.organizationInvalidStatus', 'return failure - action not allowed for this user');
                }),
                customerMethods.lockOrganization('unlock organizations 8 by maker', context => {
                    return {
                        actorIdList: [context['add organization 8']['organization.info'][0].actorId],
                        isEnabled: 1
                    };
                }),
                userMethods.logout('logout maker user', context => context['login maker user']['identity.check'].sessionId),
                userMethods.login('login checker user', CHECKERUSERNAME, NEWPASS, userConstants.TIMEZONE),
                /** CHECKER
                 * Organization 6 - approve removal of address and email. Approve edit of phone
                 * Organization 7 - reject lock
                 */
                customerMethods.rejectOrganization('reject unlock of organization 8', (context) => context['add organization 8']['organization.info'][0].actorId, REJECTREASON),
                commonFunc.createStep('customer.organization.get', 'get rejected for unlock organization 8 details', (context) => {
                    return {
                        actorId: context['add organization 8']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + 8, 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSREJECTED, 'return status ' + STATUSREJECTED);
                    assert.equals(result['organization.infoUnapproved'][0].isEnabled, true, 'return isEnabled true in organization.infoUnapproved');
                }),
                userMethods.logout('logout checker user', context => context['login checker user']['identity.check'].sessionId),
                userMethods.login('login maker user', MAKERUSERNAME, NEWPASS, userConstants.TIMEZONE),
                /** MAKER
                 * Organization 8 - discard changes
                 */
                customerMethods.discardOrganization('discard unlock of organization 8', (context) => context['add organization 8']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get rejected for unlock organization 8 details', (context) => {
                    return {
                        actorId: context['add organization 8']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.vaidateGetOrganizationInfo(result['organization.info'][0]).error, null, 'return all organization details');
                    assert.equals(result['organization.info'][0].organizationName, BUSINESSUNITNAME + 8, 'return organization name');
                    assert.equals(result['organization.info'][0].statusId, STATUSAPPROVED, 'return status ' + STATUSAPPROVED);
                    assert.equals(result['organization.info'][0].isEnabled, false, 'return isEnabled false in organization.info');
                }),
                userMethods.logout('Successful logout maker user', (context) => context['login maker user']['identity.check'].sessionId),
                /**
                 * MAKER/CHECKER USER CASE - check if a user with maker and checker rights cannot approve/reject own records
                 */
                userMethods.login('login maker/checker user', MAKERUSERNAME + 'checker', USERPASSWORD, userConstants.TIMEZONE, NEWPASS),
                // add organization
                customerMethods.addOrganization('add organization 0', (context) => {
                    return {
                        role: [context['add role maker'].role[0].actorId],
                        parent: [context['add organization parent']['organization.info'][0].actorId]
                    };
                }, BUSINESSUNITNAME + 0),
                // try to approve/reject organization
                commonFunc.createStep('customer.organization.approve', 'try to approve org 0 as maker/checker user', (context) => customerParams.approveOrganizationParams(context, context => context['add organization 0']['organization.info'][0].actorId),
                    null, (error, assert) => {
                        assert.equals(error.type, 'customer.cannotPerformThisOperation', 'return cannotPerformThisOperation');
                    }),
                commonFunc.createStep('customer.organization.reject', 'try to reject org 0 as maker/checker user', (context) => {
                    return {
                        actorId: context['add organization 0']['organization.info'][0].actorId,
                        rejectReason: REJECTREASON
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'customer.cannotPerformThisOperation', 'return cannotPerformThisOperation');
                }),
                userMethods.logout('Successful logout maker/checker user', (context) => context['login maker/checker user']['identity.check'].sessionId),
                // login admin to approve the organization, so maker/checker user can edit it
                userMethods.loginAdmin('login 2', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                customerMethods.approveOrganization('approve organization 0', (context) => context['add organization 0']['organization.info'][0].actorId),
                // add new organization for maker/checker to approve
                customerMethods.addOrganization('add organization for maker/checker to approve', (context) => {
                    return {
                        role: [context['add role maker'].role[0].actorId],
                        parent: [context['add organization parent']['organization.info'][0].actorId]
                    };
                }, BUSINESSUNITNAME + 'mchTest'),
                userMethods.logout('Successful logout 2', (context) => context['login 2']['identity.check'].sessionId),
                /**
                 * login maker/checker user:
                 *  - edit organization and try to approve/reject the edit
                 *  - approve organization created by admin
                 */
                userMethods.login('login maker/checker user 2', MAKERUSERNAME + 'checker', NEWPASS, userConstants.TIMEZONE),
                commonFunc.createStep('customer.organization.edit', 'edit organization 0 as maker/checker user', (context) => {
                    return {
                        organization: {
                            actorId: context['add organization 0']['organization.info'][0].actorId,
                            organizationName: BUSINESSUNITNAME + 0
                        },
                        grantedRoles: [context['add role maker/checker'].role[0].actorId],
                        revokedRoles: [context['add role maker'].role[0].actorId],
                        parentsAdded: [context['get admin details'].memberOF[0].object],
                        parentsRemoved: [context['add organization parent']['organization.info'][0].actorId]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditOrganization(result.organization[0]).error, null, 'return all details after editing an organization');
                    assert.equals(result.organization[0].organizationName, BUSINESSUNITNAME + 0, 'return organizationName');
                    assert.equals(result.organization[0].statusId, customerConstants.STATUSIDPENDING, 'return status pending');
                }),
                // try to approve/reject edited organization
                commonFunc.createStep('customer.organization.approve', 'try to approve edited org 0 as maker/checker user', (context) => customerParams.approveOrganizationParams(context, context => context['add organization 0']['organization.info'][0].actorId),
                    null, (error, assert) => {
                        assert.equals(error.type, 'customer.cannotPerformThisOperation', 'return cannotPerformThisOperation');
                    }),
                commonFunc.createStep('customer.organization.reject', 'try to reject edited org 0 as maker/checker user', (context) => {
                    return {
                        actorId: context['add organization 0']['organization.info'][0].actorId,
                        rejectReason: REJECTREASON
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'customer.cannotPerformThisOperation', 'return cannotPerformThisOperation');
                }),
                // try to approve org created by admin
                customerMethods.approveOrganization('approve organization created by admin', (context) => context['add organization for maker/checker to approve']['organization.info'][0].actorId),
                userMethods.logout('Successful logout maker/checker user', (context) => context['login maker/checker user']['identity.check'].sessionId)
            ]);
        }
    };
};
