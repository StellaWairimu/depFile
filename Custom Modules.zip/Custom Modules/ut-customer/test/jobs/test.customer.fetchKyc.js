const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerMethods = require('ut-test/lib/methods/customer');
const customerParams = require('ut-test/lib/requestParams/customer');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const USERNAME = 'fetchKyc' + userConstants.USERNAME;
const CUSTOMERKYCFETCH = 'customer.kyc.fetch';
const KYCDESCRIPTION = customerConstants.KYCDESCRIPTION;
const STATUSINACTIVE = 'inactive';
const STATUSACTIVE = 'active';
const RANDOMCONDITIONID = customerConstants.RANDOMCONDITIONID;
const ORDERBYDISPLAY = 'display';
const ORDERBYDESCRIPTION = 'description';
const ORDERBYSTATUSID = 'statusId';
const ORDERBYCUSTOMERTYPE = 'customerType';
const STRINGINPUT = 'test';
const DEFAULTPAGESIZE = 20;
const DEFAULTPAGENUMBER = 1;
const ASC = customerConstants.SORTORDERASC;
const DESC = customerConstants.SORTORDERDESC;
let stdPolicy;
let customerTypeNumber1, customerTypeNumber2;
let orgId1, orgId2, organizationDepthArray;
let attributeId1, attributeId2;

module.exports = function test() {
    return {
        fetchKyc: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('user.user.get', 'get admin details', (context) => {
                    return {
                        actorId: context.login['identity.check'].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, userConstants.ADMINFIRSTNAME).error, null, 'return person');
                    orgId1 = result.memberOF[0].object;
                    orgId2 = result.memberOF[0].object;
                }),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeNumber1 = result.customerType[0].customerTypeNumber;
                    customerTypeNumber2 = result.customerType[1].customerTypeNumber;
                }),
                commonFunc.createStep('core.configuration.fetch', 'fetch defaultBu setting', (context) => {
                    return {
                        key: customerConstants.GETBYDEPTHORGANIZATION
                    };
                }, (result, assert) => {
                    const orgDepth = result[0][0].value;
                    organizationDepthArray = Array.apply(null, {length: orgDepth - 1}).map(Number.call, Number);
                    assert.true(typeof result, 'object', 'return result');
                }),
                // Create organization which correspond to the kyc's depth
                {
                    name: 'Create organization by depth',
                    steps: () => organizationDepthArray.map(org => ({
                        name: 'Add and approve organizations',
                        steps: () => [
                            commonFunc.createStep('customer.organization.add', 'add organization',
                                () => ({
                                    organization: {
                                        organizationName: customerConstants.ORGNAME
                                    },
                                    parent: [orgId1]
                                }), (result, assert) => {
                                    orgId1 = result['organization.info'][0].actorId;
                                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                                }
                            ),
                            customerMethods.approveOrganization('approve organization', () => orgId1),
                            commonFunc.createStep('customer.organization.add', 'add second organization', context2 => {
                                return {
                                    organization: {
                                        organizationName: customerConstants.ORGNAME + 1
                                    },
                                    parent: [orgId2]
                                };
                            }, (result, assert) => {
                                orgId2 = result['organization.info'][0].actorId;
                                assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                            }),
                            customerMethods.approveOrganization('approve second organization', context2 => orgId2)
                        ]
                    }))
                },
                commonFunc.createStep('customer.kycAttribute.list', 'list kyc attributes - customer type 1', context => {
                    return {
                        customerTypeId: customerTypeNumber1
                    };
                }, (result, assert) => {
                    assert.true(result.kycAttributes.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateListKycAttributes(result.kycAttributes).error, null, 'Return all details for kyc attributes');
                    attributeId1 = result.kycAttributes[0].itemNameId;
                }),
                commonFunc.createStep('customer.kycAttribute.list', 'list kyc attributes - customer type 2', context => {
                    return {
                        customerTypeId: customerTypeNumber2
                    };
                }, (result, assert) => {
                    assert.true(result.kycAttributes.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateListKycAttributes(result.kycAttributes).error, null, 'Return all details for kyc attributes');
                    attributeId2 = result.kycAttributes[1].itemNameId;
                }),
                customerMethods.getForCreateKyc('get levels for creating kyc', context => {
                    return {
                        customerType: customerTypeNumber1,
                        organizationId: orgId1
                    };
                }),
                customerMethods.addKyc('add kyc 1', (context) => {
                    return {
                        display: context['get levels for creating kyc'].levels[1].itemNameTranslation,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: context['get levels for creating kyc'].levels[1].itemNameId,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION + 1),
                customerMethods.addKyc('add kyc 2', (context) => {
                    return {
                        display: context['get levels for creating kyc'].levels[2].itemNameTranslation,
                        customerTypeId: customerTypeNumber1,
                        organizationId: orgId1,
                        itemNameId: context['get levels for creating kyc'].levels[2].itemNameId,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId1
                    };
                }, KYCDESCRIPTION + 2),
                customerMethods.getForCreateKyc('get levels for creating kyc 3', context => {
                    return {
                        customerType: customerTypeNumber2,
                        organizationId: orgId2
                    };
                }),
                customerMethods.addKyc('add kyc 3', (context) => {
                    return {
                        display: context['get levels for creating kyc 3'].levels[1].itemNameTranslation,
                        customerTypeId: customerTypeNumber2,
                        organizationId: orgId2,
                        itemNameId: context['get levels for creating kyc 3'].levels[1].itemNameId,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId2
                    };
                }, KYCDESCRIPTION + 3),
                customerMethods.getForCreateKyc('get levels for creating kyc 4', context => {
                    return {
                        customerType: customerTypeNumber2,
                        organizationId: orgId1
                    };
                }),
                customerMethods.addKyc('add kyc 4', (context) => {
                    return {
                        display: context['get levels for creating kyc 4'].levels[2].itemNameTranslation,
                        customerTypeId: customerTypeNumber2,
                        organizationId: orgId1,
                        itemNameId: context['get levels for creating kyc 4'].levels[2].itemNameId,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: attributeId2
                    };
                }, KYCDESCRIPTION + 4),
                customerMethods.changeKycStatus('change kyc status of kyc 3 and 4', context => [context['add kyc 3'].kyc[0].kycId, context['add kyc 4'].kyc[0].kycId], STATUSINACTIVE),
                // Filtering
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc by status isActive and businessUnitId', (context) => {
                    return {
                        isActive: STATUSINACTIVE,
                        businessUnitId: orgId2,
                        paging: {
                            pageSize: customerConstants.PAGESIZE,
                            pageNumber: customerConstants.PAGENUMBER
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                    assert.true(result.kyc.every(kyc => kyc.statusId === STATUSINACTIVE && kyc.organizationId === orgId2), 'return kyc rules with correct status isActive and businessUnitId');
                    assert.equals(result.pagination[0].pageSize, customerConstants.PAGESIZE, 'return defined page size');
                    assert.equals(result.pagination[0].pageNumber, customerConstants.PAGENUMBER, 'return defined page number');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc by customerTypeId and businessUnitId', (context) => {
                    return {
                        customerTypeId: customerTypeNumber2,
                        businessUnitId: orgId2
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                    assert.true(result.kyc.every(kyc => kyc.customerTypeId === customerTypeNumber2.toString() && kyc.organizationId === orgId2), 'return only kyc rules with correct customerTypeId and businessUnitId');
                    assert.equals(result.pagination[0].pageSize, DEFAULTPAGESIZE, 'return default page size');
                    assert.equals(result.pagination[0].pageNumber, DEFAULTPAGENUMBER, 'return default page number');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc by businessUnitId', (context) => {
                    return {
                        businessUnitId: orgId2
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                    assert.true(result.kyc.every(kyc => kyc.organizationId === orgId2), 'return only kyc rules with businessUnitId ' + orgId2);
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc by isActive, customerTypeId and businessUnitId', (context) => {
                    return {
                        isActive: STATUSACTIVE,
                        customerTypeId: customerTypeNumber1,
                        businessUnitId: orgId1
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                    assert.true(result.kyc.every(kyc => kyc.statusId === STATUSACTIVE && kyc.customerTypeId === customerTypeNumber1.toString() && kyc.organizationId === orgId1), 'return kycs with the correct BUid, customerTypeId and status');
                }),
                // Sorting
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - order by display name in ASC order', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            field: ORDERBYDISPLAY,
                            dir: ASC
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                    assert.true(commonFunc.compareOrderString(result.kyc, ORDERBYDISPLAY, 1), 'return results in asc order by display name');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - order by display name in DESC order', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            field: ORDERBYDISPLAY,
                            dir: DESC
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                    assert.true(commonFunc.compareOrderString(result.kyc, ORDERBYDISPLAY, 0), 'return results in desc order by display name');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - order by description in ASC order', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            field: ORDERBYDESCRIPTION,
                            dir: ASC
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                    assert.true((result.kyc[0].description).localeCompare(result.kyc[1].description) <= 0, 'return results in asc order by description');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - order by description in DESC order', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            field: ORDERBYDESCRIPTION,
                            dir: DESC
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                    assert.true((result.kyc[0].description).localeCompare(result.kyc[1].description) >= 0, 'return results in desc order by description');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - order by statusId in ASC order', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            field: ORDERBYSTATUSID,
                            dir: ASC
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                    assert.true((result.kyc[0].statusId).localeCompare(result.kyc[1].statusId) <= 0, 'return results in asc order by statusId');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - order by statusId in DESC order', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            field: ORDERBYSTATUSID,
                            dir: DESC
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                    assert.true((result.kyc[0].statusId).localeCompare(result.kyc[1].statusId) >= 0, 'return results in desc order by statusId');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - order by customerType in ASC order', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            field: ORDERBYCUSTOMERTYPE,
                            dir: ASC
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                    assert.true((result.kyc[0].customerType).localeCompare(result.kyc[1].customerType) <= 0, 'return results in asc order by customerType');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - order by customerType in DESC order', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            field: ORDERBYCUSTOMERTYPE,
                            dir: DESC
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                    assert.true((result.kyc[0].customerType).localeCompare(result.kyc[1].customerType) >= 0, 'return results in desc order by customerType');
                }),
                // NEGATIVE SCENARIOS
                commonFunc.createStep('customer.kyc.fetch', 'unsuccessfully fetch kyc - missing businessUnitId', (context) => {
                    return {
                        isActive: STATUSACTIVE,
                        orderBy: {
                            field: ORDERBYCUSTOMERTYPE,
                            dir: DESC
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - BU is required');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'unsuccessfully fetch kyc - businessUnitId null', context => customerParams.fetchKycParams(context, (context) => {
                    return {
                        businessUnitId: null
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - BU is required');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'unsuccessfully fetch kyc - businessUnitId string', context => customerParams.fetchKycParams(context, (context) => {
                    return {
                        businessUnitId: STRINGINPUT
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'unsuccessfully fetch kyc - businessUnitId empty string', context => customerParams.fetchKycParams(context, (context) => {
                    return {
                        businessUnitId: ''
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - isActive null', context => customerParams.fetchKycParams(context, (context) => {
                    return {
                        businessUnitId: orgId1,
                        isActive: null
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'unsuccessfully fetch kyc - isActive invalid string status', context => customerParams.fetchKycParams(context, (context) => {
                    return {
                        businessUnitId: orgId1,
                        isActive: STRINGINPUT
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'unsuccessfully fetch kyc - isActive empty string', context => customerParams.fetchKycParams(context, (context) => {
                    return {
                        businessUnitId: orgId1,
                        isActive: ''
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - customerTypeId null', context => customerParams.fetchKycParams(context, (context) => {
                    return {
                        businessUnitId: orgId1,
                        customerTypeId: null
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'unsuccessfully fetch kyc - customerTypeId string', context => customerParams.fetchKycParams(context, (context) => {
                    return {
                        businessUnitId: orgId1,
                        customerTypeId: STRINGINPUT
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'unsuccessfully fetch kyc - customerTypeId empty string', context => customerParams.fetchKycParams(context, (context) => {
                    return {
                        businessUnitId: orgId1,
                        customerTypeId: ''
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - dir null', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            dir: null,
                            field: ORDERBYCUSTOMERTYPE
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - dir empty string', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            dir: '',
                            field: ORDERBYCUSTOMERTYPE
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - dir invalid string', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            dir: STRINGINPUT,
                            field: ORDERBYCUSTOMERTYPE
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - direction must be ASC or DESC');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - dir number', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            dir: RANDOMCONDITIONID,
                            field: ORDERBYCUSTOMERTYPE
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - field null', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            dir: ASC,
                            field: null
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - field empty string', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            dir: ASC,
                            field: ''
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - field random string', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            dir: DESC,
                            field: STRINGINPUT
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.kyc.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateFetchKyc(result).error, null, 'Return all details after fetching kyc');
                }),
                commonFunc.createStep('customer.kyc.fetch', 'fetch kyc - field number', (context) => {
                    return {
                        businessUnitId: orgId1,
                        orderBy: {
                            dir: ASC,
                            field: ''
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // MISSING PERMISSIONS
                userMethods.logout('logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('successful login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.kyc.fetch', 'unsuccessfully fetch kyc - missing permission', context => customerParams.fetchKycParams(context, (context) => {
                    return {
                        businessUnitId: orgId1
                    };
                }), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERKYCFETCH) > -1, 'Missing permissions for ' + CUSTOMERKYCFETCH);
                }),
                userMethods.logout('successfully logout new user', (context) => context['successful login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
