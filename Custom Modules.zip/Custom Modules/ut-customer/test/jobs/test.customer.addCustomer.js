const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const documentJoiValidation = require('ut-test/lib/joiValidations/document');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const documentConstants = require('ut-test/lib/constants/document').constants();
const userMethods = require('ut-test/lib/methods/user');
const customerMethods = require('ut-test/lib/methods/customer');
const customerParams = require('ut-test/lib/requestParams/customer');
const CUSTOMERCUSTOMERADD = 'customer.customer.add';
const PORTSQL = 'portSQL';
const PORTHTTP = 'PortHTTP';
const USERNAME = 'addCust' + userConstants.USERNAME;
// Customer
const INDUSTRYID = 1;
const SECTORID = 1;
const LOANCYCLE = '1';
const WRONGINDUSTRYID = -10;
const WRONGSECTORID = -91;
const WRONGLOANCYCLE = -1;
const NONEXISTINGCUSTTYPE = 'nonexisting';
const NUMCUSTTYPEID = commonFunc.generateRandomNumber();
// Phone
const PHONETYPEID = customerConstants.TYPEIDPERSONAL;
const PHONENUM = customerConstants.PHONENUMBER.slice(3, -2);
const NEWPHONENUMBER = customerConstants.NEWPHONENUMBER.slice(0, 12);
const MNOID = customerConstants.MNOID;
const WRONGMNOID = 99;
// const MNOKEY = customerConstants.MNOKEY;
// Address
const WRONGCITY = 'wrong city ' + commonFunc.generateRandomNumber();
// Document
const DOCUMENTTYPEID = documentConstants.DOCUMENTTYPEID;
const DOCUMENTNUMBER = documentConstants.DOCUMENTNUMBER.substring(0, 15);
let stdPolicy, newActorId, newKycId, newStatusId, customerTypeId;

module.exports = function test() {
    return {
        addCustomer: function(test, bus, run) {
            return run(test, bus, [
                userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                // fetch std input policy
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                customerMethods.addCustomer('Add customer successfully', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        documentId: customerConstants.NEWDOCUMENTID
                    };
                }),
                customerMethods.getCustomer('Get the newly created customer', context => context['Add customer successfully'].customer.actorId),
                commonFunc.createStep('customer.customer.add', 'Add customer successfully - all parameters', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                },
                (result, assert) => {
                    newKycId = result.customer.kycId;
                    newStatusId = result.customer.statusId;
                    newActorId = result.customer.actorId;
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                }),
                commonFunc.createStep('customer.customer.get', 'Get a single customer with all his details successufully', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add customer successfully - all parameters'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer).error, null, 'Return customer details after adding a customer');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'Return person details after adding a customer');
                    assert.equals(customerJoiValidation.validateGetPhone(result.customerPhone[0], PHONENUM, PHONETYPEID).error, null, 'Return phone details after adding a customer');
                    assert.equals(customerJoiValidation.validateGetPhone(result.customerPhone[1], NEWPHONENUMBER, PHONETYPEID).error, null, 'Return phone details after adding a customer');
                    assert.equals(customerJoiValidation.validateGetAddress(result.customerAddress[0], customerConstants.ADDRESS, customerConstants.TYPEIDHOME).error, null, 'Return address details after adding a customer');
                    assert.equals(result.customer.actorId, newActorId, 'return actorId');
                    assert.equals(result.customer.kycId, newKycId, 'return kycValue');
                    assert.equals(result.customer.statusId, newStatusId, 'return customerStatusId');
                    assert.equals(result.person.lastName, customerConstants.LASTNAME, 'return lastName');
                    assert.equals(result.person.nationalId, customerConstants.NATIONALID.toString(), 'return nationalId');
                    assert.true(result.person.dateOfBirth.indexOf(customerConstants.DATEOFBIRTH) > -1, 'return dateOfBirth');
                    assert.equals(result.person.placeOfBirth, customerConstants.PLACEOFBIRTH, 'return placeOfBirth');
                    assert.equals(result.person.nationality, customerConstants.NATIONALITY, 'return nationality');
                    assert.equals(result.person.gender, customerConstants.GENDERM, 'return gender');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                }),
                // middle name
                commonFunc.createStep('customer.customer.add', 'Add customer - middle name', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN'
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerConstants.INDIVIDUALCUSTOMERTYPEID).error, null, 'Return customer');
                }),
                /** MNO and phone */
                commonFunc.createStep('customer.customer.add', 'add customer - basic details, no phone', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerConstants.INDIVIDUALCUSTOMERTYPEID).error, null, 'Return customer');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer for mnoId 1', context => customerParams.addCustomerParams(context, (context) => {
                    return {
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerTypeId: customerTypeId,
                        phoneTypeId: PHONETYPEID,
                        phoneNumber: PHONENUM,
                        mnoId: customerConstants.MNOID,
                        documentId: customerConstants.NEWDOCUMENTID
                    };
                }, customerConstants.FIRSTNAME + ' MNOID'),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer).error, null, 'Return all details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                }),
                commonFunc.createStep('customer.customer.get', 'Get customer mnoid 1', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add customer for mnoId 1'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME + ' MNOID').error, null, 'Return person');
                    assert.equals(customerJoiValidation.validateGetPhone(result.customerPhone[0], PHONENUM, PHONETYPEID).error, null, 'Return phone details');
                    assert.equals(result.customerPhone[0].mnoId, MNOID, 'return mnoId');
                    assert.true(result.customerPhone[0].isPrimary, 'return isPrimary');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - wrong mnoId', context => customerParams.addCustomerParams(context, (context) => {
                    return {
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerTypeId: customerTypeId,
                        phoneTypeId: PHONETYPEID,
                        phoneNumber: PHONENUM,
                        mnoId: WRONGMNOID
                    };
                }, customerConstants.FIRSTNAME + 'MNOID 1'), null,
                (error, assert) => {
                    assert.equals(error.type, PORTSQL, 'return PortSQL');
                    // TODO: handle db conflicts with proper error
                    // assert.true(error.message.indexOf('The INSERT statement conflicted with') > -1, 'Fail to insert in DB due to wrong data');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - empty mnoId', context => customerParams.addCustomerParams(context, (context) => {
                    return {
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerTypeId: customerTypeId,
                        phoneTypeId: PHONETYPEID,
                        phoneNumber: PHONENUM,
                        mnoId: ''
                    };
                }, customerConstants.FIRSTNAME + 'MNOID 1'), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return PortSQL');
                }),
                customerMethods.addCustomer('Add customer - null mnoId', context => {
                    return {
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerTypeId: customerTypeId,
                        phoneTypeId: PHONETYPEID,
                        phoneNumber: PHONENUM,
                        mnoId: null,
                        documentId: customerConstants.NEWDOCUMENTID
                    };
                }, customerConstants.FIRSTNAME + 'MNOID1'),
                commonFunc.createStep('customer.customer.get', 'Get customer null mnoid', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add customer - null mnoId'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME + 'MNOID1').error, null, 'Return person');
                    assert.equals(customerJoiValidation.validateGetPhone(result.customerPhone[0], PHONENUM, PHONETYPEID).error, null, 'Return phone details');
                    assert.equals(result.customerPhone[0].mnoId, null, 'return null mnoId');
                    assert.true(result.customerPhone[0].isPrimary, 'return isPrimary');
                    // assert.equals(result.customerPhone[0].mnoKey, null, 'return null mnoKey');
                }),
                /** CITY AND ADDRESS */
                commonFunc.createStep('customer.customer.add', 'Add customer for city 1', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME + ' city 1',
                            lastName: customerConstants.LASTNAME
                        },
                        address: [{
                            city: customerConstants.CITY1,
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS,
                            statusId: customerConstants.STATUSIDACTIVE
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer).error, null, 'Return all details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                }),
                commonFunc.createStep('customer.customer.get', 'Get customer cityid 1', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add customer for city 1'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME + ' city 1').error, null, 'Return person');
                    assert.equals(customerJoiValidation.validateGetAddress(result.customerAddress[0], customerConstants.ADDRESS, customerConstants.TYPEIDHOME).error, null, 'return all details for address');
                    assert.equals(result.customerAddress[0].city, customerConstants.CITY1, 'return city');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - wrong city', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME + ' wrong city',
                            lastName: customerConstants.LASTNAME
                        },
                        address: [{
                            city: WRONGCITY,
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS,
                            statusId: customerConstants.STATUSIDACTIVE
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer).error, null, 'Return all details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                }),
                commonFunc.createStep('customer.customer.get', 'Get customer cityid 1', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add customer - wrong city'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME + ' wrong city').error, null, 'Return person');
                    assert.equals(customerJoiValidation.validateGetAddress(result.customerAddress[0], customerConstants.ADDRESS, customerConstants.TYPEIDHOME).error, null, 'return all details for address');
                    assert.equals(result.customerAddress[0].city, WRONGCITY, 'return city');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - null city', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME + ' null city',
                            lastName: customerConstants.LASTNAME
                        },
                        address: [{
                            city: null,
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS,
                            statusId: customerConstants.STATUSIDACTIVE
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer).error, null, 'Return all details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                }),
                commonFunc.createStep('customer.customer.get', 'Get customer cityid 1', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add customer - wrong city'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME + ' wrong city').error, null, 'Return person');
                    assert.equals(customerJoiValidation.validateGetAddress(result.customerAddress[0], customerConstants.ADDRESS, customerConstants.TYPEIDHOME).error, null, 'return all details for address');
                    assert.equals(result.customerAddress[0].city, WRONGCITY, 'return city');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - empty city', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME + ' empty city',
                            lastName: customerConstants.LASTNAME
                        },
                        address: [{
                            city: '',
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS,
                            statusId: customerConstants.STATUSIDACTIVE
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                /** IndustryId, sectorId, loanCycle */
                commonFunc.createStep('customer.customer.add', 'Add customer - industryId, sectorId and loanCycle - 1', context => customerParams.addCustomerParams(context, (context) => {
                    return {
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerTypeId: customerTypeId,
                        industryId: INDUSTRYID,
                        sectorId: SECTORID,
                        loanCycle: LOANCYCLE
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - wrong(negative) industryId, sectorId and loanCycl', context => customerParams.addCustomerParams(context, (context) => {
                    return {
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerTypeId: customerTypeId,
                        industryId: WRONGINDUSTRYID,
                        sectorId: WRONGSECTORID,
                        loanCycle: WRONGLOANCYCLE
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - empty industryId, sectorId and loanCycle', context => customerParams.addCustomerParams(context, (context) => {
                    return {
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerTypeId: customerTypeId,
                        industryId: '',
                        sectorId: '',
                        loanCycle: ''
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - null industryId, sectorId and loanCycle', context => customerParams.addCustomerParams(context, (context) => {
                    return {
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerTypeId: customerTypeId,
                        industryId: null,
                        sectorId: null,
                        loanCycle: null
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                // DOCUMENTS
                customerMethods.addCustomer('Add document with documentTypeId', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        documentTypeId: DOCUMENTTYPEID,
                        documentId: customerConstants.NEWDOCUMENTID
                    };
                }),
                commonFunc.createStep('customer.customer.get', 'Get a single customer with all his details successufully 4', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add document with documentTypeId'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'Return person details after adding a customer');
                    assert.equals(documentJoiValidation.validateGetDocument(result.documentAttachment).error, null, 'Return document details after adding a customer');
                    assert.equals(result.document[0].documentTypeId, DOCUMENTTYPEID, 'return documentTypeId');
                    assert.equals(result.document[0].statusId, customerConstants.STATUSIDAPPROVED, 'return documentStatusId'); // the default value should be approved
                }),
                customerMethods.addCustomer('Add document with all details', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        documentTypeId: DOCUMENTTYPEID,
                        documentStatusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                        expirationDate: documentConstants.EXPIRATIONDATE,
                        documentNumber: DOCUMENTNUMBER,
                        documentId: customerConstants.NEWDOCUMENTID
                    };
                }),
                commonFunc.createStep('customer.customer.get', 'Get a single customer with all his details successufully 5', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add document with all details'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'Return person details after adding a customer');
                    assert.equals(documentJoiValidation.validateGetDocument(result.documentAttachment).error, null, 'Return document details after adding a customer');
                    assert.equals(result.document[0].documentTypeId, DOCUMENTTYPEID, 'return documentTypeId');
                    assert.equals(result.document[0].statusId, customerConstants.STATUSIDACTIVE, 'return documentStatusId');
                    assert.equals(result.document[0].expirationDate.substring(0, 10), documentConstants.EXPIRATIONDATE, 'return expirationDate');
                    assert.equals(result.document[0].documentNumber, DOCUMENTNUMBER, 'return documentNumber');
                }),
                commonFunc.createStep('customer.customer.add', 'Add document - empty string documentTypeId', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentTypeId: '',
                            statusId: customerConstants.STATUSIDACTIVE,
                            documentId: customerConstants.NEWDOCUMENTID
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'empty string documentTypeId');
                }),
                commonFunc.createStep('customer.customer.add', 'Add document - empty string statusID', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentTypeId: DOCUMENTTYPEID,
                            statusId: '',
                            documentId: customerConstants.NEWDOCUMENTID
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'empty string statusId');
                }),
                commonFunc.createStep('customer.customer.add', 'Add document - null documentTypeId', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentTypeId: null,
                            statusId: customerConstants.STATUSIDACTIVE,
                            documentId: customerConstants.NEWDOCUMENTID
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, PORTSQL, 'return PortSQL - null documentTypeId');
                }),
                commonFunc.createStep('customer.customer.add', 'Add document - null statusId', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentTypeId: DOCUMENTTYPEID,
                            statusId: null,
                            documentNumber: DOCUMENTNUMBER,
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentId: customerConstants.NEWDOCUMENTID
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerConstants.INDIVIDUALCUSTOMERTYPEID).error, null, 'Return all details after adding a customer');
                }),
                commonFunc.createStep('customer.customer.add', 'Add document - missing documentTypeId', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            statusId: customerConstants.STATUSIDACTIVE
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTSQL, 'return PortSQL - missing documentTypeId');
                }),
                commonFunc.createStep('customer.customer.add', 'Add document - expDate and docNum with null', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentTypeId: DOCUMENTTYPEID,
                            statusId: customerConstants.STATUSIDACTIVE,
                            expirationDate: null,
                            documentNumber: null
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'Add document - expDate and docNum with empty string', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentTypeId: DOCUMENTTYPEID,
                            statusId: customerConstants.STATUSIDACTIVE,
                            expirationDate: '',
                            documentNumber: ''
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // NEGATIVE
                commonFunc.createStep('customer.customer.add', 'Add customer - data for customer not single', context => {
                    return {
                        customer: [{
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        }, {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        }],
                        person: [{
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'data not single');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - only customer parameters provided', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'customer.personJointOrganizationDataRequired', 'return failure');
                    // TODO: return validation data
                    // assert.true(error.message.indexOf('Invalid data. At least one of the parameters @personData, @jointData, @organizationData is required') > -1, 'Fail to insert in DB due to wrong data');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - empty string customerNumber', context => customerParams.addCustomerParams(context, (context) => {
                    return {
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerTypeId: customerTypeId,
                        customerNumber: ''
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer unsuccessfully - empty customerTypeId', context => {
                    return {
                        customer: {
                            customerTypeId: '',
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer unsuccessfully - empty organizationId', context => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.CLIENTTYPEID,
                            organizationId: ''
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return PortHTTP');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - middle name, same as first name', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            middleName: customerConstants.FIRSTNAME
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerConstants.INDIVIDUALCUSTOMERTYPEID).error, null, 'Return customer');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer -empty person params except names', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            nationalId: '',
                            nationality: '',
                            dateOfBirth: '',
                            gender: ''
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }]
                    };
                }, () => {}, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer -null person params except names', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            nationalId: null,
                            nationality: null,
                            dateOfBirth: null,
                            gender: null
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerConstants.INDIVIDUALCUSTOMERTYPEID).error, null, 'Return customer');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer unsuccessfully - missing customerTypeId', context => {
                    return {
                        customer: {
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, PORTSQL, 'missing customerTypeId');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer unsuccessfully - NONEXISTINGCUSTTYPE', context => {
                    return {
                        customer: {
                            customerTypeId: NONEXISTINGCUSTTYPE,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, PORTSQL, 'non existing customerTypeId');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer unsuccessfully - number for customerTypeId', context => {
                    return {
                        customer: {
                            customerTypeId: NUMCUSTTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'numeric customerTypeId');
                }),
                commonFunc.createStep('customer.customer.add', 'Register existing customer', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        }
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerConstants.INDIVIDUALCUSTOMERTYPEID).error, null, 'Return all details after adding a customer');
                }),
                commonFunc.createStep('customer.customer.add', 'Missing isEnabled', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        }
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer).error, null, 'Return all details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                }),
                commonFunc.createStep('customer.customer.add', 'Missing isDeleted', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        }
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerConstants.INDIVIDUALCUSTOMERTYPEID).error, null, 'Return all details after adding a customer');
                }),
                commonFunc.createStep('customer.customer.add', 'isEnabled false', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: false,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        }
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerConstants.INDIVIDUALCUSTOMERTYPEID).error, null, 'Return all details after adding a customer');
                }),
                commonFunc.createStep('customer.customer.get', 'Get a single customer with all his details successufully 2', (context) => customerParams.actorIdParams(
                    context, (context) => context['isEnabled false'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'Return person details after adding a customer');
                    assert.equals(result.person.isEnabled, false, 'return isEnabled');
                }),
                commonFunc.createStep('customer.customer.add', 'isDeleted false', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: false,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        }
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerConstants.INDIVIDUALCUSTOMERTYPEID).error, null, 'Return all details after adding a customer');
                }),
                commonFunc.createStep('customer.customer.get', 'Get a single customer with all his details successufully 3', (context) => customerParams.actorIdParams(
                    context, (context) => context['isDeleted false'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'Return person details after adding a customer');
                    assert.equals(result.person.isDeleted, false, 'return isEnabled');
                }),
                /**
                 * MISSING PERMISSIONS
                 */
                userMethods.logout('Logout admin user', context => context.login['identity.check'].sessionId),
                userMethods.login('Login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.customer.add', 'Add customer without rights for it', (context) => customerParams.addCustomerParams(
                    context, (context) => {
                        return {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        };
                    }), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERCUSTOMERADD) > -1, 'Missing permissions for ' + CUSTOMERCUSTOMERADD);
                }),
                userMethods.logout('Logout new user', context => context['Login new user']['identity.check'].sessionId)]);
        }
    };
};
