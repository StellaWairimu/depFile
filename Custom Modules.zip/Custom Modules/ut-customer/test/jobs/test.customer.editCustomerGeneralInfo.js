const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
// var userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const DATEOFBIRTH = commonFunc.randomDate(new Date(1980, 0, 2), new Date()); // random Date > 18 years old
const NATIONALID = commonFunc.generateRandomNumber();
const NEWPLACEOFBIRTH = 'New York';
const NEWNATIONALITY = 'US';
const FUTUREDATE = commonFunc.randomDate(new Date(), new Date(3000, 0, 2));
// Phone
const PHONETYPEID = customerConstants.TYPEIDPERSONAL;
const PHONENUM = customerConstants.PHONENUMBER.slice(3, -2);
const NEWPHONENUMBER = customerConstants.NEWPHONENUMBER.slice(0, 12);
// const MNOKEY = customerConstants.MNOKEY;
// Address
let customerTypeId, martialId, educationId, employerCategoryId, employmentId, incomeId;

module.exports = function test() {
    return {
        editCustomerGeneralInfo: function(test, bus, run) {
            return run(test, bus, [
                userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                /**
                 * GENERAL INFO TAB
                 */
                // fetch organizations
                commonFunc.createStep('customer.organization.graphFetch', 'fetch child organizations of sa organization', (context) => {
                    return {
                        parentFilter: context['get admin details'].memberOF[0].object
                    };
                }, (result, assert) => {
                    // organizationId = result.organization[0].id;
                    assert.equals(customerJoiValidation.validateFetchOrganizationGraph(result.organization).error, null, 'return organization graph fetch details');
                }),
                commonFunc.createStep('customer.incomeRange.list', 'list incomeRange', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateListIncomeRange(result.incomeRange).error, null, 'Return list incomeRange');
                    incomeId = result.incomeRange[0].incomeRangeId;
                }),
                commonFunc.createStep('customer.maritalStatus.list', 'list martialStatus', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateListMaritalStatus(result.maritalStatus).error, null, 'Return list maritalStatus');
                    martialId = result.maritalStatus[0].maritalStatusId;
                }),
                commonFunc.createStep('customer.education.list', 'list education', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateListEducation(result.education).error, null, 'Return list education');
                    educationId = result.education[0].educationId;
                }),
                commonFunc.createStep('customer.employment.list', 'list employment', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateListEmployment(result.employment).error, null, 'Return list employment');
                    employmentId = result.employment[0].employmentId;
                }),
                commonFunc.createStep('customer.employerCategory.list', 'list employerCategory', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateListEmployerCategory(result.employerCategory).error, null, 'Return list employerCategory');
                    employerCategoryId = result.employerCategory[0].employerCategoryId;
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer successfully - all parameters for General Info tab', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            middleName: customerConstants.FIRSTNAME,
                            familyMembers: 1
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }, {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: NEWPHONENUMBER
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                    assert.equals(result.person.firstName, customerConstants.FIRSTNAME, 'return fisrtName');
                    assert.equals(result.person.middleName, customerConstants.FIRSTNAME, 'return middleName');
                    assert.equals(result.person.lastName, customerConstants.LASTNAME, 'return lastName');
                    assert.equals(result.person.employerName, customerConstants.FIRSTNAME, 'return employerName');
                    assert.equals(result.person.gender, customerConstants.GENDERM, 'return gender');
                    assert.equals(result.person.nationality, customerConstants.NATIONALITY, 'return nationality');
                    assert.equals(result.person.maritalStatusId, martialId, 'return maritalStatusId');
                    assert.equals(result.person.incomeRangeId, incomeId, 'return incomeId');
                    assert.equals(result.person.educationId, educationId, 'return educationId');
                    assert.equals(result.person.employerCategoryId, employerCategoryId, 'return employerCategoryId');
                    assert.equals(result.person.employmentId, employmentId, 'return employmentId');
                    assert.equals(result.person.familyMembers, 1, 'return family members');
                }),
                /** person */
                commonFunc.createStep('customer.customer.edit', 'edit customer - person details updated - all params', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        customer: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            currentVersion: context['Add customer successfully - all parameters for General Info tab'].customer.currentVersion,
                            customerTypeId: context['Add customer successfully - all parameters for General Info tab'].customer.customerTypeId,
                            stateId: context['Add customer successfully - all parameters for General Info tab'].customer.stateId,
                            statusId: context['Add customer successfully - all parameters for General Info tab'].customer.statusId,
                            customerUnapprovedId: context['Add customer successfully - all parameters for General Info tab'].customer.customerUnapprovedId
                        },
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME + 'updated',
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME + 'updated',
                            nationalId: NATIONALID,
                            dateOfBirth: DATEOFBIRTH,
                            placeOfBirth: NEWPLACEOFBIRTH,
                            nationality: NEWNATIONALITY,
                            gender: customerConstants.GENDERF,
                            educationId: null,
                            employerCategoryId: null,
                            employerName: customerConstants.FIRSTNAME + 'NEW',
                            employmentDate: null,
                            employmentId: null,
                            incomeRangeId: null,
                            maritalStatusId: null,
                            familyMembers: 2,
                            personUnapprovedId: context['Add customer successfully - all parameters for General Info tab'].person.personUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer, customerConstants.CUSTOMERTYPEID).error, null, 'return customer details');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME + 'updated').error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.get', 'get editted customer - person all params', (context) => {
                    return {
                        actorId: context['edit customer - person details updated - all params'].customer.actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME + 'updated').error, null, 'return person details');
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer, customerConstants.CUSTOMERTYPEID).error, null, 'return customer details');
                    assert.equals(result.person.firstName, customerConstants.FIRSTNAME + 'updated', 'return updated firstName');
                    assert.equals(result.person.lastName, customerConstants.LASTNAME + 'updated', 'return updated lastName');
                    assert.equals(result.person.middleName, customerConstants.FIRSTNAME + 'MN', 'return updated middleName');
                    assert.equals(result.person.nationalId, NATIONALID.toString(), 'return updated nationalId');
                    assert.equals(result.person.placeOfBirth, NEWPLACEOFBIRTH, 'return updated place of birth');
                    assert.equals(result.person.nationality, NEWNATIONALITY, 'return updated nationality');
                    assert.equals(result.person.gender, customerConstants.GENDERF, 'return updated gender');
                    assert.equals(result.person.employerName, customerConstants.FIRSTNAME + 'NEW', 'return employerName');
                    assert.equals(result.person.maritalStatusId, null, 'return maritalStatusId');
                    assert.equals(result.person.incomeRangeId, null, 'return incomeId');
                    assert.equals(result.person.educationId, null, 'return educationId');
                    assert.equals(result.person.employerCategoryId, null, 'return employerCategoryId');
                    assert.equals(result.person.employmentId, null, 'return employmentId');
                    assert.equals(result.person.familyMembers, 2, 'return family members');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - person names, update flag false', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME + '-2',
                            middleName: customerConstants.FIRSTNAME + 'MN- 2',
                            lastName: customerConstants.LASTNAME + ' - 2',
                            personUnapprovedId: context['get editted customer - person all params'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['get editted customer - person all params'].person.actorId,
                            currentVersion: context['get editted customer - person all params'].customer.currentVersion,
                            customerTypeId: context['get editted customer - person all params'].customer.customerTypeId,
                            stateId: context['get editted customer - person all params'].customer.stateId,
                            statusId: context['get editted customer - person all params'].customer.statusId,
                            customerUnapprovedId: context['get editted customer - person all params'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer, customerConstants.CUSTOMERTYPEID).error, null, 'return customer details');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME + '-2').error, null, 'return person details');
                    assert.equals(result.person.lastName, customerConstants.LASTNAME + ' - 2', 'return updated lastName');
                    assert.equals(result.person.middleName, customerConstants.FIRSTNAME + 'MN- 2', 'return updated middleName');
                }),
                commonFunc.createStep('customer.customer.edit', 'update all again', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['edit customer - person names, update flag false'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['edit customer - person names, update flag false'].person.actorId,
                            currentVersion: context['edit customer - person names, update flag false'].customer.currentVersion,
                            customerTypeId: context['edit customer - person names, update flag false'].customer.customerTypeId,
                            stateId: context['edit customer - person names, update flag false'].customer.stateId,
                            statusId: context['edit customer - person names, update flag false'].customer.statusId,
                            customerUnapprovedId: context['edit customer - person names, update flag false'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                    assert.equals(result.person.firstName, customerConstants.FIRSTNAME, 'return fisrtName');
                    assert.equals(result.person.middleName, customerConstants.FIRSTNAME, 'return middleName');
                    assert.equals(result.person.lastName, customerConstants.LASTNAME, 'return lastName');
                    assert.equals(result.person.employerName, customerConstants.FIRSTNAME, 'return employerName');
                    assert.equals(result.person.gender, customerConstants.GENDERM, 'return gender');
                    assert.equals(result.person.nationality, customerConstants.NATIONALITY, 'return nationality');
                    assert.equals(result.person.maritalStatusId, martialId, 'return maritalStatusId');
                    assert.equals(result.person.incomeRangeId, incomeId, 'return incomeId');
                    assert.equals(result.person.educationId, educationId, 'return educationId');
                    assert.equals(result.person.employerCategoryId, employerCategoryId, 'return employerCategoryId');
                    assert.equals(result.person.employmentId, employmentId, 'return employmentId');
                    assert.equals(result.person.familyMembers, 1, 'return family members');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - person names, missing actorId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['update all again'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['update all again'].person.actorId,
                            currentVersion: context['update all again'].customer.currentVersion,
                            customerTypeId: context['update all again'].customer.customerTypeId,
                            stateId: context['update all again'].customer.stateId,
                            statusId: context['update all again'].customer.statusId,
                            customerUnapprovedId: context['update all again'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'null actorId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: null,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['update all again'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['update all again'].person.actorId,
                            currentVersion: context['update all again'].customer.currentVersion,
                            customerTypeId: context['update all again'].customer.customerTypeId,
                            stateId: context['update all again'].customer.stateId,
                            statusId: context['update all again'].customer.statusId,
                            customerUnapprovedId: context['update all again'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty actorId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: '',
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['update all again'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['update all again'].person.actorId,
                            currentVersion: context['update all again'].customer.currentVersion,
                            customerTypeId: context['update all again'].customer.customerTypeId,
                            stateId: context['update all again'].customer.stateId,
                            statusId: context['update all again'].customer.statusId,
                            customerUnapprovedId: context['update all again'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty firstName', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: '',
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['update all again'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['update all again'].person.actorId,
                            currentVersion: context['update all again'].customer.currentVersion,
                            customerTypeId: context['update all again'].customer.customerTypeId,
                            stateId: context['update all again'].customer.stateId,
                            statusId: context['update all again'].customer.statusId,
                            customerUnapprovedId: context['update all again'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing firstName', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['update all again'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['update all again'].person.actorId,
                            currentVersion: context['update all again'].customer.currentVersion,
                            customerTypeId: context['update all again'].customer.customerTypeId,
                            stateId: context['update all again'].customer.stateId,
                            statusId: context['update all again'].customer.statusId,
                            customerUnapprovedId: context['update all again'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty middleName', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: '',
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['update all again'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['update all again'].person.actorId,
                            currentVersion: context['update all again'].customer.currentVersion,
                            customerTypeId: context['update all again'].customer.customerTypeId,
                            stateId: context['update all again'].customer.stateId,
                            statusId: context['update all again'].customer.statusId,
                            customerUnapprovedId: context['update all again'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing middleName', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['update all again'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['update all again'].person.actorId,
                            currentVersion: context['update all again'].customer.currentVersion,
                            customerTypeId: context['update all again'].customer.customerTypeId,
                            stateId: context['update all again'].customer.stateId,
                            statusId: context['update all again'].customer.statusId,
                            customerUnapprovedId: context['update all again'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.person.middleName, null, 'return updated middleName');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty lastNAme', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: '',
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing middleName'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing middleName'].person.actorId,
                            currentVersion: context['missing middleName'].customer.currentVersion,
                            customerTypeId: context['missing middleName'].customer.customerTypeId,
                            stateId: context['missing middleName'].customer.stateId,
                            statusId: context['missing middleName'].customer.statusId,
                            customerUnapprovedId: context['missing middleName'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing lastName', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing middleName'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing middleName'].person.actorId,
                            currentVersion: context['missing middleName'].customer.currentVersion,
                            customerTypeId: context['missing middleName'].customer.customerTypeId,
                            stateId: context['missing middleName'].customer.stateId,
                            statusId: context['missing middleName'].customer.statusId,
                            customerUnapprovedId: context['missing middleName'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'emplty nationalId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: '',
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing middleName'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing middleName'].person.actorId,
                            currentVersion: context['missing middleName'].customer.currentVersion,
                            customerTypeId: context['missing middleName'].customer.customerTypeId,
                            stateId: context['missing middleName'].customer.stateId,
                            statusId: context['missing middleName'].customer.statusId,
                            customerUnapprovedId: context['missing middleName'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing nationalId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing middleName'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing middleName'].person.actorId,
                            currentVersion: context['missing middleName'].customer.currentVersion,
                            customerTypeId: context['missing middleName'].customer.customerTypeId,
                            stateId: context['missing middleName'].customer.stateId,
                            statusId: context['missing middleName'].customer.statusId,
                            customerUnapprovedId: context['missing middleName'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.person.nationalId, null, 'return empty nationalId');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty dateOfBirth', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: '',
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing nationalId'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing nationalId'].person.actorId,
                            currentVersion: context['missing nationalId'].customer.currentVersion,
                            customerTypeId: context['missing nationalId'].customer.customerTypeId,
                            stateId: context['missing nationalId'].customer.stateId,
                            statusId: context['missing nationalId'].customer.statusId,
                            customerUnapprovedId: context['missing nationalId'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing dateOfBirth', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing nationalId'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing nationalId'].person.actorId,
                            currentVersion: context['missing nationalId'].customer.currentVersion,
                            customerTypeId: context['missing nationalId'].customer.customerTypeId,
                            stateId: context['missing nationalId'].customer.stateId,
                            statusId: context['missing nationalId'].customer.statusId,
                            customerUnapprovedId: context['missing nationalId'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'future dateOfBirth', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: FUTUREDATE.toString(),
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing dateOfBirth'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing dateOfBirth'].person.actorId,
                            currentVersion: context['missing dateOfBirth'].customer.currentVersion,
                            customerTypeId: context['missing dateOfBirth'].customer.customerTypeId,
                            stateId: context['missing dateOfBirth'].customer.stateId,
                            statusId: context['missing dateOfBirth'].customer.statusId,
                            customerUnapprovedId: context['missing dateOfBirth'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.wrongDateOfBirth', 'return sql error');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty placeOfBirth', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: '',
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing dateOfBirth'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing dateOfBirth'].person.actorId,
                            currentVersion: context['missing dateOfBirth'].customer.currentVersion,
                            customerTypeId: context['missing dateOfBirth'].customer.customerTypeId,
                            stateId: context['missing dateOfBirth'].customer.stateId,
                            statusId: context['missing dateOfBirth'].customer.statusId,
                            customerUnapprovedId: context['missing dateOfBirth'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing placeOfBirth', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing dateOfBirth'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing dateOfBirth'].person.actorId,
                            currentVersion: context['missing dateOfBirth'].customer.currentVersion,
                            customerTypeId: context['missing dateOfBirth'].customer.customerTypeId,
                            stateId: context['missing dateOfBirth'].customer.stateId,
                            statusId: context['missing dateOfBirth'].customer.statusId,
                            customerUnapprovedId: context['missing dateOfBirth'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.person.placeOfBirth, null, 'return editted place of birth');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty nationality', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: '',
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing placeOfBirth'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing placeOfBirth'].person.actorId,
                            currentVersion: context['missing placeOfBirth'].customer.currentVersion,
                            customerTypeId: context['missing placeOfBirth'].customer.customerTypeId,
                            stateId: context['missing placeOfBirth'].customer.stateId,
                            statusId: context['missing placeOfBirth'].customer.statusId,
                            customerUnapprovedId: context['missing placeOfBirth'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer, customerConstants.CUSTOMERTYPEID).error, null, 'return customer details');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                // }, null, (error, assert) => {
                //     assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing nationality', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing placeOfBirth'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing placeOfBirth'].person.actorId,
                            currentVersion: context['missing placeOfBirth'].customer.currentVersion,
                            customerTypeId: context['missing placeOfBirth'].customer.customerTypeId,
                            stateId: context['missing placeOfBirth'].customer.stateId,
                            statusId: context['missing placeOfBirth'].customer.statusId,
                            customerUnapprovedId: context['missing placeOfBirth'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.person.nationality, null, 'return editted nationality');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty gender', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: '',
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing nationality'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing nationality'].person.actorId,
                            currentVersion: context['missing nationality'].customer.currentVersion,
                            customerTypeId: context['missing nationality'].customer.customerTypeId,
                            stateId: context['missing nationality'].customer.stateId,
                            statusId: context['missing nationality'].customer.statusId,
                            customerUnapprovedId: context['missing nationality'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing gender', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing nationality'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing nationality'].person.actorId,
                            currentVersion: context['missing nationality'].customer.currentVersion,
                            customerTypeId: context['missing nationality'].customer.customerTypeId,
                            stateId: context['missing nationality'].customer.stateId,
                            statusId: context['missing nationality'].customer.statusId,
                            customerUnapprovedId: context['missing nationality'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.person.gender, null, 'return editted gender');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty educationId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: '',
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing gender'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing gender'].person.actorId,
                            currentVersion: context['missing gender'].customer.currentVersion,
                            customerTypeId: context['missing gender'].customer.customerTypeId,
                            stateId: context['missing gender'].customer.stateId,
                            statusId: context['missing gender'].customer.statusId,
                            customerUnapprovedId: context['missing gender'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing educationId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing gender'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing gender'].person.actorId,
                            currentVersion: context['missing gender'].customer.currentVersion,
                            customerTypeId: context['missing gender'].customer.customerTypeId,
                            stateId: context['missing gender'].customer.stateId,
                            statusId: context['missing gender'].customer.statusId,
                            customerUnapprovedId: context['missing gender'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.person.educationId, null, 'return editted educationId');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty employerCategoryId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: '',
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing educationId'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing educationId'].person.actorId,
                            currentVersion: context['missing educationId'].customer.currentVersion,
                            customerTypeId: context['missing educationId'].customer.customerTypeId,
                            stateId: context['missing educationId'].customer.stateId,
                            statusId: context['missing educationId'].customer.statusId,
                            customerUnapprovedId: context['missing educationId'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing employerCategoryId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing educationId'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing educationId'].person.actorId,
                            currentVersion: context['missing educationId'].customer.currentVersion,
                            customerTypeId: context['missing educationId'].customer.customerTypeId,
                            stateId: context['missing educationId'].customer.stateId,
                            statusId: context['missing educationId'].customer.statusId,
                            customerUnapprovedId: context['missing educationId'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.person.employerCategoryId, null, 'return editted employerCategoryId');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty employerName', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: '',
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing employerCategoryId'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing employerCategoryId'].person.actorId,
                            currentVersion: context['missing employerCategoryId'].customer.currentVersion,
                            customerTypeId: context['missing employerCategoryId'].customer.customerTypeId,
                            stateId: context['missing employerCategoryId'].customer.stateId,
                            statusId: context['missing employerCategoryId'].customer.statusId,
                            customerUnapprovedId: context['missing employerCategoryId'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing employerName', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing employerCategoryId'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing employerCategoryId'].person.actorId,
                            currentVersion: context['missing employerCategoryId'].customer.currentVersion,
                            customerTypeId: context['missing employerCategoryId'].customer.customerTypeId,
                            stateId: context['missing employerCategoryId'].customer.stateId,
                            statusId: context['missing employerCategoryId'].customer.statusId,
                            customerUnapprovedId: context['missing employerCategoryId'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.person.employerName, null, 'return editted employerName');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty employmentDate', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: '',
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing employerName'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing employerName'].person.actorId,
                            currentVersion: context['missing employerName'].customer.currentVersion,
                            customerTypeId: context['missing employerName'].customer.customerTypeId,
                            stateId: context['missing employerName'].customer.stateId,
                            statusId: context['missing employerName'].customer.statusId,
                            customerUnapprovedId: context['missing employerName'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing employment DAte', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing employerName'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing employerName'].person.actorId,
                            currentVersion: context['missing employerName'].customer.currentVersion,
                            customerTypeId: context['missing employerName'].customer.customerTypeId,
                            stateId: context['missing employerName'].customer.stateId,
                            statusId: context['missing employerName'].customer.statusId,
                            customerUnapprovedId: context['missing employerName'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty employmentId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: '',
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing employment DAte'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing employment DAte'].person.actorId,
                            currentVersion: context['missing employment DAte'].customer.currentVersion,
                            customerTypeId: context['missing employment DAte'].customer.customerTypeId,
                            stateId: context['missing employment DAte'].customer.stateId,
                            statusId: context['missing employment DAte'].customer.statusId,
                            customerUnapprovedId: context['missing employment DAte'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing employmentId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing employment DAte'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing employment DAte'].person.actorId,
                            currentVersion: context['missing employment DAte'].customer.currentVersion,
                            customerTypeId: context['missing employment DAte'].customer.customerTypeId,
                            stateId: context['missing employment DAte'].customer.stateId,
                            statusId: context['missing employment DAte'].customer.statusId,
                            customerUnapprovedId: context['missing employment DAte'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.person.employmentId, employmentId, 'return employmentId');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty incomeRange', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: '',
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing employmentId'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing employmentId'].person.actorId,
                            currentVersion: context['missing employmentId'].customer.currentVersion,
                            customerTypeId: context['missing employmentId'].customer.customerTypeId,
                            stateId: context['missing employmentId'].customer.stateId,
                            statusId: context['missing employmentId'].customer.statusId,
                            customerUnapprovedId: context['missing employmentId'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing incomeRangeId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing employmentId'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing employmentId'].person.actorId,
                            currentVersion: context['missing employmentId'].customer.currentVersion,
                            customerTypeId: context['missing employmentId'].customer.customerTypeId,
                            stateId: context['missing employmentId'].customer.stateId,
                            statusId: context['missing employmentId'].customer.statusId,
                            customerUnapprovedId: context['missing employmentId'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.person.incomeRangeId, null, 'return editted incomeId');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty maritalStatusId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: '',
                            familyMembers: 1,
                            personUnapprovedId: context['missing incomeRangeId'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing incomeRangeId'].person.actorId,
                            currentVersion: context['missing incomeRangeId'].customer.currentVersion,
                            customerTypeId: context['missing incomeRangeId'].customer.customerTypeId,
                            stateId: context['missing incomeRangeId'].customer.stateId,
                            statusId: context['missing incomeRangeId'].customer.statusId,
                            customerUnapprovedId: context['missing incomeRangeId'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing maritalStatusId', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            familyMembers: 1,
                            personUnapprovedId: context['missing incomeRangeId'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing incomeRangeId'].person.actorId,
                            currentVersion: context['missing incomeRangeId'].customer.currentVersion,
                            customerTypeId: context['missing incomeRangeId'].customer.customerTypeId,
                            stateId: context['missing incomeRangeId'].customer.stateId,
                            statusId: context['missing incomeRangeId'].customer.statusId,
                            customerUnapprovedId: context['missing incomeRangeId'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.person.maritalStatusId, null, 'return editted maritalStatusId');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'empty family members', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            familyMembers: '',
                            personUnapprovedId: context['missing maritalStatusId'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing maritalStatusId'].person.actorId,
                            currentVersion: context['missing maritalStatusId'].customer.currentVersion,
                            customerTypeId: context['missing maritalStatusId'].customer.customerTypeId,
                            stateId: context['missing maritalStatusId'].customer.stateId,
                            statusId: context['missing maritalStatusId'].customer.statusId,
                            customerUnapprovedId: context['missing maritalStatusId'].customer.customerUnapprovedId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'missing family members', (context) => {
                    return {
                        actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                        person: {
                            actorId: context['Add customer successfully - all parameters for General Info tab'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM,
                            educationId: context['list education'].education[0].educationId,
                            employerCategoryId: context['list employerCategory'].employerCategory[0].employerCategoryId,
                            employerName: customerConstants.FIRSTNAME,
                            employmentDate: Date.now().toString(),
                            employmentId: context['list employment'].employment[0].employmentId,
                            incomeRangeId: context['list incomeRange'].incomeRange[0].incomeRangeId,
                            maritalStatusId: context['list martialStatus'].maritalStatus[0].maritalStatusId,
                            personUnapprovedId: context['missing maritalStatusId'].person.personUnapprovedId
                        },
                        customer: {
                            actorId: context['missing maritalStatusId'].person.actorId,
                            currentVersion: context['missing maritalStatusId'].customer.currentVersion,
                            customerTypeId: context['missing maritalStatusId'].customer.customerTypeId,
                            stateId: context['missing maritalStatusId'].customer.stateId,
                            statusId: context['missing maritalStatusId'].customer.statusId,
                            customerUnapprovedId: context['missing maritalStatusId'].customer.customerUnapprovedId
                        }
                    };
                }, (result, assert) => {
                    assert.equals(result.person.familyMembers, null, 'return family editted members');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                userMethods.logout('Logout admin user', context => context.login['identity.check'].sessionId)
            ]);
        }
    };
};
