const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerMethods = require('ut-test/lib/methods/customer');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const userConstants = require('ut-test/lib/constants/user').constants();
const USERNAME = 'getRef' + userConstants.USERNAME;
const NONEXISTING = '9999';
const NUMBERREFERID = 9999;
const PORTHTTPERROR = 'PortHTTP';
const CUSTOMERREFERRALGETPERM = 'customer.referral.get';
let stdPolicy, customerTypeId, newRefStatusId;

module.exports = function test() {
    return {
        getReferral: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', (context) => context.login['identity.check'].actorId),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                commonFunc.createStep('customer.referral.statusFetch', 'fetch referral statuses', (context) => {
                    return {};
                }, (result, assert) => {
                    const newRefStatus = result.referralStatus.find((status) => (status.code).toString().toLowerCase().indexOf('referralNew'.toLowerCase()) > -1);
                    newRefStatusId = newRefStatus.referralStatusId;
                }),
                customerMethods.addCustomer('Add customer successfully', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object
                    };
                }),
                customerMethods.getCustomer('Get the newly created customer', context => context['Add customer successfully'].customer.actorId),
                customerMethods.addReferral('add referral to just added customer', (context) => {
                    return {
                        referralSource: context['Get the newly created customer'].customer.actorId,
                        MSISDN: customerConstants.NEWPHONENUMBER + 5,
                        referralStatusId: newRefStatusId
                    };
                }),
                commonFunc.createStep('customer.referral.get', 'get referral successfully', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.equals(result.referral[0].MSISDN, customerConstants.NEWPHONENUMBER + 5, 'return correct MSISDN');
                    assert.equals(result.referral[0].referralStatusId, newRefStatusId, 'return new ref statusId');
                    assert.true(result.referral[0].isNew, 'return isNew = true');
                }),
                // negative
                commonFunc.createStep('customer.referral.get', 'get referral - no params', (context) => {
                    return {};
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTPERROR, 'return joi validation');
                }),
                commonFunc.createStep('customer.referral.get', 'get referral - empty params', (context) => {
                    return {
                        referralId: ''
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTPERROR, 'return joi validation');
                }),
                commonFunc.createStep('customer.referral.get', 'get referral - null params', (context) => {
                    return {
                        referralId: null
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTPERROR, 'return joi validation');
                }),
                commonFunc.createStep('customer.referral.get', 'get referral - nonexisting referral Id', (context) => {
                    return {
                        referralId: NONEXISTING
                    };
                }, (result, assert) => {
                    assert.same(result.referral, [], 'return empty resultset');
                }),
                commonFunc.createStep('customer.referral.get', 'get referral - number referral Id', (context) => {
                    return {
                        referralId: NUMBERREFERID
                    };
                }, (result, assert) => {
                    assert.same(result.referral, [], 'return empty resultset');
                }),
                // MISSING PERMISSIONS
                userMethods.logout('logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('successful login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.referral.get', 'get referral - no permissions', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERREFERRALGETPERM) > -1, 'Missing permissions for ' + CUSTOMERREFERRALGETPERM);
                }),
                userMethods.logout('successfully logout new user', (context) => context['successful login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
