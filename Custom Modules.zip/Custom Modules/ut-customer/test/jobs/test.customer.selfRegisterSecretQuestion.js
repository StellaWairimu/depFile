const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const documentJoiValidation = require('ut-test/lib/joiValidations/document');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const documentConstants = require('ut-test/lib/constants/document').constants();
const userMethods = require('ut-test/lib/methods/user');
const PHONENUMBER = commonFunc.generateRandomFixedInteger(9).toString();
const DOCUMENTNUMBER = documentConstants.DOCUMENTNUMBER.slice(1, 14);
const INSTALLATIONID = 'ye7hudhd738qhduqghd29';
const IMEI = (Math.floor(100000000000000 + Math.random() * 999999999999999)).toString();
const DATEOFBIRTH = commonFunc.randomDate(new Date(1972, 0, 1), new Date()); // random Date > 18 years old
const uri = '/selfregister';
const CHANNELMOBILE = 'mobile';
let customerActorId, customerTypeId, prefixNumber;

module.exports = function test() {
    return {
        selfRegisterSecretQuestion: function(test, bus, run) {
            return run(test, bus, [
                userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                commonFunc.createStep('customerTest.customer.returnAllowPhonePrefix', 'return phone prefix', context => {
                    return {};
                }, (result, assert) => {
                    prefixNumber = result.phonePrefix.phonePrefix;
                    assert.false(result.phonePrefix === null, 'return null for phone prefix');
                }),
                commonFunc.createStep('customer.selfregister', 'self register customer', (context) => {
                    return {
                        $http: {uri: uri},
                        firstName: customerConstants.FIRSTNAME,
                        lastName: customerConstants.LASTNAME,
                        dateOfBirth: DATEOFBIRTH,
                        gender: customerConstants.GENDERM,
                        phoneNumber: prefixNumber + PHONENUMBER,
                        documentTypeId: documentConstants.DOCUMENTTYPEID,
                        documentNumber: DOCUMENTNUMBER,
                        lat: customerConstants.LAT,
                        lng: customerConstants.LNG,
                        actorDevice: {
                            installationId: INSTALLATIONID,
                            imei: IMEI
                        }
                    };
                }, (result, assert) => {
                    customerActorId = result.actorId;
                    assert.equals(result.success, true, 'return success: true');
                }),
                userMethods.loginAdmin('login admin', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType.find(customerType => customerType.customerTypeId === customerConstants.INDIVIDUALCUSTOMERTYPEID).customerTypeId;
                }),
                commonFunc.createStep('customer.customer.get', 'Get the newly created customer', (context) => {
                    return {
                        actorId: customerActorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer).error, null, 'return customer details');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                    assert.equals(customerJoiValidation.validateGetPhone(result.customerPhone[0], prefixNumber + PHONENUMBER, customerConstants.TYPEIDPERSONAL).error, null, 'return phone details');
                    assert.equals(documentJoiValidation.validateGetDocument(result.document).error, null, 'return document attachment details');
                    assert.equals(result.customerAddress[0].lat, customerConstants.LAT.toString(), 'return lat coordinate');
                    assert.equals(result.customerAddress[0].lng, customerConstants.LNG.toString(), 'return lng coordinate');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                }),
                commonFunc.createStep('user.action.grant', 'give user permission', (context) => {
                    return {
                        setLevel: [{
                            actorId: customerActorId,
                            actionId: '%',
                            objectId: '%',
                            level: 1
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(result.length, 0, 'return empty result');
                }),
                commonFunc.createStep('user.user.get', 'get user hash details of self registered cutomer', (context) => {
                    return {
                        actorId: customerActorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person');
                    assert.equals(result['user.hash'][0].identifier, prefixNumber + PHONENUMBER, 'return username = customer phone number in user.hash');
                }),
                userMethods.logout('Logout admin user', (context) => context['login admin']['identity.check'].sessionId),
                commonFunc.createStep('identity.check', 'login selfRegistered user', (context) => {
                    return {
                        username: prefixNumber + PHONENUMBER,
                        password: context['self register customer'].token,
                        newPassword: userConstants.ADMINPASSWORD,
                        $http: {uri: userConstants.URI},
                        timezone: userConstants.TIMEZONE,
                        channel: CHANNELMOBILE,
                        secretQuestion: context['self register customer'].secretQuestions[0].itemNameId,
                        secretAnswer: userConstants.ADMINPASSWORD
                    };
                }, (result, assert) => {
                    assert.equals(userJoiValidation.validateLogin(result['identity.check']).error, null, 'Return all details after login a user');
                }),
                commonFunc.createStep('userTest.secretQuestionAnswer.get', 'check if secret question and answer are saved correctly', (context) => {
                    return {
                        actorId: customerActorId,
                        secretQuestion: context['self register customer'].secretQuestions[0].itemNameId,
                        secretAnswer: userConstants.ADMINPASSWORD
                    };
                }, (result, assert) => {
                    assert.equals(result.secretQuestionAnswer.length, 1, 'Return saved secret question');
                }),
                userMethods.logout('Logout selfRegistered user', (context) => context['login selfRegistered user']['identity.check'].sessionId)
            ]);
        }
    };
};
