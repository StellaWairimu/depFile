const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerMethods = require('ut-test/lib/methods/customer');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const userConstants = require('ut-test/lib/constants/user').constants();
const USERNAME = 'fetchRef' + userConstants.USERNAME;
const PHONENUMBER = customerConstants.PHONENUMBER.slice(3);
const NEWPHONENUMBER = customerConstants.PHONENUMBER.slice(1);
const WRONGREFSTATUS = 99;
const CUSTOMERREFERRALFETCHPERM = 'customer.referral.fetch';
let stdPolicy, customerTypeId, newRefStatusId;

module.exports = function test() {
    return {
        fetchReferral: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', (context) => context.login['identity.check'].actorId),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                commonFunc.createStep('customer.referral.statusFetch', 'fetch referral statuses', (context) => {
                    return {};
                }, (result, assert) => {
                    const newRefStatus = result.referralStatus.find((status) => (status.code).toString().toLowerCase().indexOf('referralNew'.toLowerCase()) > -1);
                    newRefStatusId = newRefStatus.referralStatusId;
                }),
                customerMethods.addCustomer('Add customer successfully', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object
                    };
                }),
                customerMethods.getCustomer('Get the newly created customer', context => context['Add customer successfully'].customer.actorId),
                customerMethods.addReferral('add referral to just added customer', (context) => {
                    return {
                        referralSource: context['Get the newly created customer'].customer.actorId,
                        MSISDN: customerConstants.NEWPHONENUMBER + 4,
                        referralStatusIds: [newRefStatusId]
                    };
                }),
                customerMethods.addReferral('add another referral to just added customer', (context) => {
                    return {
                        referralSource: context['Get the newly created customer'].customer.actorId,
                        MSISDN: PHONENUMBER,
                        referralStatusId: newRefStatusId
                    };
                }),
                commonFunc.createStep('customer.referral.fetch', 'fetch referrals successfully - by status open', (context) => {
                    return {
                        referralStatusIds: [newRefStatusId],
                        pageNumber: customerConstants.PAGENUMBER,
                        pageSize: customerConstants.PAGESIZE
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchReferrals(result.referral).error, null, 'return all details after fetch referrals');
                    assert.true(result.referral.every(referral => referral.referralStatusId === newRefStatusId), 'return referrals only with status open');
                    assert.true(result.referral.find(referral => referral.MSISDN === customerConstants.NEWPHONENUMBER + 4), 'return first referral in the list');
                    assert.true(result.referral.find(referral => referral.MSISDN === PHONENUMBER), 'return second referral in the list');
                }),
                commonFunc.createStep('customer.referral.fetch', 'fetch referrals successfully - by MSISDN', (context) => {
                    return {
                        MSISDN: customerConstants.NEWPHONENUMBER + 4,
                        pageNumber: customerConstants.PAGENUMBER,
                        pageSize: customerConstants.PAGESIZE
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchReferrals(result.referral).error, null, 'return all details after fetch referrals');
                    assert.true(result.referral.every(referral => referral.MSISDN === customerConstants.NEWPHONENUMBER + 4), 'return referrals only for selected MSISDN');
                }),
                // commonFunc.createStep('customer.referral.fetch', 'fetch referrals successfully - by customerNumber', (context) => {
                //     return {
                //         customerNumber: null,
                //         pageNumber: customerConstants.PAGENUMBER,
                //         pageSize: customerConstants.PAGESIZE
                //     };
                // }, (result, assert) => {
                //     assert.equals(customerJoiValidation.validateFetchReferrals(result.referral).error, null, 'return all details after fetch referrals');
                //     assert.true(result.referral.every(referral => referral.customerNumber === null), 'return referrals only for customerNumber = null');
                // }),
                commonFunc.createStep('customer.referral.fetch', 'fetch referrals successfully - no params', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchReferrals(result.referral).error, null, 'return all details after fetch referrals');
                    assert.true(result.referral.some(referral => referral.referralStatusId === newRefStatusId), 'return referrals with status open');
                }),
                // negative
                commonFunc.createStep('customer.referral.fetch', 'fetch referrals - wrong referal status', (context) => {
                    return {
                        referralStatusIds: [WRONGREFSTATUS],
                        pageNumber: customerConstants.PAGENUMBER,
                        pageSize: customerConstants.PAGESIZE
                    };
                }, (result, assert) => {
                    assert.same(result.referral, [], 'return empty resultset');
                }),
                commonFunc.createStep('customer.referral.fetch', 'fetch referrals - non existing MSIDN', (context) => {
                    return {
                        MSISDN: NEWPHONENUMBER,
                        pageNumber: customerConstants.PAGENUMBER,
                        pageSize: customerConstants.PAGESIZE
                    };
                }, (result, assert) => {
                    assert.same(result.referral, [], 'return empty resultset');
                }),
                // MISSING PERMISSIONS
                userMethods.logout('logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('successful login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.referral.fetch', 'fetch referral - no permissions', (context) => {
                    return {
                        referralStatusIds: [newRefStatusId]
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERREFERRALFETCHPERM) > -1, 'Missing permissions for ' + CUSTOMERREFERRALFETCHPERM);
                }),
                userMethods.logout('successfully logout new user', (context) => context['successful login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
