const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerMethods = require('ut-test/lib/methods/customer');
const customerParams = require('ut-test/lib/requestParams/customer');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userMethods = require('ut-test/lib/methods/user');
const userConstants = require('ut-test/lib/constants/user').constants();
const USERNAME = 'kycVisibility' + userConstants.USERNAME;
const STATUSINACTIVE = 'inactive';
const SECURITYVIOLATIONERROR = 'customer.securityViolation';
let stdPolicy;
let customerTypeNumber;
let orgId1, orgId2, organizationDepthArray;

module.exports = function test() {
    return {
        kycVisibility: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('user.user.get', 'get admin details', (context) => {
                    return {
                        actorId: context.login['identity.check'].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, userConstants.ADMINFIRSTNAME).error, null, 'return person');
                    orgId1 = orgId2 = result.memberOF[0].object;
                }),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                userMethods.addRole('add role successfully', context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeNumber = result.customerType[0].customerTypeNumber;
                }),
                commonFunc.createStep('core.configuration.fetch', 'fetch defaultBu setting', (context) => {
                    return {
                        key: customerConstants.GETBYDEPTHORGANIZATION
                    };
                }, (result, assert) => {
                    const orgDepth = result[0][0].value;
                    organizationDepthArray = Array.apply(null, {length: orgDepth - 1}).map(Number.call, Number);
                    assert.true(typeof result, 'object', 'return result');
                }),
                // Create organizations which correspond to the kyc's depth
                {
                    name: 'Create organization by depth',
                    steps: () => organizationDepthArray.map(org => ({
                        name: 'Add and approve organizations',
                        steps: () => [
                            commonFunc.createStep('customer.organization.add', 'add organization 1',
                                () => ({
                                    organization: {
                                        organizationName: customerConstants.ORGNAME
                                    },
                                    parent: [orgId1]
                                }), (result, assert) => {
                                    orgId1 = result['organization.info'][0].actorId;
                                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                                }
                            ),
                            customerMethods.approveOrganization('approve organization 1', () => orgId1),
                            commonFunc.createStep('customer.organization.add', 'add organization 2',
                                () => ({
                                    organization: {
                                        organizationName: customerConstants.ORGNAME
                                    },
                                    parent: [orgId2]
                                }), (result, assert) => {
                                    orgId2 = result['organization.info'][0].actorId;
                                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                                }
                            ),
                            customerMethods.approveOrganization('approve organization 2', () => orgId2)
                        ]
                    }))
                },
                commonFunc.createStep('customer.organization.getByDepth', 'get organizations by depth', context => {
                    return {
                        key: customerConstants.GETBYDEPTHORGANIZATION
                    };
                }, (result, assert) => {
                    assert.true(result.organizations.some(org => org.actorId === orgId1), 'return organization 1');
                    assert.true(result.organizations.some(org => org.actorId === orgId2), 'return organization 2');
                    assert.equals(customerJoiValidation.validateGetByDepthOrganization(result.organizations).error, null, 'Return all details after get by depth organizations');
                }),
                commonFunc.createStep('customer.kyc.getForCreate', 'get levels for creating kyc for org 1', context => {
                    return {
                        customerType: customerTypeNumber,
                        organizationId: orgId1
                    };
                }, (result, assert) => {
                    assert.true(result.levels.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateGetForCreateKyc(result.levels).error, null, 'Return all details for kyc levels');
                }),
                commonFunc.createStep('customer.kyc.getForCreate', 'get levels for creating kyc for org 2', context => {
                    return {
                        customerType: customerTypeNumber,
                        organizationId: orgId2
                    };
                }, (result, assert) => {
                    assert.true(result.levels.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateGetForCreateKyc(result.levels).error, null, 'Return all details for kyc levels');
                }),
                commonFunc.createStep('customer.kycAttribute.list', 'list kyc attributes', context => {
                    return {
                        customerTypeId: customerTypeNumber
                    };
                }, (result, assert) => {
                    assert.true(result.kycAttributes.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateListKycAttributes(result.kycAttributes).error, null, 'Return all details for kyc attributes');
                }),
                // add admin user in organization 1
                userMethods.addUser('add user in org 1', context => {
                    return {
                        object: orgId1,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: orgId1
                    };
                }, USERNAME),
                userMethods.approveUser('approve user in org 1', context => context['add user in org 1'].person.actorId),
                userMethods.grantAction('grant admin rights to user', context => context['add user in org 1'].person.actorId),
                /**
                 * Organizations 1 and 2 on the same hierarchy level (in the correct branch depth for kyc) - both children of the main organization.
                 * Admin user in organization 1.
                 * The user shouldn't be able to add/get/edit/delete a kyc in organization 2 or change its status.
                 * The user should be able to add/get/edit/delete/change status of kyc in his own organization.
                 */
                userMethods.logout('logout admin', context => context.login['identity.check'].sessionId),
                userMethods.login('login user 1', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                // add kyc
                commonFunc.createStep('customer.kyc.add', 'unsuccessfully add kyc in organization 2', context => {
                    return {
                        kyc: {
                            display: context['get levels for creating kyc for org 2'].levels[0].itemNameTranslation,
                            description: customerConstants.KYCDESCRIPTION,
                            customerTypeId: customerTypeNumber,
                            organizationId: orgId2,
                            itemNameId: context['get levels for creating kyc for org 2'].levels[0].itemNameId
                        },
                        kycConditionAttribute: [{
                            conditionId: customerConstants.RANDOMCONDITIONID,
                            attributeId: context['list kyc attributes'].kycAttributes[0].itemNameId
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, SECURITYVIOLATIONERROR, 'return failure - action not allowed for this user');
                }),
                customerMethods.addKyc('add kyc in organization 1', context => {
                    return {
                        display: context['get levels for creating kyc for org 1'].levels[0].itemNameTranslation,
                        customerTypeId: customerTypeNumber,
                        organizationId: orgId1,
                        itemNameId: context['get levels for creating kyc for org 1'].levels[0].itemNameId,
                        conditionId: customerConstants.RANDOMCONDITIONID,
                        attributeId: context['list kyc attributes'].kycAttributes[0].itemNameId

                    };
                }, customerConstants.KYCDESCRIPTION),
                userMethods.logout('logout user 1', context => context['login user 1']['identity.check'].sessionId),
                userMethods.loginAdmin('login admin', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                customerMethods.addKyc('add kyc in organization 2', context => {
                    return {
                        display: context['get levels for creating kyc for org 2'].levels[0].itemNameTranslation,
                        customerTypeId: customerTypeNumber,
                        organizationId: orgId2,
                        itemNameId: context['get levels for creating kyc for org 2'].levels[0].itemNameId,
                        conditionId: customerConstants.RANDOMCONDITIONID,
                        attributeId: context['list kyc attributes'].kycAttributes[0].itemNameId

                    };
                }, customerConstants.KYCDESCRIPTION),
                userMethods.logout('logout admin', context => context['login admin']['identity.check'].sessionId),
                userMethods.login('login user 2', USERNAME, userConstants.USERPASSWORD, userConstants.TIMEZONE),
                // get kyc
                commonFunc.createStep('customer.kyc.get', 'unsuccessfully get kyc in organization 2', (context) => {
                    return {
                        kycId: context['add kyc in organization 2'].kyc[0].kycId
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, SECURITYVIOLATIONERROR, 'return failure - action not allowed for this user');
                }),
                customerMethods.getKyc('successfully get kyc in organization 1', (context) => context['add kyc in organization 1'].kyc[0].kycId),
                // edit kyc
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc in organization 2', context => customerParams.editKycParams(context, (context) => {
                    return {
                        kycId: context['add kyc in organization 2'].kyc[0].kycId,
                        display: context['get levels for creating kyc for org 2'].levels[0].itemNameTranslation,
                        customerTypeId: customerTypeNumber,
                        itemNameId: context['get levels for creating kyc for org 2'].levels[0].itemNameId,
                        conditionId: customerConstants.RANDOMCONDITIONID + 1,
                        attributeId: context['list kyc attributes'].kycAttributes[1].itemNameId
                    };
                }, customerConstants.KYCDESCRIPTION + 1), null,
                (error, assert) => {
                    assert.equals(error.type, SECURITYVIOLATIONERROR, 'return failure - action not allowed for this user');
                }),
                customerMethods.editKyc('successfully edit kyc in organization 1', (context) => {
                    return {
                        kycId: context['add kyc in organization 1'].kyc[0].kycId,
                        display: context['get levels for creating kyc for org 1'].levels[0].itemNameTranslation,
                        customerTypeId: customerTypeNumber,
                        itemNameId: context['get levels for creating kyc for org 1'].levels[0].itemNameId,
                        conditionId: customerConstants.RANDOMCONDITIONID + 1,
                        attributeId: context['list kyc attributes'].kycAttributes[1].itemNameId
                    };
                }, customerConstants.KYCDESCRIPTION + 1),
                // change kyc status
                commonFunc.createStep('customer.kyc.changeStatus', 'unsuccessfully change kyc status in organization 2 to inactive', context =>
                    customerParams.changeKycStatusParams(context, (context) => [context['add kyc in organization 2'].kyc[0].kycId], STATUSINACTIVE), null,
                (error, assert) => {
                    assert.equals(error.type, SECURITYVIOLATIONERROR, 'return failure - action not allowed for this user');
                }),
                customerMethods.changeKycStatus('successfully change kyc status in organizaion 1 to inactive', context => [context['add kyc in organization 1'].kyc[0].kycId], STATUSINACTIVE),
                // delete kyc
                commonFunc.createStep('customer.kyc.delete', 'unsuccessfully delete kyc in organization 2', context => customerParams.deleteKycParams(context,
                    (context) => [context['add kyc in organization 2'].kyc[0].kycId]
                ), null,
                (error, assert) => {
                    assert.equals(error.type, SECURITYVIOLATIONERROR, 'return failure - action not allowed for this user');
                }),
                customerMethods.deleteKyc('successfully delete kyc in organization 1', context => [context['add kyc in organization 1'].kyc[0].kycId])
            ]);
        }
    };
};
