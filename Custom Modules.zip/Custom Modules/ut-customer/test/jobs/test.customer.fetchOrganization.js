const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const customerMethods = require('ut-test/lib/methods/customer');
const USERNAME = 'fetchOrg' + userConstants.USERNAME;
const ORGNAME = customerConstants.ORGNAME;
const partialOrgName = ORGNAME.slice(10, 22);
const CODE = commonFunc.generateRandomNumber().toString();
const EXECOFFICER = 'Test executive Officer';
const TRADENAME = 'SOme random trade name';
const FLOATNUM = 11.998;
const NEGATIVEVALUE = -1001;
const JSALERT = '<script type="text/javascript">alert("hi")</script>';
const TESTARR = [1, 2, 3, 4];
const LONGINT = 100000000225;
const ORGNAMEAAA = ' AAA ';
const ORGNAMEBBB = ' BBB ';
const ORGNAMECCC = ' CCC ';
const ISENABLED = 'isEnabled';
const CUSTOMERORGANIZATIONFETCH = 'customer.organization.fetch';
const appendToOrgName = commonFunc.generateRandomNumber();
let MAINORG, mainOrgName, stdPolicy;

module.exports = function test() {
    return {
        fetchOrganization: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('user.user.get', 'get admin details', (context) => {
                    return {
                        actorId: context.login['identity.check'].actorId
                    };
                },
                (result, assert) => {
                    mainOrgName = result.memberOF[0].organizationName;
                    MAINORG = result.memberOF[0].object;
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, userConstants.ADMINFIRSTNAME).error, null, 'return person');
                }),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                commonFunc.createStep('customer.organization.add', 'add organization successfully', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME + ' ' + appendToOrgName,
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            isEnabled: 1,
                            isDeleted: 0
                        },
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME + ' ' + appendToOrgName, 'return organizationName');
                    assert.equals(result['organization.info'][0].executiveOfficer, EXECOFFICER, 'return organization executiveOfficer');
                    assert.equals(result['organization.info'][0].code, CODE, 'return organization code');
                    assert.equals(result['organization.info'][0].tradeName, TRADENAME, 'return organization tradeName');
                }),
                customerMethods.approveOrganization('approve add organization successfully', (context) => context['add organization successfully']['organization.info'][0].actorId),
                // fetch organization successfully - full organizationName
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization successfully - full organizationName', (context) => {
                    return {
                        searchString: context['add organization successfully']['organization.info'][0].organizationName
                    };
                }, (result, assert) => {
                    assert.equals(result.organization[0].organizationName, ORGNAME + ' ' + appendToOrgName, 'return correct organization');
                    assert.equals(result.organization[0].parents, mainOrgName, 'return correct parent organization');
                    assert.equals(result.organization[0].isEnabled, true, 'return correct status');
                }),
                // fetch organization successfully - partial organizationName
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization successfully - partial organizationName', (context) => {
                    return {
                        searchString: partialOrgName
                    };
                }, (result, assert) => {
                    assert.true(partialOrgName.indexOf(result.organization[0].organizationName), 'return statusId CUSTOMERNUMBER');
                    assert.equals(result.organization[0].parents, mainOrgName, 'return correct parent organization');
                    assert.equals(result.organization[0].isEnabled, true, 'return correct status');
                }),
                // fetch organization successfully - full businessUnitId
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization successfully - full businessUnitId', (context) => {
                    return {
                        businessUnitId: context['add organization successfully']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result.parent[0].organizationName, ORGNAME + ' ' + appendToOrgName, 'return correct organization');
                    assert.equals(result.parent[0].parents, mainOrgName, 'return correct parent organization');
                    assert.equals(result.parent[0].isEnabled, true, 'return correct status');
                }),
                // adding organization - disabled
                commonFunc.createStep('customer.organization.add', 'add organization successfully - disabled', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME + ' ' + appendToOrgName + ' DISABLED',
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            isEnabled: 0,
                            isDeleted: 0
                        },
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME + ' ' + appendToOrgName + ' DISABLED', 'return organizationName');
                    assert.equals(result['organization.info'][0].executiveOfficer, EXECOFFICER, 'return organization executiveOfficer');
                    assert.equals(result['organization.info'][0].code, CODE, 'return organization code');
                    assert.equals(result['organization.info'][0].tradeName, TRADENAME, 'return organization tradeName');
                }),
                customerMethods.approveOrganization('approve add organization successfully - disabled', (context) => context['add organization successfully - disabled']['organization.info'][0].actorId),
                // fetch organization successfully - disabled
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization successfully - disabled', (context) => {
                    return {
                        businessUnitId: context['get admin details'].memberOF[0].object,
                        searchString: '',
                        isEnabled: false
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.true(result.organization.every(
                        (singleOrganization) => Object.keys(singleOrganization).some(
                            (key) => key === 'isEnabled' && singleOrganization[key] === false
                        )
                    ), 'returned disabled organizations');
                }),
                // adding organization A
                commonFunc.createStep('customer.organization.add', 'add organization successfully - org AAA', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME + ORGNAMEAAA,
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            isEnabled: 1,
                            isDeleted: 0
                        },
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME + ORGNAMEAAA, 'return organizationName');
                    assert.equals(result['organization.info'][0].executiveOfficer, EXECOFFICER, 'return organization executiveOfficer');
                    assert.equals(result['organization.info'][0].code, CODE, 'return organization code');
                    assert.equals(result['organization.info'][0].tradeName, TRADENAME, 'return organization tradeName');
                }),
                customerMethods.approveOrganization('approve add organization successfully - org AAA', (context) => context['add organization successfully - org AAA']['organization.info'][0].actorId),
                // adding organization B
                commonFunc.createStep('customer.organization.add', 'add organization successfully - org BBB', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME + ORGNAMEBBB,
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            isEnabled: 1,
                            isDeleted: 0
                        },
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME + ORGNAMEBBB, 'return organizationName');
                    assert.equals(result['organization.info'][0].executiveOfficer, EXECOFFICER, 'return organization executiveOfficer');
                    assert.equals(result['organization.info'][0].code, CODE, 'return organization code');
                    assert.equals(result['organization.info'][0].tradeName, TRADENAME, 'return organization tradeName');
                }),
                customerMethods.approveOrganization('approve add organization successfully - org BBB', (context) => context['add organization successfully - org BBB']['organization.info'][0].actorId),
                // adding organization C
                commonFunc.createStep('customer.organization.add', 'add organization successfully - org CCC', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME + ' CCC ',
                            code: CODE,
                            executiveOfficer: EXECOFFICER,
                            tradeName: TRADENAME,
                            isEnabled: 1,
                            isDeleted: 0
                        },
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME + ' CCC ', 'return organizationName');
                    assert.equals(result['organization.info'][0].executiveOfficer, EXECOFFICER, 'return organization executiveOfficer');
                    assert.equals(result['organization.info'][0].code, CODE, 'return organization code');
                    assert.equals(result['organization.info'][0].tradeName, TRADENAME, 'return organization tradeName');
                }),
                // fetch organization successfully - all and pageSize
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization successfully - all and sortBy name', (context) => {
                    return {
                        businessUnitId: context['get admin details'].memberOF[0].object,
                        searchString: '',
                        pageSize: 5,
                        pageNumber: customerConstants.PAGENUMBER
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.true(result.organization.length === 5, 'return exactly 5 records');
                }),
                // fetch organization successfully - all and sortBy name
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization successfully - all and sortBy name', (context) => {
                    return {
                        businessUnitId: context['get admin details'].memberOF[0].object,
                        searchString: '',
                        pageSize: customerConstants.PAGESIZE,
                        sortBy: customerConstants.ORDERBYNAME
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                    const arr = result.organization;
                    function findOrgA(arr) {
                        return arr.organizationName.indexOf('AAA') > -1;
                    }
                    function findOrgB(arr) {
                        return arr.organizationName.indexOf('BBB') > -1;
                    }
                    assert.true((arr.findIndex(findOrgA) < arr.findIndex(findOrgB)), 'return orgA comes before orgB 0');
                }),
                // fetch organization successfully - all and sortBy status
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization successfully - all and sortBy isEnabled', (context) => {
                    return {
                        businessUnitId: context['get admin details'].memberOF[0].object,
                        searchString: '',
                        pageSize: customerConstants.PAGESIZE,
                        sortBy: ISENABLED
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.equals(result.organization[0].isEnabled, false, 'return first organization disabled');
                }),
                // fetch organization successfully - all and sortOrder: DESC
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization successfully - all and sortOrder DESC', (context) => {
                    return {
                        businessUnitId: context['get admin details'].memberOF[0].object,
                        searchString: '',
                        pageSize: customerConstants.PAGESIZEDEFAULT,
                        sortOrder: customerConstants.SORTORDERDESC
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.true(result.organization[0].organizationName.indexOf(ORGNAMECCC), 'return last added organization is sorted first');
                }),
                /**
                 * NEGATIVE
                 */
                // fetch organization unsuccessfully - businessUnitId empty string
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - businessUnitId empty string', (context) => {
                    return {
                        businessUnitId: ''
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // fetch organization unsuccessfully - businessUnitId NULL
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - businessUnitId NULL', (context) => {
                    return {
                        businessUnitId: null
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.true(result.organization.length !== 0, 'empty resultset - organization');
                }),
                // fetch organization unsuccessfully - businessUnitId negative int
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - businessUnitId negative int', (context) => {
                    return {
                        businessUnitId: NEGATIVEVALUE
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, userConstants.USERSECURITYVIOLATION, 'portSQL issue');
                }),
                // fetch organization unsuccessfully - businessUnitId float
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - businessUnitId float', (context) => {
                    return {
                        businessUnitId: FLOATNUM
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // fetch organization unsuccessfully - businessUnitId non existing
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - businessUnitId non existing', (context) => {
                    return {
                        businessUnitId: LONGINT
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, userConstants.USERSECURITYVIOLATION, 'portSQL issue');
                }),
                // fetch organization unsuccessfully - businessUnitId array
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - businessUnitId array', (context) => {
                    return {
                        businessUnitId: [context['get admin details'].memberOF[0].object, 0, 0, 0]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // fetch organization unsuccessfully - searchString null
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - searchString null', (context) => {
                    return {
                        searchString: null
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.true(result.organization.length !== 0, 'return empty organization');
                }),
                // fetch organization unsuccessfully - searchString float
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - searchString float', (context) => {
                    return {
                        searchString: FLOATNUM
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // fetch organization unsuccessfully - searchString non existing
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - searchString non existing', (context) => {
                    return {
                        searchString: JSALERT
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.equals(result.organization.length, 0, 'return empty organization');
                    assert.equals(result.parent.length, 0, 'return empty parent');
                    assert.equals(result.pagination.length, 0, 'return empty pagination');
                }),
                // fetch organization unsuccessfully - searchString negative int
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - searchString negative int', (context) => {
                    return {
                        searchString: NEGATIVEVALUE
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // fetch organization unsuccessfully - searchString array
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - searchString array', (context) => {
                    return {
                        searchString: TESTARR
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // fetch organization unsuccessfully - isEnabled, pageSize, pageNumber, sortOrder - empty string
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - isEnabled, pageSize, pageNumber, sortOrder - empty string', (context) => {
                    return {
                        businessUnitId: context['get admin details'].memberOF[0].object,
                        searchString: '',
                        isEnabled: '',
                        pageSize: '',
                        pageNumber: '',
                        sortOrder: ''
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // fetch organization unsuccessfully - isEnabled - null
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - isEnabled - null', (context) => {
                    return {
                        businessUnitId: context['get admin details'].memberOF[0].object,
                        searchString: '',
                        isEnabled: null
                    };
                }, (result, assert) => {
                    assert.equals(result.parent[0].actorId, MAINORG, 'return only mainOrg');
                }),
                /**
             * MISSING PERMISSIONS
             */
                userMethods.logout('Logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('Login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization unsuccessfully - no permissions', (context) => {
                    return {
                        searchString: ''
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERORGANIZATIONFETCH) > -1, 'Missing permissions for ' + CUSTOMERORGANIZATIONFETCH);
                }),
                userMethods.logout('Logout new user', (context) => context['Login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
