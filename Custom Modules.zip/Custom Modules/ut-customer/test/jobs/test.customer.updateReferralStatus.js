const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerMethods = require('ut-test/lib/methods/customer');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const userConstants = require('ut-test/lib/constants/user').constants();
const USERNAME = 'updateRefStatus' + userConstants.USERNAME;
const PERMISSION = 'customer.referral.statusUpdate';
// referral actions - for status Update
let APPROVENEWREFERRAL, REJECTNEWREFERRAL, OPENACCOUNT, DEACTIVATEREFERRAL, APPROVEDEACTIVATE, REJECTDEACTIVATE, COMPLETEREFERRAL;
const REJECTREASON = 'reject reason';
let stdPolicy;
let customerTypeId;
let newRefStatusId, openRefStatusId, pendingRefStatusId, rejectedRefStatusId;

module.exports = function test() {
    return {
        updateReferralStatus: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', (context) => context.login['identity.check'].actorId),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                commonFunc.createStep('customer.referral.statusFetch', 'fetch referral statuses', (context) => {
                    return {};
                }, (result, assert) => {
                    // console.log(result);
                    const newRefStatus = result.referralStatus.find((status) => (status.code).toString().toLowerCase().indexOf('referralNew'.toLowerCase()) > -1);
                    newRefStatusId = newRefStatus.referralStatusId;
                    const openRefStatus = result.referralStatus.find((status) => status.code === 'referralOpen');
                    openRefStatusId = openRefStatus.referralStatusId;
                    const pendingRefStatus = result.referralStatus.find((status) => status.code === 'referralPending');
                    pendingRefStatusId = pendingRefStatus.referralStatusId;
                    const rejectedRefStatus = result.referralStatus.find((status) => (status.code.toString().toLowerCase()).indexOf('referralNewRejected'.toLowerCase()) > -1);
                    rejectedRefStatusId = rejectedRefStatus.referralStatusId;
                }),
                commonFunc.createStep('customer.referral.actionFetch', 'fetch referral actions', (context) => {
                    return {};
                }, (result, assert) => {
                    // console.log(result);
                    const newRefActionApprove = result.referralActions.find((action) => (action.name).toString().toLowerCase().indexOf('newReferralAprrove'.toLowerCase()) > -1);
                    APPROVENEWREFERRAL = newRefActionApprove.name;
                    const newRefActionReject = result.referralActions.find((action) => (action.name).toString().toLowerCase().indexOf('newReferralReject'.toLowerCase()) > -1);
                    REJECTNEWREFERRAL = newRefActionReject.name;
                    const openAccountAction = result.referralActions.find((action) => (action.name).toString().toLowerCase().indexOf('openAccount'.toLowerCase()) > -1);
                    OPENACCOUNT = openAccountAction.name;
                    const deactivateRefAction = result.referralActions.find((action) => (action.name).toString().toLowerCase().indexOf('deactivateReferral'.toLowerCase()) > -1);
                    DEACTIVATEREFERRAL = deactivateRefAction.name;
                    const deactivateRefApprove = result.referralActions.find((action) => (action.name).toString().toLowerCase().indexOf('deactivateReferralApprove'.toLowerCase()) > -1);
                    APPROVEDEACTIVATE = deactivateRefApprove.name;
                    const deactivateRefReject = result.referralActions.find((action) => (action.name).toString().toLowerCase().indexOf('deactivateReferralReject'.toLowerCase()) > -1);
                    REJECTDEACTIVATE = deactivateRefReject.name;
                    const markCompleted = result.referralActions.find((action) => (action.name).toString().toLowerCase().indexOf('markReferralCompleted'.toLowerCase()) > -1);
                    COMPLETEREFERRAL = markCompleted.name;
                }),
                customerMethods.addCustomer('Add customer successfully', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object
                    };
                }),
                customerMethods.getCustomer('Get the newly created customer', context => context['Add customer successfully'].customer.actorId),
                customerMethods.addReferral('add referral to just added customer', (context) => {
                    return {
                        referralSource: context['Get the newly created customer'].customer.actorId,
                        MSISDN: customerConstants.NEWPHONENUMBER,
                        referralStatusId: newRefStatusId
                    };
                }),
                customerMethods.addReferral('add referral 2 to just added customer', (context) => {
                    return {
                        referralSource: context['Get the newly created customer'].customer.actorId,
                        MSISDN: customerConstants.NEWPHONENUMBER + 2,
                        referralStatusId: newRefStatusId
                    };
                }),
                customerMethods.addReferral('add referral 3 to just added customer', (context) => {
                    return {
                        referralSource: context['Get the newly created customer'].customer.actorId,
                        MSISDN: customerConstants.NEWPHONENUMBER + 3,
                        referralStatusId: newRefStatusId
                    };
                }),
                customerMethods.addReferral('add referral 4 to just added customer', (context) => {
                    return {
                        referralSource: context['Get the newly created customer'].customer.actorId,
                        MSISDN: customerConstants.NEWPHONENUMBER + 4,
                        referralStatusId: newRefStatusId
                    };
                }),
                customerMethods.addReferral('add referral 5 to just added customer', (context) => {
                    return {
                        referralSource: context['Get the newly created customer'].customer.actorId,
                        MSISDN: customerConstants.NEWPHONENUMBER + 5,
                        referralStatusId: newRefStatusId
                    };
                }),
                /**
                 * CHANGE STATUS:
                 *  - approve new -> open
                 *  - reject new -> rejected
                 *  - delete new
                 *  - delete rejected
                 *  - open -> peneding
                 *  - open -> deactivate
                 *  - open -> expired
                 *  - pending -> completed
                 *  - deactivation pending -> reject deactivation -> open
                 */
                // approve new - 1
                customerMethods.updateReferralStatus('update referral 1 status - approve new', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId,
                        actionName: APPROVENEWREFERRAL
                    };
                }),
                commonFunc.createStep('customer.referral.get', 'get approved new referral', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    // console.log(result);
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.equals(result.referral[0].referralStatusId, openRefStatusId, 'return open referral status');
                }),
                // negative: try to deactivate new referral - ref 4
                commonFunc.createStep('customer.referral.statusUpdate', 'update referral 4 status - new->deactivate - not possible', (context) => {
                    return {
                        referralId: context['add referral 4 to just added customer'].referral[0].referralId,
                        actionName: DEACTIVATEREFERRAL
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.referralStatusInvalidAction', 'return customer.referralStatusInvalidAction');
                }),
                // negative: try to mark completed new referral - ref 4
                commonFunc.createStep('customer.referral.statusUpdate', 'update referral 4 status - new->mark completed - not possible', (context) => {
                    return {
                        referralId: context['add referral 4 to just added customer'].referral[0].referralId,
                        actionName: COMPLETEREFERRAL
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.referralStatusInvalidAction', 'return customer.referralStatusInvalidAction');
                }),
                // approve new - 4
                customerMethods.updateReferralStatus('update referral 4 status - approve new', (context) => {
                    return {
                        referralId: context['add referral 4 to just added customer'].referral[0].referralId,
                        actionName: APPROVENEWREFERRAL
                    };
                }),
                commonFunc.createStep('customer.referral.get', 'get approved new referral', (context) => {
                    return {
                        referralId: context['add referral 4 to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.equals(result.referral[0].referralStatusId, openRefStatusId, 'return open referral status');
                }),
                // approve new - 5
                customerMethods.updateReferralStatus('update referral 5 status - approve new', (context) => {
                    return {
                        referralId: context['add referral 5 to just added customer'].referral[0].referralId,
                        actionName: APPROVENEWREFERRAL
                    };
                }),
                commonFunc.createStep('customer.referral.get', 'get approved new referral', (context) => {
                    return {
                        referralId: context['add referral 5 to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.equals(result.referral[0].referralStatusId, openRefStatusId, 'return open referral status');
                }),
                // reject new - 2
                customerMethods.updateReferralStatus('update referral 2 status - reject new', (context) => {
                    return {
                        referralId: context['add referral 2 to just added customer'].referral[0].referralId,
                        actionName: REJECTNEWREFERRAL,
                        rejectReason: REJECTREASON
                    };
                }),
                commonFunc.createStep('customer.referral.get', 'get rejected new referral', (context) => {
                    return {
                        referralId: context['add referral 2 to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.equals(result.referral[0].referralStatusId, rejectedRefStatusId, 'return rejected referral status');
                    assert.equals(result.referral[0].rejectReason, REJECTREASON, 'return reject reason');
                }),
                // delete new - 3
                customerMethods.deleteReferral('delete new referral successfully', (context) => context['add referral 3 to just added customer'].referral[0].referralId),
                commonFunc.createStep('customer.referral.get', 'get approved new referral', (context) => {
                    return {
                        referralId: context['add referral 3 to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.same(result.referral, [], 'return empty resultset - referral deleted');
                }),
                // delete rejected - 2
                customerMethods.deleteReferral('delete rejected referral successfully', (context) => context['add referral 2 to just added customer'].referral[0].referralId),
                commonFunc.createStep('customer.referral.get', 'get approved new referral', (context) => {
                    return {
                        referralId: context['add referral 2 to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.same(result.referral, [], 'return empty resultset - referral deleted');
                }),
                // open -> pending ref 1
                customerMethods.updateReferralStatus('update referral 1 status - open->pending', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId,
                        actionName: OPENACCOUNT
                    };
                }),
                commonFunc.createStep('customer.referral.get', 'get referral 1 - pending', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.equals(result.referral[0].referralStatusId, pendingRefStatusId, 'return pending referral status');
                }),
                // open -> deactivate ref 4 - approve deactivate -> deactivated
                customerMethods.updateReferralStatus('update referral 4 status - open->deactivate', (context) => {
                    return {
                        referralId: context['add referral 4 to just added customer'].referral[0].referralId,
                        actionName: DEACTIVATEREFERRAL
                    };
                }),
                commonFunc.createStep('customer.referral.get', 'get referral 4 - pending deactivate', (context) => {
                    return {
                        referralId: context['add referral 4 to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.true(result.referral[0].referralStatus.indexOf('Deactivation Pending') > -1, 'return Deactivation Pending Referral Open status');
                }),
                customerMethods.updateReferralStatus('update referral 4 status - approve deactivate', (context) => {
                    return {
                        referralId: context['add referral 4 to just added customer'].referral[0].referralId,
                        actionName: APPROVEDEACTIVATE
                    };
                }),
                commonFunc.createStep('customer.referral.get', 'get referral 1 - approve deactivate', (context) => {
                    return {
                        referralId: context['add referral 4 to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.true(result.referral[0].referralStatus.indexOf('Deactivated') > -1, 'return Referral Deactivated status');
                }),
                // ref 1: pending -> completed
                customerMethods.updateReferralStatus('update referral 1 status - completed', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId,
                        actionName: COMPLETEREFERRAL
                    };
                }),
                commonFunc.createStep('customer.referral.get', 'get referral 1 - mark completed', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.true(result.referral[0].referralStatus.indexOf('Completed') > -1, 'return Referral Completed status');
                }),
                // deactivate ref 5: open -> pending deactivation -> reject deactivation
                customerMethods.updateReferralStatus('update referral 5 status - open->deactivate', (context) => {
                    return {
                        referralId: context['add referral 5 to just added customer'].referral[0].referralId,
                        actionName: DEACTIVATEREFERRAL
                    };
                }),
                commonFunc.createStep('customer.referral.get', 'get referral 5 - pending deactivate', (context) => {
                    return {
                        referralId: context['add referral 5 to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.true(result.referral[0].referralStatus.indexOf('Deactivation Pending') > -1, 'return Deactivation Pending Referral Open status');
                }),
                customerMethods.updateReferralStatus('update referral 5 status - reject deactivate', (context) => {
                    return {
                        referralId: context['add referral 5 to just added customer'].referral[0].referralId,
                        actionName: REJECTDEACTIVATE
                    };
                }),
                commonFunc.createStep('customer.referral.get', 'get referral 5 - open', (context) => {
                    return {
                        referralId: context['add referral 5 to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.true(result.referral[0].referralStatus.indexOf('Open') > -1, 'return Referral Open status');
                }),
                // MISSING PERMISSIONS
                userMethods.logout('logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('successful login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.referral.statusUpdate', 'update referral status- no permissions', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId,
                        actionName: REJECTNEWREFERRAL
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(PERMISSION) > -1, 'Missing permissions for ' + PERMISSION);
                }),
                userMethods.logout('successfully logout new user', (context) => context['successful login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
