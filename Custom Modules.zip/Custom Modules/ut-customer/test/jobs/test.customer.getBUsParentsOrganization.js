const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userConstants = require('ut-test/lib/constants/user').constants();
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const customerMethods = require('ut-test/lib/methods/customer');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const USERNAME = 'BUParentOrg' + userConstants.USERNAME;
const ORGNAME = customerConstants.ORGNAME;
const CUSTOMERORGANIZATIONREMOVE = 'customer.organization.getBUsParents';
let stdPolicy, orgId, mainOrgName;

module.exports = function test() {
    return {
        getBUsParentsOrganization: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('user.user.get', 'get admin details', (context) => {
                    return {
                        actorId: context.login['identity.check'].actorId
                    };
                }, (result, assert) => {
                    orgId = result.memberOF[0].object;
                    mainOrgName = result.memberOF[0].organizationName;
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, userConstants.ADMINFIRSTNAME).error, null, 'return person');
                }),
                // fetch std input policy
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                // add user for missing permissions
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId
                    };
                }, USERNAME),
                userMethods.approveUser('approve first user', context => context['add new user'].person.actorId),
                customerMethods.addOrganization('add first organization', context => {
                    return {
                        parent: [orgId]
                    };
                }, ORGNAME),
                customerMethods.approveOrganization('approve first organization', (context) => context['add first organization']['organization.info'][0].actorId),
                customerMethods.addOrganization('add second organization - member of sa organization', context => {
                    return {
                        parent: [orgId]
                    };
                }, ORGNAME + 1),
                customerMethods.approveOrganization('approve add second organization - member of sa organization', (context) => context['add second organization - member of sa organization']['organization.info'][0].actorId),
                customerMethods.addOrganization('add third organization - member of first organization', context => {
                    return {
                        parent: [context['add first organization']['organization.info'][0].actorId]
                    };
                }, ORGNAME + 2),
                customerMethods.approveOrganization('approve add third organization - member of sa organization', (context) => context['add third organization - member of first organization']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents of third organization - without depth (default = 1)', context => {
                    return {
                        organizationName: ORGNAME + 2
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetBUsParents(result.organizations).error, null, 'get BUs parents');
                    assert.true(result.organizations.length === 1, 'return one organization');
                    assert.true(result.organizations.find(organizations => organizations.parents.indexOf(ORGNAME) > -1), 'return correct parent organization');
                    assert.true(result.organizations.find(organizations => organizations.organizationName === ORGNAME + 2), 'return third organization');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents of third organization with depth = 1', context => {
                    return {
                        organizationName: ORGNAME + 2,
                        depth: 1
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetBUsParents(result.organizations).error, null, 'get BUs parents');
                    assert.true(result.organizations.length === 1, 'return one organization');
                    assert.true(result.organizations.find(organizations => organizations.parents.indexOf(ORGNAME) > -1), 'return correct parent organization');
                    assert.true(result.organizations.find(organizations => organizations.organizationName === ORGNAME + 2), 'return third organization');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents of third organization with depth = 2', context => {
                    return {
                        organizationName: ORGNAME + 2,
                        depth: 2
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetBUsParents(result.organizations).error, null, 'get BUs parents');
                    assert.true(result.organizations.length === 1, 'return one organization');
                    assert.true(result.organizations.find(organizations => organizations.parents.indexOf(ORGNAME) > -1), 'return correct parent organization');
                    assert.true(result.organizations.find(organizations => organizations.parents.indexOf(mainOrgName) > -1), 'return correct main organization');
                    assert.true(result.organizations.find(organizations => organizations.organizationName === ORGNAME + 2), 'return third organization');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents null depth', context => {
                    return {
                        organizationName: ORGNAME + 2,
                        depth: null
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetBUsParents(result.organizations).error, null, 'get BUs parents');
                    assert.true(result.organizations.length === 1, 'return one organization');
                    assert.true(result.organizations.find(organizations => organizations.parents.indexOf(ORGNAME) > -1), 'return correct parent organization');
                    assert.true(result.organizations.find(organizations => organizations.parents.indexOf(mainOrgName) > -1), 'return correct main organization');
                    assert.true(result.organizations.find(organizations => organizations.organizationName === ORGNAME + 2), 'return third organization');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents of second organization nested in main only, depth = 2', context => {
                    return {
                        organizationName: ORGNAME + 1,
                        depth: 2
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetBUsParents(result.organizations).error, null, 'get BUs parents');
                    assert.true(result.organizations.length === 1, 'return one organization');
                    assert.true(result.organizations.find(organizations => organizations.parents.indexOf(mainOrgName) > -1), 'return correct main organization');
                    assert.true(result.organizations.find(organizations => organizations.organizationName === ORGNAME + 1), 'return second organization');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents of first organization nested in main only, default depth (1)', context => {
                    return {
                        organizationName: ORGNAME
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetBUsParents(result.organizations).error, null, 'get BUs parents');
                    assert.true(result.organizations.length > 1, 'return more than one organization');
                    assert.true(result.organizations.find(organizations => organizations.parents.indexOf(mainOrgName) > -1), 'return correct main organization');
                    assert.true(result.organizations.find(organizations => organizations.organizationName === ORGNAME + 1), 'return second organization');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents - no params', context => {
                    return {};
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - organizationName is required');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents - number organizationName', context => {
                    return {
                        organizationName: 1
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - organizationName must be a string');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents - invalid number organizationName', context => {
                    return {
                        organizationName: 0
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - organizationName must be a string');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents - null organizationName', context => {
                    return {
                        organizationName: null
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - organizationName must be a string');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents - empty string organizationName', context => {
                    return {
                        organizationName: ''
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - organizationName is not allowed to be empty');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents - not existing organizationName', context => {
                    return {
                        organizationName: customerConstants.TEST1
                    };
                }, (result, assert) => {
                    assert.same(result.organizations, [], 'return empty array');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents 0 depth', context => {
                    return {
                        organizationName: ORGNAME,
                        depth: 0
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - depth must be larger than or equal to 1');
                }),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents string depth', context => {
                    return {
                        organizationName: ORGNAME,
                        depth: customerConstants.TEST1
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - depth must be a number');
                }),
                /**
                 * MISSING PERMISSION
                 */
                userMethods.logout('Logout admin user', context => context.login['identity.check'].sessionId),
                userMethods.login('Login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.getBUsParents', 'get BUs parents - no rights', (context) => {
                    return {
                        organizationName: ORGNAME
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERORGANIZATIONREMOVE) > -1, 'Missing Pemissions for ' + CUSTOMERORGANIZATIONREMOVE);
                }),
                userMethods.logout('Logout new user', context => context['Login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
