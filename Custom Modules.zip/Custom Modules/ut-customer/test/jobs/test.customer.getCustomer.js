const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const customerParams = require('ut-test/lib/requestParams/customer');
const CUSTOMERCUSTOMERGET = 'customer.customer.get';
const USERNAME = 'getCust' + userConstants.USERNAME;
const STRACTORID = ';askdjfa;';
const INTACTORID = 99999;
const customerMethods = require('ut-test/lib/methods/customer');
const PORTHTTP = 'PortHTTP';
let stdPolicy, customerTypeId;

module.exports = function test() {
    return {
        getCustomer: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                // fetch std input policy
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                customerMethods.addCustomer('Add customer successfully', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        documentId: customerConstants.NEWDOCUMENTID
                    };
                }),
                commonFunc.createStep('customer.customer.get', 'Get a customer with all his details successufully', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add customer successfully'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer, customerConstants.CUSTOMERTYPEID).error, null, 'Return customer details after adding a customer');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'Return person details after adding a customer');
                }),
                /** NEGATIVE */
                commonFunc.createStep('customer.customer.get', 'Get a customer unsuccessufully - missing actorId', (context) => {
                    return {};
                }, null,
                (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return params is required');
                }),
                commonFunc.createStep('customer.customer.get', 'Get a customer unsuccessufully - string actorId', (context) => customerParams.actorIdParams(
                    context, (context) => STRACTORID), null,
                (error, assert) => {
                    assert.equals(typeof error, 'object', 'return object');
                    assert.equals(error.type, 'PortHTTP', 'return unsupportedActorType');
                }),
                commonFunc.createStep('customer.customer.get', 'Get a customer unsuccessufully - empty string actorId', (context) => customerParams.actorIdParams(
                    context, (context) => ''), null,
                (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return unsupportedActorType - actorId must be a number');
                }),
                commonFunc.createStep('customer.customer.get', 'Get a customer unsuccessufully - int actorId (non existing actorId)', (context) => customerParams.actorIdParams(
                    context, (context) => INTACTORID), null,
                (error, assert) => {
                    assert.equals(error.type, 'customer.customerNotExists', 'return customer.customerNotExists');
                }),
                commonFunc.createStep('customer.customer.get', 'Get a customer successufully - null actorId', (context) => customerParams.actorIdParams(
                    context, (context) => null), null,
                (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return unsupportedActorType - actorId must be a number');
                }),
                /** MISSING PERMISSIONS */
                userMethods.logout('Logout admin user', context => context.login['identity.check'].sessionId),
                userMethods.login('Login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.customer.get', 'Get customer details', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add customer successfully'].customer.actorId), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERCUSTOMERGET) > -1, 'Missing permissions for ' + CUSTOMERCUSTOMERGET);
                }),
                userMethods.logout('Logout new user', context => context['Login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
