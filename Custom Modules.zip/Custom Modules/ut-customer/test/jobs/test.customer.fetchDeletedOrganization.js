const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const customerMethods = require('ut-test/lib/methods/customer');
const USERNAME = 'fetchDelOrg' + userConstants.USERNAME;
const ORGNAMEAAA = customerConstants.ORGNAME + ' AAA';
const ORGNAMEBBB = customerConstants.ORGNAME + ' BBB';
const SEARCHSTRING = 'AAA';
const SORTORDER = 'DESC';
const CUSTOMERORGANIZATIONFETCHDELETED = 'customer.organization.fetchDeleted';
const PORTHTTP = 'PortHTTP';
const NONEXISTING = 'nonexisting';
const NUMBER = 999999;
let orgId, orgId2, stdPolicy, networkId;

module.exports = function test() {
    return {
        fetchDeletedOrganization: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                // fetch access policy
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                // add user for missing permissions
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                // add organizations
                customerMethods.addOrganization('add organization - org AAA', context => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, ORGNAMEAAA),
                customerMethods.approveOrganization('approve add organization - org AAA', (context) => context['add organization - org AAA']['organization.info'][0].actorId),
                customerMethods.addOrganization('add organization - org BBB', context => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, ORGNAMEBBB),
                customerMethods.approveOrganization('approve add organization - org BBB', (context) => context['add organization - org BBB']['organization.info'][0].actorId),
                // get organizations
                commonFunc.createStep('customer.organization.get', 'get organization A', (context) => {
                    return {
                        actorId: context['add organization - org AAA']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    orgId = result['organization.info'][0].actorId;
                }),
                commonFunc.createStep('customer.organization.get', 'get organization B', (context) => {
                    return {
                        actorId: context['add organization - org BBB']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    orgId2 = result['organization.info'][0].actorId;
                }),
                // delete organizations
                customerMethods.removeOrganization('remove add organization  - org AAA', context => [context['add organization - org AAA']['organization.info'][0].actorId]),
                customerMethods.removeOrganization('remove add organization  - org BBB', context => [context['add organization - org BBB']['organization.info'][0].actorId]),
                // fetch pending for delete organizations
                commonFunc.createStep('customer.organization.fetch', 'Fetch pending for delete organizations', (context) => {
                    return {
                        statusId: customerConstants.STATUSIDPENDING,
                        pageSize: customerConstants.PAGESIZE,
                        pageNumber: customerConstants.PAGENUMBER
                    };
                }, (result, assert) => {
                    assert.true(result.organization.some(
                        (organization) => organization.actorId === orgId
                    ), 'return organization A - pending for delete');
                    assert.true(result.organization.some(
                        (organization) => organization.actorId === orgId2
                    ), 'return organization B - pending for delete');
                }),
                // fetch Deleted organizations - organizations A, B and C should not appear in the list, as they are in status "pending for delete"
                commonFunc.createStep('customer.organization.fetchDeleted', 'Fetch Deleted organizations unsuccessfully - pending for delete', (context) => {
                    return {
                        searchString: '',
                        pageSize: customerConstants.PAGESIZE,
                        pageNumber: customerConstants.PAGENUMBER
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchDeletedOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.false(result.organization.some(
                        (organization) => organization.actorId === orgId
                    ), 'does not return organization A - pending for delete');
                    assert.false(result.organization.some(
                        (organization) => organization.actorId === orgId2
                    ), 'does not return organization B - pending for delete');
                }),
                // approve delete of organizations A, B and C
                customerMethods.approveOrganization('approve remove add organization - org AAA', (context) => context['add organization - org AAA']['organization.info'][0].actorId),
                customerMethods.approveOrganization('approve remove add organization - org BBB', (context) => context['add organization - org BBB']['organization.info'][0].actorId),
                /**
                 * fetch Deleted organizations
                */
                commonFunc.createStep('customer.organization.fetchDeleted', 'Fetch Deleted organizations successfully - all orgs + network', (context) => {
                    return {
                        searchString: '',
                        pageSize: customerConstants.PAGESIZE,
                        pageNumber: customerConstants.PAGENUMBER
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchDeletedOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.true(result.organization.some(
                        (organization) => organization.actorId === orgId
                    ), 'return organization A - deleted');
                    assert.true(result.organization.some(
                        (organization) => organization.actorId === orgId2
                    ), 'return organization B - deleted');
                }),
                commonFunc.createStep('customer.organization.fetchDeleted', 'Fetch Deleted organizations successfully - by searchtring: AAA', (context) => {
                    return {
                        searchString: SEARCHSTRING,
                        pageSize: customerConstants.PAGESIZE,
                        pageNumber: customerConstants.PAGENUMBER
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchDeletedOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.true(result.organization.every(
                        (organization) => organization.organizationName.indexOf(SEARCHSTRING) > -1
                    ), 'return all results containing searchstring in the organizationName');
                    assert.true(result.organization.some(
                        (organization) => organization.actorId === orgId
                    ), 'return organization A - deleted');
                    assert.false(result.organization.some(
                        (organization) => organization.actorId === orgId2
                    ), 'does not return organization B - deleted');
                    assert.false(result.organization.some(
                        (organization) => organization.actorId === networkId
                    ), 'does not return network 1 - deleted');
                }),
                commonFunc.createStep('customer.organization.fetchDeleted', 'Fetch Deleted organizations successfully - by searchtring: orgname, sortby name, desc', (context) => {
                    return {
                        searchString: customerConstants.ORGNAME,
                        pageSize: customerConstants.PAGESIZE,
                        pageNumber: customerConstants.PAGENUMBER,
                        sortBy: customerConstants.ORDERBYNAME,
                        sortOrder: SORTORDER
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchDeletedOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.true(result.organization.every(
                        (organization) => organization.organizationName.indexOf(customerConstants.ORGNAME) > -1
                    ), 'return all results containing searchstring in the organizationName');
                    const arr = result.organization;
                    function findOrgA(arr) {
                        return arr.organizationName.indexOf('AAA') > -1;
                    }
                    function findOrgB(arr) {
                        return arr.organizationName.indexOf('BBB') > -1;
                    }
                    assert.true((arr.findIndex(findOrgB) < arr.findIndex(findOrgA)), 'return orgB before orgA');
                }),
                /**
                 * fetch deleted organizations - negative:
                 *  - by searchstring - missing
                 *  - by searchstring - null
                 *  - by searchstring - number
                 *  - by searchstring - nonexisting
                 */
                commonFunc.createStep('customer.organization.fetchDeleted', 'fetch deleted organizations - missing searchstring param', (context) => {
                    return {
                        pageSize: customerConstants.PAGESIZE,
                        pageNumber: customerConstants.PAGENUMBER
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchDeletedOrganization(result.organization).error, null, 'return all details after fetching organization');
                }),
                commonFunc.createStep('customer.organization.fetchDeleted', 'fetch deleted organizations - searchstring = null', (context) => {
                    return {
                        searchString: null,
                        pageSize: customerConstants.PAGESIZE,
                        pageNumber: customerConstants.PAGENUMBER
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchDeletedOrganization(result.organization).error, null, 'return all details after fetching organization');
                }),
                commonFunc.createStep('customer.organization.fetchDeleted', 'fetch deleted organizations - searchstring = number', (context) => {
                    return {
                        searchString: NUMBER,
                        pageSize: customerConstants.PAGESIZE,
                        pageNumber: customerConstants.PAGENUMBER
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.organization.fetchDeleted', 'fetch deleted organizations - searchstring = nonexisting', (context) => {
                    return {
                        searchString: NONEXISTING,
                        pageSize: customerConstants.PAGESIZE,
                        pageNumber: customerConstants.PAGENUMBER
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchDeletedOrganization(result.organization).error, null, 'return all details after fetching organization');
                    assert.same(result.organization, [], 'return empty resultset');
                }),
                /**
                 * MISSING PERMISSIONS
                 */
                userMethods.logout('Logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('Login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.fetchDeleted', 'Fetch Deleted organizations unsuccessfully - no permissions', (context) => {
                    return {
                        searchString: ''
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERORGANIZATIONFETCHDELETED) > -1, 'Missing permissions for ' + CUSTOMERORGANIZATIONFETCHDELETED);
                }),
                userMethods.logout('Logout new user', (context) => context['Login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
