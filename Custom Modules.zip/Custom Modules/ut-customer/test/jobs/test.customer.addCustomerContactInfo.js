const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
// var userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const coreJoiValidation = require('ut-test/lib/joiValidations/core');
const userMethods = require('ut-test/lib/methods/user');
const customerParams = require('ut-test/lib/requestParams/customer');
const PORTHTTP = 'PortHTTP';
const PHONETYPEID = customerConstants.TYPEIDPERSONAL;
const PHONENUM = customerConstants.PHONENUMBER.slice(3, -2);
let customerTypeId, addressZone1, addressZone2, addressZone3, addressZone4;

module.exports = function test() {
    return {
        addCustomerContactInfo: function(test, bus, run) {
            return run(test, bus, [
                userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                /**
                 * CONTACT INFO TAB
                 */
                commonFunc.createStep('core.country.fetch', 'fetch countries', context => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCountry(result.country).error, null, 'Return fetchCountry');
                    const country = result.country.find(
                        (country) => country.countryCode === 'BG'
                    );
                    addressZone1 = country.itemNameId;
                }),
                commonFunc.createStep('core.itemNameByParent.list', 'list itemNameByParent - address1', context => {
                    return {
                        parentItemNameId: addressZone1
                    };
                }, (result, assert) => {
                    assert.equals(coreJoiValidation.validateListItemNameByParent(result.resultSet).error, null, 'Return all details after itemNameByParent');
                    addressZone2 = result.resultSet[0].itemNameId;
                }),
                commonFunc.createStep('core.itemNameByParent.list', 'list itemNameByParent - address2', context => {
                    return {
                        parentItemNameId: addressZone2
                    };
                }, (result, assert) => {
                    assert.equals(coreJoiValidation.validateListItemNameByParent(result.resultSet).error, null, 'Return all details after itemNameByParent');
                }),
                {
                    name: 'More address zones',
                    params: (context, utils) => {
                        if (context['list itemNameByParent - address2'].resultSet.length < 1) {
                            addressZone3 = null;
                            addressZone4 = null;
                            return utils.skip();
                        }
                    },
                    steps: () => [
                        commonFunc.createStep('core.itemNameByParent.list', 'list itemNameByParent - address3', context => {
                            addressZone3 = context['list itemNameByParent - address2'].resultSet[0].itemNameId;
                            return {
                                parentItemNameId: addressZone3
                            };
                        }, (result, assert) => {
                            assert.equals(coreJoiValidation.validateListItemNameByParent(result.resultSet).error, null, 'Return all details after itemNameByParent');
                            addressZone4 = result.resultSet.length > 0 ? result.resultSet[0].itemNameId : null;
                        })
                    ]
                },
                commonFunc.createStep('customer.customer.add', 'Add customer successfully - all parameters for Contact Info tab', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            addressZone1: addressZone1,
                            addressZone2: addressZone2,
                            addressZone3: addressZone3,
                            addressZone4: addressZone4,
                            value: customerConstants.ADDRESS
                        }],
                        email: [{
                            emailTypeId: customerConstants.TYPEIDPERSONAL,
                            value: customerConstants.EMAIL
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddPhone(result.customerPhone).error, null, 'Return phone details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddEmail(result.customerEmail).error, null, 'Return email details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddAddress(result.customerAddress).error, null, 'Return address details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                    assert.equals(result.customerAddress[0].addressZone1Id, addressZone1, 'return correct addressZone1Id');
                    assert.equals(result.customerAddress[0].addressZone2Id, addressZone2, 'return correct addressZone2Id');
                    assert.equals(result.customerAddress[0].addressZone3Id, addressZone3, 'return correct addressZone3Id');
                    assert.equals(result.customerAddress[0].addressZone4Id, addressZone4, 'return correct addressZone4Id');
                    assert.equals(result.customerEmail[0].emailTypeId, customerConstants.TYPEIDPERSONAL, 'return correct email type');
                    assert.equals(result.customerEmail[0].value, customerConstants.EMAIL, 'return correct email address');
                    assert.equals(result.customerPhone[0].phoneTypeId, PHONETYPEID, 'return correct phone type');
                    assert.equals(result.customerPhone[0].phoneNumber, PHONENUM, 'return correct phone number');
                }),
                commonFunc.createStep('customer.customer.add', 'Add two phones, addresses and emails', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        },
                        {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            addressZone1: addressZone1,
                            addressZone2: addressZone2,
                            addressZone3: addressZone3,
                            addressZone4: addressZone4,
                            value: customerConstants.ADDRESS
                        },
                        {
                            addressTypeId: customerConstants.TYPEIDHOME,
                            addressZone1: addressZone1,
                            addressZone2: addressZone2,
                            addressZone3: addressZone3,
                            addressZone4: addressZone4,
                            value: customerConstants.ADDRESS
                        }],
                        email: [{
                            emailTypeId: customerConstants.TYPEIDPERSONAL,
                            value: customerConstants.EMAIL
                        },
                        {
                            emailTypeId: customerConstants.TYPEIDPERSONAL,
                            value: customerConstants.EMAIL
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddPhone(result.customerPhone).error, null, 'Return phone details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddEmail(result.customerEmail).error, null, 'Return email details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddAddress(result.customerAddress).error, null, 'Return address details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                    assert.equals(result.customerAddress[0].addressZone1Id, addressZone1, 'return correct addressZone1Id');
                    assert.equals(result.customerAddress[0].addressZone2Id, addressZone2, 'return correct addressZone2Id');
                    assert.equals(result.customerAddress[0].addressZone3Id, addressZone3, 'return correct addressZone3Id');
                    assert.equals(result.customerAddress[0].addressZone4Id, addressZone4, 'return correct addressZone4Id');
                    assert.equals(result.customerEmail[0].emailTypeId, customerConstants.TYPEIDPERSONAL, 'return correct email type');
                    assert.equals(result.customerEmail[0].value, customerConstants.EMAIL, 'return correct email address');
                    assert.equals(result.customerPhone[0].phoneTypeId, PHONETYPEID, 'return correct phone type');
                    assert.equals(result.customerPhone[0].phoneNumber, PHONENUM, 'return correct phone number');
                }),
                commonFunc.createStep('customer.customer.get', 'Get a customer with all his details successufully', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add two phones, addresses and emails'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddPhone(result.customerPhone).error, null, 'Return phone details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddEmail(result.customerEmail).error, null, 'Return email details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddAddress(result.customerAddress).error, null, 'Return address details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                    assert.equals(result.customerAddress[0].addressZone1Id, addressZone1, 'return correct addressZone1Id');
                    assert.equals(result.customerAddress[0].addressZone2Id, addressZone2, 'return correct addressZone2Id');
                    assert.equals(result.customerAddress[0].addressZone3Id, addressZone3, 'return correct addressZone3Id');
                    assert.equals(result.customerAddress[0].addressZone4Id, addressZone4, 'return correct addressZone4Id');
                    assert.equals(result.customerEmail[0].emailTypeId, customerConstants.TYPEIDPERSONAL, 'return correct email type');
                    assert.equals(result.customerEmail[0].value, customerConstants.EMAIL, 'return correct email address');
                    assert.equals(result.customerPhone[0].phoneTypeId, PHONETYPEID, 'return correct phone type');
                    assert.equals(result.customerPhone[0].phoneNumber, PHONENUM, 'return correct phone number');
                }),
                commonFunc.createStep('customer.customer.add', 'add customer - basic details, empty phoneNumber ', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: ''
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.add', 'add customer - basic details, null phoneNumber ', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: null
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.add', 'add customer - basic details, empty phoneTypeId ', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        phone: [{
                            phoneTypeId: '',
                            phoneNumber: PHONENUM
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.add', 'add customer - basic details, null phoneTypeId ', (context) => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        phone: [{
                            phoneTypeId: null,
                            phoneNumber: PHONENUM
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - empty addressTypeId', context => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME + ' empty city',
                            lastName: customerConstants.LASTNAME
                        },
                        address: [{
                            addressTypeId: '',
                            value: customerConstants.ADDRESS,
                            statusId: customerConstants.STATUSIDACTIVE
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return porthttp');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - null addressTypeId', context => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME + ' empty city',
                            lastName: customerConstants.LASTNAME
                        },
                        address: [{
                            addressTypeId: null,
                            value: customerConstants.ADDRESS,
                            statusId: customerConstants.STATUSIDACTIVE
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - empty address value', context => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME + ' empty city',
                            lastName: customerConstants.LASTNAME
                        },
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: '',
                            statusId: customerConstants.STATUSIDACTIVE
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - null address value', context => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME + ' empty city',
                            lastName: customerConstants.LASTNAME
                        },
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: null,
                            statusId: customerConstants.STATUSIDACTIVE
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - empty lat and lng', context => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME + ' empty city',
                            lastName: customerConstants.LASTNAME
                        },
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS,
                            statusId: customerConstants.STATUSIDACTIVE,
                            lat: '',
                            lng: ''
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.add', 'Add customer - null lat and lng', context => {
                    return {
                        customer: {
                            customerTypeId: customerConstants.INDIVIDUALCUSTOMERTYPEID,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME + ' empty city',
                            lastName: customerConstants.LASTNAME
                        },
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            value: customerConstants.ADDRESS,
                            statusId: customerConstants.STATUSIDACTIVE,
                            lat: null,
                            lng: null
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerConstants.INDIVIDUALCUSTOMERTYPEID).error, null, 'Return all details after adding a customer');
                }),
                userMethods.logout('Logout admin user', context => context.login['identity.check'].sessionId)
            ]);
        }
    };
};
