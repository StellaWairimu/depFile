const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
// var userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const coreJoiValidation = require('ut-test/lib/joiValidations/core');
const userMethods = require('ut-test/lib/methods/user');
const customerParams = require('ut-test/lib/requestParams/customer');
const PORTHTTP = 'PortHTTP';
const PHONETYPEID = customerConstants.TYPEIDPERSONAL;
const PHONENUM = customerConstants.PHONENUMBER.slice(3, -2);
let customerTypeId, addressZone1, addressZone2, addressZone3, addressZone4;

module.exports = function test() {
    return {
        editCustomerContactInfo: function(test, bus, run) {
            return run(test, bus, [
                userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                /**
                 * CONTACT INFO TAB
                 */
                commonFunc.createStep('core.country.fetch', 'fetch countries', context => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCountry(result.country).error, null, 'Return fetchCountry');
                    const country = result.country.find(
                        (country) => country.countryCode === 'BG'
                    );
                    addressZone1 = country.itemNameId;
                }),
                commonFunc.createStep('core.itemNameByParent.list', 'list itemNameByParent - address1', context => {
                    return {
                        parentItemNameId: addressZone1
                    };
                }, (result, assert) => {
                    assert.equals(coreJoiValidation.validateListItemNameByParent(result.resultSet).error, null, 'Return all details after itemNameByParent');
                    addressZone2 = result.resultSet[0].itemNameId;
                }),
                commonFunc.createStep('core.itemNameByParent.list', 'list itemNameByParent - address2', context => {
                    return {
                        parentItemNameId: addressZone2
                    };
                }, (result, assert) => {
                    assert.equals(coreJoiValidation.validateListItemNameByParent(result.resultSet).error, null, 'Return all details after itemNameByParent');
                }),
                {
                    name: 'More address zones',
                    params: (context, utils) => {
                        if (context['list itemNameByParent - address2'].resultSet.length < 1) {
                            addressZone3 = null;
                            addressZone4 = null;
                            return utils.skip();
                        }
                    },
                    steps: () => [
                        commonFunc.createStep('core.itemNameByParent.list', 'list itemNameByParent - address3', context => {
                            addressZone3 = context['list itemNameByParent - address2'].resultSet[0].itemNameId;
                            return {
                                parentItemNameId: addressZone3
                            };
                        }, (result, assert) => {
                            assert.equals(coreJoiValidation.validateListItemNameByParent(result.resultSet).error, null, 'Return all details after itemNameByParent');
                            addressZone4 = result.resultSet.length > 0 ? result.resultSet[0].itemNameId : null;
                        })
                    ]
                }, commonFunc.createStep('customer.customer.add', 'Add customer successfully - all parameters for Contact Info tab', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            addressZone1: addressZone1,
                            addressZone2: addressZone2,
                            addressZone3: addressZone3,
                            addressZone4: addressZone4,
                            value: customerConstants.ADDRESS
                        }],
                        email: [{
                            emailTypeId: customerConstants.TYPEIDPERSONAL,
                            value: customerConstants.EMAIL
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddPhone(result.customerPhone).error, null, 'Return phone details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddEmail(result.customerEmail).error, null, 'Return email details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddAddress(result.customerAddress).error, null, 'Return address details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                    assert.equals(result.customerAddress[0].addressZone1Id, addressZone1, 'return correct addressZone1Id');
                    assert.equals(result.customerAddress[0].addressZone2Id, addressZone2, 'return correct addressZone2Id');
                    assert.equals(result.customerAddress[0].addressZone3Id, addressZone3, 'return correct addressZone3Id');
                    assert.equals(result.customerAddress[0].addressZone4Id, addressZone4, 'return correct addressZone4Id');
                    assert.equals(result.customerEmail[0].emailTypeId, customerConstants.TYPEIDPERSONAL, 'return correct email type');
                    assert.equals(result.customerEmail[0].value, customerConstants.EMAIL, 'return correct email address');
                    assert.equals(result.customerPhone[0].phoneTypeId, PHONETYPEID, 'return correct phone type');
                    assert.equals(result.customerPhone[0].phoneNumber, PHONENUM, 'return correct phone number');
                }),
                commonFunc.createStep('customer.customer.add', 'Add two phones, addresses and emails', context => {
                    return {
                        customer: {
                            customerTypeId: customerTypeId,
                            organizationId: context['get admin details'].memberOF[0].object
                        },
                        person: {
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM
                        },
                        phone: [{
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        },
                        {
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: PHONENUM
                        }],
                        address: [{
                            addressTypeId: customerConstants.TYPEIDHOME,
                            addressZone1: addressZone1,
                            addressZone2: addressZone2,
                            addressZone3: addressZone3,
                            addressZone4: addressZone4,
                            value: customerConstants.ADDRESS
                        },
                        {
                            addressTypeId: customerConstants.TYPEIDHOME,
                            addressZone1: addressZone1,
                            addressZone2: addressZone2,
                            addressZone3: addressZone3,
                            addressZone4: addressZone4,
                            value: customerConstants.ADDRESS
                        }],
                        email: [{
                            emailTypeId: customerConstants.TYPEIDPERSONAL,
                            value: customerConstants.EMAIL
                        },
                        {
                            emailTypeId: customerConstants.TYPEIDPERSONAL,
                            value: customerConstants.EMAIL
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddPhone(result.customerPhone).error, null, 'Return phone details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddEmail(result.customerEmail).error, null, 'Return email details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddAddress(result.customerAddress).error, null, 'Return address details after adding a customer');
                    assert.equals(result.customer.customerTypeId, customerTypeId, 'return customer type');
                    assert.equals(result.customerAddress[0].addressZone1Id, addressZone1, 'return correct addressZone1Id');
                    assert.equals(result.customerAddress[0].addressZone2Id, addressZone2, 'return correct addressZone2Id');
                    assert.equals(result.customerAddress[0].addressZone3Id, addressZone3, 'return correct addressZone3Id');
                    assert.equals(result.customerAddress[0].addressZone4Id, addressZone4, 'return correct addressZone4Id');
                    assert.equals(result.customerEmail[0].emailTypeId, customerConstants.TYPEIDPERSONAL, 'return correct email type');
                    assert.equals(result.customerEmail[0].value, customerConstants.EMAIL, 'return correct email address');
                    assert.equals(result.customerPhone[0].phoneTypeId, PHONETYPEID, 'return correct phone type');
                    assert.equals(result.customerPhone[0].phoneNumber, PHONENUM, 'return correct phone number');
                    assert.equals(result.customerAddress[1].addressZone1Id, addressZone1, 'return correct addressZone1Id');
                    assert.equals(result.customerAddress[1].addressZone2Id, addressZone2, 'return correct addressZone2Id');
                    assert.equals(result.customerAddress[1].addressZone3Id, addressZone3, 'return correct addressZone3Id');
                    assert.equals(result.customerAddress[1].addressZone4Id, addressZone4, 'return correct addressZone4Id');
                    assert.equals(result.customerEmail[1].emailTypeId, customerConstants.TYPEIDPERSONAL, 'return correct email type');
                    assert.equals(result.customerEmail[1].value, customerConstants.EMAIL, 'return correct email address');
                    assert.equals(result.customerPhone[1].phoneTypeId, PHONETYPEID, 'return correct phone type');
                    assert.equals(result.customerPhone[1].phoneNumber, PHONENUM, 'return correct phone number');
                }),
                commonFunc.createStep('customer.customer.edit', 'Remove one phone, email, address', context => {
                    return {
                        actorId: context['Add two phones, addresses and emails'].person.actorId,
                        person: {
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME,
                            nationalId: customerConstants.NATIONALID,
                            dateOfBirth: customerConstants.DATEOFBIRTH,
                            placeOfBirth: customerConstants.PLACEOFBIRTH,
                            nationality: customerConstants.NATIONALITY,
                            gender: customerConstants.GENDERM
                        },
                        phone: [{
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            phoneUnapprovedId: context['Add two phones, addresses and emails'].customerPhone[0].phoneUnapprovedId,
                            statusId: context['Add two phones, addresses and emails'].customerPhone[0].statusId,
                            phoneTypeId: context['Add two phones, addresses and emails'].customerPhone[0].phoneTypeId,
                            phoneNumber: context['Add two phones, addresses and emails'].customerPhone[0].phoneNumber
                        }],
                        address: [{
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            addressId: context['Add two phones, addresses and emails'].customerAddress[0].addressId,
                            statusId: context['Add two phones, addresses and emails'].customerAddress[0].statusId,
                            addressTypeId: context['Add two phones, addresses and emails'].customerAddress[0].addressTypeId,
                            addressZone1: context['Add two phones, addresses and emails'].customerAddress[0].addressZone1Id,
                            addressZone2: context['Add two phones, addresses and emails'].customerAddress[0].addressZone2Id,
                            addressZone3: context['Add two phones, addresses and emails'].customerAddress[0].addressZone3Id,
                            addressZone4: context['Add two phones, addresses and emails'].customerAddress[0].addressZone4Id,
                            value: context['Add two phones, addresses and emails'].customerAddress[0].value
                        }],
                        email: [{
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            emailUnapprovedId: context['Add two phones, addresses and emails'].customerEmail[0].emailUnapprovedId,
                            statusId: context['Add two phones, addresses and emails'].customerEmail[0].statusId,
                            emailTypeId: context['Add two phones, addresses and emails'].customerEmail[0].emailTypeId,
                            value: context['Add two phones, addresses and emails'].customerEmail[0].value
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddPhone(result.customerPhone).error, null, 'Return phone details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddEmail(result.customerEmail).error, null, 'Return email details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddAddress(result.customerAddress).error, null, 'Return address details after adding a customer');
                    assert.equals(result.customerAddress[0].addressZone1Id, addressZone1, 'return correct addressZone1Id');
                    assert.equals(result.customerAddress[0].addressZone2Id, addressZone2, 'return correct addressZone2Id');
                    assert.equals(result.customerAddress[0].addressZone3Id, addressZone3, 'return correct addressZone3Id');
                    assert.equals(result.customerAddress[0].addressZone4Id, addressZone4, 'return correct addressZone4Id');
                    assert.equals(result.customerEmail[0].emailTypeId, customerConstants.TYPEIDPERSONAL, 'return correct email type');
                    assert.equals(result.customerEmail[0].value, customerConstants.EMAIL, 'return correct email address');
                    assert.equals(result.customerPhone[0].phoneTypeId, PHONETYPEID, 'return correct phone type');
                    assert.equals(result.customerPhone[0].phoneNumber, PHONENUM, 'return correct phone number');
                    assert.true(result.customerAddress.length === 1, 'return only one element');
                    assert.true(result.customerEmail.length === 1, 'return only one element');
                    assert.true(result.customerPhone.length === 1, 'return only one element');
                }),
                commonFunc.createStep('customer.customer.get', 'Get a customer with all his details successufully', (context) => customerParams.actorIdParams(
                    context, (context) => context['Add two phones, addresses and emails'].customer.actorId),
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddPhone(result.customerPhone).error, null, 'Return phone details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddEmail(result.customerEmail).error, null, 'Return email details after adding a customer');
                    assert.equals(customerJoiValidation.validateAddAddress(result.customerAddress).error, null, 'Return address details after adding a customer');
                    assert.equals(result.customerAddress[0].addressZone1Id, addressZone1, 'return correct addressZone1Id');
                    assert.equals(result.customerAddress[0].addressZone2Id, addressZone2, 'return correct addressZone2Id');
                    assert.equals(result.customerAddress[0].addressZone3Id, addressZone3, 'return correct addressZone3Id');
                    assert.equals(result.customerAddress[0].addressZone4Id, addressZone4, 'return correct addressZone4Id');
                    assert.equals(result.customerEmail[0].emailTypeId, customerConstants.TYPEIDPERSONAL, 'return correct email type');
                    assert.equals(result.customerEmail[0].value, customerConstants.EMAIL, 'return correct email address');
                    assert.equals(result.customerPhone[0].phoneTypeId, PHONETYPEID, 'return correct phone type');
                    assert.equals(result.customerPhone[0].phoneNumber, PHONENUM, 'return correct phone number');
                    assert.true(result.customerAddress.length === 1, 'return only one element');
                    assert.true(result.customerEmail.length === 1, 'return only one element');
                    assert.true(result.customerPhone.length === 1, 'return only one element');
                }),
                commonFunc.createStep('customer.customer.edit', 'add customer - basic details, empty phoneNumber ', (context) => {
                    return {
                        actorId: context['Add two phones, addresses and emails'].person.actorId,
                        person: {
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        phone: [{
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            phoneId: context['Add two phones, addresses and emails'].customerPhone[0].phoneId,
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: '',
                            statusId: customerConstants.STATUSIDAPPROVED,
                            isPrimary: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'add customer - basic details, null phoneNumber ', (context) => {
                    return {
                        actorId: context['Add two phones, addresses and emails'].person.actorId,
                        person: {
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        phone: [{
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            phoneId: context['Add two phones, addresses and emails'].customerPhone[0].phoneId,
                            phoneTypeId: PHONETYPEID,
                            phoneNumber: null,
                            statusId: customerConstants.STATUSIDAPPROVED,
                            isPrimary: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'add customer - basic details, empty phoneTypeId ', (context) => {
                    return {
                        actorId: context['Add two phones, addresses and emails'].person.actorId,
                        person: {
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        phone: [{
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            phoneId: context['Add two phones, addresses and emails'].customerPhone[0].phoneId,
                            phoneTypeId: '',
                            phoneNumber: PHONENUM,
                            statusId: customerConstants.STATUSIDAPPROVED,
                            isPrimary: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'add customer - basic details, null phoneTypeId ', (context) => {
                    return {
                        actorId: context['Add two phones, addresses and emails'].person.actorId,
                        person: {
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        phone: [{
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            phoneId: context['Add two phones, addresses and emails'].customerPhone[0].phoneId,
                            phoneTypeId: null,
                            phoneNumber: PHONENUM,
                            statusId: customerConstants.STATUSIDAPPROVED,
                            isPrimary: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'Add customer - empty addressTypeId', context => {
                    return {
                        actorId: context['Add two phones, addresses and emails'].person.actorId,
                        person: {
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            firstName: customerConstants.FIRSTNAME + ' empty city',
                            lastName: customerConstants.LASTNAME
                        },
                        address: [{
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            addressId: context['Add two phones, addresses and emails'].customerAddress[0].addressId,
                            addressTypeId: '',
                            value: customerConstants.ADDRESS,
                            statusId: customerConstants.STATUSIDAPPROVED
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return porthttp');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - null addressTypeId', context => {
                    return {
                        actorId: context['Add two phones, addresses and emails'].person.actorId,
                        person: {
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            firstName: customerConstants.FIRSTNAME + ' empty city',
                            lastName: customerConstants.LASTNAME
                        },
                        address: [{
                            actorId: context['Add two phones, addresses and emails'].person.actorId,
                            addressId: context['Add two phones, addresses and emails'].customerAddress[0].addressId,
                            addressTypeId: null,
                            value: customerConstants.ADDRESS,
                            statusId: customerConstants.STATUSIDAPPROVED
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'portSQL', 'retrn portSQL - null addressTypeId');
                }),
                // commonFunc.createStep('customer.customer.edit', 'Add customer - empty address value', context => {
                //     return {
                //         actorId: context['Add two phones, addresses and emails'].person.actorId,
                //         person: {
                //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                //             firstName: customerConstants.FIRSTNAME + ' empty city',
                //             lastName: customerConstants.LASTNAME
                //         },
                //         address: [{
                //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                //             addressId: context['Add two phones, addresses and emails'].customerAddress[0].addressId,
                //             addressTypeId: customerConstants.TYPEIDHOME,
                //             value: '',
                //             statusId: customerConstants.STATUSIDAPPROVED
                //         }]
                //     };
                // }, null, (error, assert) => {
                //     assert.equals(error.type, PORTHTTP, 'return joi validation');
                // }),
                // commonFunc.createStep('customer.customer.edit', 'Add customer - null address value', context => {
                //     return {
                //         actorId: context['Add two phones, addresses and emails'].person.actorId,
                //         person: {
                //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                //             firstName: customerConstants.FIRSTNAME + ' empty city',
                //             lastName: customerConstants.LASTNAME
                //         },
                //         address: [{
                //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                //             addressId: context['Add two phones, addresses and emails'].customerAddress[0].addressId,
                //             addressTypeId: customerConstants.TYPEIDHOME,
                //             value: null,
                //             statusId: customerConstants.STATUSIDAPPROVED
                //         }]
                //     };
                // }, null, (error, assert) => {
                //     assert.equals(error.type, PORTHTTP, 'return joi validation');
                // }),
                // commonFunc.createStep('customer.customer.edit', 'null email value ', (context) => {
                //     return {
                //         actorId: context['Add two phones, addresses and emails'].person.actorId,
                //         person: {
                //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                //             firstName: customerConstants.FIRSTNAME,
                //             lastName: customerConstants.LASTNAME
                //         },
                //         email: [{
                //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                //             emailId: context['Add two phones, addresses and emails'].customerEmail[0].emailId,
                //             emailTypeId: customerConstants.TYPEIDPERSONAL,
                //             value: null,
                //             statusId: customerConstants.STATUSIDAPPROVED,
                //             isPrimary: 1
                //         }]
                //     };
                // }, null, (error, assert) => {
                //     assert.equals(error.type, 'PortHTTP', 'return joi failure');
                // }),
                // commonFunc.createStep('customer.customer.edit', 'empty email value ', (context) => {
                //     return {
                //         actorId: context['Add two phones, addresses and emails'].person.actorId,
                //         person: {
                //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                //             firstName: customerConstants.FIRSTNAME,
                //             lastName: customerConstants.LASTNAME
                //         },
                //         email: [{
                //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                //             emailId: context['Add two phones, addresses and emails'].customerEmail[0].emailId,
                //             emailTypeId: customerConstants.TYPEIDPERSONAL,
                //             value: '',
                //             statusId: customerConstants.STATUSIDAPPROVED,
                //             isPrimary: 1
                //         }]
                //     };
                // }, null, (error, assert) => {
                //     assert.equals(error.type, PORTHTTP, 'return joi validation');
                // }),
                // commonFunc.createStep('customer.customer.edit', 'no isPrimary', (context) => {
                //     return {
                //         actorId: context['Add two phones, addresses and emails'].person.actorId,
                //         person: {
                //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                //             firstName: customerConstants.FIRSTNAME,
                //             lastName: customerConstants.LASTNAME
                //         },
                //         email: [{
                //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                //             emailTypeId: customerConstants.TYPEIDPERSONAL,
                //             value: customerConstants.EMAIL,
                //             statusId: customerConstants.STATUSIDAPPROVED,
                //             isPrimary: 0
                //         }]
                //     };
                // }, (result, assert) => {
                //     assert.equals(customerJoiValidation.validateAddCustomer(result.customer, customerTypeId).error, null, 'Return all details after adding a customer');
                //     assert.equals(customerJoiValidation.validateAddEmail(result.customerEmail).error, null, 'Return email details after adding a customer');
                // }),
                // // commonFunc.createStep('customer.customer.edit', 'missing isPrimary', (context) => {
                // //     return {
                // //         actorId: context['Add two phones, addresses and emails'].person.actorId,
                // //         person: {
                // //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                // //             firstName: customerConstants.FIRSTNAME,
                // //             lastName: customerConstants.LASTNAME
                // //         },
                // //         email: [{
                // //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                // //             emailTypeId: customerConstants.TYPEIDPERSONAL,
                // //             value: customerConstants.EMAIL,
                // //             statusId: customerConstants.STATUSIDAPPROVED
                // //         }]
                // //     };
                // // }, null, (error, assert) => {
                // //     assert.equals(error.type, PORTSQL, 'return joi validation');
                // // }),
                // // commonFunc.createStep('customer.customer.edit', 'missing statusId', (context) => {
                // //     return {
                // //         actorId: context['Add two phones, addresses and emails'].person.actorId,
                // //         person: {
                // //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                // //             firstName: customerConstants.FIRSTNAME,
                // //             lastName: customerConstants.LASTNAME
                // //         },
                // //         email: [{
                // //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                // //             emailTypeId: customerConstants.TYPEIDPERSONAL,
                // //             value: customerConstants.EMAIL,
                // //             isPrimary: 0
                // //         }]
                // //     };
                // // }, null, (error, assert) => {
                // //     assert.equals(error.type, PORTSQL, 'return joi validation');
                // // }),
                // commonFunc.createStep('customer.customer.edit', 'empty emailTypeId', (context) => {
                //     return {
                //         actorId: context['Add two phones, addresses and emails'].person.actorId,
                //         person: {
                //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                //             firstName: customerConstants.FIRSTNAME,
                //             lastName: customerConstants.LASTNAME
                //         },
                //         email: [{
                //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                //             emailId: context['Add two phones, addresses and emails'].customerEmail[0].emailId,
                //             emailTypeId: '',
                //             value: customerConstants.EMAIL,
                //             statusId: customerConstants.STATUSIDAPPROVED,
                //             isPrimary: 0
                //         }]
                //     };
                // }, null, (error, assert) => {
                //     assert.equals(error.type, PORTHTTP, 'return joi validation');
                // }),
                // // commonFunc.createStep('customer.customer.edit', 'missing emailTypeId', (context) => {
                // //     return {
                // //         actorId: context['Add two phones, addresses and emails'].person.actorId,
                // //         person: {
                // //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                // //             firstName: customerConstants.FIRSTNAME,
                // //             lastName: customerConstants.LASTNAME
                // //         },
                // //         email: [{
                // //             actorId: context['Add two phones, addresses and emails'].person.actorId,
                // //             emailId: context['Add two phones, addresses and emails'].customerEmail[0].emailId,
                // //             value: customerConstants.EMAIL,
                // //             statusId: customerConstants.STATUSIDAPPROVED,
                // //             isPrimary: 0
                // //         }]
                // //     };
                // // }, null, (error, assert) => {
                // //     assert.equals(error.type, PORTHTTP, 'return joi validation');
                // // }),
                userMethods.logout('Logout admin user', context => context.login['identity.check'].sessionId)
            ]);
        }
    };
};
