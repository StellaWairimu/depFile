const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerMethods = require('ut-test/lib/methods/customer');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const userConstants = require('ut-test/lib/constants/user').constants();
const USERNAME = 'addRef' + userConstants.USERNAME;
const PORTHTTPERROR = 'PortHTTP';
const APPROVENEWREFERRAL = 'newReferralAprrove';
const REJECTNEWREFERRAL = 'newReferralReject';
const OPENACCOUNT = 'openAccount';
const CUSTOMERREFERRALADDPERM = 'customer.referral.add';
let stdPolicy;
let customerTypeId;
let newRefStatusId, openRefStatusId, pendingRefStatusId, rejectedRefStatusId;

module.exports = function test() {
    return {
        addReferral: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', (context) => context.login['identity.check'].actorId),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                commonFunc.createStep('customer.referral.statusFetch', 'fetch referral statuses', (context) => {
                    return {};
                }, (result, assert) => {
                    // console.log(result);
                    const newRefStatus = result.referralStatus.find((status) => (status.code).toString().toLowerCase().indexOf('referralNew'.toLowerCase()) > -1);
                    newRefStatusId = newRefStatus.referralStatusId;
                    const openRefStatus = result.referralStatus.find((status) => status.code === 'referralOpen');
                    openRefStatusId = openRefStatus.referralStatusId;
                    const pendingRefStatus = result.referralStatus.find((status) => status.code === 'referralPending');
                    pendingRefStatusId = pendingRefStatus.referralStatusId;
                    const rejectedRefStatus = result.referralStatus.find((status) => (status.code.toString().toLowerCase()).indexOf('referralNewRejected'.toLowerCase()) > -1);
                    rejectedRefStatusId = rejectedRefStatus.referralStatusId;
                }),
                customerMethods.addCustomer('Add customer successfully', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object
                    };
                }),
                customerMethods.getCustomer('Get the newly created customer', context => context['Add customer successfully'].customer.actorId),
                customerMethods.addReferral('add referral to just added customer', (context) => {
                    return {
                        referralSource: context['Get the newly created customer'].customer.actorId,
                        MSISDN: customerConstants.NEWPHONENUMBER + 3,
                        referralStatusId: newRefStatusId
                    };
                }),
                // try to change the referral status with not allowed - instead of approve new - open account for ex.
                commonFunc.createStep('customer.referral.statusUpdate', 'update referral status with not allowed one - open account', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId,
                        actionName: OPENACCOUNT
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.referralStatusInvalidAction', 'return customer.referralStatusInvalidAction');
                }),
                commonFunc.createStep('customer.referral.statusUpdate', 'update referral status - approve new', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId,
                        actionName: APPROVENEWREFERRAL
                    };
                }, (result, assert) => {
                    assert.same(result, [], 'return empty resultset after update referral status - approve new');
                }),
                customerMethods.addReferral('add another referral to just added customer', (context) => {
                    return {
                        referralSource: context['Get the newly created customer'].customer.actorId,
                        MSISDN: customerConstants.NEWPHONENUMBER + 9,
                        referralStatusId: newRefStatusId
                    };
                }),
                commonFunc.createStep('customer.referral.statusUpdate', 'update referral 2 status - reject new', (context) => {
                    return {
                        referralId: context['add another referral to just added customer'].referral[0].referralId,
                        actionName: REJECTNEWREFERRAL
                    };
                }, (result, assert) => {
                    assert.same(result, [], 'return empty resultset after update referral status - reject new');
                }),
                commonFunc.createStep('customer.referral.fetch', 'fetch referrals', (context) => {
                    return {
                        referralStatusIds: [newRefStatusId]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchReferrals(result.referral).error, null, 'return all details after fetch referrals');
                }),
                commonFunc.createStep('customer.referral.get', 'get referral - approved', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.equals(result.referral[0].referralStatusId, openRefStatusId, 'return open referral status');
                }),
                commonFunc.createStep('customer.referral.get', 'get referral - rejected', (context) => {
                    return {
                        referralId: context['add another referral to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after getting referral');
                    assert.equals(result.referral[0].referralStatusId, rejectedRefStatusId, 'return rejected referral status');
                }),
                // negative
                commonFunc.createStep('customer.referral.add', 'add the same referral again', (context) => {
                    return {
                        referral: {
                            referralSource: context['Get the newly created customer'].customer.actorId,
                            MSISDN: customerConstants.NEWPHONENUMBER + 3,
                            referralStatusId: openRefStatusId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.referralMsisdnExists', 'return referralMsisdnExists');
                }),
                // error?
                commonFunc.createStep('customer.referral.add', 'add referral to just added customer - status pending', (context) => {
                    return {
                        referral: {
                            referralSource: context['Get the newly created customer'].customer.actorId,
                            MSISDN: customerConstants.NEWPHONENUMBER + 1,
                            referralStatusId: pendingRefStatusId
                        }
                    };
                }, (result, assert) => {
                    // console.log(result);
                    assert.equals(customerJoiValidation.validateAddReferral(result.referral).error, null, 'return all details after adding referral');
                    assert.equals(result.referral[0].referralStatusId, newRefStatusId, 'return referral statusId - new');
                    assert.true(result.referral[0].isNew, 'return isNew = true');
                }),
                commonFunc.createStep('customer.referral.add', 'add the referral to himself - own phone number', (context) => {
                    return {
                        referral: {
                            referralSource: context['Get the newly created customer'].customer.actorId,
                            MSISDN: context['Get the newly created customer'].customerPhone[0].phoneNumber,
                            referralStatusId: openRefStatusId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.customerMsisdnExists', 'return customerMsisdnExists');
                }),
                commonFunc.createStep('customer.referral.add', 'add referral  - no params', (context) => {
                    return {
                        referral: {}
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTPERROR, 'return joi validation');
                }),
                commonFunc.createStep('customer.referral.add', 'add referral  - empty params', (context) => {
                    return {
                        referral: {
                            referralSource: '',
                            MSISDN: '',
                            referralStatusId: ''
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTPERROR, 'return joi validation');
                }),
                commonFunc.createStep('customer.referral.add', 'add referral  - null params', (context) => {
                    return {
                        referral: {
                            referralSource: null,
                            MSISDN: null,
                            referralStatusId: null
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTPERROR, 'return joi validation');
                }),
                commonFunc.createStep('customer.referral.add', 'add referral  - missing MSISDN', (context) => {
                    return {
                        referral: {
                            referralSource: context['Get the newly created customer'].customer.actorId,
                            referralStatusId: openRefStatusId
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTPERROR, 'return joi validation');
                }),
                // MISSING PERMISSIONS
                userMethods.logout('logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('successful login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.referral.add', 'add referral - no permissions', (context) => {
                    return {
                        referral: {
                            referralSource: context['Get the newly created customer'].customer.actorId,
                            MSISDN: customerConstants.NEWPHONENUMBER + 6,
                            referralStatusId: openRefStatusId
                        }
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERREFERRALADDPERM) > -1, 'Missing permissions for ' + CUSTOMERREFERRALADDPERM);
                }),
                userMethods.logout('successfully logout new user', (context) => context['successful login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
