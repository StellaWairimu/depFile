const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerParams = require('ut-test/lib/requestParams/customer');
const customerMethods = require('ut-test/lib/methods/customer');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userConstants = require('ut-test/lib/constants/user').constants();
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const USERNAME = 'fetchCust' + userConstants.USERNAME;
const CUSTOMERNUMBER = customerConstants.CUSTOMERNUMBER;
const FIRSTNAME = customerConstants.FIRSTNAME;
const LASTNAME = customerConstants.LASTNAME;
const ORDERBYCUSTNUM = customerConstants.ORDERBYCUSTNUM;
const ORDERBYFIRSTNAME = customerConstants.ORDERBYFIRSTNAME;
const ORDERBYLASTNAME = customerConstants.ORDERBYLASTNAME;
const ORDERBYFULLNAME = customerConstants.ORDERBYFULLNAME;
const ORDERBYCREATEDON = customerConstants.ORDERBYCREATEDON;
const ORDERBYUPDATEDBY = customerConstants.ORDERBYUPDATEDBY;
const ORDERBYAGENCY = customerConstants.ORDERBYAGENCY;
const ORDERBYSTATUSID = customerConstants.ORDERBYSTATUSID;
const ORDERBYSTATUSVALUE = customerConstants.ORDERBYSTATUSVALUE;
const ORDERBYKYCID = customerConstants.ORDERBYKYCID;
const ORDERBYCUSTOMERTYPE = customerConstants.ORDERBYCUSTOMERTYPE;
const DESC = customerConstants.SORTORDERDESC;
const ASC = customerConstants.SORTORDERASC;
const STATUSIDREJECTED = customerConstants.STATUSIDREJECTED;
const STATUSIDDELETED = customerConstants.STATUSIDDELETED;
const STATUSIDINACTIVE = customerConstants.STATUSIDINACTIVE;
const STATUSIDPENDING = customerConstants.STATUSIDPENDING;
const STATUSIDAPPROVED = customerConstants.STATUSIDAPPROVED;
const STATEIDBLOCKED = customerConstants.STATEIDBLOCKED;
const STATEIDPENDING = customerConstants.STATUSIDPENDING;
const STATEIDREJECTED = customerConstants.STATUSIDREJECTED;
const STATEIDUPTODATE = customerConstants.STATEIDUPTODATE;
const PAGESIZE = customerConstants.PAGESIZE;
const PAGESIZEDEFAULT = customerConstants.PAGESIZEDEFAULT;
const PAGENUMBER = customerConstants.PAGENUMBER;
const PAGENUMBERDEFAULT = 1;
const AGENCY = 'test agency';
const RANDOMTEXT = 'RANDOMTEXT';
const NUMBERVALUE = 5;
const phoneNumber = customerConstants.PHONENUMBER;
const CUSTOMERCUSTOMERFETCH = 'customer.customer.fetch';
let adminAgencyId, stdPolicy, customerTypeId;
// TODO - add tests with different customerTypes, currently only 'client' is used
// TODO - create fetchCustomer method in methods.js when the implementation is finalized

module.exports = function test() {
    return {
        fetchCustomer: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('user.user.get', 'get admin details', (context) => {
                    return {
                        actorId: context.login['identity.check'].actorId
                    };
                },
                (result, assert) => {
                    adminAgencyId = result.memberOF[0].object;
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, userConstants.ADMINFIRSTNAME).error, null, 'return person');
                }),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                customerMethods.fetchOrganization('get child organizations of main org', context => context['get admin details'].memberOF[0].object),
                customerMethods.addCustomer('Add customer successfully - status APPROVED', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get child organizations of main org'].organization[0].actorId,
                        customerNumber: CUSTOMERNUMBER + 0,
                        kycId: 0,
                        lastName: LASTNAME + '1',
                        phoneTypeId: customerConstants.TYPEIDPERSONAL,
                        phoneNumber: phoneNumber,
                        isPrimary: true
                    };
                }, FIRSTNAME + ' STATUS APPROVED', STATEIDPENDING, STATUSIDAPPROVED),
                customerMethods.addCustomer('Add customer successfully - status APPROVED1, different lastName', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerNumber: CUSTOMERNUMBER + '00',
                        kycId: 0,
                        lastName: LASTNAME + '2',
                        phoneTypeId: customerConstants.TYPEIDPERSONAL,
                        phoneNumber: phoneNumber + 1,
                        isPrimary: true
                    };
                }, FIRSTNAME + ' STATUS APPROVED', STATEIDPENDING, STATUSIDAPPROVED),
                customerMethods.addCustomer('Add customer successfully - status DELETED', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerNumber: CUSTOMERNUMBER + 1,
                        kycId: 1,
                        agency: AGENCY,
                        lastName: LASTNAME + '2'
                    };
                }, FIRSTNAME + ' STATUS DELETED', STATEIDPENDING, STATUSIDDELETED),
                customerMethods.addCustomer('Add customer successfully - status INACTIVE', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerNumber: CUSTOMERNUMBER + 2,
                        kycId: 2,
                        agency: AGENCY,
                        lastName: LASTNAME + '3'
                    };
                }, FIRSTNAME + ' STATUS INACTIVE', STATEIDPENDING, STATUSIDINACTIVE),
                customerMethods.addCustomer('Add customer successfully - status PENDING', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerNumber: CUSTOMERNUMBER + 3,
                        kycId: 3,
                        agency: AGENCY,
                        lastName: LASTNAME + '3'
                    };
                }, FIRSTNAME + ' STATUS PENDING', STATEIDPENDING, STATUSIDPENDING),
                customerMethods.addCustomer('Add customer successfully - status REJECTED', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerNumber: CUSTOMERNUMBER + 4,
                        kycId: 0,
                        lastName: LASTNAME + '4'
                    };
                }, FIRSTNAME + ' STATUS REJECTED', STATEIDPENDING, STATUSIDREJECTED),
                customerMethods.addCustomer('Add customer successfully - state BLOCKED', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerNumber: CUSTOMERNUMBER + 5,
                        kycId: 0,
                        agency: AGENCY,
                        lastName: LASTNAME + '5'
                    };
                }, FIRSTNAME + ' STATE BLOCKED', STATEIDBLOCKED, STATUSIDAPPROVED),
                customerMethods.addCustomer('Add customer successfully - state PENDING', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerNumber: CUSTOMERNUMBER + 6,
                        kycId: 1,
                        agency: AGENCY,
                        lastName: LASTNAME + '6'
                    };
                }, FIRSTNAME + ' STATE PENDING', STATEIDPENDING, STATUSIDAPPROVED),
                customerMethods.addCustomer('Add customer successfully - state REJECTED', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerNumber: CUSTOMERNUMBER + 7,
                        kycId: 2,
                        agency: AGENCY,
                        lastName: LASTNAME + '7'
                    };
                }, FIRSTNAME + ' STATE REJECTED', STATEIDREJECTED, STATUSIDAPPROVED),
                customerMethods.addCustomer('Add customer successfully - state UP_TO_DATE', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        customerNumber: CUSTOMERNUMBER + 8,
                        kycId: 3,
                        agency: AGENCY,
                        lastName: LASTNAME + '8'
                    };
                }, FIRSTNAME + ' STATE UP_TO_DATE', STATEIDUPTODATE, STATUSIDAPPROVED),
                commonFunc.createStep('customer.file.update', 'Update customer first name', context => { // used because of the steps for ordering by updatedBy
                    return {
                        customer: {
                            actorId: context['Add customer successfully - state UP_TO_DATE'].customer.actorId
                        },
                        person: {
                            actorId: context['Add customer successfully - state UP_TO_DATE'].customer.actorId,
                            isEnabled: true,
                            isDeleted: false,
                            firstName: FIRSTNAME + ' STATE UP_TO_DATE UPDATED'
                        }
                    };
                },
                (result, assert) => {
                    assert.equals(result.person.firstName, FIRSTNAME + ' STATE UP_TO_DATE UPDATED', 'firstName is updated');
                    assert.true(result.customer.updatedOn !== null, 'updatedOn is not null');
                }),
                // FETCH
                // Microcred style
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - filter by firstName', (context) => {
                    return {
                        firstName: FIRSTNAME + ' STATUS APPROVED',
                        pageSize: PAGESIZE,
                        pageNumber: PAGENUMBER
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, null, null, FIRSTNAME + ' STATUS APPROVED', null).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - filter by lastName', (context) => {
                    return {
                        lastName: LASTNAME,
                        pageSize: PAGESIZE,
                        pageNumber: PAGENUMBER
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, null, null, null, LASTNAME).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - filter by firstName, lastName, status, state, customerNumber', (context) => {
                    return {
                        statusList: [STATUSIDAPPROVED],
                        stateList: [STATEIDPENDING],
                        firstName: FIRSTNAME + ' STATUS APPROVED',
                        customerNumber: CUSTOMERNUMBER + '0',
                        lastName: LASTNAME,
                        sortBy: ORDERBYLASTNAME,
                        sortOrder: DESC,
                        pageSize: PAGESIZE,
                        pageNumber: PAGENUMBER
                    };
                },
                (result, assert) => {
                    // assert.true(commonFunc.compareOrderString(result.customer, 'lastName', 0), 'return customers sorted in DESC order by lastName');
                    assert.true(result.pagination[0].pageSize === PAGESIZE, 'return correct page size');
                    assert.true(result.pagination[0].pageNumber === PAGENUMBER, 'return correct page number');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, STATUSIDAPPROVED, STATEIDPENDING, FIRSTNAME + ' STATUS APPROVED', LASTNAME).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - filter by agencyId and status approved', (context) => {
                    return {
                        statusList: [STATUSIDAPPROVED],
                        agencyId: context['get admin details'].memberOF[0].object,
                        pageSize: PAGESIZE,
                        pageNumber: PAGENUMBER
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.every(customer => customer.agencyId === adminAgencyId), 'return customers for the filtered agency');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, STATUSIDAPPROVED).error, null, 'Return all details after fetching customers');
                    assert.true(result.agencyList.length === 1, 'return only one agency');
                    assert.true(result.agencyList[0].agencyId === adminAgencyId, 'return the correct agency id');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - STATEIDREJECTED', (context) => {
                    return {
                        stateList: [STATEIDREJECTED],
                        pageSize: PAGESIZE,
                        pageNumber: PAGENUMBER
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, null, STATEIDREJECTED, null, null).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - STATEIDUP_TO_DATE', (context) => {
                    return {
                        stateList: [STATEIDUPTODATE],
                        pageSize: PAGESIZE,
                        pageNumber: PAGENUMBER
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, null, STATEIDUPTODATE, null, null).error, null, 'Return all details after fetching customers');
                }),
                // Standard style
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - STATUSIDAPPROVED', (context) => {
                    return {
                        statusList: [STATUSIDAPPROVED],
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, STATUSIDAPPROVED).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - STATUSIDDELETED', (context) => {
                    return {
                        statusList: [STATUSIDDELETED],
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, STATUSIDDELETED).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - STATUSIDINACTIVE', (context) => {
                    return {
                        statusList: [STATUSIDINACTIVE],
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, STATUSIDINACTIVE, null, null, null).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - STATUSIDPENDING', (context) => {
                    return {
                        statusList: [STATUSIDPENDING],
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, STATUSIDPENDING, null, null, null).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - STATUSIDREJECTED', (context) => {
                    return {
                        statusList: [STATUSIDREJECTED],
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, STATUSIDREJECTED, null, null, null).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - filter by customerNumber', (context) => {
                    return {
                        filterBy: {
                            customerNumber: CUSTOMERNUMBER
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true((result.customer).every(x => x.customerNumber.includes(CUSTOMERNUMBER)), 'return all customers with number which IS or CONTAINS the selected customer number');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                // TODO uncomment and test when customerName is added to customer.add proc
                // commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - filter by status and cusomerName', (context) => {
                //     return {
                //         statusList: [STATUSIDAPPROVED],
                //         filterBy: {
                //             customerName: FIRSTNAME + ' STATUS APPROVED ' + LASTNAME
                //         },
                //         orderBy: {
                //             column: 'fullName',
                //             direction: DESC
                //         },
                //         paging: {
                //             pageSize: PAGESIZE,
                //             pageNumber: PAGENUMBER
                //         }
                //     };
                // },
                // (result, assert) => {
                //     assert.true(result.customer.length > 0, 'return not empty result set');
                //     assert.true(result.customer.every(customer => customer.customerName.includes(FIRSTNAME + ' STATUS APPROVED ' + LASTNAME)), 'return customers with the given customer name');
                //     assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, STATUSIDAPPROVED).error, null, 'Return all details after fetching customers, status approved');
                //     assert.true(commonFunc.compareOrderString(result.customer, 'fullName', 0), 'return customers sorted in DESC order by fullName');
                // }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - filter by status and customerNumber', (context) => {
                    return {
                        statusList: [STATUSIDAPPROVED],
                        filterBy: {
                            customerNumber: CUSTOMERNUMBER + 0
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.length > 0, 'return not empty result set');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, STATUSIDAPPROVED, null, null, null).error, null, 'Return all details after fetching customers, status approved');
                    assert.true((result.customer).every(x => x.customerNumber.includes(CUSTOMERNUMBER + 0)), 'return all customers with number which IS or CONTAINS the selected customer number');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - filter by agencyId and status approved 1', (context) => {
                    return {
                        statusList: [STATUSIDAPPROVED],
                        filterBy: {
                            agencyId: context['get admin details'].memberOF[0].object
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.every(customer => customer.agencyId === adminAgencyId), 'return customers for the filtered agency');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, STATUSIDAPPROVED).error, null, 'Return all details after fetching customers');
                    assert.true(result.agencyList.length === 1, 'return only one agency');
                    assert.true(result.agencyList[0].agencyId === adminAgencyId, 'return the correct agency id');
                }),
                // Paging
                commonFunc.createStep('customer.customer.fetch', 'fetch customers without providing any params', context => {
                    return {};
                }, (result, assert) => {
                    assert.equals(result.pagination[0].pageSize, PAGESIZEDEFAULT, 'return default page size ' + PAGESIZEDEFAULT);
                    assert.equals(result.pagination[0].pageNumber, PAGENUMBERDEFAULT, 'return default page number ' + PAGENUMBERDEFAULT);
                    // assert.true(commonFunc.compareOrderString(result.customer, 'firstName', 1), 'return customers sorted in ASC order by firstName (by default)');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customers successfully - missing page number', context => {
                    return {
                        stateList: [STATEIDPENDING],
                        paging: {
                            pageSize: PAGESIZE
                        }
                    };
                }, (result, assert) => {
                    assert.true(result.customer.length > 0, 'return not empty resultset');
                    assert.equals(result.pagination[0].pageNumber, PAGENUMBERDEFAULT, 'return default page number ' + PAGENUMBERDEFAULT);
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customers successfully - missing pageSize', context => {
                    return {
                        stateList: [STATEIDPENDING],
                        paging: {
                            pageNumber: PAGENUMBER
                        }
                    };
                }, (result, assert) => {
                    assert.true(result.customer.length > 0, 'return not empty resultset');
                    assert.equals(result.pagination[0].pageSize, PAGESIZEDEFAULT, 'return default page size ' + PAGESIZEDEFAULT);
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customers successfully - pageNumber empty string', context => {
                    return {
                        stateList: [STATEIDPENDING],
                        paging: {
                            pageNumber: '',
                            pageSize: PAGESIZE
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customers successfully - pageSize empty string', context => {
                    return {
                        stateList: [STATEIDPENDING],
                        paging: {
                            pageNumber: PAGENUMBER,
                            pageSize: ''
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - filter by phoneNumber', (context) => {
                    return {
                        filterBy: {
                            phoneNumber: phoneNumber
                        }
                    };
                }, (result, assert) => {
                    assert.true(result.customer.length > 1, 'return not empty result set');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer, STATUSIDAPPROVED, null, null, null).error, null, 'Return all details after fetching customers, status approved');
                    assert.true((result.customer).every(x => x.primaryPhone.includes(phoneNumber)), 'return all customers with number which IS or CONTAINS the selected phone number');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - phoneNumber random text', (context) => {
                    return {
                        filterBy: {
                            phoneNumber: RANDOMTEXT
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - phoneNumber null', (context) => {
                    return {
                        filterBy: {
                            phoneNumber: null
                        }
                    };
                }, (result, assert) => {
                    assert.true(result.customer.length === 0, 'return empty resultset');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - phoneNumber empty string', (context) => {
                    return {
                        filterBy: {
                            phoneNumber: ''
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - phoneNumber 0', (context) => {
                    return {
                        filterBy: {
                            phoneNumber: 0
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // SORTING
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy customerNumber, without direction', context => customerParams.fetchCustomerParams(
                    context, (context) => {
                        return {
                            orderBy: {
                                column: ORDERBYCUSTNUM
                            },
                            paging: {
                                pageSize: PAGESIZE,
                                pageNumber: PAGENUMBER
                            }
                        };
                    }),
                (result, assert) => {
                    assert.true(result.customer.length > 0, 'return NOT empty resultset');
                    // assert.true(commonFunc.compareOrderString(result.customer, 'firstName', 1), 'return customers sorted in ASC order by firstName (by default)');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy customerNumber DESC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYCUSTNUM,
                            direction: DESC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    // assert.true(commonFunc.compareOrderString(result.customer, 'customerNumber', 0), 'return customers sorted in DESC order by customerNumber');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy customerNumber ASC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYCUSTNUM,
                            direction: ASC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    // assert.true(commonFunc.compareOrderString(result.customer, 'customerNumber', 1), 'return customers sorted in ASC order by customerNumber');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - order by firstName DESC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYFIRSTNAME,
                            direction: DESC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer[0].firstName.localeCompare(result.customer[1].firstName) >= 0, 'return customers sorted in DESC order by firstName');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - order by firstName ASC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYFIRSTNAME,
                            direction: ASC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer[0].firstName.localeCompare(result.customer[1].firstName) <= 0, 'return customers sorted in ASC order by firstName');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - order by lastName DESC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYLASTNAME,
                            direction: DESC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer[0].lastName.localeCompare(result.customer[1].lastName) >= 0, 'return customers sorted in DESC order by lastName');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - order by lastName ASC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYLASTNAME,
                            direction: ASC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer[0].lastName.localeCompare(result.customer[1].lastName) <= 0, 'return customers sorted in ASC order by lastName');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - order by fullName DESC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYFULLNAME,
                            direction: DESC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer[0].fullName.localeCompare(result.customer[1].fullName) >= 0, 'return customers sorted in DESC order by fullName');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - order by fullName ASC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYFULLNAME,
                            direction: ASC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer[0].fullName.localeCompare(result.customer[1].fullName) <= 0, 'return customers sorted in ASC order by fullName');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy createdOn DESC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYCREATEDON,
                            direction: DESC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true(new Date(result.customer[0].createdOn) >= new Date(result.customer[1].createdOn), 'return customers sorted in DESC order by createdOn');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy createdOn ASC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYCREATEDON,
                            direction: ASC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true(new Date(result.customer[0].createdOn) <= new Date(result.customer[1].createdOn), 'return customers sorted in ASC order by createdOn');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy updatedBy DESC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYUPDATEDBY,
                            direction: DESC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true((result.customer[0].updatedBy || '').localeCompare(result.customer[1].updatedBy || '') >= 0, 'return customers sorted in DESC order by updatedBy');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy updatedBy ASC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYUPDATEDBY,
                            direction: ASC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true((result.customer[0].updatedBy || '').localeCompare(result.customer[1].updatedBy || '') <= 0, 'return customers sorted in ASC order by updatedBy');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy agency DESC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYAGENCY,
                            direction: DESC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true((result.customer[0].agencyName || '').localeCompare(result.customer[1].agencyName || '') >= 0, 'return customers sorted in DESC order by agencyName');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy agency ASC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYAGENCY,
                            direction: ASC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true((result.customer[0].agencyName || '').localeCompare(result.customer[1].agencyName || '') <= 0, 'return customers sorted in ASC order by agencyName');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy statusId DESC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYSTATUSID,
                            direction: DESC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true((result.customer[0].statusId || '').localeCompare(result.customer[1].statusId || '') >= 0, 'return customers sorted in DESC order by statusId');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy statusId ASC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYSTATUSID,
                            direction: ASC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true((result.customer[0].statusId).localeCompare(result.customer[1].statusId) <= 0, 'return customers sorted in ASC order by statusId');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy statusValue (description) DESC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYSTATUSVALUE,
                            direction: DESC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true((result.customer[0].description || '').localeCompare(result.customer[1].description || '') >= 0, 'return customers sorted in DESC order by description');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy statusValue (description) ASC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYSTATUSVALUE,
                            direction: ASC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy kycId DESC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYKYCID,
                            direction: DESC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true((result.customer[0].kycId || 0) >= (result.customer[1].kycId || 0), 'return customers sorted in DESC order by kycId');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy kycId ASC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYKYCID,
                            direction: ASC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true((result.customer[0].kycId || 0) <= (result.customer[1].kycId || 0), 'return customers sorted in ASC order by kycId');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy customerType DESC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYCUSTOMERTYPE,
                            direction: DESC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true((result.customer[0].customerType).localeCompare(result.customer[1].customerType) >= 0, 'return customers sorted in DESC order by customerType');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer successfully - orderBy customerType ASC', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYCUSTOMERTYPE,
                            direction: ASC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true((result.customer[0].customerType).localeCompare(result.customer[1].customerType) <= 0, 'return customers sorted in ASC order by customerType');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                // Negative - sortList and statusList
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - statusList: number (invalid input)', (context) => {
                    return {
                        statusList: [NUMBERVALUE]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - status must be a string');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - stateList: number (invalid input)', (context) => {
                    return {
                        stateList: [NUMBERVALUE]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure - state must be a string');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - statusList: non existing', (context) => {
                    return {
                        statusList: [RANDOMTEXT]
                    };
                },
                (result, assert) => {
                    assert.same(result.customer, [], 'return empty array');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - stateList: non existing', (context) => {
                    return {
                        stateList: [RANDOMTEXT]
                    };
                },
                (result, assert) => {
                    assert.same(result.customer, [], 'return empty array');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - statusList empty string', (context) => {
                    return {
                        statusList: ['']
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - stateList empty string', (context) => {
                    return {
                        stateList: ['']
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - statusList null', (context) => {
                    return {
                        statusList: null
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.length > 0, 'Return not empty resultset');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - stateList null', (context) => {
                    return {
                        stateList: null
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.length > 0, 'Return not empty resultset');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                // Negative - orderBy
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - order by non existing column', (context) => {
                    return {
                        orderBy: {
                            column: RANDOMTEXT,
                            direction: ASC
                        },
                        paging: {
                            pageSize: PAGESIZE,
                            pageNumber: PAGENUMBER
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.length > 0, 'return not empty result');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - order by invalid direction', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYFIRSTNAME,
                            direction: RANDOMTEXT
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'The data for table-value orderBy doesnt conform to the table type of the parameter');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - order by column empty string', (context) => {
                    return {
                        orderBy: {
                            column: '',
                            direction: ASC
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.length > 0, 'return not empty result');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - order by direction empty string', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYFIRSTNAME,
                            direction: ''
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.length > 0, 'return not empty result');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - order by column null', (context) => {
                    return {
                        orderBy: {
                            column: null,
                            direction: ASC
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return failure - column must be a string');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - order by direction null', (context) => {
                    return {
                        orderBy: {
                            column: ORDERBYFIRSTNAME,
                            direction: null
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return failure - direction must be a string');
                }),
                // Negative - filterBy
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - filter by customerNumber: non existing', (context) => {
                    return {
                        filterBy: {
                            customerNumber: RANDOMTEXT
                        }
                    };
                },
                (result, assert) => {
                    assert.same(result.customer, [], 'return empty result');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - filter by firstName: non existing', (context) => {
                    return {
                        firstName: RANDOMTEXT
                    };
                },
                (result, assert) => {
                    assert.same(result.customer, [], 'return empty result');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - filter by lastName: non existing', (context) => {
                    return {
                        lastName: RANDOMTEXT
                    };
                },
                (result, assert) => {
                    assert.same(result.customer, [], 'return empty result');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - filter by agencyId: non existing', (context) => {
                    return {
                        filterBy: {
                            agencyId: RANDOMTEXT
                        }
                    };
                },
                (result, assert) => {
                    assert.same(result.customer, [], 'return empty result');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - filter by customerType: non existing', (context) => {
                    return {
                        filterBy: {
                            customerType: RANDOMTEXT
                        }
                    };
                },
                (result, assert) => {
                    assert.same(result.customer, [], 'return empty result');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - customerNumber empty string', (context) => {
                    return {
                        filterBy: {
                            customerNumber: ''
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - firstName empty string', (context) => {
                    return {
                        firstName: '',
                        lastName: LASTNAME
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - lastName empty string', (context) => {
                    return {
                        firstName: FIRSTNAME,
                        lastName: ''
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - agencyId empty string', (context) => {
                    return {
                        filterBy: {
                            agencyId: ''
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - customerType empty string', (context) => {
                    return {
                        filterBy: {
                            customerType: ''
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - customerNumber null', (context) => {
                    return {
                        filterBy: {
                            customerNumber: null
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - firstName null', (context) => {
                    return {
                        firstName: null
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - lastName null', (context) => {
                    return {
                        lastName: null
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - agencyId null', (context) => {
                    return {
                        filterBy: {
                            agencyId: null
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer - customerType null', (context) => {
                    return {
                        filterBy: {
                            customerType: null
                        }
                    };
                },
                (result, assert) => {
                    assert.true(result.customer.length > 0, 'Return not empty resultset');
                    assert.equals(customerJoiValidation.validateFetchCustomers(result.customer).error, null, 'Return all details after fetching customers');
                }),
                // Missing permissions for fetch
                userMethods.logout('Logout admin user', context => context.login['identity.check'].sessionId),
                userMethods.login('Login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.customer.fetch', 'fetch customer unsuccessfully - no rights', context => {
                    return {
                        statusList: [STATUSIDAPPROVED]
                    };
                }, null,
                (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERCUSTOMERFETCH) > -1, 'Missing permissions for ' + CUSTOMERCUSTOMERFETCH);
                }),
                userMethods.logout('Logout new user', context => context['Login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
