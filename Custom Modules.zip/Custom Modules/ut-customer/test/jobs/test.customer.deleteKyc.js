const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const customerMethods = require('ut-test/lib/methods/customer');
const customerParams = require('ut-test/lib/requestParams/customer');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const userConstants = require('ut-test/lib/constants/user').constants();
const USERNAME = 'delKyc' + userConstants.USERNAME;
const CUSTOMERKYCDELETE = 'customer.kyc.delete';
const KYCDESCRIPTION = customerConstants.KYCDESCRIPTION;
const RANDOMCONDITIONID = customerConstants.RANDOMCONDITIONID;
const TEXTINPUT = 'test';
let orgId1, organizationDepthArray;
let stdPolicy;

module.exports = function test() {
    return {
        deleteKyc: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('user.user.get', 'get admin details', (context) => {
                    return {
                        actorId: context.login['identity.check'].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, userConstants.ADMINFIRSTNAME).error, null, 'return person');
                    orgId1 = result.memberOF[0].object;
                }),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                customerMethods.fetchCustomerType('fetch customer types'),
                commonFunc.createStep('core.configuration.fetch', 'fetch defaultBu setting', (context) => {
                    return {
                        key: customerConstants.GETBYDEPTHORGANIZATION
                    };
                }, (result, assert) => {
                    const orgDepth = result[0][0].value;
                    organizationDepthArray = Array.apply(null, {length: orgDepth - 1}).map(Number.call, Number);
                    assert.true(typeof result, 'object', 'return result');
                }),
                // Create organization which correspond to the kyc's depth
                {
                    name: 'Create organization by depth',
                    steps: () => organizationDepthArray.map(org => ({
                        name: 'Add and approve organizations',
                        steps: () => [
                            commonFunc.createStep('customer.organization.add', 'add organization',
                                () => ({
                                    organization: {
                                        organizationName: customerConstants.ORGNAME
                                    },
                                    parent: [orgId1]
                                }), (result, assert) => {
                                    orgId1 = result['organization.info'][0].actorId;
                                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                                }
                            ),
                            customerMethods.approveOrganization('approve organization', () => orgId1)
                        ]
                    }))
                },
                customerMethods.getForCreateKyc('get levels for creating kyc', context => {
                    return {
                        customerType: context['fetch customer types'].customerType[0].customerTypeNumber,
                        organizationId: orgId1
                    };
                }),
                customerMethods.listKycAttributes('list kyc attributes', context => context['fetch customer types'].customerType[0].customerTypeNumber),
                customerMethods.addKyc('add kyc 1', context => {
                    return {
                        display: context['get levels for creating kyc'].levels[1].itemNameTranslation,
                        customerTypeId: context['fetch customer types'].customerType[0].customerTypeNumber,
                        organizationId: orgId1,
                        itemNameId: context['get levels for creating kyc'].levels[1].itemNameId,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: context['list kyc attributes'].kycAttributes[0].itemNameId

                    };
                }, KYCDESCRIPTION),
                customerMethods.addKyc('add kyc 2', context => {
                    return {
                        display: context['get levels for creating kyc'].levels[2].itemNameTranslation,
                        customerTypeId: context['fetch customer types'].customerType[0].customerTypeNumber,
                        organizationId: orgId1,
                        itemNameId: context['get levels for creating kyc'].levels[2].itemNameId,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: context['list kyc attributes'].kycAttributes[0].itemNameId

                    };
                }, KYCDESCRIPTION + 1),
                customerMethods.addKyc('add kyc 3', context => {
                    return {
                        display: context['get levels for creating kyc'].levels[3].itemNameTranslation,
                        customerTypeId: context['fetch customer types'].customerType[0].customerTypeNumber,
                        organizationId: orgId1,
                        itemNameId: context['get levels for creating kyc'].levels[3].itemNameId,
                        conditionId: RANDOMCONDITIONID,
                        attributeId: context['list kyc attributes'].kycAttributes[0].itemNameId
                    };
                }, KYCDESCRIPTION + 2),
                commonFunc.createStep('customer.kyc.get', 'get kyc', (context) => {
                    return {
                        kycId: context['add kyc 1'].kyc[0].kycId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetKyc(result).error, null, 'return all details for kyc');
                }),
                customerMethods.deleteKyc('delete one kyc', context => [context['add kyc 1'].kyc[0].kycId]),
                commonFunc.createStep('customer.kyc.get', 'get kyc', (context) => {
                    return {
                        kycId: context['add kyc 1'].kyc[0].kycId
                    };
                }, (result, assert) => {
                    assert.same(result.kyc, [], 'return empty resultset');
                }),
                customerMethods.deleteKyc('delete two kycs', context => [context['add kyc 2'].kyc[0].kycId, context['add kyc 3'].kyc[0].kycId]),
                commonFunc.createStep('customer.kyc.get', 'get kyc', (context) => {
                    return {
                        kycId: context['add kyc 2'].kyc[0].kycId
                    };
                }, (result, assert) => {
                    assert.same(result.kyc, [], 'return empty resultset');
                }),
                commonFunc.createStep('customer.kyc.get', 'get kyc', (context) => {
                    return {
                        kycId: context['add kyc 3'].kyc[0].kycId
                    };
                }, (result, assert) => {
                    assert.same(result.kyc, [], 'return empty resultset');
                }),
                // NEGATIVE SCENARIOS
                commonFunc.createStep('customer.kyc.delete', 'unsuccessfully delete kyc - null kycId', context => customerParams.deleteKycParams(context, (context) => [null]
                ), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.delete', 'unsuccessfully delete kyc - null', context => customerParams.deleteKycParams(context, (context) => null
                ), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.delete', 'unsuccessfully delete kyc - string kycId', context => customerParams.deleteKycParams(context, (context) => [TEXTINPUT]
                ), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.delete', 'unsuccessfully delete kyc - empty string kycId', context => customerParams.deleteKycParams(context, (context) => ['']
                ), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // MISSING PERMISSIONS
                userMethods.logout('logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('successful login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.kyc.delete', 'unsuccessfully delete kyc - missing permission', context => customerParams.deleteKycParams(context, (context) => [context['add kyc 1'].kyc[0].kycId]
                ), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERKYCDELETE) > -1, 'Missing permissions for ' + CUSTOMERKYCDELETE);
                }),
                userMethods.logout('successfully logout new user', (context) => context['successful login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
