const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userConstants = require('ut-test/lib/constants/user').constants();
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const customerMethods = require('ut-test/lib/methods/customer');
const customerParams = require('ut-test/lib/requestParams/customer');
const USERNAME = 'delOrg' + userConstants.USERNAME;
const ROLENAME = userConstants.ROLENAME;
const ROLEDESCRIPTION = userConstants.ROLEDESCRIPTION;
const ORGNAME = customerConstants.ORGNAME;
const CUSTOMERORGANIZATIONREMOVE = 'customer.organization.delete';
const ERRORCANNOTREMOVEORGANIZATION = 'customer.organizationInvalidStatus';
const ERRORCANNOTDELETEORGANIZATIONWITHROLES = 'customer.cannotDeleteHasRoles';
const ERRORCANNOTDELETEORGANIZATIONWITHORGANIZATIONS = 'customer.cannotDeleteHasOrganizations';
const ERRORCANNOTDELETEORGANIZATIONWITHUSERS = 'customer.cannotDeleteHasUsers';
const ERRORDISABLEDORDELETEDORGANIZATION = 'user.disabledOrDeletedOrganization';
const STATUSPENDING = customerConstants.STATUSIDPENDING;
const STATUSAPPROVED = customerConstants.STATUSIDAPPROVED;
const REJECTREASON = 'rejected BU';
let stdPolicy;

module.exports = function test() {
    return {
        deleteOrganization: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                // fetch std input policy
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                customerMethods.addOrganization('add first organization successfully', context => {
                    return {};
                }, ORGNAME + 1),
                customerMethods.addOrganization('add second organization - member of sa organization', context => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, ORGNAME),
                customerMethods.approveOrganization('approve add second organization - member of sa organization', (context) => context['add second organization - member of sa organization']['organization.info'][0].actorId),
                customerMethods.addOrganization('add third organization - member of sa organization', context => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, ORGNAME + 3),
                customerMethods.approveOrganization('approve add third organization - member of sa organization', (context) => context['add third organization - member of sa organization']['organization.info'][0].actorId),
                userMethods.addUser('add second user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME + 1),
                userMethods.approveUser('approve second user', context => context['add second user'].person.actorId),
                // Negative: Remove new unapproved organization
                commonFunc.createStep('customer.organization.delete', 'remove first organizations - new unapproved',
                    (context) => customerParams.removeOrganizationParams(context, context => [context['add first organization successfully']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                        assert.equals(error.type, ERRORCANNOTREMOVEORGANIZATION, 'cannot delete new unapproved organization');
                    }),
                // Negative: Remove one new and one approved organization at the same time
                commonFunc.createStep('customer.organization.delete', 'remove first(new) and second(approved) organizations',
                    (context) => customerParams.removeOrganizationParams(context, context => [context['add first organization successfully']['organization.info'][0].actorId, context['add second organization - member of sa organization']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                        assert.equals(error.type, ERRORCANNOTREMOVEORGANIZATION, 'cannot delete new unapproved organization');
                    }),
                // Remove two approved arganizations at the same time
                customerMethods.removeOrganization('remove second and third organizations', context => [context['add second organization - member of sa organization']['organization.info'][0].actorId, context['add third organization - member of sa organization']['organization.info'][0].actorId]),
                customerMethods.approveOrganization('approve removal of second organization', (context) => context['add second organization - member of sa organization']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.delete', 'unsuccessfully remove second organization after being approved for removal', (context) => customerParams.removeOrganizationParams(context, context => [context['add second organization - member of sa organization']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                    // console.log(error);
                        assert.equals(error.type, ERRORDISABLEDORDELETEDORGANIZATION, 'cannot delete already approved for removal organization');
                    }),
                // Organization with asigned roles
                customerMethods.addOrganization('add fourth organization - member of sa organization', context => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, ORGNAME + 4),
                customerMethods.approveOrganization('approve add fourth organization - member of sa organization', (context) => context['add fourth organization - member of sa organization']['organization.info'][0].actorId),
                userMethods.addRole('add role', (context) => {
                    return {
                        visibleFor: [context['add fourth organization - member of sa organization']['organization.info'][0].actorId],
                        policyId: stdPolicy
                    };
                }, ROLENAME, ROLEDESCRIPTION),
                userMethods.approveRole('approve role', context => context['add role'].role[0].actorId),
                commonFunc.createStep('customer.organization.delete', 'remove fourth organization',
                    (context) => customerParams.removeOrganizationParams(context, context => [context['add fourth organization - member of sa organization']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                        assert.equals(error.type, ERRORCANNOTDELETEORGANIZATIONWITHROLES, 'cannot delete org that has role');
                    }),
                userMethods.deleteRole('delete role', (context) => [context['add role'].role[0].actorId]),
                userMethods.approveRole('approve role delete', context => context['add role'].role[0].actorId),
                customerMethods.removeOrganization('remove fourth organization', context => [context['add fourth organization - member of sa organization']['organization.info'][0].actorId]),
                // Organization with child organization scenarios
                customerMethods.addOrganization('add fifth organization - member of sa organization', context => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, ORGNAME + 5),
                customerMethods.approveOrganization('approve add fifth organization - member of sa organization', (context) => context['add fifth organization - member of sa organization']['organization.info'][0].actorId),
                customerMethods.addOrganization('add sixth organization - member of fifth organization', context => {
                    return {
                        parent: [context['add fifth organization - member of sa organization']['organization.info'][0].actorId]
                    };
                }, ORGNAME + 6),
                customerMethods.approveOrganization('approve add sixth organization - member of fifth organization', (context) => context['add sixth organization - member of fifth organization']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.delete', 'remove fifth organization',
                    (context) => customerParams.removeOrganizationParams(context, context => [context['add fifth organization - member of sa organization']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                        assert.equals(error.type, ERRORCANNOTDELETEORGANIZATIONWITHORGANIZATIONS, 'cannot delete org that is parent of other organizations');
                    }),
                commonFunc.createStep('customer.organization.fetch', 'Fetch organization successfully - with branch and parent', (context) => {
                    return {
                        businessUnitId: context['add fifth organization - member of sa organization']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.same(result.organization[0].organizationName, ORGNAME + 6, 'return child organization');
                    assert.equals(result.parent[0].organizationName, ORGNAME + 5, 'return fetched organization name');
                }),
                customerMethods.removeOrganization('remove sixth organization - child of fifth', context => [context['add sixth organization - member of fifth organization']['organization.info'][0].actorId]),
                customerMethods.approveOrganization('approve remove sixth organization', (context) => context['add sixth organization - member of fifth organization']['organization.info'][0].actorId),
                customerMethods.removeOrganization('remove fifth organization', context => [context['add fifth organization - member of sa organization']['organization.info'][0].actorId]),
                // Scenario remove - reject - discard - remove - approve
                commonFunc.createStep('customer.organization.get', 'get pending for remove fifth organization', (context) => {
                    return {
                        actorId: context['add fifth organization - member of sa organization']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result['organization.info'][0].statusId, STATUSPENDING, 'return status ' + STATUSPENDING);
                    assert.equals(result['organization.infoUnapproved'][0].isDeleted, true, 'return isDeleted true in infoUnapproved');
                    assert.equals(result['organization.info'][0].isDeleted, false, 'return isDeleted false in info');
                }),
                commonFunc.createStep('customer.organization.fetch', 'Fetch pending for delete organization successfully - BU id', (context) => {
                    return {
                        businessUnitId: context['add fifth organization - member of sa organization']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.same(result.organization, [], 'return empty resultset for organization - the org has no child organizations');
                    assert.equals(result.parent[0].organizationName, ORGNAME + 5, 'return fetched organization name');
                }),
                customerMethods.rejectOrganization('reject removal of fifth organization', (context) => context['add fifth organization - member of sa organization']['organization.info'][0].actorId, REJECTREASON),
                customerMethods.discardOrganization('discard removal of fifth organization', (context) => context['add fifth organization - member of sa organization']['organization.info'][0].actorId),
                customerMethods.removeOrganization('remove fifth organization', context => [context['add fifth organization - member of sa organization']['organization.info'][0].actorId]),
                customerMethods.approveOrganization('approve remove fifth organization', (context) => context['add fifth organization - member of sa organization']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get approved for removal fifth organization', (context) => {
                    return {
                        actorId: context['add fifth organization - member of sa organization']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result['organization.info'][0].statusId, STATUSAPPROVED, 'return status ' + STATUSAPPROVED);
                    assert.equals(result['organization.info'][0].isDeleted, true, 'return isDeleted true');
                }),
                commonFunc.createStep('customer.organization.fetch', 'unsuccessfully fetch approved for delete organization successfully - BU id', (context) => {
                    return {
                        businessUnitId: context['add fifth organization - member of sa organization']['organization.info'][0].actorId
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, userConstants.USERSECURITYVIOLATION, 'cannot fetch deleted BU');
                }),
                // Organization with asigned users
                customerMethods.addOrganization('add organization 7', context => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, ORGNAME + 5),
                customerMethods.approveOrganization('approve add organization 7', (context) => context['add organization 7']['organization.info'][0].actorId),
                userMethods.addUser('add new user assigned to organization', context => {
                    return {
                        object: context['add organization 7']['organization.info'][0].actorId,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['add organization 7']['organization.info'][0].actorId
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user assigned to organization'].person.actorId),
                commonFunc.createStep('customer.organization.delete', 'remove organization 7', (context) => customerParams.removeOrganizationParams(context, context => [context['add organization 7']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                        assert.equals(error.type, ERRORCANNOTDELETEORGANIZATIONWITHUSERS, 'cannot delete org that has assigned users');
                    }),
                userMethods.deleteUser('delete user', (context) => [context['add new user assigned to organization'].person.actorId]),
                userMethods.approveUser('approve user delete', context => context['add new user assigned to organization'].person.actorId),
                customerMethods.removeOrganization('remove organization 7 after removing the assinged user', context => [context['add organization 7']['organization.info'][0].actorId]),
                /**
                 * NEGATIVE SCENARIOS
                 */
                commonFunc.createStep('customer.organization.delete', 'remove organization - array with empty string actorId',
                    (context) => customerParams.removeOrganizationParams(context, context => ['']), null,
                    (error, assert) => {
                        assert.equals(error.type, 'PortHTTP', 'return joi failure');
                    }),
                commonFunc.createStep('customer.organization.delete', 'remove organization - empty string actorId',
                    (context) => customerParams.removeOrganizationParams(context, context => ''), null,
                    (error, assert) => {
                        assert.equals(error.type, 'PortHTTP', 'return joi failure');
                    }),
                commonFunc.createStep('customer.organization.delete', 'remove organization - null actorId',
                    (context) => customerParams.removeOrganizationParams(context, context => [null]), null,
                    (error, assert) => {
                        assert.equals(error.type, 'PortHTTP', 'return joi failure');
                    }),
                commonFunc.createStep('customer.organization.delete', 'remove organization - no params', (context) => {
                    return {};
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi validation');
                }),
                userMethods.logout('logout admin user', context => context.login['identity.check'].sessionId),
                /**
                 * MISSING PERMISSION
                 */
                userMethods.login('Login new user', USERNAME + 1, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.delete', 'remove organization - no rights',
                    (context) => customerParams.removeOrganizationParams(context, context => [context['add second organization - member of sa organization']['organization.info'][0].actorId]), null,
                    (error, assert) => {
                        assert.true(error.message.indexOf(CUSTOMERORGANIZATIONREMOVE) > -1, 'Missing Pemissions for ' + CUSTOMERORGANIZATIONREMOVE);
                    }),
                userMethods.logout('Logout new user', context => context['Login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
