const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const documentJoiValidation = require('ut-test/lib/joiValidations/document');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const documentConstants = require('ut-test/lib/constants/document').constants();
const userMethods = require('ut-test/lib/methods/user');
const customerMethods = require('ut-test/lib/methods/customer');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const CUSTOMERCUSTOMEREDIT = 'customer.customer.edit';
const PORTSQL = 'portSQL';
const PORTHTTP = 'PortHTTP';
const TEST1 = 'test1';
const USERNAME = 'editCust' + userConstants.USERNAME;
const DOCUMENTNUMBER = commonFunc.generateRandomNumber().toString().substring(0, 15);
const DOCUMENTNUMBER2 = commonFunc.generateRandomNumber().toString().substring(0, 15);
const DOCUMENTNUMBER3 = commonFunc.generateRandomNumber().toString().substring(0, 15);
let stdPolicy, organizationId, customerTypeId;

module.exports = function test() {
    return {
        editCustomer: function(test, bus, run) {
            return run(test, bus, [
                userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', context => context.login['identity.check'].actorId),
                // fetch std input policy
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                // fetch organizations
                commonFunc.createStep('customer.organization.graphFetch', 'fetch child organizations of sa organization', (context) => {
                    return {
                        parentFilter: context['get admin details'].memberOF[0].object
                    };
                }, (result, assert) => {
                    organizationId = result.organization[0].id;
                    assert.equals(customerJoiValidation.validateFetchOrganizationGraph(result.organization).error, null, 'return organization graph fetch details');
                }),
                customerMethods.addCustomer('Add customer successfully', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object,
                        documentId: customerConstants.NEWDOCUMENTID,
                        documentNumber: DOCUMENTNUMBER
                    };
                }),
                commonFunc.createStep('customer.customer.get', 'Get the newly created customer', context => {
                    return {
                        actorId: context['Add customer successfully'].customer.actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer, customerConstants.CUSTOMERTYPEID).error, null, 'return customer details');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                /** customer */
                commonFunc.createStep('customer.customer.edit', 'edit customer - customer details updated - all params', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        customer: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            stateId: customerConstants.STATEIDUPTODATE,
                            statusId: customerConstants.STATUSIDAPPROVED,
                            organizationId: context['fetch child organizations of sa organization'].organization[0].id,
                            customerTypeId: context['Get the newly created customer'].customer.customerTypeId
                        },
                        document: [{
                            documentId: context['Get the newly created customer'].document[0].documentId,
                            documentTypeId: context['Get the newly created customer'].document[0].documentTypeId,
                            statusId: context['Get the newly created customer'].document[0].statusId,
                            expirationDate: context['Get the newly created customer'].document[0].expirationDate,
                            documentNumber: context['Get the newly created customer'].document[0].documentNumber
                        }],
                        actorDocument: [{
                            actorId: context['Get the newly created customer'].person.actorId,
                            documentId: context['Get the newly created customer'].document[0].documentId
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer, customerConstants.CUSTOMERTYPEID).error, null, 'return customer details');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                    assert.equals(result.customer.organizationId, organizationId, 'return updated organizationId');
                    assert.equals(result.customer.stateId, customerConstants.STATEIDUPTODATE, 'return updated stateID');
                    assert.equals(result.customer.statusId, customerConstants.STATUSIDAPPROVED, 'return updated statusId');
                }),
                /** document */
                commonFunc.createStep('customer.customer.edit', 'edit customer - add second document (without documentOrder)', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE,
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER2
                        }, {
                            documentId: context['edit customer - customer details updated - all params'].document[0].documentId,
                            documentTypeId: context['edit customer - customer details updated - all params'].document[0].documentTypeId,
                            statusId: context['edit customer - customer details updated - all params'].document[0].statusId,
                            expirationDate: context['edit customer - customer details updated - all params'].document[0].expirationDate,
                            documentNumber: context['edit customer - customer details updated - all params'].document[0].documentNumber
                        }],
                        actorDocument: [{
                            actorId: context['Get the newly created customer'].person.actorId,
                            documentId: '-1'
                        }, {
                            actorId: context['Get the newly created customer'].person.actorId,
                            documentId: context['edit customer - customer details updated - all params'].document[0].documentId
                        }],
                        attachment: [{
                            documentId: '-1',
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 1
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer, customerConstants.CUSTOMERTYPEID).error, null, 'return customer details');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                    assert.equals(documentJoiValidation.validateGetDocument(result.document).error, null, 'return document details');
                    assert.equals(documentJoiValidation.validateGetAttachment(result.attachment).error, null, 'return attachment details');
                }),
                commonFunc.createStep('customer.customer.get', 'get editted customer - second document (without documentOrder)', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId
                    };
                }, (result, assert) => {
                    assert.true(result.document.find(document => document.documentTypeId === documentConstants.DOCUMENTTYPEIDPASSPORT), 'return correct documentTypeId');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - add document - third document (with documentOrder)', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER3
                        }, {
                            documentId: context['edit customer - add second document (without documentOrder)'].document[0].documentId,
                            documentTypeId: context['edit customer - add second document (without documentOrder)'].document[0].documentTypeId,
                            statusId: context['edit customer - add second document (without documentOrder)'].document[0].statusId,
                            expirationDate: context['edit customer - add second document (without documentOrder)'].document[0].expirationDate,
                            documentNumber: context['edit customer - add second document (without documentOrder)'].document[0].documentNumber
                        }, {
                            documentId: context['edit customer - add second document (without documentOrder)'].document[1].documentId,
                            documentTypeId: context['edit customer - add second document (without documentOrder)'].document[1].documentTypeId,
                            statusId: context['edit customer - add second document (without documentOrder)'].document[1].statusId,
                            expirationDate: context['edit customer - add second document (without documentOrder)'].document[1].expirationDate,
                            documentNumber: context['edit customer - add second document (without documentOrder)'].document[1].documentNumber
                        }],
                        actorDocument: [{
                            actorId: context['Get the newly created customer'].person.actorId,
                            documentId: '-1',
                            documentOrder: 2
                        }, {
                            actorId: context['Get the newly created customer'].person.actorId,
                            documentId: context['edit customer - add second document (without documentOrder)'].document[0].documentId,
                            documentOrder: 1
                        }, {
                            actorId: context['Get the newly created customer'].person.actorId,
                            documentId: context['edit customer - add second document (without documentOrder)'].document[1].documentId,
                            documentOrder: 1
                        }],
                        attachment: [{
                            documentId: '-1',
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 2
                        }, {
                            documentId: context['edit customer - add second document (without documentOrder)'].attachment[0].documentId,
                            attachmentUnapprovedId: context['edit customer - add second document (without documentOrder)'].attachment[0].attachmentUnapprovedId,
                            attachmentSizeId: context['edit customer - add second document (without documentOrder)'].attachment[0].attachmentSizeId,
                            content: documentConstants.CONTENT,
                            contentEncoding: context['edit customer - add second document (without documentOrder)'].attachment[0].contentEncoding,
                            contentType: context['edit customer - add second document (without documentOrder)'].attachment[0].contentType,
                            extension: context['edit customer - add second document (without documentOrder)'].attachment[0].extension,
                            page: context['edit customer - add second document (without documentOrder)'].attachment[0].page
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer, customerConstants.CUSTOMERTYPEID).error, null, 'return customer details');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                    assert.equals(documentJoiValidation.validateGetDocument(result.document).error, null, 'return document details');
                    assert.equals(documentJoiValidation.validateGetAttachment(result.attachment).error, null, 'return attachment details');
                }),
                commonFunc.createStep('customer.customer.get', 'get editted customer - third document (with documentOrder)', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId
                    };
                }, (result, assert) => {
                    // assert.true(result.primaryDocument.length > 0, 'return ')
                    assert.true(result.document.filter(document => document.documentTypeId === documentConstants.DOCUMENTTYPEIDPASSPORT).length === 2, 'return two documents');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }), // TODO change the documentOrder, remove one of the documents, also add negative scenarios for the objects - 'document' and 'attachment'
                /** NEGATIVE - customer stuff */
                commonFunc.createStep('customer.customer.edit', 'edit customer - customer details, empty params', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        customer: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            organizationId: '',
                            stateId: '',
                            statusId: '',
                            customerTypeId: '',
                            customerNumber: ''
                        },
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME + 'A',
                            middleName: customerConstants.FIRSTNAME + 'B',
                            lastName: customerConstants.LASTNAME + 'C'
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - customer details, null params', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        customer: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            organizationId: null,
                            stateId: null,
                            statusId: null,
                            customerTypeId: null,
                            customerNumber: null
                        },
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME + 'A',
                            middleName: customerConstants.FIRSTNAME + 'B',
                            lastName: customerConstants.LASTNAME + 'C'
                        }
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME + 'A').error, null, 'return person details');
                // }, null, (error, assert) => {
                //     assert.equals(error.type, 'PortHTTP', 'return PortHTTP');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - customer details, missing actorId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        customer: {
                            // actorId: context['Get the newly created customer'].person.actorId,
                            organizationId: context['fetch child organizations of sa organization'].organization[1].id,
                            stateId: customerConstants.STATEIDUPTODATE,
                            statusId: customerConstants.STATUSIDAPPROVED
                        },
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME + 'A',
                            middleName: customerConstants.FIRSTNAME + 'B',
                            lastName: customerConstants.LASTNAME + 'C'
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - customer details, empty actorId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        customer: {
                            actorId: '',
                            organizationId: context['fetch child organizations of sa organization'].organization[1].id,
                            stateId: customerConstants.STATEIDUPTODATE,
                            statusId: customerConstants.STATUSIDAPPROVED
                        },
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME + 'A',
                            middleName: customerConstants.FIRSTNAME + 'B',
                            lastName: customerConstants.LASTNAME + 'C'
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - customer details, null actorId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        customer: {
                            actorId: null,
                            organizationId: context['fetch child organizations of sa organization'].organization[1].id,
                            stateId: customerConstants.STATEIDUPTODATE,
                            statusId: customerConstants.STATUSIDAPPROVED
                        },
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME + 'A',
                            middleName: customerConstants.FIRSTNAME + 'B',
                            lastName: customerConstants.LASTNAME + 'C'
                        }
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation');
                }),
                /** NEGATIVE DOCUMENT SCENARIOS */
                commonFunc.createStep('customer.customer.edit', 'edit customer - actorDocument missing actorDocument', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER
                        }],
                        attachment: [{
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTSQL, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - actorDocument missing actorId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER
                        }],
                        actorDocument: [{
                            documentId: '-1'
                        }],
                        attachment: [{
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTSQL, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - actorDocument missing documentId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER
                        }],
                        actorDocument: [{
                            actorId: context['Get the newly created customer'].person.actorId
                        }],
                        attachment: [{
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTSQL, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - actorDocument invalid number actorId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER
                        }],
                        actorDocument: [{
                            actorId: 0,
                            documentId: '-1'
                        }],
                        attachment: [{
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTSQL, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - actorDocument empty string actorId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER
                        }],
                        actorDocument: [{
                            actorId: '',
                            documentId: '-1'
                        }],
                        attachment: [{
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation - actorId must be a number');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - actorDocument string actorId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER
                        }],
                        actorDocument: [{
                            actorId: TEST1,
                            documentId: '-1'
                        }],
                        attachment: [{
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation - actorId must be a number');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - actorDocument null actorId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER
                        }],
                        actorDocument: [{
                            actorId: null,
                            documentId: '-1'
                        }],
                        attachment: [{
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation - actorId must be a number');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - actorDocument invalid number documentId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER
                        }],
                        actorDocument: [{
                            actorId: context['Get the newly created customer'].person.actorId,
                            documentId: 0
                        }],
                        attachment: [{
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTSQL, 'return joi validation');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - actorDocument empty string documentId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER
                        }],
                        actorDocument: [{
                            actorId: context['Get the newly created customer'].person.actorId,
                            documentId: ''
                        }],
                        attachment: [{
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation - documentId must be a number');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - actorDocument string documentId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER
                        }],
                        actorDocument: [{
                            actorId: context['Get the newly created customer'].person.actorId,
                            documentId: TEST1
                        }],
                        attachment: [{
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation - documentId must be a number');
                }),
                commonFunc.createStep('customer.customer.edit', 'edit customer - actorDocument null documentId', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        document: [{
                            documentId: '-1',
                            documentTypeId: documentConstants.DOCUMENTTYPEIDPASSPORT,
                            statusId: customerConstants.STATUSIDACTIVE, // documentStatusId, not statusId
                            expirationDate: documentConstants.EXPIRATIONDATE,
                            documentNumber: DOCUMENTNUMBER
                        }],
                        actorDocument: [{
                            actorId: context['Get the newly created customer'].person.actorId,
                            documentId: null,
                            documentOrder: 1
                        }],
                        attachment: [{
                            attachmentSizeId: documentConstants.ATTACHMENTSIZE,
                            content: documentConstants.CONTENT,
                            contentEncoding: documentConstants.BASE64ENCODING,
                            contentType: documentConstants.CONTENTTYPE,
                            extension: documentConstants.EXTENSIONJPG,
                            page: 1
                        }]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return joi validation - documentId must be a number');
                }),
                /*
                commonFunc.createStep('customer.customer.edit', 'edit customer - missing document', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME,
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME
                        },
                        actorDocument: [{
                            actorId: context['Get the newly created customer'].person.actorId,
                            documentId: '-1'
                        }],
                        attachment: [{
                            documentId: context['get editted customer - third document (with documentOrder)'].attachment[0].documentId,
                            attachmentUnapprovedId: context['get editted customer - third document (with documentOrder)'].attachment[0].attachmentUnapprovedId,
                            attachmentSizeId: context['get editted customer - third document (with documentOrder)'].attachment[0].attachmentSizeId,
                            content: documentConstants.CONTENT,
                            contentEncoding: context['get editted customer - third document (with documentOrder)'].attachment[0].contentEncoding,
                            contentType: context['get editted customer - third document (with documentOrder)'].attachment[0].contentType,
                            extension: context['get editted customer - third document (with documentOrder)'].attachment[0].extension,
                            page: context['get editted customer - third document (with documentOrder)'].attachment[0].page
                        }]
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetCustomer(result.customer, customerConstants.CUSTOMERTYPEID).error, null, 'return customer details');
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'return person details');
                }), // TODO add negative scenarios for Document and attachment
                */
                /**
                 * MISSING PERMISSIONS
                 */
                userMethods.logout('Logout admin user', context => context.login['identity.check'].sessionId),
                userMethods.login('Login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.customer.edit', 'edit customer - person details updated', (context) => {
                    return {
                        actorId: context['Get the newly created customer'].person.actorId,
                        person: {
                            actorId: context['Get the newly created customer'].person.actorId,
                            firstName: customerConstants.FIRSTNAME + 'updated',
                            middleName: customerConstants.FIRSTNAME + 'MN',
                            lastName: customerConstants.LASTNAME + 'updated'
                        }
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERCUSTOMEREDIT) > -1, 'Missing permissions for ' + CUSTOMERCUSTOMEREDIT);
                }),
                userMethods.logout('Logout new user', context => context['Login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
