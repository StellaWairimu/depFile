const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerMethods = require('ut-test/lib/methods/customer');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const userConstants = require('ut-test/lib/constants/user').constants();
const USERNAME = 'delRef' + userConstants.USERNAME;
const PORTHTTPERROR = 'PortHTTP';
const PERMISSION = 'customer.referral.delete';
const NONEXISTINGREFID = 999999; // customerConstants.PHONENUMBER.slice(6);
const REJECTNEWREFERRAL = 'newReferralReject';
let stdPolicy, customerTypeId, newRefStatusId;

module.exports = function test() {
    return {
        deleteReferral: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', (context) => context.login['identity.check'].actorId),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                commonFunc.createStep('customerTest.customer.mChStatusChange', 'disable maker checker of customers', (context) => {
                    return {
                        isMCHDisabled: 1
                    };
                }, (result, assert) => {
                    assert.equals(typeof result, 'object', 'return object');
                }),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeId = result.customerType[0].customerTypeId;
                }),
                commonFunc.createStep('customer.referral.statusFetch', 'fetch referral statuses', (context) => {
                    return {};
                }, (result, assert) => {
                    const newRefStatus = result.referralStatus.find((status) => (status.code).toString().toLowerCase().indexOf('referralNew'.toLowerCase()) > -1);
                    newRefStatusId = newRefStatus.referralStatusId;
                }),
                customerMethods.addCustomer('Add customer successfully', context => {
                    return {
                        customerTypeId: customerTypeId,
                        organizationId: context['get admin details'].memberOF[0].object
                    };
                }),
                customerMethods.getCustomer('Get the newly created customer', context => context['Add customer successfully'].customer.actorId),
                customerMethods.addReferral('add referral to just added customer', (context) => {
                    return {
                        referralSource: context['Get the newly created customer'].customer.actorId,
                        MSISDN: customerConstants.NEWPHONENUMBER + 8,
                        referralStatusId: newRefStatusId
                    };
                }),
                customerMethods.addReferral('add referral 2 to just added customer', (context) => {
                    return {
                        referralSource: context['Get the newly created customer'].customer.actorId,
                        MSISDN: customerConstants.NEWPHONENUMBER + 2,
                        referralStatusId: newRefStatusId
                    };
                }),
                commonFunc.createStep('customer.referral.statusUpdate', 'update referral 2 status - reject new', (context) => {
                    return {
                        referralId: context['add referral 2 to just added customer'].referral[0].referralId,
                        actionName: REJECTNEWREFERRAL
                    };
                }, (result, assert) => {
                    assert.same(result, [], 'return empty resultset after update referral status - reject new');
                }),
                customerMethods.deleteReferral('delete referral successfully', (context) => context['add referral to just added customer'].referral[0].referralId),
                customerMethods.deleteReferral('delete referral 2 - rejected - successfully', (context) => context['add referral 2 to just added customer'].referral[0].referralId),
                commonFunc.createStep('customer.referral.get', 'get deleted referral', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId
                    };
                }, (result, assert) => {
                    assert.same(result.referral, [], 'return empty resultset after delete referral');
                }),
                // negative
                commonFunc.createStep('customer.referral.delete', 'delete referral - no params', (context) => {
                    return { };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTPERROR, 'return PortHTTP');
                }),
                commonFunc.createStep('customer.referral.delete', 'delete referral - empty params', (context) => {
                    return {
                        referralId: ''
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTPERROR, 'return PortHTTP');
                }),
                commonFunc.createStep('customer.referral.delete', 'delete referral - null params', (context) => {
                    return {
                        referralId: null
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTPERROR, 'return PortHTTP');
                }),
                commonFunc.createStep('customer.referral.delete', 'delete referral - nonexisting', (context) => {
                    return {
                        referralId: NONEXISTINGREFID
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.referralDeleteNotAllowed', 'return Could not delete the referral');
                }),
                // MISSING PERMISSIONS
                userMethods.logout('logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('successful login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.referral.delete', 'delete referral - no permissions', (context) => {
                    return {
                        referralId: context['add referral to just added customer'].referral[0].referralId
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(PERMISSION) > -1, 'Missing permissions for ' + PERMISSION);
                }),
                userMethods.logout('successfully logout new user', (context) => context['successful login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
