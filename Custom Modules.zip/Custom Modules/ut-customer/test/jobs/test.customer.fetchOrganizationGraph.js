const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const customerMethods = require('ut-test/lib/methods/customer');
const USERNAME = 'fetchOrgGrapth' + userConstants.USERNAME;
const ORGNAME = customerConstants.ORGNAME;
const CHILDORGNAME = 'Child' + customerConstants.ORGNAME;
const WRONGACTORID = '9999999bc';
const PORTHTTP = 'PortHTTP';
const PHONENUMBER = (customerConstants.PHONENUMBER).slice(-6);
const CUSTOMERORGANIZATIONGRAPHFETCH = 'customer.organization.graphFetch';
let topOrgId, orgId, orgId2, childOrgId, childOrgId2, topOrgName, stdPolicy;

module.exports = function test() {
    return {
        fetchOrganizationGraph: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('user.user.get', 'get admin details', (context) => {
                    return {
                        actorId: context.login['identity.check'].actorId
                    };
                },
                (result, assert) => {
                    topOrgId = result.memberOF[0].object;
                    topOrgName = result.memberOF[0].organizationName;
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, userConstants.ADMINFIRSTNAME).error, null, 'return person');
                }),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                userMethods.addRole('add role successfully', context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                // add org 1 - member of top Org
                commonFunc.createStep('customer.organization.add', 'add organization successfully', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME,
                            isEnabled: 1,
                            isDeleted: 0
                        },
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, (result, assert) => {
                    orgId = result['organization.info'][0].actorId;
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME, 'return organizationName');
                    assert.equals(result['organization.parents'][0].actorId, topOrgId, 'Return correct actorId of parent organization');
                    assert.equals(result['organization.parents'][0].organizationName, topOrgName, 'Return correct actorId of parent organization');
                }),
                customerMethods.approveOrganization('approve organization successfully', (context) => context['add organization successfully']['organization.info'][0].actorId),
                // add org 2 - member of top Org
                commonFunc.createStep('customer.organization.add', 'add organization 2 successfully', (context) => {
                    return {
                        organization: {
                            organizationName: ORGNAME + 2,
                            isEnabled: 1,
                            isDeleted: 0
                        },
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, (result, assert) => {
                    orgId2 = result['organization.info'][0].actorId;
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME + 2, 'return organizationName');
                    assert.equals(result['organization.parents'][0].actorId, topOrgId, 'Return correct actorId of parent organization');
                    assert.equals(result['organization.parents'][0].organizationName, topOrgName, 'Return correct actorId of parent organization');
                }),
                customerMethods.approveOrganization('approve organization 2 successfully', (context) => context['add organization 2 successfully']['organization.info'][0].actorId),
                // add child org 1 - member of Org 1
                commonFunc.createStep('customer.organization.add', 'add child organization', (context) => {
                    return {
                        organization: {
                            organizationName: CHILDORGNAME,
                            isEnabled: 1,
                            isDeleted: 0
                        },
                        parent: [context['add organization successfully']['organization.info'][0].actorId]
                    };
                }, (result, assert) => {
                    childOrgId = result['organization.info'][0].actorId;
                    // console.log(childOrgId);
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, CHILDORGNAME, 'return organizationName');
                    assert.equals(result['organization.parents'][0].actorId, orgId, 'Return correct actorId of parent organization');
                    assert.equals(result['organization.parents'][0].organizationName, ORGNAME, 'Return correct actorId of parent organization');
                }),
                customerMethods.approveOrganization('approve child organization', (context) => context['add child organization']['organization.info'][0].actorId),
                // add child org 2 - member of org 1 & SA = should return error!!!
                commonFunc.createStep('customer.organization.add', 'add child organization 2 - member of 2 orgs', (context) => {
                    return {
                        organization: {
                            organizationName: CHILDORGNAME + 2,
                            isEnabled: 1,
                            isDeleted: 0
                        },
                        parent: [context['add organization successfully']['organization.info'][0].actorId, context['get admin details'].memberOF[0].object]
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.recursion', 'return customer.recursion');
                }),
                // add child org 2 - member of 2 orgs
                commonFunc.createStep('customer.organization.add', 'add child organization 2 - member of 2 orgs', (context) => {
                    return {
                        organization: {
                            organizationName: CHILDORGNAME + 2,
                            isEnabled: 1,
                            isDeleted: 0
                        },
                        parent: [context['add organization successfully']['organization.info'][0].actorId, context['add organization 2 successfully']['organization.info'][0].actorId]
                    };
                }, (result, assert) => {
                    childOrgId2 = result['organization.info'][0].actorId;
                    // console.log(childOrgId2);
                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                    assert.equals(result['organization.info'][0].organizationName, CHILDORGNAME + 2, 'return organizationName');
                }),
                customerMethods.approveOrganization('approve child organization 2', (context) => context['add child organization 2 - member of 2 orgs']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.graphFetch', 'should return all BUs related to logged user (sa)', (context) => {
                    return {};
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganizationGraph(result.organization).error, null, 'Return all details after organization graph fetch');
                    const arr = result.organization;
                    const countOrgId = arr.filter((x) => { return x.id === orgId; }).length;
                    const countOrgId2 = arr.filter((x) => { return x.id === orgId2; }).length;
                    const countChildOrgId = arr.filter((x) => { return x.id === childOrgId; }).length;
                    const countChildOrgId2 = arr.filter((x) => { return x.id === childOrgId2; }).length;
                    assert.true(arr.findIndex(
                        (arr) => arr.id === topOrgId
                    ) > -1, 'Top organization in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === orgId
                    ) > -1, 'Organization 1 in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === orgId2
                    ) > -1, 'Organization 2 in the result list');
                    assert.true(arr.some(
                        (arr) => arr.parents === topOrgId
                    ), 'There are child organizations - member of Top Organization in the list');
                    assert.true(arr.some(
                        (arr) => arr.parents === orgId
                    ), 'There is at least one child organization - member of Organization 1 in the list');
                    assert.true(arr.some(
                        (arr) => arr.parents === orgId2
                    ), 'There is at least one child organization - member of Organization 2 in the list');
                    // assert counts
                    assert.true(countOrgId === 1, 'return only 1 result for organization 1 in the list - has 1 parent');
                    assert.true(countOrgId2 === 1, 'return only 1 result for organization 2 in the list - has 1 parent');
                    assert.true(countChildOrgId === 1, 'return only 1 result for child organization 1 in the list - has 1 parent');
                    assert.true(countChildOrgId2 === 2, 'return only 2 results for child organization 2 in the list - has 2 parents');
                }),
                commonFunc.createStep('customer.organization.graphFetch', 'should return all BUs member of SA user organization', (context) => {
                    return {
                        parentFilter: context['get admin details'].memberOF[0].object
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganizationGraph(result.organization).error, null, 'Return all details after organization graph fetch');
                    const arr = result.organization;
                    const countOrgId = arr.filter((x) => { return x.id === orgId; }).length;
                    const countOrgId2 = arr.filter((x) => { return x.id === orgId2; }).length;
                    assert.true(arr.findIndex(
                        (arr) => arr.id === topOrgId
                    ) === -1, 'Top Organization not in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === orgId
                    ) > -1, 'Organization 1 in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === orgId2
                    ) > -1, 'Organization 2 in the result list');
                    assert.true(arr.every(
                        (arr) => arr.parents.indexOf(topOrgId) > -1
                    ), 'Return organizations member of Top Organization only');
                    assert.true(arr.findIndex(
                        (arr) => arr.parents.indexOf(orgId) < -1
                    ) === -1, 'There are no child organizations - member of Organization 1 in the list');
                    assert.true(countOrgId === 1, 'return only 1 result for organization 1 in the list - has 1 parent');
                    assert.true(countOrgId2 === 1, 'return only 1 result for organization 2 in the list - has 1 parent');
                }),
                commonFunc.createStep('customer.organization.graphFetch', 'fetch organizations by organizationTypeList - empty array', (context) => {
                    return {
                        organizationTypeList: []
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganizationGraph(result.organization).error, null, 'Return all details after organization graph fetch');
                }),
                commonFunc.createStep('customer.organization.graphFetch', 'fetch organizations by organizationTypeList - empty values', (context) => {
                    return {
                        organizationTypeList: ['', '']
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return PortHTTP');
                }),
                commonFunc.createStep('customer.organization.graphFetch', 'fetch organizations by organizationTypeList - wrong values', (context) => {
                    return {
                        organizationTypeList: ['networks', 'businessUnits']
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganizationGraph(result.organization).error, null, 'Return all details after organization graph fetch');
                }),
                // add user 1 - member of main org
                userMethods.addUser('add new user', (context) => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', (context) => context['add new user'].person.actorId),
                // add user 2 - member of child org
                userMethods.addUser('add new user 2', (context) => {
                    return {
                        object: context['add organization successfully']['organization.info'][0].actorId,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['add organization successfully']['organization.info'][0].actorId
                    };
                }, USERNAME + 2),
                userMethods.approveUser('approve user 2', (context) => context['add new user 2'].person.actorId),
                // add user 3 - member of main org - missing permissions
                userMethods.addUser('add new user 3', (context) => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME + 3),
                userMethods.approveUser('approve user 3', (context) => context['add new user 3'].person.actorId),
                // add user 4 - member of sub child org
                userMethods.addUser('add new user 4', (context) => {
                    return {
                        object: context['add child organization']['organization.info'][0].actorId,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['add child organization']['organization.info'][0].actorId
                    };
                }, USERNAME + 4),
                userMethods.approveUser('approve user 4', (context) => context['add new user 4'].person.actorId),
                userMethods.addUser('add new user 5', (context) => {
                    return {
                        object: context['add child organization 2 - member of 2 orgs']['organization.info'][0].actorId,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['add child organization 2 - member of 2 orgs']['organization.info'][0].actorId
                    };
                }, USERNAME + 5),
                userMethods.approveUser('approve user 5', (context) => context['add new user 5'].person.actorId),
                // add user 5 - member of sub child org & main org
                commonFunc.createStep('user.user.add', 'add new user 55', (context) => {
                    return {
                        hash: [{
                            identifier: USERNAME + 55,
                            value: userConstants.USERPASSWORD + 1,
                            isEnabled: 1,
                            expireDate: customerConstants.EXPIRATIONDATE,
                            type: userConstants.POLICYTYPE
                        }],
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        phone: [{
                            phoneTypeId: customerConstants.TYPEIDHOME,
                            phoneNumber: PHONENUMBER,
                            mnoId: customerConstants.MNOID,
                            isPrimary: 1
                        }],
                        actorHierarchy: [{
                            predicate: 'memberOf',
                            object: context['get admin details'].memberOF[0].object
                        }, {
                            predicate: 'memberOf',
                            object: context['add child organization']['organization.info'][0].actorId
                        }],
                        user: [{primaryLanguageId: userConstants.LANGUAGEID}],
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'user.recursion', 'return user.recursion');
                }),
                // add user 6 - member of sub child org & main org
                commonFunc.createStep('user.user.add', 'add new user 6', (context) => {
                    return {
                        hash: [{
                            identifier: USERNAME + 6,
                            value: userConstants.USERPASSWORD + 1,
                            isEnabled: 1,
                            expireDate: customerConstants.EXPIRATIONDATE,
                            type: userConstants.POLICYTYPE
                        }],
                        person: {
                            isEnabled: true,
                            isDeleted: false,
                            firstName: customerConstants.FIRSTNAME,
                            lastName: customerConstants.LASTNAME
                        },
                        phone: [{
                            phoneTypeId: customerConstants.TYPEIDHOME,
                            phoneNumber: PHONENUMBER,
                            mnoId: customerConstants.MNOID,
                            isPrimary: 1
                        }],
                        actorHierarchy: [{
                            predicate: 'memberOf',
                            object: context['add child organization']['organization.info'][0].actorId
                        }, {
                            predicate: 'memberOf',
                            object: context['add child organization 2 - member of 2 orgs']['organization.info'][0].actorId
                        }],
                        user: [{primaryLanguageId: userConstants.LANGUAGEID}],
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['add child organization']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, customerConstants.FIRSTNAME).error, null, 'Return all details after adding a user 5');
                    assert.equals(result['user.hash'][0].identifier, USERNAME + 6, 'return username');
                    assert.equals(result.person.firstName, customerConstants.FIRSTNAME, 'return fisrtName');
                    assert.equals(result.person.lastName, customerConstants.LASTNAME, 'return lastName');
                }),
                userMethods.approveUser('approve user 6', (context) => context['add new user 6'].person.actorId),
                userMethods.grantAction('grant action for customer.organization.graphFetch to user 1', (context) => context['add new user'].person.actorId, CUSTOMERORGANIZATIONGRAPHFETCH),
                userMethods.grantAction('grant action for customer.organization.graphFetch to user 2', (context) => context['add new user 2'].person.actorId, CUSTOMERORGANIZATIONGRAPHFETCH),
                userMethods.grantAction('grant action for customer.organization.graphFetch to user 4', (context) => context['add new user 4'].person.actorId, CUSTOMERORGANIZATIONGRAPHFETCH),
                userMethods.grantAction('grant action for customer.organization.graphFetch to user 5', (context) => context['add new user 5'].person.actorId, CUSTOMERORGANIZATIONGRAPHFETCH),
                userMethods.grantAction('grant action for customer.organization.graphFetch to user 6', (context) => context['add new user 6'].person.actorId, CUSTOMERORGANIZATIONGRAPHFETCH),
                /**
                 * NEGATIVE
                 */
                // wrong param
                commonFunc.createStep('customer.organization.graphFetch', 'graphFeth unsuccessfully - wrong param', (context) => {
                    return {
                        parentFilter: WRONGACTORID
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return PortHTTP');
                }),
                // null param
                commonFunc.createStep('customer.organization.graphFetch', 'graphFeth unsuccessfully - null param', (context) => {
                    return {
                        parentFilter: null
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return PortHTTP');
                }),
                commonFunc.createStep('customer.organization.graphFetch', 'graphFeth unsuccessfully - null in string param', (context) => {
                    return {
                        parentFilter: 'null'
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return PortHTTP');
                }),
                // enpty param
                commonFunc.createStep('customer.organization.graphFetch', 'graphFeth unsuccessfully - empty param', (context) => {
                    return {
                        parentFilter: ''
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, PORTHTTP, 'return PortHTTP');
                }),
                userMethods.logout('Logout admin user', (context) => context.login['identity.check'].sessionId),
                /**
                 * MISSING PERMISSIONS
                 */
                // login with user 3 - no rights
                userMethods.login('Successful login user 3', USERNAME + 3, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.graphFetch', 'try to execute customer.organization.grapFetch unsuccessfully - no rights', (context) => {
                    return {
                        parentFilter: context['get admin details'].memberOF[0].object
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERORGANIZATIONGRAPHFETCH) > -1, 'Missing permissions for ' + CUSTOMERORGANIZATIONGRAPHFETCH);
                }),
                userMethods.logout('Successful logout user 3', (context) => context['Successful login user 3']['identity.check'].sessionId),
                /**
                 * LOGIN OTHER USERS WITH GRANTED ACTION
                 */
                // login user 1
                userMethods.login('Successful login user 1', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.graphFetch', 'should return BUS for user 1 - member of Top Org', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganizationGraph(result.organization).error, null, 'Return all details after organization graph fetch');
                    const arr = result.organization;
                    const countOrgId = arr.filter((x) => { return x.id === orgId; }).length;
                    const countOrgId2 = arr.filter((x) => { return x.id === orgId2; }).length;
                    const countChildOrgId = arr.filter((x) => { return x.id === childOrgId; }).length;
                    const countChildOrgId2 = arr.filter((x) => { return x.id === childOrgId2; }).length;
                    assert.true(arr.findIndex(
                        (arr) => arr.id === topOrgId
                    ) > -1, 'Top organization in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === orgId
                    ) > -1, 'Organization 1 in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === orgId2
                    ) > -1, 'Organization 2 in the result list');
                    assert.true(arr.some(
                        (arr) => arr.parents === topOrgId
                    ), 'There are child organizations - member of Top Organization in the list');
                    assert.true(arr.some(
                        (arr) => arr.parents === orgId
                    ), 'There is at least one child organization - member of Organization 1 in the list');
                    assert.true(arr.some(
                        (arr) => arr.parents === orgId2
                    ), 'There is at least one child organization - member of Organization 2 in the list');
                    // assert counts
                    assert.true(countOrgId === 1, 'return only 1 result for organization 1 in the list - has 1 parent');
                    assert.true(countOrgId2 === 1, 'return only 1 result for organization 2 in the list - has 1 parent');
                    assert.true(countChildOrgId === 1, 'return only 1 result for child organization 1 in the list - has 1 parent');
                    assert.true(countChildOrgId2 === 2, 'return only 2 results for child organization 2 in the list - has 2 parents');
                }),
                userMethods.logout('Successful logout user 1', (context) => context['Successful login user 1']['identity.check'].sessionId),
                // login user 2
                userMethods.login('Successful login user 2', USERNAME + 2, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.graphFetch', 'should return BUS for user 2 - member of org 1', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganizationGraph(result.organization).error, null, 'Return all details after organization graph fetch');
                    const arr = result.organization;
                    const countOrgId = arr.filter((x) => { return x.id === orgId; }).length;
                    const countChildOrgId = arr.filter((x) => { return x.id === childOrgId; }).length;
                    const countChildOrgId2 = arr.filter((x) => { return x.id === childOrgId2; }).length;
                    assert.true(arr.findIndex(
                        (arr) => arr.id === topOrgId
                    ) === -1, 'Top Organization not in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === orgId
                    ) > -1, 'User organization in the result list');
                    assert.true(arr.some(
                        (arr) => arr.parents === orgId
                    ), 'There is at least one child organization - member of User Organization in the list');
                    // assert counts
                    assert.true(countOrgId === 1, 'return only 1 result for organization 1 in the list - has 1 parent');
                    assert.true(countChildOrgId === 1, 'return only 1 result for child organization 1 in the list - has 1 parent');
                    assert.true(countChildOrgId2 === 1, 'return only 1 results for child organization 2 in the list - has 2 parents');
                }),
                userMethods.logout('Successful logout user 2', (context) => context['Successful login user 2']['identity.check'].sessionId),
                // login user 4
                userMethods.login('Successful login user 4', USERNAME + 4, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.graphFetch', 'should return BUS for user 4 - member of child org 1', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganizationGraph(result.organization).error, null, 'Return all details after organization graph fetch');
                    const arr = result.organization;
                    const countChildOrgId = arr.filter((x) => { return x.id === childOrgId; }).length;
                    assert.true(arr.findIndex(
                        (arr) => arr.id === topOrgId
                    ) === -1, 'Top Organization not in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === orgId
                    ) === -1, 'Organization 1 not in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === childOrgId
                    ) > -1, 'User organization in the result list');
                    // assert counts
                    assert.true(countChildOrgId === 1, 'return only 1 result for child organization 1 in the list - has 1 parent');
                }),
                userMethods.logout('Successful logout user 4', (context) => context['Successful login user 4']['identity.check'].sessionId),
                // login user 5
                userMethods.login('Successful login user 5', USERNAME + 5, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.graphFetch', 'should return BUS for user 5 - member of child org 2', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganizationGraph(result.organization).error, null, 'Return all details after organization graph fetch');
                    const arr = result.organization;
                    const countsubChildOrgId = arr.filter((x) => { return x.id === childOrgId2; }).length;
                    assert.true(arr.findIndex(
                        (arr) => arr.id === topOrgId
                    ) === -1, 'Top organization not in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === orgId
                    ) === -1, 'Organization 1 not in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === orgId2
                    ) === -1, 'Organization 2 not in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === childOrgId2
                    ) > -1, 'User organization in the result list');
                    // assert counts
                    assert.true(countsubChildOrgId === 2, 'return 2 records in the resultset for child organization 2 - has 2 parents');
                }),
                userMethods.logout('Successful logout user 5', (context) => context['Successful login user 5']['identity.check'].sessionId),
                // login user 6
                userMethods.login('Successful login user 6', USERNAME + 6, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.graphFetch', 'should return BUS for user 6 - member of 2 child orgs', (context) => {
                    return {};
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateFetchOrganizationGraph(result.organization).error, null, 'Return all details after organization graph fetch');
                    const arr = result.organization;
                    const countsubChildOrgId = arr.filter((x) => { return x.id === childOrgId; }).length;
                    const countsubChildOrgId2 = arr.filter((x) => { return x.id === childOrgId2; }).length;
                    assert.true(arr.findIndex(
                        (arr) => arr.id === topOrgId
                    ) === -1, 'Top organization not in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === orgId
                    ) === -1, 'Organization 1 not in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === childOrgId
                    ) > -1, 'User organization 1 in the result list');
                    assert.true(arr.findIndex(
                        (arr) => arr.id === childOrgId2
                    ) > -1, 'User organization 2 in the result list');
                    // assert counts
                    assert.true(countsubChildOrgId === 1, 'return only 1 record in the resultset for child organization 1 - has 1 parent');
                    assert.true(countsubChildOrgId2 === 2, 'return 2 records in the resultset for child organization 2 - has 2 parents');
                }),
                userMethods.logout('Successful logout user 6', (context) => context['Successful login user 6']['identity.check'].sessionId)
            ]);
        }
    };
};
