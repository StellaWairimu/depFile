const commonFunc = require('ut-test/lib/methods/commonFunc');
const customerMethods = require('ut-test/lib/methods/customer');
const customerParams = require('ut-test/lib/requestParams/customer');
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerJoiValidation = require('ut-test/lib/joiValidations/customer');
const USERNAME = 'editKyc' + userConstants.USERNAME;
const CUSTOMERKYCEDIT = 'customer.kyc.edit';
const INVALIDATTRIBUTESRROR = 'customer.kycInvalidAttributes';
const KYCDESCRIPTION = customerConstants.KYCDESCRIPTION;
const RANDOMCONDITIONID = customerConstants.RANDOMCONDITIONID;
const STATUSACTIVE = 'active';
const TEXTINPUT = 'test';
let stdPolicy;
let customerTypeNumber1, customerTypeNumber2;
let orgId1, organizationDepthArray;
let levelId1, levelName1;
let attributeId1, attributeId2, attributeName2, attributeId3, kycConditionAttribute1, kycConditionAttribute2;

module.exports = function test() {
    return {
        editKyc: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                commonFunc.createStep('user.user.get', 'get admin details', (context) => {
                    return {
                        actorId: context.login['identity.check'].actorId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetPerson(result.person, userConstants.ADMINFIRSTNAME).error, null, 'return person');
                    orgId1 = result.memberOF[0].object;
                }),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                userMethods.addUser('add new user', context => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME),
                userMethods.approveUser('approve user', context => context['add new user'].person.actorId),
                commonFunc.createStep('customer.type.fetch', 'fetch customer types', (context) => {
                    return {};
                }, (result, assert) => {
                    customerTypeNumber1 = result.customerType[0].customerTypeNumber;
                    customerTypeNumber2 = result.customerType[1].customerTypeNumber;
                }),
                commonFunc.createStep('core.configuration.fetch', 'fetch defaultBu setting', (context) => {
                    return {
                        key: customerConstants.GETBYDEPTHORGANIZATION
                    };
                }, (result, assert) => {
                    const orgDepth = result[0][0].value;
                    organizationDepthArray = Array.apply(null, {length: orgDepth - 1}).map(Number.call, Number);
                    assert.true(typeof result, 'object', 'return result');
                }),
                // Create organization which correspond to the kyc's depth
                {
                    name: 'Create organization by depth',
                    steps: () => organizationDepthArray.map(org => ({
                        name: 'Add and approve organizations',
                        steps: () => [
                            commonFunc.createStep('customer.organization.add', 'add organization',
                                () => ({
                                    organization: {
                                        organizationName: customerConstants.ORGNAME
                                    },
                                    parent: [orgId1]
                                }), (result, assert) => {
                                    orgId1 = result['organization.info'][0].actorId;
                                    assert.equals(customerJoiValidation.validateAddOrganization(result['organization.info'][0]).error, null, 'return all details after creating the organization');
                                }
                            ),
                            customerMethods.approveOrganization('approve organization', () => orgId1)
                        ]
                    }))
                },
                commonFunc.createStep('customer.kyc.getForCreate', 'get levels for creating kyc', context => {
                    return {
                        customerType: customerTypeNumber1,
                        organizationId: orgId1
                    };
                }, (result, assert) => {
                    assert.true(result.levels.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateGetForCreateKyc(result.levels).error, null, 'Return all details for kyc levels');
                    levelId1 = result.levels[1].itemNameId;
                    levelName1 = result.levels[1].itemNameTranslation;
                }),
                commonFunc.createStep('customer.kycAttribute.list', 'list kyc attributes', context => {
                    return {
                        customerTypeId: customerTypeNumber1
                    };
                }, (result, assert) => {
                    assert.true(result.kycAttributes.length > 0, 'return not empty resultset');
                    assert.equals(customerJoiValidation.validateListKycAttributes(result.kycAttributes).error, null, 'Return all details for kyc attributes');
                    attributeId1 = result.kycAttributes[0].itemNameId;
                    attributeId2 = result.kycAttributes[1].itemNameId;
                    attributeName2 = result.kycAttributes[1].itemNameTranslation;
                    attributeId3 = result.kycAttributes[2].itemNameId;
                }),
                commonFunc.createStep('customer.kyc.add', 'add kyc 1', context => {
                    return {
                        kyc: {
                            display: levelName1,
                            description: KYCDESCRIPTION,
                            customerTypeId: customerTypeNumber1,
                            organizationId: orgId1,
                            itemNameId: levelId1
                        },
                        kycConditionAttribute: [{
                            conditionId: RANDOMCONDITIONID,
                            attributeId: attributeId1
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateAddKyc(result.kyc).error, null, 'Return all details after adding a kyc');
                    assert.equals(result.kyc[0].description, KYCDESCRIPTION, 'return kyc description');
                }),
                commonFunc.createStep('customer.kyc.get', 'get kyc 1 details after add', (context) => {
                    return {
                        kycId: context['add kyc 1'].kyc[0].kycId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetKyc(result).error, null, 'Return all details for kyc');
                    kycConditionAttribute1 = result.kycAttributes[0].kycConditionAttributeId;
                }),
                commonFunc.createStep('customer.kyc.edit', 'successfully edit kyc 1', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            kycConditionAttributeId: kycConditionAttribute1,
                            conditionId: RANDOMCONDITIONID + 1,
                            attributeId: attributeId2
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditKyc(result.kyc).error, null, 'Return all details after editing a kyc');
                    assert.equals(result.kyc[0].description, KYCDESCRIPTION + 'edited', 'return edited kyc description');
                    assert.equals(result.kyc[0].display, levelName1, 'return kyc display unchanged');
                    assert.equals(result.kyc[0].statusId, STATUSACTIVE, 'return unchanged statusId ' + STATUSACTIVE);
                    assert.equals(result.kyc[0].organizationId, orgId1, 'return kyc organization unchanged');
                    assert.equals(result.kyc[0].customerTypeId, customerTypeNumber1, 'return kyc customerTypeId unchanged');
                    assert.equals(result.kyc[0].itemNameId, levelId1, 'return kyc itemNameId unchanged');
                }),
                commonFunc.createStep('customer.kyc.get', 'get kyc 1 details after edit', (context) => {
                    return {
                        kycId: context['add kyc 1'].kyc[0].kycId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetKyc(result).error, null, 'Return all details for kyc');
                    assert.equals(result.kycAttributes.length, 1, 'return only one attribute');
                    assert.equals(result.kycAttributes[0].kycConditionAttributeId, kycConditionAttribute1, 'return correct kycConditionAttributeId of the edited attribute');
                    assert.equals(result.kycAttributes[0].conditionId, RANDOMCONDITIONID + 1, 'return edited conditionId');
                    assert.equals(result.kycAttributes[0].attributeId, attributeId2, 'return edited attributeId');
                    assert.equals(result.kycAttributes[0].itemNameTranslation, attributeName2, 'return correct attribute itemNameTranslation');
                }),
                commonFunc.createStep('customer.kyc.edit', 'successfully edit kyc 1 - add attribute', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + ' added attribute'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            kycConditionAttributeId: kycConditionAttribute1,
                            conditionId: RANDOMCONDITIONID + 1,
                            attributeId: attributeId2
                        },
                        {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            conditionId: RANDOMCONDITIONID + 2,
                            attributeId: attributeId3
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditKyc(result.kyc).error, null, 'Return all details after editing a kyc');
                    assert.equals(result.kyc[0].description, KYCDESCRIPTION + ' added attribute', 'return edited kyc description');
                }),
                commonFunc.createStep('customer.kyc.get', 'get kyc 1 details after adding new attribute', (context) => {
                    return {
                        kycId: context['add kyc 1'].kyc[0].kycId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetKyc(result).error, null, 'Return all details for kyc');
                    assert.equals(result.kycAttributes.length, 2, 'return two attributes');
                    assert.true(result.kycAttributes.find(attr => attr.conditionId === RANDOMCONDITIONID + 1 && attr.attributeId === attributeId2), 'return first attribute');
                    assert.true(result.kycAttributes.find(attr => attr.conditionId === RANDOMCONDITIONID + 2 && attr.attributeId === attributeId3), 'return new attribute');
                    kycConditionAttribute2 = result.kycAttributes.find(attr => attr.attributeId === attributeId3).kycConditionAttributeId;
                }),
                commonFunc.createStep('customer.kyc.edit', 'successfully edit kyc 1 - edit 2 attributes', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + ' edit 2 attributes'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            kycConditionAttributeId: kycConditionAttribute1,
                            conditionId: RANDOMCONDITIONID + 3,
                            attributeId: attributeId2
                        },
                        {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            kycConditionAttributeId: kycConditionAttribute2,
                            conditionId: RANDOMCONDITIONID + 4,
                            attributeId: attributeId3
                        }]
                    };
                },
                (result, assert) => {
                    assert.equals(customerJoiValidation.validateEditKyc(result.kyc).error, null, 'Return all details after editing a kyc');
                    assert.equals(result.kyc[0].description, KYCDESCRIPTION + ' edit 2 attributes', 'return edited kyc description');
                }),
                commonFunc.createStep('customer.kyc.get', 'get kyc 1 details after editing 2 attributes', (context) => {
                    return {
                        kycId: context['add kyc 1'].kyc[0].kycId
                    };
                }, (result, assert) => {
                    assert.equals(customerJoiValidation.validateGetKyc(result).error, null, 'Return all details for kyc');
                    assert.equals(result.kycAttributes.length, 2, 'return two attributes');
                    assert.true(result.kycAttributes.find(attr => attr.conditionId === RANDOMCONDITIONID + 3 && attr.attributeId === attributeId2 && attr.kycConditionAttributeId === kycConditionAttribute1), 'return first attribute');
                    assert.true(result.kycAttributes.find(attr => attr.conditionId === RANDOMCONDITIONID + 4 && attr.attributeId === attributeId3 && attr.kycConditionAttributeId === kycConditionAttribute2), 'return second attribute');
                }),
                // NEGATIVE SCENARIOS
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc 1 - 2 attributes with the same id', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + ' added attribute'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            kycConditionAttributeId: kycConditionAttribute1,
                            conditionId: RANDOMCONDITIONID + 1,
                            attributeId: attributeId2
                        },
                        {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            conditionId: RANDOMCONDITIONID + 2,
                            attributeId: attributeId2
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'portSQL', 'cannot have attributes with the same id');
                }),
                customerMethods.listKycAttributes('list kyc attributes - customer type 2', context => customerTypeNumber2),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc 1 - add attribute for different customer type', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + ' added attribute'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            conditionId: RANDOMCONDITIONID + 2,
                            attributeId: context['list kyc attributes - customer type 2'].kycAttributes[0].itemNameId
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, INVALIDATTRIBUTESRROR, 'invalid attribute - the attribute is not for the correct customer type');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - missing kycId', context => customerParams.editKycParams(context, (context) => {
                    return {
                        // kycId: context['add kyc 2'].kyc[0].kycId,
                        conditionId: RANDOMCONDITIONID + 1,
                        attributeId: attributeId2
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - null kycId', context => customerParams.editKycParams(context, (context) => {
                    return {
                        kycId: null,
                        conditionId: RANDOMCONDITIONID + 1,
                        attributeId: attributeId2
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - empty string kycId', context => customerParams.editKycParams(context, (context) => {
                    return {
                        kycId: '',
                        conditionId: RANDOMCONDITIONID + 1,
                        attributeId: attributeId2
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - string kycId', context => customerParams.editKycParams(context, (context) => {
                    return {
                        kycId: TEXTINPUT,
                        conditionId: RANDOMCONDITIONID + 1,
                        attributeId: attributeId2
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - missing description', context => customerParams.editKycParams(context, (context) => {
                    return {
                        kycId: context['add kyc 1'].kyc[0].kycId,
                        conditionId: RANDOMCONDITIONID + 1,
                        attributeId: attributeId2
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - description null', context => customerParams.editKycParams(context, (context) => {
                    return {
                        kycId: context['add kyc 1'].kyc[0].kycId,
                        conditionId: RANDOMCONDITIONID + 1,
                        attributeId: attributeId2
                    };
                }, null), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - description empty string', context => customerParams.editKycParams(context, (context) => {
                    return {
                        kycId: context['add kyc 1'].kyc[0].kycId,
                        conditionId: RANDOMCONDITIONID + 1,
                        attributeId: attributeId2
                    };
                }, ''), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - description number', context => customerParams.editKycParams(context, (context) => {
                    return {
                        kycId: context['add kyc 1'].kyc[0].kycId,
                        conditionId: RANDOMCONDITIONID + 1,
                        attributeId: attributeId2
                    };
                }, RANDOMCONDITIONID), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - missing kycConditionAttribute', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        }
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - kycConditionAttribute empty array', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: []
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - missing conditionId', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            attributeId: attributeId2
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - conditionId null', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            conditionId: null,
                            attributeId: attributeId2
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - conditionId empty string', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            conditionId: '',
                            attributeId: attributeId2
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - conditionId string', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            conditionId: TEXTINPUT,
                            attributeId: attributeId2
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - missing attributeId', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            conditionId: RANDOMCONDITIONID + 1
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - attributeId null', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            conditionId: RANDOMCONDITIONID + 1,
                            attributeId: null
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - attributeId empty string', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            conditionId: RANDOMCONDITIONID + 1,
                            attributeId: ''
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - attributeId string', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: [{
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            conditionId: RANDOMCONDITIONID + 1,
                            attributeId: TEXTINPUT
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - missing kycId inside kycConditionAttribute', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: [{
                            conditionId: RANDOMCONDITIONID + 1,
                            attributeId: attributeId2
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - null kycId inside kycConditionAttribute', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: [{
                            kycId: null,
                            conditionId: RANDOMCONDITIONID + 1,
                            attributeId: attributeId2
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - empty string kycId inside kycConditionAttribute', context => {
                    return {
                        kyc: {
                            kycId: context['add kyc 1'].kyc[0].kycId,
                            description: KYCDESCRIPTION + 'edited'
                        },
                        kycConditionAttribute: [{
                            kycId: '',
                            kycConditionAttributeId: kycConditionAttribute1,
                            conditionId: RANDOMCONDITIONID + 1,
                            attributeId: attributeId2
                        }]
                    };
                }, null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                // MISSING PERMISSIONS
                userMethods.logout('logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('successful login new user', USERNAME, userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.kyc.edit', 'unsuccessfully edit kyc - missing permission', context => customerParams.editKycParams(context, (context) => {
                    return {
                        kycId: context['add kyc 1'].kyc[0].kycId,
                        conditionId: RANDOMCONDITIONID + 1,
                        attributeId: attributeId2
                    };
                }, KYCDESCRIPTION), null,
                (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERKYCEDIT) > -1, 'Missing permissions for ' + CUSTOMERKYCEDIT);
                }),
                userMethods.logout('successfully logout new user', (context) => context['successful login new user']['identity.check'].sessionId)
            ]);
        }
    };
};
