const commonFunc = require('ut-test/lib/methods/commonFunc');
const userConstants = require('ut-test/lib/constants/user').constants();
const customerConstants = require('ut-test/lib/constants/customer').constants();
const userMethods = require('ut-test/lib/methods/user');
const userJoiValidation = require('ut-test/lib/joiValidations/user');
const userParams = require('ut-test/lib/requestParams/user');
const customerMethods = require('ut-test/lib/methods/customer');
const customerParams = require('ut-test/lib/requestParams/customer');
const USERNAME = 'lockOrg' + userConstants.USERNAME;
const ORGNAME = customerConstants.ORGNAME;
const FLOATNUM = 11.998;
const ROLENAME = userConstants.ROLENAME;
const DESCRIPTION = userConstants.ROLEDESCRIPTION;
const CUSTOMERORGANIZATIONLOCK = 'customer.organization.lock';
const ERRORCANNOTLOCKORGANIZATION = 'customer.organizationIsEnabledSet';
let stdPolicy;

module.exports = function test() {
    return {
        lockUnlockOrganization: function(test, bus, run) {
            return run(test, bus, [userMethods.generateAdmin(),
                userMethods.loginAdmin('login', (context) => {
                    return {
                        username: context.generateAdmin.hash.identifier
                    };
                }),
                userMethods.getUser('get admin details', (context) => context.login['identity.check'].actorId),
                commonFunc.createStep('policy.policy.fetch', 'get std input by admin policy', (context) => {
                    return {
                        searchString: 'STD'
                    };
                }, (result, assert) => {
                    const policy = result.policy.find(
                        (singlePolicy) => singlePolicy.name.indexOf('STD_input') > -1
                    );
                    stdPolicy = (policy.policyId).toString();
                }),
                commonFunc.createStep('user.role.add', 'add role successfully', (context) => userParams.addRoleParams(context, context => {
                    return {
                        visibleFor: [context['get admin details'].memberOF[0].object],
                        policyId: stdPolicy
                    };
                }, userConstants.ROLENAME, userConstants.ROLEDESCRIPTION),
                (result, assert) => {
                    assert.equals(userJoiValidation.validateAddRole(result.role[0]).error, null, 'Return all details after adding role');
                    assert.equals(result.role[0].name, userConstants.ROLENAME, 'return role name');
                    assert.equals(result.role[0].description, userConstants.ROLEDESCRIPTION, 'return role description');
                    assert.equals(result.role[0].isEnabled, false, 'return unlocked role status');
                }),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                userMethods.addUser('add user to test permissions', (context) => {
                    return {
                        object: context['get admin details'].memberOF[0].object,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['get admin details'].memberOF[0].object
                    };
                }, USERNAME + 'PERMISSIONS'),
                userMethods.approveUser('approve user 3', (context) => context['add user to test permissions'].person.actorId),
                customerMethods.addOrganization('add organization 1', (context) => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, ORGNAME + 1),
                customerMethods.approveOrganization('approve add organization 1', (context) => context['add organization 1']['organization.info'][0].actorId),
                customerMethods.lockOrganization('lock organization', (context) => {
                    return {
                        actorIdList: [context['add organization 1']['organization.info'][0].actorId],
                        isEnabled: false
                    };
                }),
                customerMethods.approveOrganization('approve lock organization successfully - first', (context) => context['add organization 1']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get locked organization 1 details', (context) => {
                    return {
                        actorId: context['add organization 1']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME + 1, 'return organization name');
                    assert.equals(result['organization.info'][0].isEnabled, false, 'return isEnabled false');
                }),
                commonFunc.createStep('customer.organization.lock', 'unsuccessfully lock already locked organization', (context) => customerParams.lockOrganizationParams(context, context => {
                    return {
                        actorIdList: [context['add organization 1']['organization.info'][0].actorId],
                        isEnabled: 0
                    };
                }), null,
                (error, assert) => {
                    // console.log(error);
                    assert.equals(error.type, ERRORCANNOTLOCKORGANIZATION, 'cannot lock already locked organization');
                }),
                commonFunc.createStep('user.user.add', 'add user - organization locked', (context) => userParams.addUserParams(context, context => {
                    return {
                        object: context['add organization 1']['organization.info'][0].actorId,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['add organization 1']['organization.info'][0].actorId
                    };
                }, USERNAME), null,
                (error, assert) => {
                    assert.equals(error.type, 'user.disabledOrDeletedOrganization', 'return type user.disabledOrDeletedOrganization');
                }),
                customerMethods.lockOrganization('unlock organization 1', (context) => {
                    return {
                        actorIdList: [context['add organization 1']['organization.info'][0].actorId],
                        isEnabled: 1
                    };
                }),
                customerMethods.approveOrganization('approve unlock organization 1', (context) => context['add organization 1']['organization.info'][0].actorId),
                commonFunc.createStep('customer.organization.get', 'get unlocked organization 1 details', (context) => {
                    return {
                        actorId: context['add organization 1']['organization.info'][0].actorId
                    };
                }, (result, assert) => {
                    assert.equals(result['organization.info'][0].organizationName, ORGNAME + 1, 'return organization name');
                    assert.equals(result['organization.info'][0].isEnabled, true, 'return isEnabled true');
                }),
                commonFunc.createStep('customer.organization.lock', 'unsuccessfully unlock already unlocked organization', (context) => customerParams.lockOrganizationParams(context, context => {
                    return {
                        actorIdList: [context['add organization 1']['organization.info'][0].actorId],
                        isEnabled: 1
                    };
                }), null,
                (error, assert) => {
                    // console.log(error);
                    assert.equals(error.type, ERRORCANNOTLOCKORGANIZATION, 'cannot unlock already unlocked organization');
                }),
                // Scenario: Lock organization with users
                userMethods.addUser('add user 2', (context) => {
                    return {
                        object: context['add organization 1']['organization.info'][0].actorId,
                        policyId: stdPolicy,
                        roles: [context['add role successfully'].role[0].actorId],
                        defaultRoleId: context['add role successfully'].role[0].actorId,
                        defaultBuId: context['add organization 1']['organization.info'][0].actorId
                    };
                }, USERNAME + 2),
                userMethods.approveUser('approve user', (context) => context['add user 2'].person.actorId),
                commonFunc.createStep('customer.organization.lock', 'lock organization - after adding user to it', (context) => {
                    return {
                        actorIdList: [context['add organization 1']['organization.info'][0].actorId],
                        isEnabled: 0
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.cannotLockHasUsers', 'return customer.cannotLockHasUsers');
                }),
                userMethods.deleteUser('delete user 2', (context) => [context['add user 2'].person.actorId]),
                userMethods.approveUser('approve removal of user 2', context => context['add user 2'].person.actorId),
                customerMethods.lockOrganization('lock organization 2 - after deleting the assigned user to it', (context) => {
                    return {
                        actorIdList: [context['add organization 1']['organization.info'][0].actorId],
                        isEnabled: false
                    };
                }),
                // Scenario: Lock organization with roles
                customerMethods.addOrganization('add organization 2', (context) => {
                    return {
                        parent: [context['get admin details'].memberOF[0].object]
                    };
                }, ORGNAME + 2),
                customerMethods.approveOrganization('approve add organization 2', (context) => context['add organization 2']['organization.info'][0].actorId),
                userMethods.addRole('add role successfully', (context) => {
                    return {
                        visibleFor: [context['add organization 2']['organization.info'][0].actorId],
                        policyId: stdPolicy
                    };
                }, ROLENAME, DESCRIPTION),
                userMethods.approveRole('approve role', context => context['add role successfully'].role[0].actorId),
                commonFunc.createStep('customer.organization.lock', 'lock organization - after assigning role to it', (context) => {
                    return {
                        actorIdList: [context['add organization 2']['organization.info'][0].actorId],
                        isEnabled: false
                    };
                }, null, (error, assert) => {
                    assert.equals(error.type, 'customer.cannotLockHasRoles', 'return customer.cannotLockHasRoles');
                }),
                userMethods.deleteRole('delete role', (context) => [context['add role successfully'].role[0].actorId]),
                userMethods.approveRole('approve role delete', context => context['add role successfully'].role[0].actorId),
                customerMethods.lockOrganization('lock organization 2 - after deleting the assigned roles to it', (context) => {
                    return {
                        actorIdList: [context['add organization 2']['organization.info'][0].actorId],
                        isEnabled: false
                    };
                }),
                /**
                 * NEGATIVE
                 */
                commonFunc.createStep('customer.organization.lock', 'lock organization - actorId - empty string', (context) => customerParams.lockOrganizationParams(context, context => {
                    return {
                        actorIdList: [''],
                        isEnabled: false
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.lock', 'lock organization - actorId - null', (context) => customerParams.lockOrganizationParams(context, context => {
                    return {
                        actorIdList: [null],
                        isEnabled: false
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.lock', 'lock organization - actorId - missing params', (context) => customerParams.lockOrganizationParams(context, context => {
                    return {};
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                commonFunc.createStep('customer.organization.lock', 'lock organization - actorId - float', (context) => customerParams.lockOrganizationParams(context, context => {
                    return {
                        actorIdList: [FLOATNUM],
                        isEnabled: false
                    };
                }), null,
                (error, assert) => {
                    assert.equals(error.type, 'PortHTTP', 'return joi failure');
                }),
                /**
                 * MISSING PERMISSION
                 */
                userMethods.logout('Logout admin user', (context) => context.login['identity.check'].sessionId),
                userMethods.login('Successful login user 3', USERNAME + 'PERMISSIONS', userConstants.USERPASSWORD + 1, userConstants.TIMEZONE, userConstants.USERPASSWORD),
                commonFunc.createStep('customer.organization.lock', 'lock organization - no rights', (context) => {
                    return {
                        actorIdList: [context['add organization 1']['organization.info'][0].actorId],
                        isEnabled: false
                    };
                }, null, (error, assert) => {
                    assert.true(error.message.indexOf(CUSTOMERORGANIZATIONLOCK) > -1, 'Missing permissions for ' + CUSTOMERORGANIZATIONLOCK);
                }),
                userMethods.logout('Successful logout user 3', (context) => context['Successful login user 3']['identity.check'].sessionId)
            ]);
        }
    };
};
