module.exports = () => function utCustomer() {
    return {
        adapter: () => [
            require('./api/sql/schema'),
            require('./api/sql/seed'),
            require('./api/sql/standard'),
            require('./api/t24'),
            require('./test/schema'),
            require('./errors')
        ],
        orchestrator: () => [
            require('ut-dispatch-db')(['customer'], ['utCustomer.customer']),
            require('./api/script'),
            require('./errors')
        ],
        gateway: () => [
            require('./http'),
            require('./validations'),
            require('./validations/testValidations')
        ],
        test: () => require('./test/jobs')
    };
};
