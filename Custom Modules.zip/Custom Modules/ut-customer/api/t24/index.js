'use strict';
const convertDate = require('./util/converter/date');
const convertDictionary = require('./util/converter/dictionary');
module.exports = function t24Customer() {
    return {
        'customer.update.request.send': function(msg, $meta) {
            if (!msg.customer && msg.customer.customerNumber == null) {
                throw new Error('Missing customer number');
            }
            const data = {};
            if (msg.customerAddress) {
                if (!Array.isArray(msg.customerAddress)) {
                    msg.customerAddress = [msg.customerAddress];
                }
                msg.customerAddress.some(function(address) {
                    if (address && address.addressTypeId === 'home' && address.statusId === 'active') {
                        data.STREET = address.value;
                        return true;
                    }
                    return false;
                });
            }
            if (msg.document) {
                if (!Array.isArray(msg.document)) {
                    msg.document = [msg.document];
                }
                msg.document.map(function(document, id) {
                    if (document) {
                        if (document.documentTypeId === 'id_card' && document.documentNumber != null) {
                            data['LEGAL.ID'] = document.documentNumber;
                            if (document.expirationDate) {
                                data['EXPIRY.DATE'] = convertDate(document.expirationDate);
                            }
                        } else if (document.documentTypeId === 'proof_of_address') {
                            data['RESIDE.PROOF'] = 'Y';
                        }
                    }
                });
            }
            if (msg.location) {
                msg.location.busLat != null && (data['BUS.LAT'] = msg.location.busLat);
                msg.location.busLng != null && (data['BUS.LNG'] = msg.location.busLng);
                msg.location.homeLat != null && (data['HOME.LAT'] = msg.location.homeLat);
                msg.location.homeLng != null && (data['HOME.LNG'] = msg.location.homeLng);
            }
            if (msg.customerPhone) {
                let phonePrefix = msg.customer.phonePrefix;
                if (typeof phonePrefix === 'string' && phonePrefix.startsWith('+')) {
                    phonePrefix = phonePrefix.substr(1);
                } else {
                    phonePrefix = '';
                }
                if (!Array.isArray(msg.customerPhone)) {
                    msg.customerPhone = [msg.customerPhone];
                }
                msg.customerPhone.some(function(phone) {
                    if (phone.statusId === 'approved') {
                        data['CONF.TEL.NO'] = phonePrefix + phone.phoneNumber;
                        return true;
                    }
                    return false;
                });
            }
            if (msg.person) {
                msg.person.firstName != null && (data['NAME.1'] = msg.person.firstName);
                msg.person.lastName != null && (data['SHORT.NAME'] = msg.person.lastName);
                msg.person.gender && (data.GENDER = convertDictionary(String(msg.person.gender).toUpperCase(), {
                    M: 'MALE',
                    F: 'FEMALE'
                }));
                msg.person.childrenCount != null && (data['NO.OF.KIDS'] = msg.person.childrenCount);
                msg.person.dateOfBirth != null && (data['BIRTH.INCORP.DATE'] = convertDate(msg.person.dateOfBirth));
                msg.person.placeOfBirth != null && (data['LOC.BIRTH'] = msg.person.placeOfBirth);
                msg.person.nationality != null && (data.NATIONALITY = msg.person.nationality);
            }
            msg.customer.customerCategoryId != null && (data['CUSTOMER.STATUS'] = msg.customer.customerCategoryId);
            msg.customer.dao != null && (data['ACCOUNT.OFFICER'] = msg.customer.dao);
            // msg.customer.kycId != null && (data['CUSTOMER.LEVEL'] = msg.customer.kycId);
            data.BLOCKED = 'N';
            data['POSTING.RESTRICT'] = '';

            // if (Array.isArray(msg.bio)) {
            //     // data['BIO.ENROLL.FLAG'] = msg.bio.length > 0 ? 'YES' : '';
            //     data['BIO.ENROL.STAT'] =  'UNLOCK ';
            //     if (msg.bio.length > 0) {
            //         var bioList = msg.bio.slice(0);
            //         bioList = bioList.sort(function(a, b) {
            //             return convertDate(a.lastChange) > convertDate(b.lastChange);
            //         });
            //         data['BIO.ENROLL.DATE'] = convertDate(bioList[0].lastChange);
            //     }
            // }

            $meta.opcode = 'SAVE_RECORD';
            return this.config.send.call(this, {
                application: 'CUSTOMER',
                fields: data,
                record_id: msg.customer.customerNumber,
                version: 'SG.UPDATE'
            }, $meta);
        },
        'customer.update.response.receive': function(msg, $meta) {
            try {
                msg = this.config.receive.call(this, msg, $meta);
            } catch (err) {
                return msg;
            }

            msg.customerNumber = msg.record_id;
            return msg;
        },
        'customer.block.request.send': function(msg, $meta) {
            if (!msg.customer && msg.customer.customerNumber == null) {
                throw new Error('Missing customer number');
            }

            const data = {};
            if (msg.customerAddress) {
                if (!Array.isArray(msg.customerAddress)) {
                    msg.customerAddress = [msg.customerAddress];
                }
                msg.customerAddress.some(function(address) {
                    if (address && address.addressTypeId === 'home' && address.statusId === 'active') {
                        data.STREET = address.value;
                        return true;
                    }
                    return false;
                });
            }
            if (msg.document) {
                if (!Array.isArray(msg.document)) {
                    msg.document = [msg.document];
                }
                msg.document.map(function(document) {
                    if (document) {
                        if (document.documentTypeId === 'id_card' && document.documentNumber != null) {
                            data['LEGAL.ID'] = document.documentNumber;
                            if (document.expirationDate) {
                                data['EXPIRY.DATE'] = convertDate(document.expirationDate);
                            }
                        } else if (document.documentTypeId === 'proof_of_address') {
                            data['RESIDE.PROOF'] = 'Y';
                        }
                    }
                });
            }
            if (msg.location) {
                msg.location.busLat != null && (data['BUS.LAT'] = msg.location.busLat);
                msg.location.busLng != null && (data['BUS.LNG'] = msg.location.busLng);
                msg.location.homeLat != null && (data['HOME.LAT'] = msg.location.homeLat);
                msg.location.homeLng != null && (data['HOME.LNG'] = msg.location.homeLng);
            }
            if (msg.customerPhone) {
                let phonePrefix = msg.customer.phonePrefix;
                if (typeof phonePrefix === 'string' && phonePrefix.startsWith('+')) {
                    phonePrefix = phonePrefix.substr(1);
                } else {
                    phonePrefix = '';
                }
                if (!Array.isArray(msg.customerPhone)) {
                    msg.customerPhone = [msg.customerPhone];
                }
                msg.customerPhone.some(function(phone) {
                    if (phone.statusId === 'approved') {
                        data['CONF.TEL.NO'] = phonePrefix + phone.phoneNumber;
                        return true;
                    }
                    return false;
                });
            }
            if (msg.person) {
                msg.person.firstName != null && (data['NAME.1'] = msg.person.firstName);
                msg.person.lastName != null && (data['SHORT.NAME'] = msg.person.lastName);
                msg.person.gender && (data.GENDER = convertDictionary(String(msg.person.gender).toUpperCase(), {
                    M: 'MALE',
                    F: 'FEMALE'
                }));
                msg.person.childrenCount != null && (data['NO.OF.KIDS'] = msg.person.childrenCount);
                msg.person.dateOfBirth != null && (data['BIRTH.INCORP.DATE'] = convertDate(msg.person.dateOfBirth));
                msg.person.placeOfBirth != null && (data['LOC.BIRTH'] = msg.person.placeOfBirth);
                msg.person.nationality != null && (data.NATIONALITY = msg.person.nationality);
            }
            msg.customer.customerCategoryId != null && (data['CUSTOMER.STATUS'] = msg.customer.customerCategoryId);
            msg.customer.dao != null && (data['ACCOUNT.OFFICER'] = msg.customer.dao);
            msg.customer.kycId != null && (data['CUSTOMER.LEVEL'] = msg.customer.kycId);
            data.BLOCKED = 'Y';
            data['POSTING.RESTRICT'] = '90';

            // if (Array.isArray(msg.bio)) {
            //     data['BIO.ENROLL.FLAG'] = msg.bio.length > 0 ? 'Y' : 'N';
            //     data['BIO.ENROL.STAT'] = msg.bio.length > 0 ? 'UNLOCKED' : '';
            //     if (msg.bio.length > 0) {
            //         var bioList = msg.bio.slice(0);
            //         bioList = bioList.sort(function(a, b) {
            //             return convertDate(a.lastChange) > convertDate(b.lastChange);
            //         });
            //         data['BIO.ENROLL.DATE'] = convertDate(bioList[0].lastChange);
            //     }
            // }

            $meta.opcode = 'SAVE_RECORD';
            return this.config.send.call(this, {
                application: 'CUSTOMER',
                fields: data,
                record_id: msg.customer.customerNumber,
                version: 'SG.BLOCK'
            }, $meta);
        },
        'customer.block.response.receive': function(msg, $meta) {
            try {
                msg = this.config.receive.call(this, msg, $meta);
            } catch (err) {
                return msg;
            }

            msg.customerNumber = msg.record_id;
            return msg;
        },
        'customer.activity.request.send': function(msg, $meta) {
            if (!msg.customer && msg.customer.customerNumber == null) {
                throw new Error('Missing customer number');
            }
            const request = {
                application: 'MCR.SG.ACCT.BAL.STMT',
                filter: 'CUSTOMER EQ ' + msg.customer.customerNumber
            };
            $meta.opcode = 'SELECT';
            return this.config.send.call(this, request, $meta);
        },
        'customer.activity.response.receive': function(msg, $meta) {
            msg = this.config.receive.call(this, msg, $meta);
            const language = $meta.language && $meta.language.iso2Code ? $meta.language.iso2Code : 'fr';
            let resultSet = null;
            const result = {
                balance: [],
                activity: []
            };
            const balanceMap = {};
            Object.keys(msg).some(function(key) {
                if (REGEXP_RESULTSET_KEY.test(key)) {
                    resultSet = msg[key];
                    return true;
                }
                return false;
            });
            if (resultSet && Array.isArray(resultSet.rows)) {
                resultSet.rows.forEach((row) => {
                    if (!Object.prototype.hasOwnProperty.call(balanceMap, row.ACCOUNT)) {
                        balanceMap[row.ACCOUNT] = {
                            accountNumber: row.ACCOUNT,
                            value: convertMoney(row['ACCOUNT.BALANCE'])
                        };
                        if (Object.prototype.hasOwnProperty.call(row, 'ACCOUNT.NAME')) {
                            balanceMap[row.ACCOUNT].accountName = convertName(row['ACCOUNT.NAME'], language);
                        }
                        result.balance.push(balanceMap[row.ACCOUNT]);
                    }
                    if (row.AMOUNT !== 'NO ENTRIES FOR PERIOD') {
                        const activity = {};
                        activity.executeDate = convertDate(row['VALUE.DATE']);
                        activity.postDate = convertDate2(row['POST.DATE']);
                        activity.transactionId = row['TRANS.REF.NO'];
                        activity.amount = convertMoney(row.AMOUNT);
                        if (Object.prototype.hasOwnProperty.call(row, 'ACCOUNT.NAME')) {
                            activity.accountName = convertName(row['ACCOUNT.NAME'], language);
                        }

                        activity.description = convertName(row.DESCRIPTION, language || 'fr');
                        const location = convertName(row.LOCATION, language || 'fr');
                        activity.shortDescription = Object.prototype.hasOwnProperty.call(row, 'LOCATION') && row.LOCATION !== null && row.LOCATION !== '' ? `Your transaction at ${location}` : '';
                        activity.account = row.ACCOUNT;
                        if (Object.prototype.hasOwnProperty.call(row, 'TRANS.REF.NO') && row['TRANS.REF.NO'].substring(0, 2) !== 'FT') {
                            result.activity.push(activity);
                            return;
                        }
                        if ((!Object.prototype.hasOwnProperty.call(row, 'TRANSFER.DETAILS') && !Object.prototype.hasOwnProperty.call(row, 'ADDITIONAL.TRANSFER.DETAILS')) || row['ADDITIONAL.TRANSFER.DETAILS'] === '' || row['TRANSFER.DETAILS'] === '') {
                            return;
                        }
                        const accountTranslation = language === 'en' ? 'account' : 'compte';
                        const account = activity.accountName.replace(/\s{0,}account\s{0,}/gi, '');
                        if (activity.description === 'Transfert-correspondant' || activity.description === 'Transfer Correspondants') {
                            const transferTo = convertName(row['TRANSFER.DETAILS'], language || 'fr');
                            activity.description = language === 'en' ? `Transfer from ${account} ${accountTranslation} to ${transferTo}` : `Transfert du ${account} ${accountTranslation} compte ${transferTo}`;
                        } else if (activity.description === 'Cash Out Correspondence' || activity.description === 'Versement - correspondant') {
                            activity.description = language === 'en' ? `Deposit into your ${account} ${accountTranslation}` : `Dépôt dans votre ${account} ${accountTranslation}`;
                        } else if (activity.description === 'Cash Deposit Correspondence' || activity.description === 'Retrait - correspondant') {
                            activity.description = language === 'en' ? `Withdrawal from your ${account} ${accountTranslation}` : `Retrait du votre ${account} ${accountTranslation}`;
                        }

                        result.activity.push(activity);
                    }
                });
            }
            return result;

            function convertMoney(value) {
                if (value === null) return value;
                if (value[value.length - 1] === '-') {
                    value = '-' + value.substr(0, value.length - 1);
                }
                return value;
            }

            function convertDate(value) {
                if (value === null || value === '') return null;

                const parts = REGEXP_ACCOUNT_BALANCE_DATE.exec(value);
                if (!parts) {
                    throw new Error('Invalid date');
                }
                // This workaround will work before year 2100, please update this software before then.
                const cy2 = (new Date()).getFullYear() - 2000;
                if (parts[3] > cy2) {
                    parts[3] = (1900 + parseInt(parts[3])) + '';
                } else {
                    parts[3] = (2000 + parseInt(parts[3])) + '';
                }
                return parts[3] + '-' + monthKeys[parts[2]] + '-' + parts[1];
            }

            function convertDate2(value) {
                if (value === null || value === '') return null;

                const parts = REGEXP_ACCOUNT_BALANCE_DATE2.exec(value);
                if (!parts) {
                    throw new Error('Invalid date');
                }
                // This workaround will work before year 2100, please update this software before then.
                const cy2 = (new Date()).getFullYear() - 2000;
                if (parts[3] > cy2) {
                    parts[3] = (1900 + parseInt(parts[3])) + '';
                } else {
                    parts[3] = (2000 + parseInt(parts[3])) + '';
                }
                return parts[3] + '-' + monthKeys[parts[2]] + '-' + parts[1] + ' ' + parts[4] + ':' + parts[5];
            }
        },
        'customer.bio.request.send': function(msg, $meta) {
            const data = {};

            if (msg && msg.date) {
                const dateObject = new Date(msg.date);

                msg.flag && (data['BIO.ENROLL.FLAG'] = 'Y');
                data['BIO.ENROL.STAT'] = msg.stat;
                data['BIO.ENROLL.DATE'] = convertDate(msg.date);
                data['BIO.UPD.CHK'] = `${convertDate(msg.date)}${dateObject.getHours()}${dateObject.getMinutes()}${dateObject.getSeconds()}`;
            } else {
                throw Error('Invalid params for t24');
            }

            $meta.opcode = 'SAVE_RECORD';
            return this.config.send.call(this, {
                application: 'CUSTOMER',
                fields: data,
                record_id: msg.customerNumber,
                version: 'MCR.PARTY.INDIV.UPD.BIO.SMS'
            }, $meta);
        },
        'customer.bio.response.receive': function(msg, $meta) {
            return this.config.receive.call(this, msg, $meta) || {};
        },
        'customer.createT24.request.send': function(msg, $meta) {
            const data = {};
            data['ACCOUNT.OFFICER'] = msg.dao;
            data['BIRTH.INCORP.DATE'] = convertDate(msg.person.dateOfBirth);
            data.GENDER = msg.person.gender;
            data['INITIATOR.ID'] = '5'; // hardcoded to 5 = mobile
            msg.documentAttachment.forEach(function(doc) {
                if (doc.documentTypeId === 'id_card') {
                    data['LEGAL.ID'] = doc.documentNumber;
                    if (doc.expirationDate) {
                        data['EXPIRY.DATE'] = convertDate(doc.expirationDate);
                    }
                }
            });
            data['LOC.BIRTH'] = msg.person.placeOfBirth;
            if (this.config.id === 't24/china' || this.config.id === 't24/ivorycoast' || this.config.id === 't24/zimbabwe') {
                data['MCI.EMPLOYEE'] = 'NO';
            } else if (this.config.id === 't24/nigeria') {
                data['MCI.EMPLOYEE'] = 'N';
            } else {
                data['MCI.EMPLOYEE'] = 'NON';
            }
            data['NAME.1'] = msg.person.firstName;
            data.NATIONALITY = msg.person.nationality;
            data['PROC.CODE'] = '75';
            data['SHORT.NAME'] = msg.person.lastName;
            data.STREET = msg.customerAddress[0].value;
            data['TEL.MOBILE'] = '';
            data['TERMINAL.ID'] = msg.person.deviceID;
            data['MARITAL.STATUS'] = msg.person.maritalStatus;
            data['NO.OF.KIDS'] = msg.person.childrenCount;
            data['INCL.LEVEL'] = msg.person.financialInclusionStatus;
            data['INCOME.FREQ'] = msg.person.incomeFrequency;
            data['INCOME.GRP'] = msg.person.incomeAmount;
            data['PHONE.TYPE'] = msg.person.phoneModel;

            $meta.opcode = 'SAVE_RECORD';
            return this.config.send.call(this, {
                application: 'CUSTOMER',
                fields: data,
                record_id: '',
                version: 'MCR.UNET.PARTY.INDIV.PROMOL1'
            }, $meta);
        },
        'customer.createT24.response.receive': function(msg, $meta) {
            try {
                const result = this.config.receive.call(this, msg, $meta) || {};
                return result;
            } catch (err) {
                if (typeof err.fieldErrors === 'object' && err.fieldErrors[Object.keys(err.fieldErrors)[0]] && err.fieldErrors[Object.keys(err.fieldErrors)[0]].message) {
                    err.message = err.fieldErrors[Object.keys(err.fieldErrors)[0]].message;
                }
                throw err;
            }
        },
        'customer.createAccountT24.request.send': function(msg, $meta) {
            const data = {};
            data['BIO.ENROLL.DATE'] = convertDate(msg.customer.lastChange);
            const dateObject = new Date(msg.customer.lastChange);
            data['BIO.UPD.CHK'] = `${convertDate(msg.customer.lastChange)}${dateObject.getHours()}${dateObject.getMinutes()}${dateObject.getSeconds()}`;

            $meta.opcode = 'SAVE_RECORD';
            return this.config.send.call(this, {
                application: 'CUSTOMER',
                fields: data,
                record_id: msg.customer.customerNumber,
                version: 'MCR.UPDATE.PROOF.RESIDE'
            }, $meta);
        },
        'customer.createAccountT24.response.receive': function(msg, $meta) {
            return this.config.receive.call(this, msg, $meta) || {};
        },
        'customer.optInOutAlip.request.send': function(msg, $meta) {
            if (!msg.customerNumber) {
                throw new Error('Missing customer number');
            }
            const data = {};
            data['OPT.OUT.IND'] = msg.state;
            $meta.opcode = 'SAVE_RECORD';
            return this.config.send.call(this, {
                application: 'CUSTOMER',
                fields: data,
                record_id: msg.customerNumber,
                version: 'MCR.OPT.OUT.CUSTOMER'
            }, $meta);
        },
        'customer.optInOutAlip.response.receive': function(msg, $meta) {
            const result = this.config.receive.call(this, msg, $meta) || {};
            if (!result.operation_successful && typeof result.field_errors === 'object' && result.field_errors[Object.keys(result.field_errors)[0]] && result.field_errors[Object.keys(result.field_errors)[0]].message) {
                throw Error(result.field_errors[Object.keys(result.field_errors)[0]].message);
            }
            // fix for t24 not returning an error when there is a permission problem
            if (result.fields && typeof result.fields === 'object' && result.fields[' you don\'t have permissions to access this data']) {
                throw Error(result.fields[' you don\'t have permissions to access this data']);
            }
            delete result.fields;
            return result;
        },
        'customer.optInOutTaka.request.send': function(msg, $meta) {
            if (!msg.customerNumber) {
                throw new Error('Missing customer number');
            }
            const data = {};
            data['OPT.OUT.TAKA'] = msg.state;
            $meta.opcode = 'SAVE_RECORD';
            return this.config.send.call(this, {
                application: 'CUSTOMER',
                fields: data,
                record_id: msg.customerNumber,
                version: 'MCR.OPT.OUT.CUSTOMER.TAKA'
            }, $meta);
        },
        'customer.optInOutTaka.response.receive': function(msg, $meta) {
            const result = this.config.receive.call(this, msg, $meta) || {};
            if (!result.operation_successful && typeof result.field_errors === 'object' && result.field_errors[Object.keys(result.field_errors)[0]] && result.field_errors[Object.keys(result.field_errors)[0]].message) {
                throw Error(result.field_errors[Object.keys(result.field_errors)[0]].message);
            }
            // fix for t24 not returning an error when there is a permission problem
            if (result.fields && typeof result.fields === 'object' && result.fields[' you don\'t have permissions to access this data']) {
                throw Error(result.fields[' you don\'t have permissions to access this data']);
            }
            delete result.fields;
            return result;
        }
    };
};

const REGEXP_RESULTSET_KEY = /^result_set(?:_.*)?/;
const REGEXP_ACCOUNT_BALANCE_DATE = /^([0-9]{2}) (JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC) ([0-9]{2})$/;
const REGEXP_ACCOUNT_BALANCE_DATE2 = /^([0-9]{2}) (JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC) ([0-9]{2}) ([0-9]{2}):([0-9]{2})$/;
const monthKeys = {
    JAN: '01',
    FEB: '02',
    MAR: '03',
    APR: '04',
    MAY: '05',
    JUN: '06',
    JUL: '07',
    AUG: '08',
    SEP: '09',
    OCT: '10',
    NOV: '11',
    DEC: '12'
};
const languageOrder = ['en', 'fr'];
function convertName(name, languageCode) {
    // may the god have mercy on your soul, because T24 won't
    const translations = name && name.indexOf('|') ? name.split('|') : '';
    const index = languageOrder.indexOf(languageCode);
    if (index < 0 || !translations[index]) {
        if (translations[1]) {
            return translations[1];
        }
        return translations[0];
    }
    return translations[index];
}
