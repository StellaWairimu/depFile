(function() {
    'use strict';
    module.exports = function(value, options) {
        if (!Object.prototype.hasOwnProperty.call(options, value)) {
            const err = new Error('Invalid value');
            err.type = 'mapping';
            err.value = value;
            err.dictionary = Object.keys(options);
            throw err;
        }
        return options[value];
    };
})();
