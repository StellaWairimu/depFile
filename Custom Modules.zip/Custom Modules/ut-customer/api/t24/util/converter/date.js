(function() {
    'use strict';
    const fillFront = function(s, c, ch) {
        s = '' + s;
        while (s.length < c) {
            s = ch + s;
        }
        return s;
    };
    module.exports = function(value, options) {
        // TODO: Remove this complexity once linting is fixed to allow moment.
        // TODO: Until then, input and output format will be hardcoded.
        // Following lines of code are equivalent to: moment(value, 'YYYY-MM-DD').format('YYYYMMDD');
        // Except that this is not optimized.
        let year, month, date;
        if (typeof value === 'string' || typeof value === 'number') {
            value = new Date(value);
        } else if (Array.isArray(value)) {
            value = new Date(Date.UTC.apply(Date, value));
        } else if (!(value instanceof Date)) {
            throw new Error('Invalid date format: ' + String(value) + ' cannot be converted to date');
        }
        if (!isFinite(value)) {
            throw new Error('Invalid date format: ' + String(value) + ' cannot be converted to date');
        }
        year = fillFront(value.getUTCFullYear(), 4, '0');
        month = fillFront(value.getUTCMonth() + 1, 2, '0');
        date = fillFront(value.getUTCDate(), 2, '0');
        return year + month + date;
    };
})();
