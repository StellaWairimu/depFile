---CustomerSelfRegistration
-- for default @branchId the business unit chosen should be at the correct depth level as selected below in
DECLARE @branchId NVARCHAR (200) = ( SELECT actorId FROM customer.organization WHERE organizationName = 'Bulgaria')
DECLARE @accountTypeId NVARCHAR (200) = ( SELECT [accountTypeId] FROM [customer].[accountType] WHERE accountTypeCode = 'mwallet')
DECLARE @languageId NVARCHAR (200) = ( SELECT languageId FROM core.language WHERE iso2Code = 'en')
DECLARE @kycId NVARCHAR (200) = ( SELECT kycId FROM customer.kyc WHERE display = 'Level 0' AND organizationId = @branchId AND isDeleted = 0)
DECLARE @currencyId NVARCHAR (200) = ( SELECT a.currencyId FROM core.currency a JOIN core.itemname b ON b.itemnameid = a.itemnameid WHERE b.itemname = 'USD')
DECLARE @customerType NVARCHAR (200) = ( SELECT customerTypeId FROM customer.customerType WHERE customerTypeId = 'individual')
DECLARE @customerStatusId NVARCHAR (200) = ( SELECT statusId FROM core.status WHERE statusId = 'approved')
DECLARE @customerStateId NVARCHAR (200) = ( SELECT stateId FROM customer.state WHERE stateId = 'up_to_date')
DECLARE @policyId NVARCHAR (200) = ( SELECT policyId FROM policy.policy WHERE name = 'STD')
DECLARE @mnoId NVARCHAR (200) = ( SELECT mnoId FROM customer.mno WHERE name = 'Airtel Madagascar' )
DECLARE @phoneTypeId NVARCHAR (200) = ( SELECT phoneTypeId FROM customer.phonetype WHERE phoneTypeId = 'personal' )
DECLARE @phoneStatusId NVARCHAR (200) = ( SELECT statusId FROM core.status WHERE statusId = 'approved' )
DECLARE @attachmentSizeId NVARCHAR (200) = ( SELECT attachmentSizeId FROM document.attachmentSize WHERE attachmentSizeId = 'original' )
DECLARE @roleID NVARCHAR (200) = 'MobileClient'

MERGE INTO [core].[configuration] AS target
USING
(VALUES
    ('policyIdSelfAdd', @policyId, 'Default policy user for self registration'),
    ('accountTypeIdSelfAdd', @accountTypeId, 'Default account type user for self registration'),
    ('languageIdSelfAdd', @languageId, 'Default lenguage user for self registration'),
    ('currencyIdSelfAdd', @currencyId, 'Default currency for self registration'),
    ('customerStateIdSelfAdd', @customerStateId, 'Default customer state for self registration'),
    ('customerStatusIdSelfAdd', @customerStatusId, 'Default customer status for self registration'),
    ('customerKycIdSelfAdd', @kycId, 'Default Kyc user for self registration'),
    ('customerTypeSelfAdd', @customerType, 'Default customer type for self registration'),
    ('customerbranchSelfAdd', @branchId, 'Default customer branch (HO) for self registration'),
    ('mnoSelfAdd', @mnoId, 'Default mno for self registration'),
    ('phoneTypeIdSelfAdd', @phoneTypeId, 'Default phone type for self registration'),
    ('phoneStatusIdSelfAdd', @phoneStatusId, 'Default phone status for self registration'),
    ('attachmentSizeSelfAdd', @attachmentSizeId, 'Default attachment size used for self registration'),
    ('roleIdForSelfAdd', @roleID, 'Default role for customer registered under self registration'),
    ('openReferralLimitation', '10', 'Referrals limitation to an individual customer'),
    ('referralPeriodExpiration', '10', 'Referrals period limitation to open an account and the minimum deposit'),
    ('KYCLevelForBranchesDepth', '2', 'On which depth in hierarchy of the branches are defined the KYC levels'),
    ('CBSforBranchesDepth', '2', 'On which depth in hierarchy of the branches are defined the CBS sytems'),
    ('DisableCustomerM/C', '0', 'Option to ban (Maker - Checker) functionalities for cusmtomer'),
    ('DisableAccountM/C', '0', 'Option to ban (Maker - Checker) functionalities for account')
) AS source ([key], [value], [description])
ON target.[key] = source.[key]
WHEN MATCHED THEN
    UPDATE SET target.[value] = source.[value]
WHEN NOT MATCHED BY TARGET THEN
    INSERT ([key], [value], [description])
    VALUES ([key], [value], [description]);
