DECLARE @australiaBU BIGINT, @egyptBU BIGINT, @ghanaBU BIGINT, @indiaBU BIGINT, @kenyaBU BIGINT, @mexicoBU BIGINT, @philippinesBU BIGINT, @usaBU BIGINT, @bulgariaBU BIGINT, @ibBU BIGINT
DECLARE @sg BIGINT = (SELECT actorId FROM customer.organization WHERE organizationName = 'Software Group')
DECLARE @countryId INT
DECLARE @mustUpdate BIT = 0

IF NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName = 'Software Group')
    AND NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName LIKE 'Software Group deleted%')
BEGIN
    SET @mustUpdate = 1
    INSERT INTO core.actor(actorType, isEnabled) VALUES('organization', 1)
    SET @sg = SCOPE_IDENTITY()

    INSERT INTO [customer].[organization] ([actorId], [organizationName], isEnabled, isDeleted)
    VALUES (@sg, N'Software Group', 1, 0)
END

IF NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName = 'Bulgaria')
    AND NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName LIKE 'Bulgaria deleted%')
BEGIN
    SET @mustUpdate = 1
    INSERT INTO core.actor(actorType, isEnabled) VALUES('organization', 1)
    SET @bulgariaBU = SCOPE_IDENTITY()

    SET @countryId = (SELECT countryId FROM core.country WHERE name = 'Bulgaria')

    INSERT INTO [customer].[organization] ([actorId], [organizationName], isEnabled, isDeleted, countryId)
    VALUES (@bulgariaBU, N'Bulgaria', 1, 0, @countryId)

    INSERT INTO core.actorHierarchy(subject, predicate, object) VALUES(@bulgariaBU, 'memberOf', @sg)
END


IF NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName = 'Australia')
    AND NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName LIKE 'Australia deleted%')
BEGIN
    SET @mustUpdate = 1
    INSERT INTO core.actor(actorType, isEnabled) VALUES('organization', 1)
    SET @australiaBU = SCOPE_IDENTITY()

    SET @countryId = (SELECT countryId FROM core.country WHERE name = 'Australia')

    INSERT INTO [customer].[organization] ([actorId], [organizationName], isEnabled, isDeleted, countryId)
    VALUES (@australiaBU, N'Australia', 1, 0, @countryId)

    INSERT INTO core.actorHierarchy(subject, predicate, object) VALUES(@australiaBU, 'memberOf', @sg)
END

IF NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName = 'Egypt')
    AND NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName LIKE 'Egypt deleted%')
BEGIN
    SET @mustUpdate = 1
    INSERT INTO core.actor(actorType, isEnabled) VALUES('organization', 1)
    SET @egyptBU = SCOPE_IDENTITY()

    SET @countryId = (SELECT countryId FROM core.country WHERE name = 'Egypt')

    INSERT INTO [customer].[organization] ([actorId], [organizationName], isEnabled, isDeleted, countryId)
    VALUES (@egyptBU, N'Egypt', 1, 0, @countryId)

    INSERT INTO core.actorHierarchy(subject, predicate, object) VALUES(@egyptBU, 'memberOf', @sg)
END

IF NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName = 'Ghana')
    AND NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName LIKE 'Ghana deleted%')
BEGIN
    SET @mustUpdate = 1
    INSERT INTO core.actor(actorType, isEnabled) VALUES('organization', 1)
    SET @ghanaBU = SCOPE_IDENTITY()

    SET @countryId = (SELECT countryId FROM core.country WHERE name = 'Ghana')

    INSERT INTO [customer].[organization] ([actorId], [organizationName], isEnabled, isDeleted, countryId)
    VALUES (@ghanaBU, N'Ghana', 1, 0, @countryId)

    INSERT INTO core.actorHierarchy(subject, predicate, object) VALUES(@ghanaBU, 'memberOf', @sg)
END

IF NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName = 'India')
    AND NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName LIKE 'India deleted%')
BEGIN
    SET @mustUpdate = 1
    INSERT INTO core.actor(actorType, isEnabled) VALUES('organization', 1)
    SET @indiaBU = SCOPE_IDENTITY()

    SET @countryId = (SELECT countryId FROM core.country WHERE name = 'India')

    INSERT INTO [customer].[organization] ([actorId], [organizationName], isEnabled, isDeleted, countryId)
    VALUES (@indiaBU, N'India', 1, 0, @countryId)

    INSERT INTO core.actorHierarchy(subject, predicate, object) VALUES(@indiaBU, 'memberOf', @sg)
END

IF NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName = 'Kenya')
    AND NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName LIKE 'Kenya deleted%')
BEGIN
    SET @mustUpdate = 1
    INSERT INTO core.actor(actorType, isEnabled) VALUES('organization', 1)
    SET @kenyaBU = SCOPE_IDENTITY()

    SET @countryId = (SELECT countryId FROM core.country WHERE name = 'Kenya')

    INSERT INTO [customer].[organization] ([actorId], [organizationName], isEnabled, isDeleted, countryId)
    VALUES (@kenyaBU, N'Kenya', 1, 0, @countryId)

    INSERT INTO core.actorHierarchy(subject, predicate, object) VALUES(@kenyaBU, 'memberOf', @sg)
END

IF NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName = 'Mexico')
    AND NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName LIKE 'Mexico deleted%')
BEGIN
    SET @mustUpdate = 1
    INSERT INTO core.actor(actorType, isEnabled) VALUES('organization', 1)
    SET @mexicoBU = SCOPE_IDENTITY()

    SET @countryId = (SELECT countryId FROM core.country WHERE name = 'Mexico')

    INSERT INTO [customer].[organization] ([actorId], [organizationName], isEnabled, isDeleted, countryId)
    VALUES (@mexicoBU, N'Mexico', 1, 0, @countryId)

    INSERT INTO core.actorHierarchy(subject, predicate, object) VALUES(@mexicoBU, 'memberOf', @sg)
END

IF NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName = 'Philippines')
    AND NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName LIKE 'Philippines deleted%')
BEGIN
    SET @mustUpdate = 1
    INSERT INTO core.actor(actorType, isEnabled) VALUES('organization', 1)
    SET @philippinesBU = SCOPE_IDENTITY()

    SET @countryId = (SELECT countryId FROM core.country WHERE name = 'Philippines')

    INSERT INTO [customer].[organization] ([actorId], [organizationName], isEnabled, isDeleted, countryId)
    VALUES (@philippinesBU, N'Philippines', 1, 0, @countryId)

    INSERT INTO core.actorHierarchy(subject, predicate, object) VALUES(@philippinesBU, 'memberOf', @sg)
END

IF NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName = 'USA')
    AND NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName LIKE 'USA deleted%')
BEGIN
    SET @mustUpdate = 1
    INSERT INTO core.actor(actorType, isEnabled) VALUES('organization', 1)
    SET @usaBU = SCOPE_IDENTITY()

    SET @countryId = (SELECT countryId FROM core.country WHERE name = 'United States of America')

    INSERT INTO [customer].[organization] ([actorId], [organizationName], isEnabled, isDeleted, countryId)
    VALUES (@usaBU, N'USA', 1, 0, @countryId)

    INSERT INTO core.actorHierarchy(subject, predicate, object) VALUES(@usaBU, 'memberOf', @sg)
END

IF NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName = 'Internet Banking')
    AND NOT EXISTS(SELECT * FROM customer.organization WHERE organizationName LIKE 'Internet Banking deleted%')
BEGIN
    SET @mustUpdate = 1
    INSERT INTO core.actor(actorType, isEnabled) VALUES('organization', 1)
    SET @ibBU = SCOPE_IDENTITY()

    INSERT INTO [customer].[organization] ([actorId], [organizationName], isEnabled, isDeleted)
    VALUES (@ibBU, N'Internet Banking', 1, 0)

    INSERT INTO core.actorHierarchy(subject, predicate, object) VALUES(@ibBU, 'memberOf', @sg)
END

IF @mustUpdate = 1

    MERGE INTO [customer].[organizationHierarchyFlat] AS target
    USING
    (
        SELECT a.actorId AS [subject], h.parentActorId, h.actorId AS [object], h.depth AS [relationDepth]
        FROM customer.organization a
        CROSS APPLY [customer].[organizationsVisibleForFlat](a.actorId) h
    ) AS SOURCE ([subject], [parentActorId], [object], [relationDepth])
    ON target.[subject] = source.[subject]
        AND target.[parentActorId] = source.[parentActorId]
        AND target.[object] = source.[object]
    WHEN MATCHED AND (target.[relationDepth] <> SOURCE.[relationDepth] ) THEN
        UPDATE SET target.[relationDepth] = SOURCE.[relationDepth]
    WHEN NOT MATCHED BY SOURCE THEN
	   DELETE
    WHEN NOT MATCHED BY TARGET THEN
        INSERT ([subject], [parentActorId], [object], [relationDepth])
        VALUES (SOURCE.[subject], SOURCE.[parentActorId], SOURCE.[object], SOURCE.[relationDepth]);
