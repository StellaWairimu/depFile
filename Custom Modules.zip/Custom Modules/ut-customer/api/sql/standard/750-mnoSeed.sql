-- insert MNO
DECLARE @countrySenegal INT = (SELECT countryId FROM core.country WHERE name = 'Senegal')
DECLARE @countryTunisia INT = (SELECT countryId FROM core.country WHERE name = 'tunisia')
DECLARE @countryIvory INT = (SELECT countryId FROM core.country WHERE name = 'Ivory Coast')
DECLARE @countryMali INT = (SELECT countryId FROM core.country WHERE name = 'Mali')
DECLARE @countryMadagascar INT = (SELECT countryId FROM core.country WHERE name = 'Madagascar')
DECLARE @countryBulgaria INT = (SELECT countryId FROM core.country WHERE name = 'Bulgaria')
DECLARE @countryGhana INT = (SELECT countryId FROM core.country WHERE name = 'Ghana')

MERGE INTO customer.mno AS target
USING
    (VALUES
        (@countrySenegal, 'Orange Senegal', 'active', 'sms/senegal'),
        (@countryTunisia, 'Landosi L-2T Tunisia', 'active', 'sms/tunisia'),
        (@countryIvory, 'SMS Pro Ivory Coast', 'active', 'sms/ivoryCoast'),
        (@countryMali, 'Orange Mali', 'active', 'sms/mali'),
        (@countryMadagascar, 'Airtel Madagascar', 'active', 'sms/madagascar'),
        (@countryBulgaria, 'Mtel Bulgaria', 'active', 'sms/Mtel'),
        (@countryBulgaria, 'Vivacom Bulgaria', 'active', 'sms/Vivacom'),
        (@countryGhana, 'Ghana Telecom', 'active', 'sms/GhanaTelecom')
    ) AS source (countryId, name, statusId, ut5Key)
ON target.ut5Key = source.ut5Key
WHEN NOT MATCHED BY TARGET THEN
    INSERT (countryId, name, statusId, ut5Key)
    VALUES (countryId, name, statusId, ut5Key);
