DECLARE @itemNameTranslationTT core.itemNameTranslationTT
DECLARE @meta core.metaDataTT

DECLARE @enLanguageId [TINYINT] = (SELECT languageId FROM [core].[language] WHERE iso2Code = 'en');
DECLARE @frLanguageId [TINYINT] = (SELECT languageId FROM [core].[language] WHERE iso2Code = 'fr');
DECLARE @cnLanguageId [TINYINT] = (SELECT languageId FROM [core].[language] WHERE iso2Code = 'cn');

DECLARE @itemNameId BIGINT
DECLARE @parentItemNameId BIGINT

--county

IF NOT EXISTS (SELECT * FROM [core].[itemType] WHERE [name] = 'county')
BEGIN
    INSERT INTO [core].[itemType]([alias], [name], [description], [TABLE], [keyColumn], [nameColumn])
    VALUES('county', 'county', 'county', NULL, 'itemCode', 'itemName')
END

DELETE FROM @itemNameTranslationTT
INSERT INTO @itemNameTranslationTT(itemCode, itemName, itemNameTranslation, parentItemType, parentItemName )
VALUES
    (NULL, 'Burgas', 'Burgas', 'country', 'Bulgaria' ),
    (NULL, 'Turgoviste', 'Turgoviste', 'country', 'Bulgaria')

EXEC core.[itemNameTranslation.upload]
    @itemNameTranslationTT = @itemNameTranslationTT,
    @languageId = @enLanguageId,
    @organizationId = NULL,
    @itemType = 'county',
    @meta = @meta

--city
IF NOT EXISTS (SELECT * FROM [core].[itemType] WHERE [name] = 'city')
BEGIN
    INSERT INTO [core].[itemType]([alias], [name], [description], [table], [keyColumn], [nameColumn])
    VALUES('city', 'city', 'city', NULL, 'itemCode', 'itemName')
END

DELETE FROM @itemNameTranslationTT
INSERT INTO @itemNameTranslationTT(itemCode, itemName, itemNameTranslation, parentItemType, parentItemName)
VALUES
    (NULL, 'Burgas', 'Burgas', 'county', 'Burgas'),
    (NULL, 'Aitos', 'Aitos', 'county', 'Burgas'),
    (NULL, 'Karnobat', 'Karnobat', 'county', 'Burgas'),
    (NULL, 'Turgoviste', 'Turgoviste', 'county', 'Turgoviste'),
    (NULL, 'Popovo', 'Popovo', 'county', 'Turgoviste')

EXEC core.[itemNameTranslation.upload]
    @itemNameTranslationTT = @itemNameTranslationTT,
    @languageId = @enLanguageId,
    @organizationId = NULL,
    @itemType = 'city',
    @meta = @meta
