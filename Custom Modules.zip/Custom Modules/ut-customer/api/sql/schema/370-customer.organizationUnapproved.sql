CREATE TABLE customer.organizationUnapproved( -- table that stores information about all unapproved organizations
    organizationUnapprovedId BIGINT IDENTITY(1, 1) NOT NULL, -- the id of the unapproved record
    actorId BIGINT NOT NULL, -- the id of the organization
    frontEndRecordId VARCHAR (10), -- an id, needed for the frontend of the mobile app
    organizationName NVARCHAR (100) NOT NULL, -- the name of the organization
    code NVARCHAR(50) NULL, -- the code of the organization
    executiveOfficer NVARCHAR(255) NULL, -- the name of the executive officer of the organization
    tradeName NVARCHAR(50) NULL, -- the trade name of the organization
    capital NVARCHAR(50) NULL, -- the capital of the organization
    currency VARCHAR(3) NULL, -- the currency of the organization
    timeZone VARCHAR(50) NULL, -- the time zone of the organization
    primaryLanguageId BIGINT NULL, -- the primary language id of the organization
    oldValues XML NULL, -- history of previous values of organization information
    isEnabled BIT NOT NULL DEFAULT(1), -- a flag to show if the organization is enabled or locked
    isDeleted BIT NOT NULL DEFAULT(0), -- a flag to show if the organization is deleted or active
    cbsId INT NULL, -- the core banking system id, relevant to the organization
    countryId INT NULL, -- the country where the organization is
    [updatedBy] BIGINT NOT NULL, -- the id of the user updating the user
    [updatedOn] DATETIMEOFFSET(7) NOT NULL, -- the datetime the user si updated on
    [statusId] VARCHAR(20) NOT NULL, -- the status of the unapproved record
    [rejectReason] NVARCHAR(MAX) NULL, -- the reason for rejecting unapproved record
    organizationTypeId TINYINT NOT NULL DEFAULT(1), -- the id of organization type
    [description] NVARCHAR(1000) NULL, -- description of the organization
    CONSTRAINT pkCustomerOrganizationUnapproved PRIMARY KEY CLUSTERED(organizationUnapprovedId ASC),
    CONSTRAINT fkCustomerOrganizationUnapproved_coreActor FOREIGN KEY(actorId) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerOrganizationUnapproved_updatedByCoreActor FOREIGN KEY(updatedBy) REFERENCES core.actor (actorId),
    CONSTRAINT fkcustomerOrganizationUnapproved_cbsId FOREIGN KEY(cbsId) REFERENCES core.[cbs] (cbsId),
    CONSTRAINT fkCustomerOrganizationUnapproved_customerCountry FOREIGN KEY(countryId) REFERENCES core.country (countryId),
    CONSTRAINT fkCustomerOrganizationUnapproved_coreStatus FOREIGN KEY(statusId) REFERENCES core.[status] (statusId),
    CONSTRAINT fkCustomerOrganizationUnapproved_organizationType FOREIGN KEY(organizationTypeId) REFERENCES customer.organizationType (organizationTypeId)
)
