CREATE TABLE [customer].[organizationType]( -- table that stores organization types
    organizationTypeId TINYINT NOT NULL, -- the id of the organization type, e.g. client
    organizationType VARCHAR (20) NOT NULL, -- the the organization type
    CONSTRAINT [pkCustomerOrganizationType] PRIMARY KEY (organizationTypeId)
)
