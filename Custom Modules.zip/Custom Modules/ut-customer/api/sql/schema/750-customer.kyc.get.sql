ALTER PROCEDURE [customer].[kyc.get] -- this sp gets all properties for a KYC level setup
    @kycId SMALLINT, -- the id of the KYC level
    @meta core.metaDataTT READONLY -- information for the logged user
AS
BEGIN TRY
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    DECLARE @languageId BIGINT = (
        SELECT languageId
        FROM [core].[language] cl
        JOIN [user].[session] us ON us.[language] = cl.[iso2Code]
        WHERE us.[actorId] = @userId)

    --check if user has access to the organization
    IF NOT EXISTS(
        SELECT o.actorId
        FROM customer.organizationsVisibleFor(@userId) o
        JOIN customer.kyc k ON o.actorId = k.organizationId
        WHERE k.kycId = @kycId)
        BEGIN
            RAISERROR('customer.securityViolation', 16, 1)
        END

    SELECT 'kyc' AS resultSetName

    SELECT
        k.kycId, k.itemNameId, cin.itemCode, it.itemNameTranslation AS displayName, k.[description], k.statusId, ct.customerTypeId,
        ct.[description] AS customerType, ct.customerTypeNumber, k.organizationId, o.organizationName
    FROM [customer].[kyc] k
    JOIN [customer].[customerType] ct ON k.customerTypeId = ct.customerTypeNumber
    JOIN [customer].[organization] o ON k.organizationId = o.actorId
    JOIN core.itemTranslation it ON it.itemNameId = k.itemNameId AND it.languageId = @languageId
    JOIN core.itemName cin ON cin.itemNameId = k.itemNameId
    WHERE k.kycId = @kycId AND k.isDeleted = 0

    SELECT 'kycAttributes' AS resultSetName

    SELECT kycConditionAttributeId, conditionId, attributeId, itemCode, itemNameTranslation, conditionCheck
    FROM [customer].[kycConditionAttribute] kca
    JOIN [customer].[kyc] k ON k.kycId = kca.kycId
    JOIN core.itemName cin ON cin.itemNameId = kca.attributeId
    JOIN core.itemTranslation it ON it.itemNameId = kca.attributeId AND it.languageId = @languageId
    WHERE k.kycId = @kycId AND k.isDeleted = 0
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
