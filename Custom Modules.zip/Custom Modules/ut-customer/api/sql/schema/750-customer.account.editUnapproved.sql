ALTER PROCEDURE [customer].[account.editUnapproved]
    @account customer.accountUnapprovedTT READONLY,
    @noResultSet BIT = 0,
    @meta core.metaDataTT READONLY
AS
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
    DECLARE @actorId BIGINT = (SELECT TOP 1 actorId FROM @account)
    DECLARE @result customer.accountUnapprovedTT
    SET @noResultSet = ISNULL(@noResultSet, 0)
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    BEGIN TRANSACTION

        DELETE a
        FROM [customer].[accountUnapproved] a
        LEFT JOIN @account aa ON a.accountUnapprovedId = aa.accountUnapprovedId
        WHERE a.actorId = @actorId AND aa.accountUnapprovedId IS NULL

        UPDATE t
        SET t.actorId = s.actorId,
            t.accountTypeId = s.accountTypeId,
            t.accountName = s.accountName,
            t.statusId = ISNULL(s.statusId, 'active'),
            t.updatedBy = @userId,
            t.updatedOn = SYSDATETIMEOFFSET()
        OUTPUT INSERTED.* INTO @result
        FROM customer.accountUnapproved t
        JOIN @account s ON t.accountUnapprovedId = s.accountUnapprovedId

        INSERT INTO [customer].[accountUnapproved] (accountId, actorId, frontEndRecordId, accountTypeId, accountNumber, accountName, statusId, oldValues, currencyId, balance, accountOpenedOn, accountLastTrx, accountLastTrxOn, isDeleted, updatedBy, updatedOn)
        OUTPUT INSERTED.* INTO @result
        SELECT a.accountId, a.actorId, a.frontEndRecordId, a.accountTypeId, a.accountNumber, a.accountName, ISNULL(a.statusId, 'active'), a.oldValues, a.currencyId, a.balance, a.accountOpenedOn, a.accountLastTrx, a.accountLastTrxOn, 0, @userId, SYSDATETIMEOFFSET()
        FROM @account a
        WHERE a.accountUnapprovedId IS NULL

        INSERT INTO [customer].[accountUnapproved] (accountId, actorId, frontEndRecordId, accountTypeId, accountNumber, accountName, statusId, oldValues, currencyId, balance, accountOpenedOn, accountLastTrx, accountLastTrxOn, isDeleted, updatedBy, updatedOn)
        SELECT a.accountId, a.actorId, a.frontEndRecordId, a.accountTypeId, a.accountNumber, a.accountName, a.statusId, a.oldValues, a.currencyId, a.balance, a.accountOpenedOn, a.accountLastTrx, a.accountLastTrxOn, 1, @userId, SYSDATETIMEOFFSET()
        FROM [customer].[account] a
        LEFT JOIN @account aa ON a.accountId = aa.accountId
        WHERE a.actorId = @actorId AND aa.accountId IS NULL

    COMMIT TRANSACTION

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'account' AS resultSetName
        SELECT * FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
