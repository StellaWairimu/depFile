ALTER PROCEDURE [customer].[kycLevel.update]
    @actorId BIGINT,
    @kycId SMALLINT,
    @meta core.metaDataTT READONLY -- information for the logged user
AS

DECLARE @callParams XML

BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
        RETURN 55555

    UPDATE customer.customer
    SET kycId = ISNULL (@kycId, kycId)
    WHERE actorId = @actorId

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
