ALTER PROCEDURE [customer].[organizationHierarchyFlat.rebuild] -- rebuild the organization.hierarhyflat table
    @actorId BIGINT, -- the id of the organization which has been changed
    @actorIdParents core.arrayNumberList READONLY, -- the id of the organization in which a new element is added
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @TranCounter INT = @@TRANCOUNT

BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    IF @TranCounter = 0
        BEGIN TRANSACTION

            IF NOT EXISTS (SELECT * FROM @actorIdParents)
            BEGIN
                IF @actorId IS NULL -- When ParentIds and actorId are not provided we will rebuild all hierarchy
                BEGIN
                    DELETE FROM [customer].[organizationHierarchyFlat]

                    INSERT INTO [customer].[organizationHierarchyFlat] ([subject], [parentActorId], [object], [relationDepth])
                    SELECT a.actorId AS [subject], h.parentActorId, h.actorId AS [object], h.depth AS [relationDepth]
                    FROM customer.organization a
                    CROSS APPLY [customer].[organizationsVisibleForFlat](a.actorId) h
                    LEFT JOIN [customer].[organizationHierarchyFlat] ch ON ch.[subject] = a.actorId AND ch.[object] = h.actorId AND ch.[parentActorId] = h.parentActorId
                    WHERE ch.[subject] IS NULL
                END
                ELSE -- When ParentIds are not provided but actorId is populated we will delete hierarchy related to the actorid
                    DELETE FROM [customer].[organizationHierarchyFlat]
                    WHERE [object] = @actorId
            END
            ELSE -- When ParentIds and ActorId are populated we will rebuild provided relations
            BEGIN
                DELETE FROM [customer].[organizationHierarchyFlat]
                WHERE [object] = @actorId

                INSERT INTO [customer].[organizationHierarchyFlat] ([subject], [parentActorId], [object], [relationDepth])
                SELECT @actorId AS [subject], h.parentActorId, h.actorId AS [object], h.depth AS [relationDepth]
                FROM [customer].[organizationsVisibleForFlat](@actorId) h
                LEFT JOIN [customer].[organizationHierarchyFlat] ch ON ch.[subject] = @actorId AND ch.[object] = h.actorId AND ch.[parentActorId] = h.parentActorId
                WHERE ch.[subject] IS NULL

                INSERT INTO [customer].[organizationHierarchyFlat] ([subject], [object], [parentActorId], [relationDepth])
                SELECT [subject], @actorId AS [object], p.value AS parentActorId, relationDepth + 1 AS [relationDepth]
                FROM customer.organizationHierarchyFlat f
                JOIN @actorIdParents p ON p.value = f.object
            END

            IF @TranCounter = 0
        COMMIT TRANSACTION

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH

