ALTER PROCEDURE [customer].[phone.editApproved] -- edits phone information
    @actorId BIGINT, -- the id of the object that "owns" the phones
    @noResultSet BIT = 0, -- a flag to show if result is expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @result customer.phoneTT

BEGIN TRY
    DELETE p
    FROM customer.phone p
    LEFT JOIN customer.phoneUnapproved pu ON p.phoneId = pu.phoneId
    WHERE p.actorId = @actorId AND pu.phoneId IS NULL

    UPDATE t
    SET t.phoneTypeId = pu.phoneTypeId,
        t.phoneNumber = pu.phoneNumber,
        t.statusId = pu.statusId,
        t.mnoId = pu.mnoId,
        t.isPrimary = pu.isPrimary
    OUTPUT INSERTED.phoneId, INSERTED.actorId, INSERTED.phoneTypeId, INSERTED.phoneNumber, INSERTED.statusId, INSERTED.mnoId, INSERTED.isPrimary
    INTO @result (phoneId, actorId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary)
    FROM customer.phone t
    INNER JOIN customer.phoneUnapproved pu ON t.phoneId = pu.phoneId
    WHERE pu.actorId = @actorId

    INSERT INTO customer.phone (actorId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary)
    OUTPUT INSERTED.phoneId, INSERTED.actorId, INSERTED.phoneTypeId, INSERTED.phoneNumber, INSERTED.statusId, INSERTED.mnoId, INSERTED.isPrimary
    INTO @result (phoneId, actorId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary)
    SELECT actorId, phoneTypeId, phoneNumber, ISNULL(statusId, 'active'), mnoId, isPrimary
    FROM customer.phoneUnapproved pu
    WHERE pu.phoneId IS NULL AND pu.actorId = @actorId

    DELETE FROM customer.phoneUnapproved WHERE actorId = @actorId

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'phone' AS resultSetName
        SELECT phoneId, actorId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
