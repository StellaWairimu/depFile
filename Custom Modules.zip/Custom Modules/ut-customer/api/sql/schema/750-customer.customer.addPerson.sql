ALTER PROCEDURE [customer].[customer.addPerson] -- adds a new person with provided parameters
    @customer customer.customerTT READONLY, -- table with basic data about the new customer
    -----------------------------------------
    @person customer.personTT READONLY, -- table with personal information about the new customer, if it is a person
    -----------------------------------------
    @account customer.accountTT READONLY, -- information about the accounts of the customer
    @email customer.emailTT READONLY, -- information about the e-mails of the customer
    @phone customer.phoneTT READONLY, -- information about the phone numbers of the customer
    @address customer.addressTT READONLY, -- information about the addresses of the customer
    @document document.documentTT READONLY, --information about the document
    @attachment document.attachmentTT READONLY, --information about the document attachment
    @actorDocument [document].[actorDocumentTT] READONLY, --information about the document AND document order
    ------------------------------------------------
    @noResultSet BIT = 0, -- a flag to show if result is expected
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @actorId BIGINT OUT -- the id of the customer, that will be created
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user adding the customer
DECLARE
    @customerTT customer.customerTT,
    @personTT customer.personTT,
    @emailTT customer.emailTT,
    @phoneTT customer.phoneTT,
    @addressTT customer.addressTT,
    @actorDocumentTT document.actorDocumentTT,
    @accountTT customer.accountTT


BEGIN TRY
    -- checks IF the user has a RIGHT to ADD customers
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    IF ((SELECT COUNT( * ) FROM @customer) <> 1)
        RAISERROR('customer.customerDataNotSingle', 16, 1);

    IF NOT EXISTS (SELECT * FROM @person)
        RAISERROR('customer.personNotSingle', 16, 1);

    IF CAST(DATEADD(YEAR, 18, (SELECT dateOfBirth FROM @person)) AS DATE) > CAST(GETDATE() AS DATE)
    RAISERROR('customer.wrongDateOfBirth', 16, 1);
    --unsert INTO new customer temp TABLE
    INSERT INTO @customerTT (actorId, frontEndRecordId, customerNumber, customerTypeId, kycId, stateId, statusId, createdBy, createdOn, updatedBy, updatedOn, oldValues, customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee, udf)
    SELECT actorId, frontEndRecordId, customerNumber, customerTypeId, kycId, stateId, statusId, createdBy, createdOn, updatedBy, updatedOn, oldValues, customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee, udf FROM @customer


    IF EXISTS (SELECT * FROM @customer WHERE kycId IS NULL)
    BEGIN
        DECLARE @KYC SMALLINT = 1
        /*(SELECT min (kycId) FROM customer.kyc )*/
        UPDATE @customerTT SET kycId = @KYC WHERE kycId IS NULL
    END
        --get customer organization
    IF EXISTS (SELECT * FROM @customerTT WHERE organizationId IS NULL )
        BEGIN
            UPDATE @customerTT SET organizationId = (
                SELECT TOP 1 ah.[object]
                FROM core.actorHierarchy ah
                JOIN customer.organization o ON o.actorId = ah.[object] AND o.isEnabled = 1
                WHERE [subject] = @userId AND predicate = 'memberOf')
        END

    INSERT INTO @emailTT SELECT * FROM @email
    INSERT INTO @phoneTT SELECT * FROM @phone
    INSERT INTO @addressTT SELECT * FROM @address
    INSERT INTO @personTT SELECT * FROM @person
    INSERT INTO @actorDocumentTT SELECT * FROM @actorDocument
    INSERT INTO @accountTT SELECT * FROM @account

    DECLARE @TranCounter INT = @@TRANCOUNT
    IF @TranCounter = 0
        BEGIN TRANSACTION;

            EXEC [core].[actor.add]
                @actorType = 'person',
                @actorId = @actorId OUT,
                @meta = @meta

            UPDATE @customerTT SET actorId = @actorId
            UPDATE @personTT SET actorId = @actorId
            UPDATE @emailTT SET actorId = @actorId
            UPDATE @phoneTT SET actorId = @actorId
            UPDATE @addressTT SET actorId = @actorId
            UPDATE @customerTT SET statusId = 'approved' WHERE statusId IS NULL
            UPDATE @customerTT SET stateId = 'pending' WHERE stateId IS NULL
            UPDATE @accountTT SET actorId = @actorId

            EXEC customer.[person.add]
                @person = @personTT,
                @email = @emailTT,
                @phone = @phoneTT,
                @address = @addressTT,
                @account = @accountTT,
                @noResultSet = 1,
                @meta = @meta

            INSERT INTO [customer].[customer] SELECT * FROM @customerTT

            IF EXISTS (SELECT * FROM @document)
            BEGIN
                UPDATE @actorDocumentTT SET actorId = @actorId
                EXEC [document].[document.add]
                    @actorId = @actorId,
                    @document = @document,
                    @attachment = @attachment,
                    @actorDocument = @actorDocument,
                    @noResultSet = 1,
                    @meta = @meta
            END

            --IF (ISNULL(@noResultSet, 0) = 0)
            --BEGIN
            --    SELECT 'customer' AS resultSetName
            --    SELECT * FROM @customerTT
            --END

            EXEC core.auditCall
                @procid = @@procId,
                @params = @callParams

            IF @TranCounter = 0
        COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@tranCount > 0
        ROLLBACK TRANSACTION;
    EXEC core.error
END CATCH;
