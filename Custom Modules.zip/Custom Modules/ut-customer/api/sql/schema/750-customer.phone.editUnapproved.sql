ALTER PROCEDURE [customer].[phone.editUnapproved] -- edits phone information
    @phone customer.phoneUnapprovedTT READONLY, -- the edited phone information
    @actorId BIGINT, -- customer id
    @noResultSet BIT = 0, -- a flag to show if result is expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @result customer.phoneUnapprovedTT

BEGIN TRY
    DELETE p
    FROM [customer].[phoneUnapproved] p
    LEFT JOIN @phone pp ON p.phoneUnapprovedId = pp.phoneUnapprovedId
    WHERE p.actorId = @actorId AND pp.phoneUnapprovedId IS NULL

    -- re-edit new AND existing phones IN the unapproved TABLE
    UPDATE t
    SET t.phoneTypeId = s.phoneTypeId,
        t.phoneNumber = s.phoneNumber,
        t.statusId = s.statusId,
        t.mnoId = s.mnoId,
        t.isPrimary = s.isPrimary,
        t.updatedBy = @userId,
        t.updatedOn = SYSDATETIMEOFFSET()
    OUTPUT INSERTED.phoneId, INSERTED.actorId, INSERTED.phoneTypeId, INSERTED.phoneNumber, INSERTED.statusId, INSERTED.mnoId, INSERTED.isPrimary
    INTO @result (phoneId, actorId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary)
    FROM customer.phoneUnapproved t
    JOIN @phone s ON s.phoneUnapprovedId = t.phoneUnapprovedId

    -- insert new or existing edited phones FOR approval
    INSERT INTO [customer].[phoneUnapproved] (phoneId, actorId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary, isDeleted, updatedBy, updatedOn)
    OUTPUT INSERTED.phoneId, INSERTED.actorId, INSERTED.phoneTypeId, INSERTED.phoneNumber, INSERTED.statusId, INSERTED.mnoId, INSERTED.isPrimary
    INTO @result (phoneId, actorId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary)
    SELECT ph.phoneId, ph.actorId, ph.phoneTypeId, ph.phoneNumber, ISNULL(ph.statusId, 'active'), ph.mnoId, ph.isPrimary, 0, @userId, SYSDATETIMEOFFSET()
    FROM @phone ph
    WHERE ph.phoneUnapprovedId IS NULL

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'phone' AS resultSetName
        SELECT phoneId, actorId, frontEndRecordId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
