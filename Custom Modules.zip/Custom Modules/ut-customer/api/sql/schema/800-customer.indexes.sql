IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_customer_customerNumber_organizationId')
    CREATE NONCLUSTERED INDEX [IX_customer_customerNumber_organizationId] ON [customer].[customer] ([customerNumber], organizationId)
ELSE
BEGIN
    IF (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_customer_customerNumber_organizationId' AND ic.index_column_id = 1) != 'customerNumber'
    OR (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_customer_customerNumber_organizationId' AND ic.index_column_id = 2) != 'organizationId'
    BEGIN
        DROP INDEX [IX_customer_customerNumber_organizationId] ON [customer].[customer]

        CREATE NONCLUSTERED INDEX [IX_customer_customerNumber_organizationId] ON [customer].[customer] ([customerNumber], organizationId)
    END
END


IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_customer_organizationId')
    CREATE NONCLUSTERED INDEX [IX_customer_organizationId] ON [customer].[customer] ([organizationId]) INCLUDE ([countryId], [customerNumber], [stateId], [industryId], [sectorId])
ELSE
BEGIN
    IF (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_customer_organizationId' AND ic.index_column_id = 1) != 'organizationId'
    OR NOT EXISTS (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_customer_organizationId' AND c.name = 'countryId')
    OR NOT EXISTS (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_customer_organizationId' AND c.name = 'customerNumber')
    OR NOT EXISTS (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_customer_organizationId' AND c.name = 'stateId')
    OR NOT EXISTS (
        SELECT 1 FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_customer_organizationId' AND c.name = 'industryId')
    OR NOT EXISTS (
        SELECT 1 FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_customer_organizationId' AND c.name = 'sectorId')
    BEGIN
        DROP INDEX [IX_customer_organizationId] ON [customer].[customer]

        CREATE NONCLUSTERED INDEX [IX_customer_organizationId] ON [customer].[customer] ([organizationId]) INCLUDE ([countryId], [customerNumber], [stateId], [industryId], [sectorId])
    END
END

-- [customer].[address]
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_address_actorId_statusId_addressTypeId')
    CREATE NONCLUSTERED INDEX [IX_address_actorId_statusId_addressTypeId] ON [customer].[address] (actorId, statusId, addressTypeId) INCLUDE ([value], city, lat, lng)
ELSE
BEGIN
    IF (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_address_actorId_statusId_addressTypeId' AND ic.index_column_id = 1) != 'actorId'
    OR (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_address_actorId_statusId_addressTypeId' AND ic.index_column_id = 2) != 'statusId'
    OR (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_address_actorId_statusId_addressTypeId' AND ic.index_column_id = 3) != 'addressTypeId'
    OR NOT EXISTS (
        SELECT 1 FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_address_actorId_statusId_addressTypeId' AND c.name = 'value')
    OR NOT EXISTS (
        SELECT 1 FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_address_actorId_statusId_addressTypeId' AND c.name = 'city')
    OR NOT EXISTS (
        SELECT 1 FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_address_actorId_statusId_addressTypeId' AND c.name = 'lat')
    OR NOT EXISTS (
        SELECT 1 FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_address_actorId_statusId_addressTypeId' AND c.name = 'lng')
    BEGIN
        DROP INDEX [IX_address_actorId_statusId_addressTypeId] ON [customer].[address]
        CREATE NONCLUSTERED INDEX [IX_address_actorId_statusId_addressTypeId] ON [customer].[address] (actorId, statusId, addressTypeId) INCLUDE ([value], city, lat, lng)
    END
END

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_address_statusId_addressTypeId')
    CREATE NONCLUSTERED INDEX [IX_address_statusId_addressTypeId] ON [customer].[address]([statusId] ASC, [addressTypeId] ASC) INCLUDE ( [actorId], [value])
ELSE
BEGIN
    IF (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_address_statusId_addressTypeId' AND ic.index_column_id = 1) != 'statusId'
    OR (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_address_statusId_addressTypeId' AND ic.index_column_id = 2) != 'addressTypeId'
    OR NOT EXISTS (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_address_statusId_addressTypeId' AND c.name = 'actorId')
    OR NOT EXISTS (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_address_statusId_addressTypeId' AND c.name = 'value')
    BEGIN
        DROP INDEX [IX_address_statusId_addressTypeId] ON [customer].[address]

        CREATE NONCLUSTERED INDEX [IX_address_statusId_addressTypeId] ON [customer].[address]([statusId] ASC, [addressTypeId] ASC) INCLUDE ( [actorId], [value])
    END
END

--index for the flat hiearchy
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_organizationHierarchyFlat_object')
    CREATE NONCLUSTERED INDEX [IX_organizationHierarchyFlat_object] ON [customer].[organizationHierarchyFlat] ([object]) INCLUDE ([subject])
ELSE
BEGIN
    IF (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_organizationHierarchyFlat_object' AND ic.index_column_id = 1) != 'object'
    OR NOT EXISTS (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_organizationHierarchyFlat_object' AND c.name = 'subject')
    BEGIN
        DROP INDEX [IX_organizationHierarchyFlat_object] ON [customer].[organizationHierarchyFlat]

        CREATE NONCLUSTERED INDEX [IX_organizationHierarchyFlat_object] ON [customer].[organizationHierarchyFlat] ([object]) INCLUDE ([subject])
    END
END


-- [customer].[email]
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_email_actorId')
    CREATE NONCLUSTERED INDEX [IX_email_actorId] ON [customer].[email] ([actorId])
ELSE
BEGIN
    IF (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_email_actorId' AND ic.index_column_id = 1) != 'actorId'
    BEGIN
        DROP INDEX [IX_email_actorId] ON [customer].[email]

        CREATE NONCLUSTERED INDEX [IX_email_actorId] ON [customer].[email] ([actorId])
    END
END

-- [customer].[phone]
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_phone_phoneNumber')
    CREATE NONCLUSTERED INDEX [IX_phone_phoneNumber] ON [customer].[phone]([phoneNumber])
ELSE
BEGIN
    IF (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_phone_phoneNumber' AND ic.index_column_id = 1) != 'phoneNumber'
    BEGIN
        DROP INDEX [IX_phone_phoneNumber] ON [customer].[phone]

        CREATE NONCLUSTERED INDEX [IX_phone_phoneNumber] ON [customer].[phone]([phoneNumber])
    END
END

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_phone_statusId_phonetTypeId')
    CREATE NONCLUSTERED INDEX [IX_phone_statusId_phonetTypeId] ON [customer].[phone]([statusId] ASC, [phoneTypeId] ASC) INCLUDE ([actorId], [phoneNumber])
ELSE
BEGIN
    IF (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_phone_statusId_phonetTypeId' AND ic.index_column_id = 1) != 'statusId'
    OR (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_phone_statusId_phonetTypeId' AND ic.index_column_id = 2) != 'phoneTypeId'
    OR NOT EXISTS (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_phone_statusId_phonetTypeId' AND c.name = 'actorId')
    OR NOT EXISTS (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_phone_statusId_phonetTypeId' AND c.name = 'phoneNumber')
    BEGIN
        DROP INDEX [IX_phone_statusId_phonetTypeId] ON [customer].[phone]

        CREATE NONCLUSTERED INDEX [IX_phone_statusId_phonetTypeId] ON [customer].[phone]([statusId] ASC, [phoneTypeId] ASC) INCLUDE ([actorId], [phoneNumber])
    END
END

IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_phone_actorId')
    CREATE NONCLUSTERED INDEX [IX_phone_actorId] ON [customer].[phone]([actorId] ASC) INCLUDE ([phoneNumber], [phoneTypeId], [statusId])
ELSE
BEGIN
    IF (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_phone_actorId' AND ic.index_column_id = 1) != 'actorId'
    OR NOT EXISTS (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_phone_actorId' AND c.name = 'phoneNumber')
    OR NOT EXISTS (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_phone_actorId' AND c.name = 'phoneTypeId')
    OR NOT EXISTS (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 1
        WHERE i.name = 'IX_phone_actorId' AND c.name = 'statusId')
    BEGIN
        DROP INDEX [IX_phone_actorId] ON [customer].[phone]

        CREATE NONCLUSTERED INDEX [IX_phone_actorId] ON [customer].[phone]([actorId] ASC) INCLUDE ([phoneNumber], [phoneTypeId], [statusId])
    END
END

-- [customer].[person]
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_person_firstName_lastName_dateOfBirth')
    CREATE NONCLUSTERED INDEX [IX_person_firstName_lastName_dateOfBirth] ON [customer].[person] ([firstName], [lastName], [dateOfBirth])
ELSE
BEGIN
    IF (SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_person_firstName_lastName_dateOfBirth' AND ic.index_column_id = 1) != 'firstName'
    OR (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_person_firstName_lastName_dateOfBirth' AND ic.index_column_id = 2) != 'lastName'
    OR (
        SELECT c.name FROM sys.indexes i
        JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        JOIN sys.columns c ON C.object_id = I.object_id AND C.column_id = ic.column_id AND IC.is_included_column = 0
        WHERE i.name = 'IX_person_firstName_lastName_dateOfBirth' AND ic.index_column_id = 3) != 'dateOfBirth'
    BEGIN
        DROP INDEX [IX_person_firstName_lastName_dateOfBirth] ON [customer].[person]

        CREATE NONCLUSTERED INDEX [IX_person_firstName_lastName_dateOfBirth] ON [customer].[person] ([firstName], [lastName], [dateOfBirth])
    END
END

