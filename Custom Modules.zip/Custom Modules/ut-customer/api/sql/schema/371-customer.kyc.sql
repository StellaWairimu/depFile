CREATE TABLE customer.kyc( -- TABLE that stores Know Your Customer types
    kycId SMALLINT IDENTITY(0, 1) NOT NULL, -- Know Your Customer type id
    display VARCHAR (10) NOT NULL, -- Know Your Customer type displayed, e.g. 'Level 1', 'Pulse', 'Full KYC'
    [description] VARCHAR (100), -- Know Your Customer type description
    statusId VARCHAR (20) NOT NULL, -- Know Your Customer type statusId, e.g. active/inactive
    customerTypeId INT, -- Know Your Customer type customer type Id, e.g. 'individual', 'corporate'
    organizationId BIGINT, -- Know Your Customer type organization
    itemNameId BIGINT, -- the id if the item for translation
    isDeleted BIT NOT NULL DEFAULT(0), -- a flag to show if the kyc rule is deleted, e.g. 1 - Deleted
    createdBy BIGINT NULL, -- id of the actor
    createdOn DATETIME2 (0) NULL, -- date of the referral created
    updatedBy BIGINT NULL, -- id of the actor
    updatedOn DATETIME2 (0) NULL, --  date of the referral updated
    CONSTRAINT pkCustomerKyc PRIMARY KEY (kycId),
    CONSTRAINT fkCustomerKyc_coreStatus FOREIGN KEY(statusId) REFERENCES core.[status] (statusId),
    CONSTRAINT fkCustomerKyc_customerType FOREIGN KEY(customerTypeId) REFERENCES customer.[customerType] (customerTypeNumber),
    CONSTRAINT fkCustomerKyc_customerOrganization FOREIGN KEY(organizationId) REFERENCES customer.[organization] (actorId),
    CONSTRAINT fkCustomerKyc_itemName FOREIGN KEY(itemNameId) REFERENCES core.[itemName] (itemNameId)
)
