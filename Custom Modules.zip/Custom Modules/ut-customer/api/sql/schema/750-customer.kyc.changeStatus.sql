ALTER PROCEDURE [customer].[kyc.changeStatus] --the sp changes statuses of the selected kyc levels
    @kycList core.arrayNumberList READONLY, -- a list with kyc to activate/deactivate
    @isActive VARCHAR(20), -- to what status to put them - active or inactive
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
DECLARE @callParams XML
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    --check if user has access to the organization(s)
    IF EXISTS(
        SELECT o.actorId
        FROM @kycList kl
        JOIN customer.kyc k ON k.kycId = kl.value
        LEFT JOIN customer.organizationsVisibleFor(@userId) o ON o.actorId = k.organizationId
        WHERE o.actorId IS NULL)
        BEGIN
            RAISERROR('customer.securityViolation', 16, 1)
        END

    UPDATE x
    SET x.statusId = @isActive
    FROM [customer].kyc x
    JOIN @kycList ids ON x.kycId = ids.value

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
