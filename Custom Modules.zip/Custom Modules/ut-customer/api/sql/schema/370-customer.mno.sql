CREATE TABLE customer.mno( -- table that stores all Mobile Network Operators used in the system for sending sms
    mnoId TINYINT IDENTITY(1, 1) NOT NULL, -- the id of the Mobile Network Operator
    name NVARCHAR (50) NOT NULL, -- the name of the mno
    ut5Key VARCHAR(100), -- Name of the UT5 port
    statusId VARCHAR (20) NOT NULL, -- the statusId of the mno, e.g. active/inactive
    countryId INT, -- in which country operates the MNO
    CONSTRAINT pkCustomerMNO PRIMARY KEY CLUSTERED(mnoId ASC),
    CONSTRAINT fkCustomerMNO_customerCountry FOREIGN KEY(countryId) REFERENCES core.country (countryId),
    CONSTRAINT fkCustomerMNO_coreStatus FOREIGN KEY(statusId) REFERENCES core.[status] (statusId)
)
