CREATE TABLE customer.organization( -- table that stores information about all organizations
    actorId BIGINT NOT NULL, -- the id of the organization
    frontEndRecordId VARCHAR (10), -- an id, needed for the frontend of the mobile app
    organizationName NVARCHAR (100) NOT NULL, -- the name of the organization
    code NVARCHAR(50) NULL, -- the code of the organization
    executiveOfficer NVARCHAR(255) NULL, -- the name of the executive officer of the organization
    tradeName NVARCHAR(50) NULL, -- the trade name of the organization
    capital NVARCHAR(50) NULL, -- the capital of the organization
    currency VARCHAR(3) NULL, -- the currency of the organization
    timeZone VARCHAR(50) NULL, -- the time zone of the organization
    primaryLanguageId BIGINT NULL, -- the primary language id of the organization
    oldValues XML NULL, -- history of previous values of organization information
    isEnabled BIT NOT NULL DEFAULT(1), -- a flag to show if the organization is enabled or locked
    isDeleted BIT NOT NULL DEFAULT(0), -- a flag to show if the organization is deleted or active
    cbsId INT NULL, -- the core banking system id, relevant to the organization
    countryId INT NULL, -- the country where the organization is
    organizationTypeId TINYINT NOT NULL DEFAULT(1), -- the id of organization type,
    [description] NVARCHAR(1000) NULL, -- description of the organization
    CONSTRAINT pkCustomerOrganization PRIMARY KEY CLUSTERED(actorId ASC),
    CONSTRAINT fkCustomerOrganization_coreActor FOREIGN KEY(actorId) REFERENCES core.actor (actorId),
    CONSTRAINT fkcustomerOrganization_cbsId FOREIGN KEY(cbsId) REFERENCES core.[cbs] (cbsId),
    CONSTRAINT fkCustomerOrganization_customerCountry FOREIGN KEY(countryId) REFERENCES core.country (countryId),
    CONSTRAINT fkCustomerOrganization_organizationType FOREIGN KEY(organizationTypeId) REFERENCES customer.organizationType (organizationTypeId)
)
