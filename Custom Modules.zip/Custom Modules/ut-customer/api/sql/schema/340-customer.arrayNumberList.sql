CREATE TYPE [customer].[arrayNumberList] AS TABLE (
    [value] BIGINT
)
