ALTER PROCEDURE customer.[customer.reject] -- supports the reject functionality, where the checker rejects changes for the selected role
    @actorId BIGINT, -- the id of the role to be rejected
    @rejectReason NVARCHAR(MAX), -- the reason the role was rejected by the checker
    --@currentVersionUnapproved bigint, -- auto generated calumn, updated on every row change, used to check for modification on each dml operation in unapproved table
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
BEGIN TRY

    --DECLARE @currentVersionUnapprovedDb BIGINT = CONVERT(ROWVERSION, @currentVersionUnapproved)

    DECLARE @callParams XML
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@procId) + '.' + OBJECT_NAME(@@procId), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user adding the account

    -- check if the maker and the checker are different users
    IF EXISTS (
        SELECT c.updatedBy
        FROM [customer].[customerUnapproved] c
        LEFT JOIN [user].[vSystemUser] su ON su.actorid = c.updatedBy
        WHERE c.actorId = @actorId
            AND c.updatedBy = @userId
            AND su.actorid IS NULL)
        RAISERROR('customer.cannotPerformThisOperation', 16, 1)

    UPDATE a
    SET statusId = 'rejected',
        rejectReason = @rejectReason,
        updatedBy = @userId,
        a.updatedOn = GETDATE()
    FROM customer.customerUnapproved a
    WHERE actorId = @actorId --AND currentVersion = @currentVersionUnapprovedDb

    --IF @@rowCount = 0
    --    RAISERROR('ledger.notOnTheLatestVersion', 16, 1)

    EXEC core.auditCall @procid = @@procId, @params = @callParams
END TRY
BEGIN CATCH
    IF @@tranCount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
