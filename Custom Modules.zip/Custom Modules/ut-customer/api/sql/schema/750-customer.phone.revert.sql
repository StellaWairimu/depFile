ALTER PROCEDURE [customer].[phone.revert] -- validates the phone and updates it needed
    @actorId BIGINT, --the Id of the phone
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @phoneId BIGINT = (SELECT TOP 1 phoneId FROM customer.phone p WHERE actorId = @actorId AND statusId = 'approved')
DECLARE @oldPhoneNumber VARCHAR(50) = (
    SELECT m.c.value( '.', 'VARCHAR(50)')
    FROM customer.phone p
    OUTER APPLY p.oldValues.nodes('/udf/phoneNumber') AS m(c)
    WHERE p.phoneId = @phoneId)


BEGIN TRY
    IF @oldPhoneNumber IS NULL
    BEGIN
        DELETE p FROM customer.phone p WHERE p.phoneId = @phoneId
        RETURN
    END

    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0

    UPDATE p SET phoneNumber = @oldPhoneNumber FROM customer.phone p WHERE p.phoneId = @phoneId

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
