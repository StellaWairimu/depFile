CREATE TABLE [customer].[customerCategory]( -- table that stores customer categories, related to loans
    [customerCategoryId] SMALLINT NOT NULL, -- the id of the customer category, related to loans
    [name] [VARCHAR](50) NULL, -- the name of the customer category, related to loans - e.g. AAA, AA, monitored, etc.
    [description] [VARCHAR](100) NULL, -- the description of the customer category
    [statusId] [VARCHAR](20) NOT NULL, -- the statusId of the customer category, e.g. active/inactive
    CONSTRAINT [pkCustomerCustomerCategory] PRIMARY KEY CLUSTERED ([customerCategoryId]),
    CONSTRAINT [fkCustomerCustomerCategory_coreStatus] FOREIGN KEY([statusId]) REFERENCES [core].[status] ([statusId])
)
