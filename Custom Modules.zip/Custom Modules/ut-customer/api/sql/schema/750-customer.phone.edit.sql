ALTER PROCEDURE [customer].[phone.edit] -- edits phone information
    @phone customer.phoneUnapprovedTT READONLY, -- the edited phone information
    @actorId BIGINT, -- customer id
    @noResultSet BIT = 0, -- a flag to show if result is expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @result customer.phoneUnapprovedTT

BEGIN TRY
    DECLARE @tranCounter INT = @@TRANCOUNT;
    IF @tranCounter = 0
        BEGIN TRANSACTION
            DELETE p
            FROM customer.phone p
            LEFT JOIN @phone pp ON p.phoneId = pp.phoneId
            WHERE p.actorId = @actorId AND pp.phoneId IS NULL

            UPDATE t
            SET t.phoneTypeId = s.phoneTypeId,
            t.phoneNumber = s.phoneNumber,
            t.statusId = s.statusId,
            t.mnoId = s.mnoId,
            t.isPrimary = s.isPrimary
            OUTPUT INSERTED.phoneId, INSERTED.actorId, INSERTED.phoneTypeId, INSERTED.phoneNumber, INSERTED.statusId, INSERTED.mnoId, INSERTED.isPrimary
            INTO @result (phoneId, actorId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary)
            FROM customer.phone t
            INNER JOIN @phone s ON t.phoneId = s.phoneId

            INSERT INTO customer.phone (actorId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary)
            OUTPUT INSERTED.phoneId, INSERTED.actorId, INSERTED.phoneTypeId, INSERTED.phoneNumber, INSERTED.statusId, INSERTED.mnoId, INSERTED.isPrimary
            INTO @result (phoneId, actorId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary)
            SELECT actorId, phoneTypeId, phoneNumber, ISNULL(statusId, 'active'), mnoId, isPrimary
            FROM @phone p
            WHERE p.phoneId IS NULL

            IF @tranCounter = 0
        COMMIT TRANSACTION

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'phone' AS resultSetName
        SELECT phoneId, actorId, frontEndRecordId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
