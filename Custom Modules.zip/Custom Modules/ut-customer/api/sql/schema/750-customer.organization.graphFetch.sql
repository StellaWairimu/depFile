ALTER PROCEDURE [customer].[organization.graphFetch] -- returns the business units information for the logged user
    @parentFilter BIGINT, -- if passed returns all business units that are members of this unit
    @level TINYINT = 200, -- to reduce hierarchy
    @organizationTypeList core.arrayList READONLY, -- type of organizations to fetch
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS

SET NOCOUNT ON

DECLARE @organizationTypeIds core.arrayNumberList
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
---checks IF we have a level,THEN we take sa
-- IF @Level !=200 -- to be equal AS defoult @Level value
-- BEGIN
-- SET @userId = (SELECT TOP 1 [actorId]   FROM [user].[hash] WHERE identifier='sa') --!!!!!!! to see herarhy AS SA to level 4
-- END


-- checks if the user has a right to make the operation
DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
IF @return != 0
BEGIN
    RETURN 55555
END

IF NOT EXISTS(SELECT * FROM @organizationTypeList)
    INSERT INTO @organizationTypeIds
    SELECT organizationTypeId
    FROM customer.organizationType
    WHERE organizationType = ('businessUnit')
ELSE
    INSERT INTO @organizationTypeIds
    SELECT organizationTypeId
    FROM @organizationTypeList otl
    JOIN customer.organizationType ot ON ot.organizationType = otl.[value]

SELECT 'organization' AS resultSetName
/*
;WITH CTE AS
(
    SELECT mem.actorId AS id, o.organizationName AS title
    FROM core.membersVisibleFor(@userId) mem
    JOIN customer.organization o ON o.actorId = mem.actorId AND o.isEnabled = 1 AND o.isDeleted = 0
)

SELECT id, title, parents
FROM
(
    SELECT mem.id, title, (SELECT stuff((
            SELECT ',' + CONVERT(VARCHAR(20), ah.object)
            FROM core.actorHierarchy ah
            JOIN CTE memVis ON memVis.id = ah.object
            WHERE ah.predicate = 'memberOf' AND ah.subject = mem.id
            FOR XML PATH(''), type).value('.', 'VARCHAR(max)'), 1, 1, '')) AS parents
    FROM CTE mem
) m
WHERE @parentFilter IS NULL or charindex(',' + CONVERT(VARCHAR(20), @parentFilter) + ',', ',' + parents + ',') > 0 */


IF OBJECT_ID('tempdb..#organizationsVisibleForCOG') IS NOT NULL
    DROP TABLE #organizationsVisibleForCOG

SELECT actorId, countryId, depth, organizationName
INTO #organizationsVisibleForCOG
FROM [customer].[organizationsVisibleFor](@userId) v
JOIN @organizationTypeIds ol ON ol.[value] = v.organizationTypeId
WHERE depth <= @Level

SELECT DISTINCT m.actorId AS id, m.organizationName AS title, ah.object AS parents
FROM #organizationsVisibleForCOG AS m
LEFT JOIN core.actorHierarchy ah ON ah.predicate = 'memberOf' AND ah.subject = m.actorId
    AND (m.depth = 1 OR ah.[object] IN (SELECT actorId FROM #organizationsVisibleForCOG)) -- restrict to fetch childrenBU's from user associted BU only, not from other parents
WHERE @parentFilter IS NULL OR ah.object = @parentfilter

DROP TABLE #organizationsVisibleForCOG
