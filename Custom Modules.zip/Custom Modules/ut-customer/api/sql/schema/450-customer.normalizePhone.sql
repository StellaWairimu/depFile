CREATE FUNCTION [customer].[normalizePhone] --this function returns the passed phone number wihout the symbols that are not part of the number
(
    @phoneNumber VARCHAR(50), -- the phone number
    @phonePrefix VARCHAR(10), -- the country prefix of the phone number
    @returnWithPrefix BIT = 1 -- whether to RETURN the phone concatenated WITH the prefix
)
RETURNS VARCHAR(60)
AS
BEGIN
    DECLARE @requireCountryCode BIT = 0;

    IF LEFT(@phonePrefix, 1) = '+'
        SET @phonePrefix = SUBSTRING(@phonePrefix, 2, LEN(@phonePrefix))

    IF LEFT(@phoneNumber, 1) = '+'
    BEGIN
        SET @phoneNumber = SUBSTRING(@phoneNumber, 2, LEN(@phoneNumber));
        SET @requireCountryCode = 1;
    END
    ELSE IF LEFT(@phoneNumber, 4) = '0011'
    BEGIN
        SET @phoneNumber = SUBSTRING(@phoneNumber, 5, LEN(@phoneNumber));
        SET @requireCountryCode = 1;
    END
    ELSE IF LEFT(@phoneNumber, 3) = '010'
    BEGIN
        SET @phoneNumber = SUBSTRING(@phoneNumber, 4, LEN(@phoneNumber));
        SET @requireCountryCode = 1;
    END
    ELSE IF LEFT(@phoneNumber, 3) = '011'
    BEGIN
        SET @phoneNumber = SUBSTRING(@phoneNumber, 4, LEN(@phoneNumber));
        SET @requireCountryCode = 1;
    END
    ELSE IF LEFT(@phoneNumber, 2) = '00'
    BEGIN
        SET @phoneNumber = SUBSTRING(@phoneNumber, 3, LEN(@phoneNumber));
        SET @requireCountryCode = 1;
    END
    ELSE IF LEFT(@phoneNumber, 1) = '0'
    BEGIN
        SET @phoneNumber = SUBSTRING(@phoneNumber, 2, LEN(@phoneNumber));
    END

    IF @phonePrefix IS NOT NULL AND LEN(@phonePrefix) > 0
    BEGIN
        IF @requireCountryCode = 1 AND LEFT(@phoneNumber, LEN(@phonePrefix)) = @phonePrefix
            SET @phoneNumber = SUBSTRING(@phoneNumber, LEN(@phonePrefix) + 1, LEN(@phoneNumber))
        ELSE IF LEFT(@phoneNumber, LEN(@phonePrefix)) = @phonePrefix
            SET @phoneNumber = SUBSTRING(@phoneNumber, LEN(@phonePrefix) + 1, LEN(@phoneNumber));
        ELSE IF @requireCountryCode = 1
            RETURN NULL;
    END

    IF LEN(@phonePrefix + @phoneNumber) > 15
        RETURN NULL;

    IF @returnWithPrefix = 1
        SET @phoneNumber = @phonePrefix + @phoneNumber

    RETURN @phoneNumber
END
