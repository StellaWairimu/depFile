ALTER PROCEDURE [customer].[customer.add] -- adds a new customer with provided parameters
    @customer customer.customerTT READONLY, -- table with basic data about the new customer
    -----------------------------------------
    @person customer.personTT READONLY, -- table with personal information about the new customer, if it is a person
    @joint customer.jointTT READONLY, -- table with information about the new customer, if it is a joint
    @organization customer.organizationTT READONLY, -- table with information about the new customer, if it is an organization
    -----------------------------------------
    @account customer.accountTT READONLY, -- in this parameter the stored procedure receives all fields of account
    @accountPerson ledger.accountPersonTT READONLY, -- in this parameter the stored procedure receives all fields of account to which person
    @email customer.emailTT READONLY, -- information about the e-mails of the customer
    @phone customer.phoneTT READONLY, -- information about the phone numbers of the customer
    @address customer.addressTT READONLY, -- information about the addresses of the customer
    @document document.documentTT READONLY, --information about the document
    @attachment document.attachmentTT READONLY, --information about the document attachment
    @actorDocument [document].[actorDocumentTT] READONLY, --information about the document and document order
    ------------------------------------------------
    @actorId BIGINT = NULL, -- the id of the customer, that will be created
    @noResultSet BIT = 0, -- a flag to show if result is expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user adding the customer
DECLARE @businessUnitId BIGINT = (SELECT organizationId FROM @customer)

DECLARE
    @customerTT customer.customerTT,
    @personTT customer.personTT,
    @emailTT customer.emailTT,
    @phoneTT customer.phoneTT,
    @addressTT customer.addressTT,
    @actorDocumentTT document.actorDocumentTT,
    @accountTT customer.accountTT


    INSERT INTO @customerTT SELECT * FROM @customer
    INSERT INTO @emailTT SELECT * FROM @email
    INSERT INTO @phoneTT SELECT * FROM @phone
    INSERT INTO @addressTT SELECT * FROM @address
    INSERT INTO @personTT SELECT * FROM @person
    INSERT INTO @actorDocumentTT SELECT * FROM @actorDocument
    INSERT INTO @accountTT SELECT * FROM @account


BEGIN TRY
    -- checks IF the user has a RIGHT to ADD customers
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @result customer.customerTT



    IF ((SELECT COUNT( * ) FROM @person) = 0 AND (SELECT COUNT( * ) FROM @joint) = 0 AND (SELECT COUNT( * ) FROM @organization) = 0)
        BEGIN
            RAISERROR('customer.personJointOrganizationDataRequired', 16, 1);
        END

    IF ((SELECT COUNT( * ) FROM @customer) <> 1)
        RAISERROR('customer.customerDataNotSingle', 16, 1);

    IF NOT EXISTS (SELECT * FROM @person)
        RAISERROR('customer.personNotSingle', 16, 1);

    IF CAST(DATEADD(YEAR, 18, (SELECT dateOfBirth FROM @person)) AS DATE) > CAST(GETDATE() AS DATE)
        RAISERROR('customer.wrongDateOfBirth', 16, 1);

    DECLARE @DisableCustomerMCH BIT = 0
    IF EXISTS (SELECT TOP 1 * FROM core.configuration WHERE [key] = 'DisableCustomerM/C' AND [value] = 1)
    SET @DisableCustomerMCH = 1

    BEGIN TRANSACTION
        EXEC [core].[actor.add] @actorType = 'person',
            @actorId = @actorId OUT,
            @meta = @meta


        UPDATE @customerTT SET actorId = @actorId, customerNumber = ISNULL (customerNumber, CONVERT (NVARCHAR (20), @actorId))
        UPDATE @personTT SET actorId = @actorId
        UPDATE @emailTT SET actorId = @actorId
        UPDATE @phoneTT SET actorId = @actorId
        UPDATE @addressTT SET actorId = @actorId
        UPDATE @customerTT SET stateId = 'up_to_date' WHERE stateId IS NULL
        -- UPDATE @accountTT SET ownerId = @actorId, businessUnitId = @businessUnitId
        UPDATE @accountTT SET actorId = @actorId
        UPDATE aa SET aa.currencyId = ci.itemNameId
        FROM @accountTT aa, core.itemName ci
        WHERE ci.itemCode = 'MGA'

        IF @DisableCustomerMCH = 1

        BEGIN
            EXEC customer.[person.add] @person = @personTT,
                @email = @emailTT,
                @phone = @phoneTT,
                @address = @addressTT,
                @noResultSet = 1,
                @meta = @meta

            EXEC [customer].[account.add]
                @account = @accountTT,
                @noResultSet = 1,
                @meta = @meta

            EXEC document.[document.add] @actorId = @actorId,
                @document = @document,
                @attachment = @attachment,
                @actorDocument = @actorDocument,
                @meta = @meta

            INSERT INTO customer.customer (actorId, frontEndRecordId, customerNumber, customerTypeId, kycId, stateId, statusId, createdBy, createdOn, updatedBy, updatedOn, oldValues, customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee, udf)
            OUTPUT INSERTED.actorId, INSERTED.frontEndRecordId, INSERTED.customerNumber, INSERTED.customerTypeId, INSERTED.kycId, INSERTED.stateId, INSERTED.statusId, INSERTED.createdBy, INSERTED.createdOn, INSERTED.updatedBy, INSERTED.updatedOn, INSERTED.oldValues, INSERTED.customerCategoryId, INSERTED.dao, INSERTED.description, INSERTED.cbsId, INSERTED.countryId, INSERTED.industryId, INSERTED.sectorId, INSERTED.loanCycle, INSERTED.organizationId, INSERTED.prospectClient, INSERTED.adminFee, INSERTED.udf
            INTO @result (actorId, frontEndRecordId, customerNumber, customerTypeId, kycId, stateId, statusId, createdBy, createdOn, updatedBy, updatedOn, oldValues, customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee, udf)
            SELECT actorId, frontEndRecordId, customerNumber, customerTypeId, kycId, stateId, ISNULL(statusId, 'approved'), @userId, SYSDATETIMEOFFSET(), @userId, SYSDATETIMEOFFSET(), oldValues, customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee, udf
            FROM @customerTT;

        END

        ELSE

        BEGIN
            EXEC customer.[person.addUnapproved]
                @person = @personTT,
                @email = @emailTT,
                @phone = @phoneTT,
                @address = @addressTT,
                @meta = @meta

            EXEC [customer].[account.addUnapproved]
                @account = @accountTT,
                @noResultSet = 1,
                @meta = @meta

            EXEC document.[document.addUnapproved]
                @actorId = @actorId,
                @document = @document,
                @attachment = @attachment,
                @actorDocument = @actorDocument,
                @meta = @meta


            INSERT INTO [customer].[customerUnapproved] (actorId, frontEndRecordId, customerNumber, customerTypeId, kycId, stateId, statusId, createdBy, createdOn, updatedBy, updatedOn, oldValues, customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee, udf)
            OUTPUT INSERTED.actorId, INSERTED.frontEndRecordId, INSERTED.customerNumber, INSERTED.customerTypeId, INSERTED.kycId, INSERTED.stateId, INSERTED.statusId, INSERTED.createdBy, INSERTED.createdOn, INSERTED.updatedBy, INSERTED.updatedOn, INSERTED.oldValues, INSERTED.customerCategoryId, INSERTED.dao, INSERTED.description, INSERTED.cbsId, INSERTED.countryId, INSERTED.industryId, INSERTED.sectorId, INSERTED.loanCycle, INSERTED.organizationId, INSERTED.prospectClient, INSERTED.adminFee, INSERTED.udf
            INTO @result (actorId, frontEndRecordId, customerNumber, customerTypeId, kycId, stateId, statusId, createdBy, createdOn, updatedBy, updatedOn, oldValues, customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee, udf)
            SELECT actorId, frontEndRecordId, customerNumber, customerTypeId, kycId, stateId, ISNULL (statusId, 'new'), @userId, SYSDATETIMEOFFSET(), @userId, SYSDATETIMEOFFSET(), oldValues, customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee, udf
            FROM @customerTT;

        END
    COMMIT TRANSACTION

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        --SELECT 'customer' AS resultSetName, 1 AS single
        EXEC customer.[customer.get] @actorId = @actorId, @meta = @meta
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
        EXEC core.error
        RETURN 55555
END CATCH
