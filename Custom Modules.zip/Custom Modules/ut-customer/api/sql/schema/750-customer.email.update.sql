ALTER PROCEDURE [customer].[email.update]
    @email customer.emailTT READONLY,
    @noResultSet BIT = 0,
    @meta core.metaDataTT READONLY
AS
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
    DECLARE @result customer.emailTT

BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    UPDATE
        TARGET
    SET
        TARGET.actorId = ISNULL(SOURCE.actorId, TARGET.actorId),
        TARGET.[value] = ISNULL(SOURCE.[value], TARGET.[value]),
        TARGET.emailTypeId = ISNULL(SOURCE.emailTypeId, TARGET.emailTypeId),
        TARGET.statusId = ISNULL(SOURCE.statusId, TARGET.statusId),
        TARGET.isPrimary = ISNULL(SOURCE.isPrimary, TARGET.isPrimary)
    OUTPUT
        INSERTED.emailId, INSERTED.actorId, INSERTED.value, INSERTED.frontEndRecordId, INSERTED.emailTypeId, INSERTED.statusId, INSERTED.oldValues, INSERTED.isPrimary
        INTO @result (emailId, actorId, value, frontEndRecordId, emailTypeId, statusId, oldValues, isPrimary)
    FROM
        customer.email TARGET
    INNER JOIN
        @email SOURCE
    ON
        TARGET.emailId = SOURCE.emailId

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'email' AS resultSetName
        SELECT emailId, actorId, value, frontEndRecordId, emailTypeId, statusId, oldValues, isPrimary
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
