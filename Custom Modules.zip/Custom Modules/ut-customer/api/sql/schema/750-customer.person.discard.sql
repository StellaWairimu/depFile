ALTER PROCEDURE [customer].[person.discard]
    @actorId BIGINT, -- customer id
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DELETE FROM customer.personUnapproved
    WHERE actorId = @actorId

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
