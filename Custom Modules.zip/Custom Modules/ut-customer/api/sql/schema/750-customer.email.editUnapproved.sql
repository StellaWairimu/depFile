ALTER PROCEDURE [customer].[email.editUnapproved] -- edits email information
    @email customer.emailUnapprovedTT READONLY, -- the edited email information
    @actorId BIGINT, -- customer id
    @noResultSet BIT = 0, -- a flag to show IF result IS expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @result customer.emailUnapprovedTT

BEGIN TRY
    DELETE p
    FROM [customer].[emailUnapproved] p
    LEFT JOIN @email pp ON p.emailUnapprovedId = pp.emailUnapprovedId
    WHERE p.actorId = @actorId AND pp.emailUnapprovedId IS NULL

    -- re-edit new AND existing emails IN the unapproved TABLE
    UPDATE t
    SET t.value = s.value,
        t.emailTypeId = s.emailTypeId,
        t.statusId = ISNULL(s.statusId, 'active'),
        t.isPrimary = s.isPrimary,
        t.updatedBy = @userId,
        t.updatedOn = SYSDATETIMEOFFSET()
    OUTPUT INSERTED.emailUnapprovedId, INSERTED.emailId, INSERTED.actorId, INSERTED.value, INSERTED.emailTypeId, INSERTED.statusId, INSERTED.isDeleted, INSERTED.updatedBy, INSERTED.updatedOn, INSERTED.isPrimary
    INTO @result (emailUnapprovedId, emailId, actorId, value, emailTypeId, statusId, isDeleted, updatedBy, updatedOn, isPrimary)
    FROM customer.emailUnapproved t
    JOIN @email s ON t.emailUnapprovedId = s.emailUnapprovedId

    -- insert new or existing edited emails FOR approval
    INSERT INTO [customer].[emailUnapproved] (emailId, actorId, [value], emailTypeId, statusId, isDeleted, updatedBy, updatedOn, isPrimary)
    OUTPUT INSERTED.emailUnapprovedId, INSERTED.emailId, INSERTED.actorId, INSERTED.value, INSERTED.emailTypeId, INSERTED.statusId, INSERTED.isDeleted, INSERTED.updatedBy, INSERTED.updatedOn, INSERTED.isPrimary
    INTO @result (emailUnapprovedId, emailId, actorId, [value], emailTypeId, statusId, isDeleted, updatedBy, updatedOn, isPrimary)
    SELECT e.emailId, e.actorId, e.[value], e.emailTypeId, ISNULL(e.statusId, 'active'), 0, @userId, SYSDATETIMEOFFSET(), isPrimary
    FROM @email e
    WHERE e.emailUnapprovedId IS NULL

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'email' AS resultSetName
        SELECT emailUnapprovedId, emailId, actorId, [value], emailTypeId, statusId, isPrimary, isDeleted, updatedBy, updatedOn, isPrimary
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
