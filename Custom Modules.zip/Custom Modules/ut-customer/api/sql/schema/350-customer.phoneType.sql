CREATE TABLE [customer].[phoneType]( -- table that stores phone types
    [phoneTypeId] [VARCHAR] (20) NOT NULL, -- the id of the phone type, e.g. home, work
    [description] [VARCHAR] (100), -- the id of the phone type
    [statusId] [VARCHAR] (20) NOT NULL, -- the statusId of the phone type, e.g. active/inactive
    CONSTRAINT [pkCustomerPhoneType] PRIMARY KEY ([phoneTypeId]),
    CONSTRAINT [fkCustomerPhoneType_coreStatus] FOREIGN KEY([statusId]) REFERENCES [core].[status] ([statusId])
)
