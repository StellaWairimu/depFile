

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'addressZone1' AND Object_ID = OBJECT_ID(N'customer.address') )
BEGIN
    ALTER TABLE customer.address ADD addressZone1 BIGINT
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'addressZone1' AND Object_ID = OBJECT_ID(N'customer.addressUnapproved') )
BEGIN
    ALTER TABLE customer.addressUnapproved ADD addressZone1 BIGINT
END


IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'addressZone2' AND Object_ID = OBJECT_ID(N'customer.address') )
BEGIN
    ALTER TABLE customer.address ADD addressZone2 BIGINT
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'addressZone2' AND Object_ID = OBJECT_ID(N'customer.addressUnapproved') )
BEGIN
    ALTER TABLE customer.addressUnapproved ADD addressZone2 BIGINT
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'addressZone3' AND Object_ID = OBJECT_ID(N'customer.address') )
BEGIN
    ALTER TABLE customer.address ADD addressZone3 BIGINT
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'addressZone3' AND Object_ID = OBJECT_ID(N'customer.addressUnapproved') )
BEGIN
    ALTER TABLE customer.addressUnapproved ADD addressZone3 BIGINT
END


IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'addressZone4' AND Object_ID = OBJECT_ID(N'customer.address') )
BEGIN
    ALTER TABLE customer.address ADD addressZone4 BIGINT
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'addressZone4' AND Object_ID = OBJECT_ID(N'customer.addressUnapproved') )
BEGIN
    ALTER TABLE customer.addressUnapproved ADD addressZone4 BIGINT
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'rejectReason' AND Object_ID = OBJECT_ID(N'customer.referral') )
BEGIN
    ALTER TABLE customer.referral ADD rejectReason NVARCHAR(MAX)
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'permission' AND Object_ID = OBJECT_ID(N'customer.referralStatusAction') )
BEGIN
    ALTER TABLE customer.referralStatusAction ADD permission VARCHAR(100)
END

IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'module' AND Object_ID = OBJECT_ID(N'customer.referralStatusAction') )
BEGIN
    ALTER TABLE customer.referralStatusAction DROP pkreferralStatusAction
    ALTER TABLE customer.referralStatusAction DROP COLUMN module

    ALTER TABLE customer.referralStatusAction ADD CONSTRAINT [pkreferralStatusAction] PRIMARY KEY CLUSTERED (fromStatusId, actionId, toStatusId)
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'customerUnapprovedId' AND Object_ID = OBJECT_ID(N'customer.customerUnapproved') )
BEGIN
    ALTER TABLE customer.customerUnapproved ADD customerUnapprovedId BIGINT IDENTITY(1, 1) NOT NULL
END


IF NOT EXISTS(
    SELECT COLUMN_NAME
    FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
    WHERE OBJECTPROPERTY(OBJECT_ID(CONSTRAINT_SCHEMA + '.' + QUOTENAME(CONSTRAINT_NAME)), 'IsPrimaryKey') = 1
        AND TABLE_NAME = 'customerUnapproved' AND TABLE_SCHEMA = 'customer' AND COLUMN_NAME = 'customerUnapprovedId' )

BEGIN
    ALTER TABLE customer.customerUnapproved DROP CONSTRAINT pkCustomerCustomerUnapproved
    ALTER TABLE customer.customerUnapproved ADD CONSTRAINT pkCustomerCustomerUnapproved PRIMARY KEY CLUSTERED (customerUnapprovedId)
END



IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'rejectReason' AND Object_ID = OBJECT_ID(N'customer.customerUnapproved') )
BEGIN
    ALTER TABLE customer.customerUnapproved ADD rejectReason [NVARCHAR](max) NULL
END



IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'personUnapprovedId' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
BEGIN

    ALTER TABLE customer.personUnapproved ADD personUnapprovedId BIGINT IDENTITY(1, 1) NOT NULL

END


IF NOT EXISTS(
    SELECT COLUMN_NAME
    FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
    WHERE OBJECTPROPERTY(OBJECT_ID(CONSTRAINT_SCHEMA + '.' + QUOTENAME(CONSTRAINT_NAME)), 'IsPrimaryKey') = 1
        AND TABLE_NAME = 'personUnapproved' AND TABLE_SCHEMA = 'customer' AND COLUMN_NAME = 'personUnapprovedId' )

BEGIN
    ALTER TABLE customer.personUnapproved DROP CONSTRAINT pkCustomerPersonUnapproved
    ALTER TABLE customer.personUnapproved ADD CONSTRAINT pkCustomerPersonUnapproved PRIMARY KEY CLUSTERED (personUnapprovedId)
END
