ALTER PROCEDURE [customer].[organization.approve] -- supports the approve functionality, where the checker approves the selected organization
    @actorId BIGINT, -- the id of the organization to be approved
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
BEGIN TRY
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)

    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @isDeleted BIT, @isEnabled BIT, @statusId VARCHAR(20), @isEnabledUnapproved BIT

    SET @isEnabled = (SELECT isEnabled FROM [customer].[organization] WHERE actorId = @actorId)

    SELECT @isDeleted = isDeleted, @isEnabledUnapproved = isEnabled, @statusId = statusId
    FROM [customer].[organizationUnapproved]
    WHERE actorId = @actorId

    IF @statusId IS NULL OR @statusId = 'rejected'
    BEGIN
        RAISERROR('customer.organizationInvalidStatus', 16, 1);
    END

    -- check if maker <> checker if not a system user
    IF EXISTS (
        SELECT *
        FROM [customer].[organizationUnapproved] cou
        LEFT JOIN [user].[vSystemUser] usu ON usu.actorId = cou.updatedBy
        WHERE cou.actorId = @actorId AND cou.updatedBy = @userId AND usu.actorId IS NULL)
        RAISERROR('customer.cannotPerformThisOperation', 16, 1)

    IF @isDeleted = 1 AND EXISTS (SELECT actorId FROM [customer].[organization] WHERE actorId = @actorId) --the approved action IS "DELETE organization"
    BEGIN
        BEGIN TRANSACTION

            UPDATE t
            SET t.organizationName = s.organizationName,
                t.isEnabled = 0,
                t.isDeleted = 1
            FROM [customer].[organization] t
            JOIN [customer].[organizationUnapproved] s ON t.actorId = s.actorId
            WHERE t.actorId = @actorId

            DELETE FROM [customer].[organizationUnapproved] WHERE actorId = @actorId
            -- DELETE relation to BUs AND assigned roles
            DELETE FROM [core].[actorHierarchy] WHERE [subject] = @actorId

            EXECUTE [customer].[organizationHierarchyFlat.rebuild] @actorId = @actorId, @meta = @meta -- rebuild the customer.organizationHierarchyFlat TABLE

        COMMIT TRANSACTION
    END
    ELSE IF @isEnabled IS NOT NULL AND (@isEnabled <> @isEnabledUnapproved)
    BEGIN
        BEGIN TRANSACTION

            UPDATE x
            SET isEnabled = @isEnabledUnapproved
            FROM [customer].[organization] x
            WHERE actorId = @actorId

            DELETE FROM [customer].[organizationUnapproved] WHERE actorId = @actorId

        COMMIT TRANSACTION
    END
    ELSE -- approved some changes IN organization's data
    BEGIN
        -- approve newly added organization
        IF NOT EXISTS (SELECT actorId FROM [customer].[organization] WHERE actorId = @actorId)
            EXEC [customer].[organization.addApproved] @actorId = @actorId, @meta = @meta
        -- approve edited information FOR existing organization
        ELSE
            EXEC [customer].[organization.editApproved] @actorId = @actorId, @meta = @meta
    END

    SELECT 'approvedObjectAndAction' AS resultSetName, 1 AS single

    SELECT @actorId AS organizationId,
        CASE WHEN @isDeleted = 1 THEN 'DELETE' WHEN @isEnabled IS NOT NULL AND (@isEnabled <> @isEnabledUnapproved) THEN 'Enable/Disable' ELSE 'Change' END AS [action]

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
