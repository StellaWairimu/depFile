CREATE TABLE [customer].[referralAction] ( --table for customer referral actions
    referralActionId TINYINT IDENTITY(1, 1) NOT NULL, -- the id of the action
    itemNameId BIGINT NOT NULL, --the link to the action's name, translated
    CONSTRAINT [pkreferralAction] PRIMARY KEY CLUSTERED (referralActionId),
    CONSTRAINT [fkreferralAction_CoreItemName] FOREIGN KEY(itemNameId) REFERENCES [core].[itemName] (itemNameId)
)
