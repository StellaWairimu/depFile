CREATE TABLE [customer].[emailType]( -- table that stores e-mail types
    [emailTypeId] [VARCHAR] (20) NOT NULL, -- the id of the e-mail type, e.g. personal, work
    [description] [VARCHAR] (100), -- the description of the e-mail type
    [statusId] [VARCHAR] (20) NOT NULL, -- the statusId of the e-mail type, e.g. active/inactive
    CONSTRAINT [pkCustomerEmailType] PRIMARY KEY ([emailTypeId]),
    CONSTRAINT [fkCustomerEmailType_coreStatus] FOREIGN KEY([statusId]) REFERENCES [core].[status] ([statusId])
)
