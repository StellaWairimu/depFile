CREATE TABLE [customer].[state]( -- table that stores customer states
    [stateId] [VARCHAR] (20) NOT NULL, -- the id of the customer state, e.g. pending, blocked, etc.
    [description] [VARCHAR] (100), -- the description of the customer state
    [statusId] [VARCHAR] (20) NOT NULL, -- the statusId of the customer state, e.g. active/inactive
    [display] [VARCHAR] (10) NOT NULL, -- the customer state value displayed in UI
    CONSTRAINT [pkCustomerState] PRIMARY KEY ([stateId]),
    CONSTRAINT [fkCustomerState_coreStatus] FOREIGN KEY([statusId]) REFERENCES [core].[status] ([statusId])
)
