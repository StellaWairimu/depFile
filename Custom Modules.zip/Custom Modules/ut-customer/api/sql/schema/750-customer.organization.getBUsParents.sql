ALTER PROCEDURE [customer].[organization.getBUsParents] -- this SP lists all organizations availble for user that contain in the names the passed string and their parents for the predifined level
    @organizationName NVARCHAR(100), -- the name of the BU(s) for which to search
    @depth TINYINT = 1, -- how much above to go
    @excludeOrganizationId BIGINT = NULL, -- the id of the organization (eg. edited organization) and its children that have to be excluded from the result
    @organizationTypeList core.arrayList READONLY, -- type of organizations to fetch
    @showParents BIT = 0, -- flag, according to its value parent organizations are shown or not
    @meta core.metaDataTT READONLY -- information for the logged user
AS
SET NOCOUNT ON

DECLARE @organizationTypeIds core.arrayNumberList
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
-- checks if the user has a right to make the operation
DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
IF @return != 0
BEGIN
    RETURN 55555
END

IF NOT EXISTS(SELECT * FROM @organizationTypeList)
    INSERT INTO @organizationTypeIds
    SELECT organizationTypeId
    FROM customer.organizationType
    WHERE organizationType = ('businessUnit')
ELSE
    INSERT INTO @organizationTypeIds
    SELECT organizationTypeId
    FROM @organizationTypeList otl
    JOIN customer.organizationType ot ON ot.organizationType = otl.[value]

IF OBJECT_ID('tempdb..#bu') IS NOT NULL
    DROP TABLE #bu

CREATE TABLE #bu (actorId BIGINT, organizationName NVARCHAR(100))


IF @excludeOrganizationId IS NULL
    INSERT INTO #bu (actorId, organizationName)
    SELECT actorId, organizationName
    FROM
    (
        SELECT o.actorId, organizationTypeId, organizationName
        FROM [user].parentOrganizationsForUser(@userId) o
        WHERE @showParents = 1

        UNION

        SELECT o.actorId, organizationTypeId, organizationName
        FROM [customer].[organizationsVisibleFor] (@userId) o
    ) o
    JOIN @organizationTypeIds ol ON ol.[value] = o.organizationTypeId
    WHERE organizationName LIKE @organizationName + '%'
ELSE
    INSERT INTO #bu (actorId, organizationName)
    SELECT DISTINCT o.actorId, organizationName
    FROM
    (
        SELECT o.actorId, organizationTypeId, organizationName
        FROM [user].parentOrganizationsForUser(@userId) o
        WHERE @showParents = 1

        UNION

        SELECT o.actorId, organizationTypeId, organizationName
        FROM [customer].[organizationsVisibleFor] (@userId) o
    ) o
    JOIN @organizationTypeIds ol ON ol.[value] = o.organizationTypeId
    LEFT JOIN customer.organizationHierarchyFlat cof ON cof.object = o.actorId AND cof.subject = @excludeOrganizationId
    WHERE organizationName LIKE @organizationName + '%' AND cof.subject IS NULL

SELECT 'organizations' AS resultSetName

SELECT actorId AS actorId, bu.organizationName,
    STUFF (
        (SELECT ', ' + o.organizationName
        FROM customer.organizationHierarchyFlat orgs
        JOIN customer.organization o ON o.actorId = orgs.subject
        WHERE bu.actorId = orgs.object AND orgs.subject != orgs.object AND
            (@depth IS NULL OR orgs.relationDepth <= @depth + 1)
        ORDER BY relationDepth
        FOR XML PATH ('') ), 1, 2, '') AS parents

FROM #bu bu


IF OBJECT_ID('tempdb..#bu') IS NOT NULL
    DROP TABLE #bu
