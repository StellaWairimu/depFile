ALTER PROCEDURE customer.[referral.getReferre] -- gets the referre
    @customerNumber NVARCHAR (20), -- customer number  identity to the referre
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
SET NOCOUNT ON;

DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
-- checks if the user has a right to make the operation

DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
IF @return != 0
    RETURN 55555

DECLARE @customerNumberBigint BIGINT = (
    CASE
        WHEN ISNUMERIC(@customerNumber) = 1 AND LEN(@customerNumber) <= 18 THEN CONVERT(BIGINT, @customerNumber)
        ELSE - 1
    END
)

DECLARE @actorId BIGINT = (
    SELECT actorId FROM [customer].[customer] WHERE (customerNumber = @customerNumber OR actorId = @customerNumberBigint) AND customerTypeId = 'individual'
)

--Error message
IF (@actorId IS NULL)
    BEGIN
        RAISERROR('customer.customerNotExists', 16, 1);
    END

--get

SELECT 'customer' AS resultSetName, 1 AS single

SELECT
    c.actorId,
    c.customerNumber,
    c.statusId,
    cp.firstName,
    cp.middleName,
    cp.lastName
FROM [customer].[customer] c
JOIN [customer].[person] cp ON c.actorId = cp.actorId
WHERE c.actorId = @actorId
