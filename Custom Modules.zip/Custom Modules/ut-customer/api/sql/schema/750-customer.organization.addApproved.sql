ALTER PROCEDURE [customer].[organization.addApproved] -- adds a new organization
    @actorId BIGINT, -- the Id of the organization that is approved
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @actorHierarchyTT core.actorHierarchyTT, @emptyList core.ArrayNumberList

BEGIN TRY
    DECLARE @grantedRoles core.arrayNumberList, @parents core.arrayNumberList

    INSERT INTO @parents
    SELECT [object]
    FROM [core].[actorHierarchyUnapproved]
    WHERE [subject] = @actorId AND predicate = 'memberOf' AND isDeleted = 0

    --checks IF among parents there are disabled or deleted organizations
    IF EXISTS(
        SELECT * FROM @parents p
        LEFT JOIN customer.organization o ON p.value = o.actorId AND o.isEnabled = 1 AND o.isDeleted = 0
        WHERE o.actorId IS NULL)
            RAISERROR('customer.disabledOrDeletedOrganization', 16, 1)

    IF EXISTS(
        SELECT p.value
        FROM @parents p
        LEFT JOIN customer.organizationsVisibleFor(@userId) o ON o.actorId = p.value
        WHERE o.actorId IS NULL)
            RAISERROR('customer.securityViolation', 16, 1)

    INSERT INTO @grantedRoles
    SELECT [object]
    FROM [core].[actorHierarchyUnapproved]
    WHERE [subject] = @actorId AND predicate = 'role' AND isDeleted = 0

    DECLARE @TranCounter INT = @@TRANCOUNT;
    IF @TranCounter = 0
        BEGIN TRANSACTION

            INSERT INTO [customer].[organization](
                actorId, frontEndRecordId, organizationName, code, executiveOfficer, tradeName, capital, currency, timeZone,
                primaryLanguageId, oldValues, isEnabled, isDeleted, cbsId, countryId, organizationTypeId, description)
            SELECT actorId, frontEndRecordId, organizationName, code, executiveOfficer, tradeName, capital, currency, timeZone,
                primaryLanguageId, oldValues, 1 AS isEnabled, 0 AS isDeleted, cbsId, countryId, organizationTypeId, description
            FROM [customer].[organizationUnapproved]
            WHERE actorId = @actorId

            DELETE FROM [customer].[organizationUnapproved] WHERE actorId = @actorId

            INSERT INTO [core].[actorHierarchy] ([subject], predicate, [object])
            SELECT @actorId, 'memberOf', p.value
            FROM @parents p

            EXEC [user].[role.grant]
                @actorId = @actorId,
                @granted = @grantedRoles,
                @revoked = @emptyList,
                @defaultRoleId = NULL,
                @meta = @meta

            DELETE FROM [core].[actorHierarchyUnapproved] WHERE [subject] = @actorId

            IF EXISTS (SELECT * FROM @parents)
                EXEC [customer].[organizationHierarchyFlat.rebuild] @actorId = @actorId, @actorIdParents = @parents, @meta = @meta -- rebuild the customer.organizationHierarchyFlat TABLE
            ELSE -- IF the organization IS without parents, we should ADD it IN hierarchy only AS one row (itself)
                INSERT INTO [customer].[organizationHierarchyFlat] ([subject], [object], [parentActorId], [relationDepth])
                VALUES(@actorId, @actorId, @actorId, 1)

            EXEC [customer].[email.addApproved]
                @actorId = @actorId,
                @meta = @meta,
                @noResultSet = 1

            EXEC [customer].[phone.addApproved]
                @actorId = @actorId,
                @meta = @meta,
                @noResultSet = 1

            EXEC [customer].[address.addApproved]
                @actorId = @actorId,
                @meta = @meta,
                @noResultSet = 1

            IF @TranCounter = 0
        COMMIT TRANSACTION

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
