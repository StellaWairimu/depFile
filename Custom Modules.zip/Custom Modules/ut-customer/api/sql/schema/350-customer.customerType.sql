CREATE TABLE [customer].[customerType]( -- table that stores customer types
    [customerTypeId] [VARCHAR] (20) NOT NULL, -- the id of the customer type, e.g. client
    [description] [VARCHAR] (100), -- the description of the customer type
    [statusId] [VARCHAR] (20) NOT NULL, -- the statusId of the customer type, e.g. active/inactive
    customerTypeNumber INT IDENTITY(1, 1), --the number for customer type generated
    CONSTRAINT [pkCustomerCustomerType] PRIMARY KEY ([customerTypeId]),
    CONSTRAINT [fkCustomerCustomerType_coreStatus] FOREIGN KEY([statusId]) REFERENCES [core].[status] ([statusId]),
    CONSTRAINT [uqcustomerTypeNumber] UNIQUE ([customerTypeNumber])
)
