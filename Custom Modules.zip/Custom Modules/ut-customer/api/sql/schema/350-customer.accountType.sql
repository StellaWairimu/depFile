CREATE TABLE [customer].[accountType](
    [accountTypeCode] [VARCHAR] (20) NOT NULL,
    [itemNameId] [BIGINT] NULL,
    [description] [VARCHAR] (100),
    [statusId] [VARCHAR] (20) NOT NULL,
    [accountTypeId] [INT] IDENTITY(1, 1) NOT NULL,
    CONSTRAINT [pkCustomerAccountType] PRIMARY KEY ([accountTypeId]),
    CONSTRAINT [fkCustomerAccountType_coreStatus] FOREIGN KEY([statusId]) REFERENCES [core].[status] ([statusId]),
    CONSTRAINT [fkCustomerAccountType_coreItemNameId] FOREIGN KEY([itemNameId]) REFERENCES [core].[itemName] ([itemNameId])
)
