CREATE TABLE [customer].[industry]( --table that stores the industry codes AS they are defined in T24
    [industryId] [INT] IDENTITY(1, 1) NOT NULL, -- industry id
    [itemNameId] BIGINT NULL,
    CONSTRAINT pkCustomerIndustry PRIMARY KEY CLUSTERED(industryId ASC),
    CONSTRAINT [fkcCustomerIndustry_itemNameId] FOREIGN KEY(itemNameId) REFERENCES [core].[itemName] (itemNameId)
)
