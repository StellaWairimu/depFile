ALTER PROCEDURE customer.[kyc.getForCreate] -- this SP gets which levels arenot yet created for the passed customer type and bu
    @customerType INT, -- the customer type for which to check
    @organizationId BIGINT, -- the branch for which to check
    @noResultSet BIT = 0, -- whether to return  the added objects as result
    @meta core.metaDataTT READONLY -- information for the logged user
AS
    DECLARE @userId BIGINT =
    (
        SELECT [auth.actorId]
        FROM @meta
    )
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check]
        @actionId = @actionID,
        @objectId = NULL,
        @meta = @meta
    IF @return != 0
        BEGIN
            RETURN 55555
        END

    SET @noResultSet = ISNULL(@noResultSet, 0)

    DECLARE @currentDepth SMALLINT
    DECLARE @KYCLevelForBranchesDepth SMALLINT =
    (
        SELECT [value]
        FROM core.configuration
        WHERE [key] = 'KYCLevelForBranchesDepth'
    )

    IF @KYCLevelForBranchesDepth IS NULL
    BEGIN
        RAISERROR('customer.defaultKYCLevelForBranchesIsNotDefined', 16, 1);
        RETURN 55555
    END

    IF NOT EXISTS (SELECT * FROM customer.organizationsVisibleFor(@userId) WHERE actorId = @organizationId)
    BEGIN
        RAISERROR('customer.cantAccessThisBranch', 16, 1);
        RETURN 55555
    END

    DECLARE @languageId BIGINT = 1;
    --(
    --    SELECT languageId
    --    FROM core.language AS cl
    --    JOIN [user].[session] AS us ON us.language = cl.iso2Code
    --    WHERE us.actorId = @userId
    --)

    WITH allOrg AS
    (
        SELECT o.actorId, 1 AS depth
        FROM customer.organization AS o
        LEFT JOIN core.actorHierarchy AS cur ON o.actorId = cur.subject AND predicate = 'memberOf'
        WHERE cur.subject IS NULL

        UNION ALL

        SELECT o.actorId, depth + 1
        FROM allOrg AS par
        JOIN core.actorHierarchy AS ch ON ch.object = par.actorId AND predicate = 'memberOf'
        JOIN customer.organization AS o ON o.actorId = ch.subject
        WHERE depth + 1 <= @KYCLevelForBranchesDepth
    )

    --get the depth of the passed organization - WITH min because it IS possible to be added multiple times
    SELECT @currentDepth = MIN(depth)
    FROM allOrg
    WHERE actorId = @organizationId

    IF @KYCLevelForBranchesDepth <> ISNULL(@currentDepth, -1)
        BEGIN
            RAISERROR('customer.branchDepthIsNotCorrect', 16, 1);
            RETURN 55555
        END

    DECLARE @kycLevelTypeId INT =
    (
        SELECT itemTypeId
        FROM core.itemType
        WHERE alias = 'kycLevel'
    )

    IF @noResultSet = 0
    BEGIN
        SELECT 'levels' AS resultSetName

        SELECT i.itemNameId, it.itemNameTranslation
        FROM core.itemName AS i
        JOIN core.itemTranslation AS it ON it.itemNameId = i.itemNameId AND it.languageId = @languageId
        LEFT JOIN customer.kyc AS k ON i.itemNameId = k.itemNameId AND k.customerTypeId = @customerType AND k.organizationId = @organizationId AND k.isDeleted = 0
        WHERE i.itemTypeId = @kycLevelTypeId AND k.kycId IS NULL
        ORDER BY itemOrder
    END
