CREATE TABLE [customer].[employment]( --table that stores employment of the person
    [employmentId] TINYINT IDENTITY(1, 1) NOT NULL, -- employment id
    [itemNameId] BIGINT NULL,
    CONSTRAINT pkCustomeremployment PRIMARY KEY CLUSTERED(employmentId ASC),
    CONSTRAINT [fkCustomeremployment_itemNameId] FOREIGN KEY(itemNameId) REFERENCES [core].[itemName] (itemNameId)
)
