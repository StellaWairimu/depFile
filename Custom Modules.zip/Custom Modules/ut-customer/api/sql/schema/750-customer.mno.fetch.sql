ALTER PROCEDURE [customer].[mno.fetch] -- fetches all MNOs that are relevant to the user, according to the BUs, visible for them
    --@businessUnits core.arrayNumberList READONLY, -- the ids of the business units visible FOR the added/edited user
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
-- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    SELECT 'mno' AS resultSetName

    SELECT *
    FROM [customer].[mno] mno
    --JOIN [customer].[organization] o ON mno.countryId = o.countryId AND o.isEnabled = 1
    --JOIN @businessUnits bu ON bu.value = o.actorId
