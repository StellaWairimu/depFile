CREATE TABLE customer.joint(
    actorId BIGINT,
    frontEndRecordId VARCHAR (10),
    jointName NVARCHAR (50),
    oldValues XML NULL,
    CONSTRAINT pkCustomerJoint PRIMARY KEY CLUSTERED(actorId ASC),
    CONSTRAINT fkCustomerJoint_coreActor FOREIGN KEY(actorId) REFERENCES core.actor (actorId)
)
