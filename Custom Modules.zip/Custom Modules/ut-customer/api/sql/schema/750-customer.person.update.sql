ALTER PROCEDURE customer.[person.update] -- update changed person data in customer.person table
    @person customer.personTTU READONLY, -- in this parameter the stored procedure receives all changed fields
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
    DECLARE
        @result [customer].personTT,
        @oldValuesXML XML,
        @newXML XML,
        @actorId BIGINT

-- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    IF EXISTS(
        SELECT actorId
        FROM @person
        WHERE nationalityUpdated = 1)
    AND
    NOT EXISTS(
        SELECT countryId
        FROM @person p
        JOIN core.country c ON c.countryCode = p.nationality OR c.name = p.nationality)
        RAISERROR('customer.missingNationality', 16, 1);

    SET @actorId = (SELECT actorId FROM @person)

    SET @oldValuesXML = (
        SELECT *
        FROM customer.person
        WHERE actorId = @actorId
        FOR XML PATH('oldUdf') , type, ELEMENTS XSINIL)

    SET @newXML = (SELECT * FROM @person FOR XML PATH('udf'))

    UPDATE p
    SET
        p.firstName = CASE WHEN ptt.firstNameUpdated = 1 THEN ptt.firstName ELSE p.firstName END,
        p.lastName = CASE WHEN ptt.lastNameUpdated = 1 THEN ptt.lastName ELSE p.lastName END,
        p.nationalId = CASE WHEN ptt.nationalIdUpdated = 1 THEN ptt.nationalId ELSE p.nationalId END,
        p.dateOfBirth = CASE WHEN ptt.dateOfBirthUpdated = 1 THEN ptt.dateOfBirth ELSE p.dateOfBirth END,
        p.placeOfBirth = CASE WHEN ptt.placeOfBirthUpdated = 1 THEN ptt.placeOfBirth ELSE p.placeOfBirth END,
        p.nationality = CASE WHEN ptt.nationalityUpdated = 1 THEN ptt.nationality ELSE p.nationality END,
        p.gender = CASE WHEN ptt.genderUpdated = 1 THEN ptt.gender ELSE p.gender END,
        p.bioId = CASE WHEN ptt.bioIdUpdated = 1 THEN ptt.bioId ELSE p.bioId END,
        p.oldValues = core.mergeXML(@oldValuesXML, @userId, @newXML),
        p.udf = CASE WHEN ptt.udfUpdated = 1 THEN ptt.udf ELSE p.udf END,
        p.phoneModel = CASE WHEN ptt.phoneModelUpdated = 1 THEN ptt.phoneModel ELSE p.phoneModel END,
        p.computerModel = CASE WHEN ptt.computerModelUpdated = 1 THEN ptt.computerModel ELSE p.computerModel END
        --p.updatedOn = SYSDATETIMEOFFSET(),
        --p.updatedBy = (SELECT [auth.actorId] FROM @meta )
    OUTPUT inserted.firstName, inserted.lastName, inserted.nationalId, inserted.dateOfBirth, inserted.placeOfBirth, inserted.nationality, inserted.gender, inserted.bioId, inserted.oldValues, inserted.udf, inserted.phoneModel, inserted.computerModel
    INTO @result (firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, oldValues, udf, phoneModel, computerModel)
    FROM customer.person p
    INNER JOIN @person ptt ON ptt.actorId = p.actorId

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'person' AS resultSetName
        SELECT * FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    EXEC core.error
    RETURN 55555
END CATCH
