CREATE TABLE [customer].[phoneUnapproved]( -- table that stores all customer phone numbers, pending approval
    [phoneUnapprovedId] INT IDENTITY(1, 1) NOT NULL, -- the id of the unapproved record
    [phoneId] INT NULL, -- the id of the phone, NULL if new
    [actorId] BIGINT NOT NULL, -- the id of the actor, who the phone belongs to
    [frontEndRecordId] VARCHAR(10), -- an id, needed for the frontend of the mobile app
    [phoneTypeId] VARCHAR (20) NOT NULL, -- the phoneTypeId, e.g. home, work
    [phoneNumber] VARCHAR (50) NOT NULL, -- the customer phone number, without country prefix
    [statusId] VARCHAR (20) NOT NULL, -- the statusId of the phone, e.g. active/inactive
    [oldValues] XML NULL, -- history of old values of customer phones
    [udf] XML, -- user defined fields
    [mnoId] TINYINT, -- the Mobile Network Operator
    [isPrimary] BIT NOT NULL DEFAULT(0), -- a flag to show if the phone is used for otpSend, if OTP access policy is assigned
    [isDeleted] BIT NOT NULL, -- a flag to show if the phone will be deleted or inserted/edited
    [updatedBy] BIGINT NOT NULL, -- the id of the user updating the phone
    [updatedOn] DATETIMEOFFSET(7) NOT NULL, -- the datetime the phone is updated on
    CONSTRAINT pkCustomerPhoneUnapproved PRIMARY KEY CLUSTERED(phoneUnapprovedId ASC),
    CONSTRAINT fkCustomerPhoneUnapproved_coreActor FOREIGN KEY(actorId) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerPhoneUnapproved_updatedByCoreActor FOREIGN KEY(updatedBy) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerPhoneUnapproved_customerPhone FOREIGN KEY(phoneId) REFERENCES [customer].[phone] (phoneId),
    CONSTRAINT fkCustomerPhoneUnapproved_customerPhoneType FOREIGN KEY(phoneTypeId) REFERENCES customer.phoneType (phoneTypeId),
    CONSTRAINT fkCustomerPhoneUnapproved_coreStatus FOREIGN KEY(statusId) REFERENCES core.[status] (statusId),
    CONSTRAINT fkCustomerPhoneUnapproved_customerMNO FOREIGN KEY(mnoId) REFERENCES customer.mno(mnoId)
)
