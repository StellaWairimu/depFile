ALTER PROCEDURE [customer].[organization.lock] --the SP locks/unlocks selected organizations
    @actorIdList core.arrayNumberList READONLY, -- a list with organizations to lock/unlock
    @isEnabled BIT = 0,
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
BEGIN TRY
        -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    IF EXISTS(SELECT statusId FROM [customer].[organizationUnapproved] o JOIN @actorIdList a ON o.actorId = a.value WHERE statusId = 'new' OR statusId = 'pending')
    BEGIN
        RAISERROR('customer.organizationInvalidStatus', 16, 1);
    END

    IF EXISTS(SELECT * FROM [customer].[organization] o JOIN @actorIdList a ON o.actorId = a.value WHERE isEnabled = @isEnabled)
    BEGIN
        RAISERROR('customer.organizationIsEnabledSet', 16, 1);
    END

    --check if user has access to the organization
    IF EXISTS(
        SELECT o.actorId
        FROM @actorIdList al
        LEFT JOIN customer.organizationsVisibleForUnapproved(@userId) o ON al.value = o.actorId
        WHERE o.actorId IS NULL)
            RAISERROR('customer.securityViolation', 16, 1)

    IF @isEnabled = 0
    BEGIN
        --CHECK IF an organization has members; IF there are active sub Organizations WE CANNOT LOCK it
        IF EXISTS (
            SELECT TOP 1 ah.[object]
            FROM core.actorHierarchy ah
                JOIN customer.organization o ON o.actorId = ah.[object]
                JOIN @actorIdList ids ON ah.[object] = ids.value
                JOIN customer.organization oChild ON oChild.actorId = ah.subject
            WHERE ah.predicate = 'memberOf'
            AND oChild.isDeleted = 0 AND oChild.isEnabled = 1)
        BEGIN
            RAISERROR('customer.cannotLockHasOrganizations', 16, 1);
        END
        ELSE IF--CHECK IF an organization has members; IF there are active Users WE CANNOT LOCK it
            EXISTS (
                SELECT TOP 1 ah.[object]
                FROM core.actorHierarchy ah
                    JOIN customer.organization o ON o.actorId = ah.[object]
                    JOIN @actorIdList ids ON ah.[object] = ids.value
                    JOIN [user].[user] uChild ON uChild.actorId = ah.subject
                WHERE ah.predicate = 'memberOf'
                AND uChild.isDeleted = 0 AND uChild.isEnabled = 1)
        BEGIN
            RAISERROR('customer.cannotLockHasUsers', 16, 1);
        END
        ELSE IF--CHECK IF a role IS visibleFor the organization
        EXISTS (
            SELECT TOP 1 ah.[object]
            FROM core.actorHierarchy ah
                JOIN customer.organization o ON o.actorId = ah.[object]
                JOIN @actorIdList ids ON ah.[object] = ids.value
                JOIN [user].[role] r ON r.actorId = ah.[subject]
            WHERE ah.predicate = 'visibleFor'
            AND r.isDeleted = 0 AND r.isEnabled = 1)
        BEGIN
            RAISERROR('customer.cannotLockHasRoles', 16, 1);
        END
    END

    INSERT INTO [customer].[organizationUnapproved](actorId, frontEndRecordId, organizationName, description, code, executiveOfficer, tradeName, capital, currency, timeZone, primaryLanguageId, oldValues, isEnabled, isDeleted, cbsId, countryId, updatedBy, updatedOn, statusId)
    SELECT o.actorId, o.frontEndRecordId, o.organizationName, o.description, o.code, o.executiveOfficer, o.tradeName, o.capital, o.currency, o.timeZone, o.primaryLanguageId, o.oldValues, @isEnabled, o.isDeleted, o.cbsId, o.countryId, @userId, SYSDATETIMEOFFSET(), 'pending'
    FROM [customer].[organization] o
    JOIN @actorIdList a ON a.value = o.actorId
    LEFT JOIN [customer].[organizationUnapproved] ou ON o.actorId = ou.actorId
    WHERE ou.actorId IS NULL

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
