ALTER PROCEDURE [customer].[referral.fetch] -- gets basic information for all access referrals
    @referralId VARCHAR(20), --filter by referralid
    @actorId BIGINT, -- filter by actorid
    @MSISDN VARCHAR(50), -- filter by msisdn of referral
    @customerNumber VARCHAR(20), -- filter by customernumber
    @pageSize INT = 25, -- how many rows will be returned per page
    @pageNumber INT = 1, -- which page number to display
    @sortBy VARCHAR(50) = '', -- on which column results to be sorted
    @sortOrder VARCHAR(4) = 'ASC', --what kind of sort to be used ascending or descending
    @referralStatusIds core.arrayNumberList READONLY, -- filter by referral statuses
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
BEGIN TRY

    SET NOCOUNT ON
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
    DECLARE @startRow INT = (@pageNumber - 1) * @pageSize + 1
    DECLARE @endRow INT = @startRow + @pageSize - 1


    DECLARE @callParams XML



    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    IF OBJECT_ID('tempdb..#referral') IS NOT NULL
        DROP TABLE #referral

    DECLARE @referralStatusId TINYINT = (SELECT TOP 1 value FROM @referralStatusIds)
    SET @customerNumber = '%' + @customerNumber + '%'
    SET @MSISDN = '%' + @MSISDN + '%'
    SET @referralId = '%' + @referralId + '%'

    CREATE TABLE #referral(referralId BIGINT,
        referralSource BIGINT,
        referralTarget BIGINT,
        referralDate [DATETIME2](0),
        referralStatusId TINYINT,
        MSISDN VARCHAR(50),
        createdOn [DATETIME2](0),
        updatedOn DATETIME2(0),
        customerNumber NVARCHAR (20),
        referralStatus VARCHAR(50),
        referralStatusCode VARCHAR(50),
        referredCustomerNumber NVARCHAR (20),
        rejectReason VARCHAR(max),
        isNew BIT,
        rowNum INT,
        recordsTotal INT);
    WITH CTE AS(
        SELECT r.referralId, r.MSISDN,
            c.customerNumber, ci.itemName AS referralStatus,
            r.referralSource, r.referralTarget, r.referralDate, r.createdOn, r.updatedOn, r.referralStatusId, ci.itemCode AS referralStatusCode,
            CAST (CASE WHEN ci.itemCode = 'referralNew' OR ci.itemCode = 'referralRejected' THEN 1 ELSE 0 END AS BIT) AS isNew,
            r.rejectReason,
            CASE WHEN c.customerNumber IS NULL THEN c.actorId ELSE c.customerNumber END AS referredCustomerNumber,
            COUNT(*) OVER(PARTITION BY 1) AS recordsTotal
        FROM [customer].[referral] r
        INNER JOIN customer.customer c
        ON r.referralSource = c.actorId
        LEFT JOIN customer.customer rtc
        ON r.referralTarget = rtc.actorId
        INNER JOIN customer.referralStatus rs
        ON rs.referralStatusId = r.referralStatusId
        INNER JOIN core.itemName ci
        ON ci.itemNameId = rs.itemNameId
        WHERE (@actorId IS NULL OR r.referralSource = @actorId)
            AND (@MSISDN IS NULL OR r.MSISDN LIKE @MSISDN)
            AND (@referralId IS NULL OR r.referralId LIKE @referralId)
            AND (@customerNumber IS NULL OR (c.customerNumber LIKE @customerNumber OR c.actorId LIKE @customerNumber))
            AND (@referralStatusId IS NULL OR r.referralStatusId IN (SELECT value FROM @referralStatusIds))
    )
    , CTE1 AS (SELECT * ,
    ROW_NUMBER() OVER(ORDER BY
        CASE WHEN @sortOrder = 'ASC' THEN
        CASE
            WHEN @sortBy = 'referralStatus' THEN CTE.referralStatus
            WHEN @sortBy = 'MSISDN' THEN CONVERT(BIGINT, CTE.MSISDN)
            WHEN @sortBy = 'referralDate' THEN CONVERT(NVARCHAR(50), CTE.referralDate)
            WHEN @sortBy = 'updatedOn' THEN CONVERT(NVARCHAR(50), CTE.updatedOn)
            WHEN @sortBy = 'customerNumber' THEN CONVERT(NVARCHAR(50), CTE.referredCustomerNumber)
            WHEN @sortBy = 'referralId' THEN CONVERT(NVARCHAR(50), CTE.referralId)
        END
        END,
        CASE WHEN @sortOrder = 'DESC' THEN
        CASE
            WHEN @sortBy = 'referralStatus' THEN CTE.referralStatus
            WHEN @sortBy = 'MSISDN' THEN CONVERT(BIGINT, CTE.MSISDN)
            WHEN @sortBy = 'referralDate' THEN CONVERT(NVARCHAR(50), CTE.referralDate)
            WHEN @sortBy = 'updatedOn' THEN CONVERT(NVARCHAR(50), CTE.updatedOn)
            WHEN @sortBy = 'customerNumber' THEN CONVERT(NVARCHAR(50), CTE.referredCustomerNumber)
            WHEN @sortBy = 'referralId' THEN CONVERT(NVARCHAR(50), CTE.referralId)
        END
        END DESC) rowNum
        FROM CTE
        )

    INSERT INTO #referral(referralId, referralSource, referralTarget, referralDate, createdOn, updatedOn, referralStatusId, referralStatusCode, MSISDN, customerNumber, referredCustomerNumber, referralStatus, rejectReason, isNew, rowNum, recordsTotal)
    SELECT referralId, referralSource, referralTarget, referralDate, createdOn, updatedOn, referralStatusId, referralStatusCode, MSISDN, customerNumber, referredCustomerNumber, referralStatus, rejectReason, isNew, rowNum, recordsTotal
    FROM CTE1
    WHERE @pageNumber IS NULL OR @pageSize IS NULL OR rowNum BETWEEN ((@pageNumber - 1) * @pageSize) + 1 AND @pageSize * (@pageNumber)

    SELECT 'referral' AS resultSetName

    SELECT referralId, referralSource, referralTarget, referralDate, createdOn, updatedOn, referralStatusId, referralStatusCode, MSISDN, customerNumber, referredCustomerNumber, rejectReason, referralStatus, isNew, rowNum, recordsTotal
    FROM #referral
    ORDER BY rowNum

    SELECT 'pagination' AS resultSetName

    SELECT TOP 1 @pageSize AS pageSize, recordsTotal AS recordsTotal, @pageNumber AS pageNumber, (recordsTotal - 1) / @pageSize + 1 AS pagesTotal
    FROM #referral

    DROP TABLE #referral


    EXEC core.auditCall @procid = @@PROCID, @params = @callParams

END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
