CREATE FUNCTION [customer].[organizationsVisibleForFlat]
(
    @actor BIGINT
)
RETURNS TABLE AS
RETURN

WITH actors(actorId, parentActorId, depth, countryId, organizationName) AS
(
    SELECT actorId AS actorId, actorId AS parentActorId, 1 AS depth, o.countryId, o.organizationName
    FROM customer.organization o
    WHERE o.actorId = @actor AND o.isDeleted = 0

    UNION ALL

    SELECT h.[subject], [object] AS parentActorId, depth + 1 AS depth, o.countryId, o.organizationName
    FROM core.actorHierarchy h
    JOIN actors a ON a.actorId = h.[object] AND h.predicate = 'memberOf'
    JOIN customer.organization o ON o.actorId = h.subject AND o.isDeleted = 0 -- AND o.isEnabled = 1
)

SELECT DISTINCT a.actorId, parentActorId, countryId, depth, organizationName
FROM actors a
-- JOIN customer.organization o ON o.actorId = a.actorId AND o.isDeleted = 0
