ALTER PROCEDURE [customer].[kyc.add] -- this procedure add a new kyc level with all the conditions and attributes defined in it
    @kyc customer.kycTT READONLY, -- in this parameter is passed the kyc table information - for which branch, status, customer type and etc.
    @kycConditionAttribute customer.kycConditionAttributeTT READONLY, -- in this parameter are passed the defined  attributes and conditions
    @noResultSet BIT = 0, -- thether to return  the added objects as result
    @meta core.metaDataTT READONLY -- information for the logged user
AS

DECLARE @callParams XML
DECLARE @kycId SMALLINT
DECLARE @organizationId BIGINT
DECLARE @customerType INT
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
SET @noResultSet = ISNULL(@noResultSet, 0)

BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
        RETURN 55555

    --check if user has access to the organization
    IF NOT EXISTS(
        SELECT o.actorId
        FROM customer.organizationsVisibleFor(@userId) o
        JOIN @kyc k ON o.actorId = k.organizationId)
        BEGIN
            RAISERROR('customer.securityViolation', 16, 1)
        END

    IF EXISTS (
        SELECT * FROM [customer].[kyc] ck
        JOIN @kyc k ON ck.itemNameId = k.itemNameId AND ck.customerTypeId = k.customerTypeId AND ck.organizationId = k.organizationId
        WHERE ck.isDeleted = 0)
        BEGIN
            RAISERROR('customer.kycLevelAlreadyExists', 16, 1);
        END

    IF EXISTS (
        SELECT * FROM @kyc
        WHERE [customerTypeId] IS NULL OR [organizationId] IS NULL OR [itemNameId] IS NULL OR [description] IS NULL)
        BEGIN
            RAISERROR('customer.kycMissingMandatoryFields', 16, 1);
        END

    IF NOT EXISTS (SELECT 1 FROM @kycConditionAttribute)
        BEGIN
            RAISERROR('customer.kycMissingAttributes', 16, 1);
        END

    --CHECK IF branch depth IS correct
    SET @organizationId = (SELECT organizationId FROM @kyc)
    SET @customerType = (SELECT customerTypeId FROM @kyc)
    EXEC [customer].[kyc.getForCreate] @customerType = @customerType, @organizationId = @organizationId, @noResultSet = 1, @meta = @meta

    --CHECK IF applied KYC attributes are valid FOR customer type
    IF EXISTS (
        SELECT * FROM @kycConditionAttribute
        LEFT JOIN [customer].[kycAttributeType] (@customerType) ON attributeId = itemNameId
        WHERE itemNameId IS NULL)
        BEGIN
            RAISERROR('customer.kycInvalidAttributes', 16, 1);
        END

    INSERT INTO [customer].[kyc] (display, description, statusId, customerTypeId, organizationId, itemNameId, createdOn, createdBy)
    SELECT display, description, 'active', customerTypeId, organizationId, itemNameId, GETDATE(), @userId
    FROM @kyc

    SET @kycId = SCOPE_IDENTITY()

    INSERT INTO [customer].[kycConditionAttribute] (kycId, conditionId, attributeId, conditionCheck)
    SELECT @kycId, conditionId, attributeId, ISNULL (conditionCheck, 'NOT NULL')
    FROM @kycConditionAttribute

    IF @noResultSet = 0
    BEGIN
        SELECT 'kyc' AS resultSetName

        SELECT kycId, display, description, statusId, customerTypeId, organizationId, itemNameId
        FROM [customer].[kyc]
        WHERE kycId = @kycId
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
