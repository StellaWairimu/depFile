ALTER PROCEDURE customer.[address.update] -- update changed data of address in customer.address table
    @address customer.addressTTU READONLY, -- in this parameter the stored procedure receives all changed fields
    @noResultSet BIT = 0, -- this is the flag about the waited result
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
    DECLARE @result customer.addressTT
    DECLARE @addressXML TABLE (addressId BIGINT, oldXmlValues XML, newXml XML, resultXml XML)

    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    INSERT INTO @addressXML(addressId, oldXmlValues, newXml)
    SELECT addressId, (
        SELECT *
        FROM customer.[address]
        WHERE addressId = a.addressId
        FOR XML PATH('oldUdf') , TYPE, ELEMENTS XSINIL),
            (SELECT * FROM @address aIn
            WHERE aIn.addressId = a.addressId
            FOR XML PATH('udf'))
    FROM @address a
    WHERE a.addressId IS NOT NULL

    UPDATE @addressXML
    SET resultXml = core.mergeXML(oldXmlValues, @userId, newXML)

    UPDATE a
    SET a.[value] = CASE WHEN att.valueUpdated = 1 THEN att.value ELSE a.value END,
        a.addressTypeId = CASE WHEN att.addressTypeIdUpdated = 1 THEN att.addressTypeId ELSE a.addressTypeId END,
        a.statusId = CASE WHEN att.statusIdUpdated = 1 THEN att.statusId ELSE a.statusId END,
        a.oldValues = resultXml,
        a.city = CASE WHEN att.cityUpdated = 1 THEN att.city ELSE a.city END,
        a.lat = CASE WHEN att.latUpdated = 1 THEN att.lat ELSE a.lat END,
        a.lng = CASE WHEN att.lngUpdated = 1 THEN att.lng ELSE a.lng END
        --p.updatedOn = SYSDATETIMEOFFSET(),
        --p.updatedBy = (SELECT [auth.actorId] FROM @meta )
    OUTPUT INSERTED.* INTO @result
    FROM customer.[address] a
    INNER JOIN @address att ON att.addressId = a.addressId
    JOIN @addressXML aXml ON aXml.addressId = a.addressId


    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'address' AS resultSetName
        SELECT * FROM @result
    END
    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
