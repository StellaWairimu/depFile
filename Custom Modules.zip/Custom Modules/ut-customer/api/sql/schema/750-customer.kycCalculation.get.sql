ALTER PROCEDURE [customer].[kycCalculation.get] -- get info for kyc calculation
    @actorId BIGINT, --id of the customer
    @organizationId BIGINT, --id of the organization
    @meta core.metaDataTT READONLY -- information for the logged user
AS
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    DECLARE @languageId BIGINT = (
        SELECT languageId
        FROM [core].[language] cl
        JOIN [user].[session] us ON us.[language] = cl.[iso2Code]
        WHERE us.[actorId] = @userId)

    SELECT 'customerInfo' AS resultSetName

    SELECT
        cp.[actorId],
        cp.[firstName],
        cp.[middleName],
        cp.[lastName],
        cp.[gender],
        cp.[dateOfBirth],
        cp.[familyMembers],
        cp.[nationality],
        cin.itemName AS maritalStatus,
        cin1.itemName AS education,
        cin2.itemNameId AS employment,
        cp.[employerName],
        cin3.itemNameId AS employerCategory,
        cp.[employmentDate],
        cin4.itemNameId AS incomeRange,
        cin5.itemNameId AS businessSector,
        ctr.[name] AS countryZone1,
        ca.[addressZone1] AS addressZone2,
        ca.[addressZone2] AS addressZone3,
        ca.[addressZone3] AS addressZone4,
        ca.[addressZone4] AS addressStreet,
        ca.lat + ca.lng AS gpsCoordinates,
        ph.[phoneNumber] AS mobileNumber
    FROM [customer].[person] cp
    LEFT JOIN [customer].[maritalStatus] cms ON cms.maritalStatusId = cp.maritalStatusId
    LEFT JOIN core.itemName cin ON cin.itemNameId = cms.itemNameId
    LEFT JOIN [customer].[education] ced ON ced.educationId = cp.educationId
    LEFT JOIN core.itemName cin1 ON cin1.itemNameId = ced.itemNameId
    LEFT JOIN [customer].[employment] cem ON cem.employmentId = cp.employmentId
    LEFT JOIN core.itemName cin2 ON cin2.itemNameId = cem.itemNameId
    LEFT JOIN [customer].[employerCategory] cec ON cec.employerCategoryId = cp.employerCategoryId
    LEFT JOIN core.itemName cin3 ON cin3.itemNameId = cec.itemNameId
    LEFT JOIN [customer].[incomeRange] cir ON cir.incomeRangeId = cp.incomeRangeId
    LEFT JOIN core.itemName cin4 ON cin4.itemNameId = cir.itemNameId
    LEFT JOIN [customer].[customer] cc ON cc.actorId = cp.actorId
    LEFT JOIN [customer].[industry] ci ON ci.industryId = cc.industryId
    LEFT JOIN core.itemName cin5 ON cin5.itemNameId = ci.itemNameId
    LEFT JOIN [customer].[country] ctr ON ctr.countryId = cc.countryId
    LEFT JOIN [customer].[address] ca ON ca.actorId = cp.actorId
    LEFT JOIN [customer].[phone] ph ON ph.actorId = cp.actorId AND (ph.isPrimary = 1 OR isPrimary = NULL)
    WHERE cp.actorId = @actorId


    SELECT 'documentInfo' AS resultSetName

    SELECT dad.actorId, documentTypeId, documentNumber, [name] AS idPlaceOfIsssue, expirationDate AS idDateOfIssue, da.attachmentId, dad.documentOrder
    FROM [document].[actorDocument] dad
    JOIN [document].[document] dd ON dd.documentId = dad.documentId
    LEFT JOIN [document].[attachment] da ON da.documentId = dd.documentId
    LEFT JOIN core.country cc ON cc.countryId = dd.countryId
    WHERE dad.actorId = @actorId


    SELECT 'kyc' AS resultSetName

    SELECT k.kycId, k.itemNameId, cin.itemCode, it.itemNameTranslation AS displayName, k.[description], k.statusId, ct.customerTypeId,
        ct.[description] AS customerType, ct.customerTypeNumber, k.organizationId, o.organizationName
    FROM [customer].[kyc] k
    JOIN [customer].[customerType] ct ON k.customerTypeId = ct.customerTypeNumber
    JOIN [customer].[organization] o ON k.organizationId = o.actorId
    JOIN core.itemTranslation it ON it.itemNameId = k.itemNameId AND it.languageId = @languageId
    JOIN core.itemName cin ON cin.itemNameId = k.itemNameId
    WHERE k.organizationId = @organizationId AND k.isDeleted = 0 AND k.statusId = 'active'


    SELECT 'kycAttributes' AS resultSetName

    SELECT k.kycId, kycConditionAttributeId, conditionId, attributeId, itemCode, itemNameTranslation, conditionCheck
    FROM [customer].[kycConditionAttribute] kca
    JOIN [customer].[kyc] k ON k.kycId = kca.kycId
    JOIN core.itemName cin ON cin.itemNameId = kca.attributeId
    JOIN core.itemTranslation it ON it.itemNameId = kca.attributeId AND it.languageId = @languageId
    WHERE k.organizationId = @organizationId AND k.isDeleted = 0 AND k.statusId = 'active'
