CREATE PROCEDURE [customer].[organization.mergeJSON] -- merge passed JSON into organization, phone, address, email, actorProperty and actorHierarchy
    @json NVARCHAR(max) -- data to merge
AS
DECLARE @jsonHierarchy [core].[JSONHierarchy];
INSERT INTO @jsonHierarchy SELECT * FROM [core].[fromJSON](@json);

DECLARE @flat TABLE (
    actorId BIGINT,
    organizationName NVARCHAR(max),
    organizationType NVARCHAR(max),
    [description] NVARCHAR(1000),
    code NVARCHAR(max),
    country NVARCHAR(max),
    properties INT,
    parents INT,
    phone INT,
    email INT,
    address INT
)

DECLARE @rootObjectId int = (SELECT objectId FROM @jsonHierarchy WHERE parentId IS NULL)

INSERT INTO @flat (actorId, organizationName, organizationType, [description], code, country, properties, parents, phone, email, [address])
SELECT o.actorId, p.organizationName, p.organizationType, p.description, p.code, p.country, p.properties, p.parents, p.phone, p.email, p.address
FROM (
    SELECT
        parentId, [name], stringValue
    FROM @jsonHierarchy
    WHERE parentId IN (SELECT objectId FROM @jsonHierarchy WHERE parentId = @rootObjectId)
) h
PIVOT(
    MAX(h.stringValue)
    FOR h.[name] IN (organizationName, organizationType, [description], code, country, properties, parents, phone, email, [address])
) p
LEFT JOIN customer.organization o ON p.code = o.code

DECLARE @code NVARCHAR(200);
WHILE (1 = 1)
BEGIN
    SET @code = (SELECT TOP 1 code FROM @flat WHERE actorId IS NULL)
    IF (@code IS NULL)
        BREAK;

    INSERT INTO core.actor ([actorType], [isEnabled])
    VALUES ('organization', 1)

    UPDATE @flat
    SET actorId = SCOPE_IDENTITY()
    WHERE code = @code
END

DECLARE @organizationTypeId tinyint = (SELECT organizationTypeId FROM customer.organizationType WHERE organizationType = 'businessUnit');

MERGE INTO
    customer.organization AS target
USING
(
    SELECT
        f.actorId, f.organizationName, f.code, c.countryId, o.organizationTypeId, f.description
    FROM
        @flat f
    LEFT JOIN core.country c ON f.country = c.name
    LEFT JOIN customer.organizationType o ON f.organizationType = o.organizationType
) AS source
ON
    target.code = source.code
WHEN NOT MATCHED BY target THEN
    INSERT
        ([actorId], [organizationName], [code], [isEnabled], [isDeleted], [countryId], [organizationTypeId], [description])
    VALUES
        (source.actorId, source.organizationName, source.code, 1, 0, source.countryId, ISNULL(source.organizationTypeId, @organizationTypeId), source.description)
WHEN MATCHED THEN
    UPDATE SET
        target.[organizationName] = source.[organizationName],
        target.[description] = source.[description],
        target.[countryId] = source.[countryId],
        target.[organizationTypeId] = ISNULL(source.organizationTypeId, @organizationTypeId);

-- phone
MERGE INTO
    customer.phone AS target
USING
(
    SELECT
        actorId, phoneNumber, phoneTypeId, statusId, isPrimary
    FROM (
        SELECT
            f.actorId,
            h2.parentId, -- used for grouping
            CASE h1.valueType WHEN 'object' THEN h2.name ELSE h1.name END AS name, -- cover both object or array
            CASE h1.valueType WHEN 'object' THEN h2.stringValue ELSE h1.stringValue END AS stringValue -- cover both object or array
        FROM @flat f
        JOIN @jsonHierarchy h1 ON h1.parentId = f.phone
        LEFT JOIN @jsonHierarchy h2 ON h2.parentId = h1.objectId
        WHERE f.phone IS NOT NULL
    ) h
    PIVOT(
        MAX(h.stringValue)
        FOR h.[name] IN (phoneNumber, phoneTypeId, statusId, isPrimary)
    ) p
) AS source
ON
    target.actorId = source.actorId
    AND target.phoneNumber = source.phoneNumber -- To think of a way of updating phone numbers!!!
WHEN NOT MATCHED BY target THEN
INSERT (
    actorId,
    phoneNumber,
    phoneTypeId,
    statusId,
    isPrimary
)
VALUES (
    source.actorId,
    source.phoneNumber,
    ISNULL(source.phoneTypeId, 'work'),
    ISNULL(source.statusId, 'active'),
    ISNULL(source.isPrimary, 0)
);

-- address
MERGE INTO
    customer.address AS target
USING
(
    SELECT
        actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
    FROM (
        SELECT
            f.actorId,
            h2.parentId, -- used for grouping
            CASE h1.valueType WHEN 'object' THEN h2.name ELSE h1.name END AS name,
            CASE h1.valueType WHEN 'object' THEN h2.stringValue ELSE h1.stringValue END AS stringValue
        FROM @flat f
        JOIN @jsonHierarchy h1 ON h1.parentId = f.address
        LEFT JOIN @jsonHierarchy h2 ON h2.parentId = h1.objectId
        WHERE f.address IS NOT NULL
    ) h
    PIVOT(
        MAX(h.stringValue)
        FOR h.[name] IN (value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    ) p
) AS source
ON
    target.actorId = source.actorId
    AND target.value = source.value -- To think of a way of updating address!!!
WHEN NOT MATCHED BY target THEN
INSERT (
    actorId,
    value,
    addressTypeId,
    statusId,
    city,
    lat,
    lng,
    addressZone1,
    addressZone2,
    addressZone3,
    addressZone4
)
VALUES (
    source.actorId,
    source.value,
    ISNULL(source.addressTypeId, 'work'),
    ISNULL(source.statusId, 'active'),
    source.city,
    source.lat,
    source.lng,
    source.addressZone1,
    source.addressZone2,
    source.addressZone3,
    source.addressZone4
);

-- email
MERGE INTO
    customer.email AS target
USING
(
    SELECT
        actorId, value, emailTypeId, statusId, isPrimary
    FROM (
        SELECT
            f.actorId,
            h2.parentId, -- used for grouping
            CASE h1.valueType WHEN 'object' THEN h2.name ELSE h1.name END AS name,
            CASE h1.valueType WHEN 'object' THEN h2.stringValue ELSE h1.stringValue END AS stringValue
        FROM @flat f
        JOIN @jsonHierarchy h1 ON h1.parentId = f.email
        LEFT JOIN @jsonHierarchy h2 ON h2.parentId = h1.objectId
        WHERE f.email IS NOT NULL
    ) h
    PIVOT(
        MAX(h.stringValue)
        FOR h.[name] IN (value, emailTypeId, statusId, isPrimary)
    ) p
) AS source
ON
    target.actorId = source.actorId
    AND target.value = source.value -- To think of a way of updating email address!!!
WHEN NOT MATCHED BY target THEN
INSERT (
    actorId,
    value,
    emailTypeId,
    statusId,
    isPrimary
)
VALUES (
    source.actorId,
    source.value,
    ISNULL(source.emailTypeId, 'work'),
    ISNULL(source.statusId, 'active'),
    ISNULL(source.isPrimary, 0)
);

-- properties
MERGE INTO
    [core].[actorProperty] AS target
USING
(
    SELECT
        f.actorId,
        h.name,
        h.stringValue
    FROM @flat f
    JOIN @jsonHierarchy h ON h.parentId = f.properties
    WHERE f.properties IS NOT NULL
) AS source
ON
    target.actorId = source.actorId
    AND target.name = source.name
WHEN MATCHED AND target.value != source.stringValue THEN
    UPDATE
    SET target.value = source.stringValue
WHEN NOT MATCHED BY TARGET THEN
    INSERT (actorId, name, value)
    VALUES (source.actorId, source.name, source.stringValue);
-- maybe delete if not matched by source

-- parents
MERGE INTO [core].[actorHierarchy] target
USING
(
    SELECT DISTINCT
        child.actorId subject, parent.actorId object
    FROM
        @flat child
    JOIN
        @jsonHierarchy h ON child.parents = h.parentId
    JOIN
        @flat parent ON h.stringValue = parent.code

) AS source
ON target.subject = source.subject AND target.object = source.object -- AND target.predicate = 'memberOf'
WHEN NOT MATCHED BY TARGET THEN
    INSERT (subject, predicate, object)
    VALUES (source.subject, 'memberOf', source.object);


-- rebuild the whole hierarchy
DELETE FROM [customer].[organizationHierarchyFlat]

INSERT INTO [customer].[organizationHierarchyFlat] ([subject], [parentActorId], [object], [relationDepth])
SELECT a.actorId AS [subject], h.parentActorId, h.actorId AS [object], h.depth AS [relationDepth]
FROM customer.organization a
CROSS APPLY [customer].[organizationsVisibleForFlat](a.actorId) h
LEFT JOIN [customer].[organizationHierarchyFlat] ch ON ch.[subject] = a.actorId AND ch.[object] = h.actorId AND ch.[parentActorId] = h.parentActorId
WHERE ch.[subject] IS NULL
