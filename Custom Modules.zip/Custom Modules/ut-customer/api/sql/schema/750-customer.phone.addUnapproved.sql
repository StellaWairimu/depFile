ALTER PROCEDURE customer.[phone.addUnapproved] -- create new phones in customer.phone/customer.phoneunapproved table
    @phone customer.phoneTT READONLY, -- in this parameter the stored procedure receives all fields of phones
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
    DECLARE @oldValues XML, @Today DATETIME2 = GETDATE()

-- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @result customer.phoneUnapprovedTT

    INSERT INTO [customer].[phoneUnapproved] (phoneId, actorId, frontEndRecordId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary, isDeleted, updatedBy, updatedOn)
    OUTPUT INSERTED.phoneUnapprovedId, INSERTED.phoneId, INSERTED.actorId, INSERTED.frontEndRecordId, INSERTED.phoneTypeId, INSERTED.phoneNumber, INSERTED.statusId, INSERTED.mnoId, INSERTED.isPrimary, INSERTED.isDeleted, INSERTED.updatedBy, INSERTED.updatedOn
    INTO @result (phoneUnapprovedId, phoneId, actorId, frontEndRecordId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary, isDeleted, updatedBy, updatedOn)
    SELECT ph.phoneId, ph.actorId, ph.frontEndRecordId, ph.phoneTypeId, ph.phoneNumber, ISNULL(ph.statusId, 'active'), ph.mnoId, ph.isPrimary, 0, @userId, SYSDATETIMEOFFSET()
    FROM @phone ph

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'phone' AS resultSetName
        SELECT phoneUnapprovedId, phoneId, actorId, frontEndRecordId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary, isDeleted, updatedBy, updatedOn FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
