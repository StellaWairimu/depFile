ALTER PROCEDURE customer.[person.addUnapproved] -- create new persons in customer.person/customer.personunapproved table
    @person customer.personTT READONLY, -- in this parameter the stored procedure receives all fields of persons
    @email customer.emailTT READONLY, -- information about the e-mails of the person
    @phone customer.phoneTT READONLY, -- information about the phone numbers of the person
    @address customer.addressTT READONLY, -- information about the addresses of the person
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 1 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
    DECLARE @oldValues XML
    DECLARE @Today DATETIME2 = GETDATE()

-- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @result customer.personUnapprovedTT

    INSERT INTO [customer].[personUnapproved] (actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, updatedBy, updatedOn, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers)
    OUTPUT INSERTED.personUnapprovedId, INSERTED.actorId, INSERTED.firstName, INSERTED.lastName, INSERTED.nationalId, INSERTED.dateOfBirth, INSERTED.placeOfBirth, INSERTED.nationality, INSERTED.gender, INSERTED.bioId, INSERTED.phoneModel, INSERTED.computerModel, INSERTED.isEnabled, INSERTED.isDeleted, INSERTED.maritalStatusId, INSERTED.age, INSERTED.updatedBy, INSERTED.updatedOn, INSERTED.middleName, INSERTED.educationId, INSERTED.employmentId, INSERTED.employmentDate, INSERTED.incomeRangeId, INSERTED.employerName, INSERTED.employerCategoryId, INSERTED.familyMembers
    INTO @result (personUnapprovedId, actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, updatedBy, updatedOn, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers)
    SELECT ph.actorId, ph.firstName, ph.lastName, ph.nationalId, ph.dateOfBirth, ph.placeOfBirth, CASE WHEN c.name IS NOT NULL THEN c.name ELSE ph.nationality END AS nationality, ph.gender, ph.bioId, ph.phoneModel, ph.computerModel, ph.isEnabled, 0, ph.maritalStatusId, ph.age, @userId, SYSDATETIMEOFFSET(), ph.middleName, ph.educationId, ph.employmentId, ph.employmentDate, ph.incomeRangeId, ph.employerName, ph.employerCategoryId, ph.familyMembers
    FROM @person ph
    LEFT JOIN customer.person p ON p.actorId = ph.actorId
    LEFT JOIN core.country c ON CAST(c.countryId AS VARCHAR(50)) = ph.nationality
    WHERE p.actorId IS NULL


    EXEC customer.[email.addUnapproved] @email = @email, @noResultSet = 1, @meta = @meta

    EXEC customer.[phone.addUnapproved] @phone = @phone, @noResultSet = 1, @meta = @meta

    EXEC customer.[address.addUnapproved] @address = @address, @noResultSet = 1, @meta = @meta


    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'person' AS resultSetName, 1 AS single
        SELECT personUnapprovedId, actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, updatedBy, updatedOn, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
