ALTER PROCEDURE [customer].[actorContacts.list] -- provides lists of actor emails and phone numbers
    @actorId BIGINT -- id of the searched actor contacts
AS

SELECT 'actorEmails' AS resultSetName
SELECT emailId, value
FROM customer.email
WHERE actorId = @actorId
    AND statusId = 'active'

SELECT 'actorPhoneNumbers' AS resultSetName
SELECT phoneId, phoneNumber
FROM customer.phone
WHERE actorId = @actorId
    AND statusId = 'active'

