ALTER PROCEDURE [customer].[organization.fetch] -- fetches organization information
    @businessUnitId BIGINT = NULL, -- the id of the business unit the user is entitled to filter by
    @searchString NVARCHAR(100), -- the string to be searched in organization name or organization parents
    @isEnabled BIT, -- the organization status to filter by
    @statusId VARCHAR(20) = NULL, --filter by status of the user, e.g. new, pending, rejected
    @pageSize INT = 25, -- how many rows will be returned per page
    @pageNumber INT = 1, -- which page number to display
    @sortBy VARCHAR(50) = 'name', -- on which column results to be sorted
    @sortOrder VARCHAR(4) = 'ASC', -- what kind of sort to be used ascending or descending
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @startRow INT = (@pageNumber - 1) * @pageSize + 1
DECLARE @endRow INT = @startRow + @pageSize - 1
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)

-- checks if the user has a right to make the operation
DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
IF @return != 0
BEGIN
    RETURN 55555
END
-- checks IF the BU IS visible FOR the user
IF @businessUnitId IS NOT NULL
BEGIN
    DECLARE @buArray core.ArrayNumberList
    INSERT INTO @buArray VALUES(@businessUnitId)

    EXEC [user].[visibility.check] @objectIds = @buArray, @meta = @meta
END

IF OBJECT_ID('tempdb..#Organizations') IS NOT NULL
    DROP TABLE #Organizations

CREATE TABLE #Organizations(actorId BIGINT, organizationName NVARCHAR(100), isEnabled BIT, statusId VARCHAR(20), rejectReason NVARCHAR(MAX), isOwn BIT, recordsTotal INT, rowNum INT)

;WITH CTE AS
(
    SELECT DISTINCT o.actorId, o.organizationName, o.isEnabled, statusId, rejectReason,
        CASE WHEN o.actorId IN (SELECT ah.[object]
            FROM core.actorHierarchy ah
            JOIN customer.organization o ON o.actorId = ah.[object] AND o.isEnabled = 1
            WHERE [subject] = @userId AND predicate = 'memberOf') THEN 1 ELSE 0 END AS isOwn,
        ROW_NUMBER() OVER(ORDER BY
            CASE WHEN @sortOrder = 'ASC' THEN
                CASE
                WHEN @sortBy = 'name' THEN organizationName
                WHEN @sortBy = 'statusId' THEN statusId
                WHEN @sortBy = 'isEnabled' THEN CONVERT(NVARCHAR(1), isEnabled) END
            END,
            CASE WHEN @sortOrder = 'DESC' THEN
                CASE
                WHEN @sortBy = 'name' THEN organizationName
                WHEN @sortBy = 'statusId' THEN statusId
                WHEN @sortBy = 'isEnabled' THEN CONVERT(NVARCHAR(1), isEnabled) END
            END DESC) rowNum,
            COUNT( * ) OVER(PARTITION BY 1) AS recordsTotal
    FROM
        (SELECT o.actorId, o.organizationName, o.isEnabled, o.isDeleted, o.organizationTypeId, CASE WHEN ou.statusId IS NULL THEN 'approved' ELSE ou.statusId END AS statusId, NULL AS rejectReason
        FROM customer.organization o
        LEFT JOIN customer.organizationUnapproved ou ON ou.actorId = o.actorId -- to get statusId
        UNION ALL
        SELECT ou.actorId, ou.organizationName, ou.isEnabled, ou.isDeleted, ou.organizationTypeId, ou.statusId, ou.rejectReason -- to get new organizations
        FROM customer.organizationUnapproved ou
        LEFT JOIN customer.organization o ON o.actorId = ou.actorId
        WHERE o.actorId IS NULL) o -- we have all organizations
        JOIN [customer].[organizationsVisibleForUnapproved](@userId) m ON o.actorId = m.actorId -- filter organizations visible FOR the user
        JOIN [customer].[organizationType] ot ON o.organizationTypeId = ot.organizationTypeId
        OUTER APPLY -- only FOR filter - IF @businessUnitId IS NULL, it returns NULL, IF @businessUnitId IS NOT NULL, we get filtered BUs --see WHERE par.actorId IS NOT NULL
        (
            SELECT DISTINCT actorId -- get all (users + organizations) members of @businessUnitId AND JOIN to organizations to get only organizations
            FROM (
                SELECT ah.[subject] AS actorId -- get all organizations members of visible organizations, or @businessUnitId
                    FROM (
                        SELECT [subject], predicate, [object] FROM core.actorHierarchy
                        UNION ALL
                        SELECT [subject], predicate, [object]
                        FROM [core].[actorHierarchyUnapproved] ahu) ah
                    WHERE ah.predicate = 'memberOf' AND ah.[subject] = m.actorId AND ah.[object] = @businessUnitId -- get direct branches
                    UNION ALL
                    SELECT g.actorId -- get NOT direct branches AND search IN them - will be displayed only IN search, should NOT be displayed ON filter!!!
                    FROM [user].actorGraphUnapproved(CASE WHEN @businessUnitId IS NOT NULL AND @searchString IS NOT NULL AND @searchString <> '' THEN @businessUnitId END, 'memberOf', 'object') g
                    JOIN (
                        SELECT o.actorId -- get only organizations
                        FROM customer.organization o
                        UNION ALL
                        SELECT ou.actorId
                        FROM customer.organizationUnapproved ou
                        LEFT JOIN customer.organization o ON o.actorId = ou.actorId
                        WHERE o.actorId IS NULL) o ON g.actorId = o.actorId
                    WHERE g.actorId = m.actorId
                    AND g.actorId <> @businessUnitId
                ) x

    ) par

    WHERE (@searchString IS NULL OR o.organizationName LIKE '%' + @searchString + '%')
    AND (@isEnabled IS NULL OR o.isEnabled = @isEnabled)
    AND o.isDeleted = 0
    AND (@statusId IS NULL OR o.statusId = @statusId)
    AND (@businessUnitId IS NULL OR par.actorId IS NOT NULL)
    AND organizationType = 'businessUnit'
)

INSERT INTO #Organizations(actorId, organizationName, isEnabled, statusId, rejectReason, isOwn, recordsTotal, rowNum)
SELECT actorId, organizationName, isEnabled, statusId, rejectReason, isOwn, recordsTotal, rowNum
FROM CTE
WHERE rowNum BETWEEN ((@PageNumber - 1) * @pageSize) + 1 AND @pageSize * (@PageNumber)

SELECT 'organization' AS resultSetName

SELECT actorId, organizationName, par.parents, isEnabled, statusId, rejectReason, isOwn
FROM #Organizations o
OUTER APPLY(
    SELECT ISNULL(STUFF(
        (SELECT ', ' + oo.organizationName
        FROM core.actorHierarchy ah
        JOIN customer.organization oo ON oo.actorId = ah.[object] AND oo.isEnabled = 1
        WHERE ah.[subject] = o.actorId AND ah.predicate = 'memberOf'
        ORDER BY oo.organizationName
        FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(max)'), 1, 2, ''), '') AS parents
) par
ORDER BY CASE WHEN @sortBy = 'parents'
    THEN ROW_NUMBER() OVER(ORDER BY
        CASE WHEN @sortOrder = 'ASC' THEN parents END,
        CASE WHEN @sortOrder = 'DESC' THEN parents END DESC)
        ELSE rowNum END

SELECT 'parent' AS resultSetName
SELECT o.actorId, o.organizationName, o.isEnabled, CASE WHEN ou.statusId IS NULL THEN 'approved' ELSE ou.statusId END AS statusId,
    (
        SELECT ISNULL(STUFF(
            (SELECT ', ' + oo.organizationName
            FROM core.actorHierarchy ah
            JOIN customer.organization oo ON oo.actorId = ah.[object] AND oo.isEnabled = 1
            WHERE ah.[subject] = o.actorId AND ah.predicate = 'memberOf'
            ORDER BY oo.organizationName
            FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(max)'), 1, 2, ''), '')) AS parents,
    CASE WHEN o.actorId IN (
        SELECT ah.[object]
        FROM core.actorHierarchy ah
        JOIN customer.organization o ON o.actorId = ah.[object] AND o.isEnabled = 1
        WHERE [subject] = @userId AND predicate = 'memberOf') THEN 1 ELSE 0 END AS isOwn
FROM customer.organization o
LEFT JOIN customer.organizationUnapproved ou ON ou.actorId = o.actorId -- to get statusId
WHERE o.actorId = @businessUnitId

SELECT 'pagination' AS resultSetName

SELECT TOP 1 @pageSize AS pageSize, recordsTotal AS recordsTotal, @pageNumber AS pageNumber, (recordsTotal - 1) / @pageSize + 1 AS pagesTotal
FROM #Organizations

DROP TABLE #Organizations
