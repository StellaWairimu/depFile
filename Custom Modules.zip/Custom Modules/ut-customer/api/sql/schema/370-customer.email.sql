CREATE TABLE customer.email( -- table that stores all e-mails
    emailId INT IDENTITY(1000, 1) NOT NULL, -- the id of the e-mail
    actorId BIGINT, -- the id of the actor, who the e-mail belongs to
    value VARCHAR (50) NOT NULL, -- the e-mail value
    frontEndRecordId VARCHAR (10), -- an id, needed for the frontend of the mobile app
    emailTypeId VARCHAR (20) NOT NULL, -- the emailTypeId, e.g. personal, work
    statusId VARCHAR (20) NOT NULL, -- the statusId of the e-mail, e.g. active/inactive
    oldValues XML NULL, -- history of old values of customer e-mails
    isPrimary BIT NOT NULL DEFAULT(0), -- a flag to show if the email is primary
    CONSTRAINT pkCustomerEmail PRIMARY KEY CLUSTERED(emailId ASC),
    CONSTRAINT fkCustomerEmail_coreActor FOREIGN KEY(actorId) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerEmail_customerEmailType FOREIGN KEY(emailTypeId) REFERENCES customer.emailType (emailTypeId),
    CONSTRAINT fkCustomerEmail_coreStatus FOREIGN KEY(statusId) REFERENCES core.[status] (statusId)
)
