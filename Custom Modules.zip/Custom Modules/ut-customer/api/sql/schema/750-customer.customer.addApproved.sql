ALTER PROCEDURE customer.[customer.addApproved] -- approve new customers in customer.customer table
    @actorId BIGINT, -- customer id
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY

    DECLARE @TranCounter INT = @@TRANCOUNT;
    IF @TranCounter = 0
        BEGIN TRANSACTION

            EXEC customer.[person.addApproved] @actorId = @actorId, @noResultSet = @noResultSet, @meta = @meta

            EXEC ledger.[account.approve] @ownerId = @actorId, @meta = @meta

            EXEC document.[document.addApproved] @actorId = @actorId, @noResultSet = @noResultSet, @meta = @meta

            INSERT INTO customer.customer (
                actorId, customerNumber, customerTypeId, kycId, stateId, statusId, createdBy, createdOn, updatedBy, updatedOn,
                customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee, udf)
            SELECT
                actorId, customerNumber, customerTypeId, kycId, ISNULL(stateId, 'up_to_date'), 'approved', createdBy, createdOn, updatedBy, updatedOn,
                customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee, udf
            FROM customer.customerUnapproved pu
            WHERE pu.actorId = @actorId

            DELETE FROM customer.customerUnapproved WHERE actorId = @actorId

            IF @TranCounter = 0
        COMMIT TRANSACTION

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'customer' AS resultSetName
        SELECT actorId, customerNumber, customerTypeId, kycId, stateId, statusId, createdBy, createdOn, updatedBy, updatedOn,
            customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee
        FROM customer.customer
        WHERE actorId = @actorId
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
