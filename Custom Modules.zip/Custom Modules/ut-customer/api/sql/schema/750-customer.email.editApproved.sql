ALTER PROCEDURE [customer].[email.editApproved] -- edits email information
    @actorId BIGINT, -- customer id
    @noResultSet BIT = 0, -- a flag to show IF result IS expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @result customer.emailTT

BEGIN TRY
    DELETE e
    FROM customer.email e
    LEFT JOIN customer.emailUnapproved eu ON e.emailId = eu.emailId
    WHERE e.actorId = @actorId AND eu.emailId IS NULL

    UPDATE e
    SET e.value = t.value,
        e.emailTypeId = t.emailTypeId,
        e.statusId = ISNULL(t.statusId, 'active'),
        e.isPrimary = t.isPrimary
    OUTPUT INSERTED.emailId, INSERTED.actorId, INSERTED.value, INSERTED.emailTypeId, INSERTED.statusId, INSERTED.isPrimary
    INTO @result (emailId, actorId, value, emailTypeId, statusId, isPrimary)
    FROM customer.emailUnapproved t
    JOIN customer.email e ON t.emailId = e.emailId
    WHERE t.actorId = @actorId

    INSERT INTO [customer].[email] (actorId, value, emailTypeId, statusId, isPrimary)
    OUTPUT INSERTED.emailId, INSERTED.actorId, INSERTED.value, INSERTED.emailTypeId, INSERTED.statusId, INSERTED.isPrimary
    INTO @result (emailId, actorId, value, emailTypeId, statusId, isPrimary)
    SELECT actorId, value, ISNULL(emailTypeId, 'home'), ISNULL(e.statusId, 'active'), isPrimary
    FROM customer.emailUnapproved e
    WHERE e.emailId IS NULL AND e.actorId = @actorId

    DELETE FROM customer.emailUnapproved WHERE actorId = @actorId

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'email' AS resultSetName
        SELECT emailId, actorId, value, emailTypeId, statusId, isPrimary
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
