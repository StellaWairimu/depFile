CREATE TABLE [customer].[addressType]( -- table that stores types of addresses
    [addressTypeId] [VARCHAR] (20) NOT NULL, -- the Id of the address type, e.g. home/work
    [description] [VARCHAR] (100), -- description of the address type
    [statusId] [VARCHAR] (20) NOT NULL, -- the status of the address type, e.g. active/inactive
    CONSTRAINT [pkCustomerAddressType] PRIMARY KEY ([addressTypeId]),
    CONSTRAINT [fkCustomerAddressType_coreStatus] FOREIGN KEY([statusId]) REFERENCES [core].[status] ([statusId])
)
