ALTER PROCEDURE customer.[person.addApproved] -- create new phones in customer.phone table
    @actorId BIGINT, -- customer id
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    INSERT INTO customer.person (
        actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId,
        phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, middleName, educationId, employmentId, employmentDate,
        incomeRangeId, employerName, employerCategoryId, familyMembers)
    SELECT actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId,
        phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, middleName, educationId, employmentId, employmentDate,
        incomeRangeId, employerName, employerCategoryId, familyMembers
    FROM [customer].[personUnapproved] pu
    WHERE pu.actorId = @actorId

    DELETE FROM [customer].[personUnapproved] WHERE actorId = @actorId

    EXEC customer.[email.addApproved] @actorId = @actorId, @meta = @meta, @noResultSet = 1

    EXEC customer.[phone.addApproved] @actorId = @actorId, @meta = @meta, @noResultSet = 1

    EXEC customer.[address.addApproved] @actorId = @actorId, @meta = @meta, @noResultSet = 1

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'person' AS resultSetName, 1 AS single
        SELECT actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId,
            phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, middleName, educationId, employmentId, employmentDate,
            incomeRangeId, employerName, employerCategoryId, familyMembers
        FROM customer.person
        WHERE actorId = @actorId
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
