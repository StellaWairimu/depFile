ALTER PROCEDURE [customer].[referral.get] -- to list alias, key column and value
    @referralId BIGINT,
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
BEGIN TRY
    DECLARE @callParams XML
        DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)

        -- checks if the user has a right to make the operation
        DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
        EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
        IF @return != 0
        BEGIN
            RETURN 55555
        END

    SELECT 'referral' AS resultSetName
    SELECT r.referralId, r.referralSource, r.referralTarget, r.MSISDN, r.referralStatusId, r.referralDate, r.updatedOn,
        r.updatedBy, r.rejectReason,
        CAST (CASE WHEN ci.itemCode = 'referralNew' OR ci.itemCode = 'referralRejected' THEN 1 ELSE 0 END AS BIT) AS isNew,
        c.customerNumber,
        ci.itemName AS referralStatus
        FROM customer.referral r
        INNER JOIN customer.customer c
        ON r.referralSource = c.actorId
        INNER JOIN customer.referralStatus rs
        ON rs.referralStatusId = r.referralStatusId
        INNER JOIN core.itemName ci
        ON ci.itemNameId = rs.itemNameId
        WHERE r.referralId = @referralId

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams

END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
