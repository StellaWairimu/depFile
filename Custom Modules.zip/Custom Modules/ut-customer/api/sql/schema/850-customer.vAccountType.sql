ALTER VIEW [customer].[vAccountType]
AS
SELECT cat.accountTypeId, cat.accountTypeCode, cat.itemNameId, i.itemCode, i.itemSyncId, i.organizationId, i.countryId, i.itemName, i.itemTypeId
FROM customer.[accountType] AS cat
JOIN core.itemName i ON i.itemNameId = cat.itemNameId
WHERE i.isEnabled = 1
