ALTER PROCEDURE [customer].[kyc.edit] -- this procedure edits a kyc level with all the conditions and attributes defined in it
    @kyc customer.kycTT READONLY, -- in this parameter is passed the kyc table information - for which branch, status, customer type and etc.
    @kycConditionAttribute customer.kycConditionAttributeTT READONLY, -- in this parameter are passed the defined  attributes and conditions
    @noResultSet BIT = 0, -- thether to return  the added objects as result
    @meta core.metaDataTT READONLY -- information for the logged user
AS

DECLARE @callParams XML
DECLARE @kycId SMALLINT = (SELECT kycId FROM @kyc)
DECLARE @customerType INT = (SELECT customerTypeId FROM customer.kyc WHERE kycId = @kycId)
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
SET @noResultSet = ISNULL(@noResultSet, 0)

BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
        RETURN 55555

    --check if user has access to the organization
    IF NOT EXISTS(
        SELECT o.actorId
        FROM customer.organizationsVisibleFor(@userId) o
        JOIN customer.kyc ck ON ck.organizationId = o.actorId
        JOIN @kyc k ON k.kycId = ck.kycId)
        BEGIN
            RAISERROR('customer.securityViolation', 16, 1)
        END

    IF NOT EXISTS (SELECT 1 FROM @kycConditionAttribute)
        BEGIN
            RAISERROR('customer.kycMissingAttributes', 16, 1);
        END

    --CHECK IF applied KYC attributes are valid FOR customer type
    IF EXISTS (
        SELECT * FROM @kycConditionAttribute
        LEFT JOIN [customer].[kycAttributeType] (@customerType) ON attributeId = itemNameId
        WHERE itemNameId IS NULL)
        BEGIN
            RAISERROR('customer.kycInvalidAttributes', 16, 1);
        END

    UPDATE k
    SET [description] = ISNULL (kk.[description], k.[description]),
        updatedOn = GETDATE(),
        updatedBy = @userId
    FROM [customer].[kyc] k
    JOIN @kyc kk ON k.kycId = kk.kycId

    MERGE INTO [customer].[kycConditionAttribute] AS t
        USING @kycConditionAttribute AS s ON s.kycConditionAttributeId = t.kycConditionAttributeId
    WHEN MATCHED THEN
        UPDATE
        SET [conditionId] = s.[conditionId],
            [attributeId] = s.[attributeId],
            [conditionCheck] = ISNULL (s.conditionCheck, 'NOT NULL')
    WHEN NOT matched BY target THEN
        INSERT (kycId, conditionId, attributeId, conditionCheck)
        VALUES (s.kycId, s.conditionId, s.attributeId, ISNULL (s.conditionCheck, 'NOT NULL'))
    WHEN NOT matched BY source AND t.kycId = @kycId THEN
        DELETE;

    IF @noResultSet = 0
    BEGIN
        SELECT 'kyc' AS resultSetName

        SELECT kycId, display, description, statusId, customerTypeId, organizationId, itemNameId
        FROM [customer].[kyc]
        WHERE kycId = @kycId
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
