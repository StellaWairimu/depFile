CREATE TABLE customer.kycConditionAttribute( -- table that stores Know Your Customer conditions
    kycConditionAttributeId INT IDENTITY(1, 1) NOT NULL, -- Know Your Customer type id
    kycId SMALLINT NOT NULL, -- Know Your Customer type id
    conditionId TINYINT NOT NULL, -- Know Your Customer condition
    attributeId BIGINT NOT NULL, -- the item name id if the attribute for translation
    conditionCheck NVARCHAR(100), -- the check function for KYC condition
    CONSTRAINT pkkycConditionAttribute PRIMARY KEY (kycConditionAttributeId),
    CONSTRAINT fkkycConditionAttribute_kyc FOREIGN KEY (kycId) REFERENCES customer.kyc (kycId),
    CONSTRAINT fkkycConditionAttribute_itemName FOREIGN KEY(attributeId) REFERENCES core.[itemName] (itemNameId),
    CONSTRAINT ukkycConditionAttribute_kycIdattributeId UNIQUE (kycId, attributeId)
)
