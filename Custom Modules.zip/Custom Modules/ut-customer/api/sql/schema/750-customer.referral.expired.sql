ALTER PROCEDURE [customer].[referral.expired] -- create new referral in customer.referral table
    @meta core.metaDataTT READONLY
AS
BEGIN
    DECLARE @callParams XML
    DECLARE @referralExpirationId INT =
        (
            SELECT value
            FROM core.configuration
            WHERE [key] = 'referralPeriodExpiration'
        )

    DECLARE @referralExpireStateId INT = (
        SELECT referralStatusId FROM [customer].[referralStatus] rs
        JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
        WHERE itemCode = 'referralExpired'),
            @dateDiff INT

    BEGIN TRY

        UPDATE r
        SET
            r.referralStatusId = @referralExpireStateId
        FROM [customer].[referral] r
        JOIN [customer].[referralStatus] s
        ON r.referralStatusId = s.referralStatusId
        JOIN [core].[itemName] ci ON ci.itemNameId = s.itemNameId
        WHERE
            r.referralDate < DATEADD(Day, -1 * @referralExpirationId, GETDATE())
        AND ci.itemCode IN ('referralOpen', 'referralPending', 'deactivationPendingReferralOpen',
            'deactivationPendingReferralPending', 'deactivationPendingReferralCompleted')
        EXEC core.auditCall @procid = @@PROCID, @params = @callParams

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        EXEC [core].[error]
    END CATCH
END
