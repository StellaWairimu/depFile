ALTER FUNCTION [customer].[organizationsDepthCheck]
(
    @branchDepth TINYINT, -- key in core configuration table to search the required depth value
    @userId BIGINT
)
RETURNS TABLE AS
RETURN


    WITH orgs AS
    (
        SELECT o.actorId, 1 AS depth
        FROM customer.organization AS o
        LEFT JOIN core.actorHierarchy AS cur ON o.actorId = cur.[subject] AND [predicate] = 'memberOf'
        WHERE cur.[subject] IS NULL

        UNION ALL

        SELECT o.actorId, depth + 1
        FROM orgs AS par
        JOIN core.actorHierarchy AS ch ON ch.[object] = par.actorId AND [predicate] = 'memberOf'
        JOIN customer.organization AS o ON o.actorId = ch.[subject]
        WHERE depth + 1 <= @branchDepth
    )

    SELECT orgs.actorId, organizationName
    FROM orgs
    JOIN customer.organizationsVisibleFor(@userId) u ON orgs.actorId = u.actorId
    WHERE orgs.depth = @branchDepth
