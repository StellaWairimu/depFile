ALTER PROCEDURE customer.[person.addMS] -- adds a new person with provided parameters
    @customer customer.customerTT READONLY, -- table with basic data about the new customer or existing customer in CBS
    @person customer.personTT READONLY, --table with personal information about the new customer, if it is a person
    @phone customer.phoneTT READONLY, -- in this parameter the stored procedure receives all fields of phone
    @address customer.addressTT READONLY, -- in this parameter the stored procedure receives all fields of address
    @email customer.emailTT READONLY -- in this parameter the stored procedure receives all fields of emails
AS
DECLARE @callParams XML

BEGIN TRY

    DECLARE @tranCounter INT = @@tranCount

    IF @tranCounter = 0
        BEGIN TRANSACTION;

            --customer person add
            INSERT INTO customer.person (actorId, frontEndRecordId, firstName, lastName, nationalId, dateOfBirth,
                nationality, gender, isEnabled, isDeleted, maritalStatusId, middleName)
            SELECT actorId, frontEndRecordId, firstName, lastName, nationalId, dateOfBirth,
                nationality, gender, isEnabled, isDeleted, maritalStatusId, middleName
            FROM @person

            --add mail
            INSERT INTO customer.email (actorId, value, emailTypeId, statusId, isPrimary)
            SELECT actorId, value, emailTypeId, ISNULL(statusId, 'active'), isPrimary
            FROM @email
            WHERE emailId IS NULL

            --add phone
            INSERT INTO customer.phone (actorId, frontEndRecordId, phoneTypeId, phoneNumber, statusId, oldValues, mnoId, isPrimary)
            SELECT actorId, frontEndRecordId, phoneTypeId, phoneNumber, ISNULL(statusId, 'active'), oldValues, mnoId, isPrimary
            FROM @phone

            --add address
            INSERT INTO customer.address (actorId, value, frontEndRecordId, addressTypeId, statusId, oldValues, city, lat, lng)
            SELECT actorId, value, frontEndRecordId, ISNULL(addressTypeId, 'home'), ISNULL(statusId, 'active'), oldValues, city, lat, lng
            FROM @address

            --add customer
            INSERT INTO customer.customer (actorId, frontEndRecordId, customerNumber, customerTypeId, kycId, stateId, statusId,
                createdBy, createdOn, updatedBy, updatedOn, customerCategoryId, dao,
                cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee)
            SELECT actorId, frontEndRecordId, customerNumber,
                CASE
                    WHEN ISNUMERIC (c.customerTypeId) = 1 THEN t.customerTypeId
                ELSE c.customerTypeId
                END,
            kycId, ISNULL (stateId, 'up_to_date'), ISNULL (c.statusId, 'approved'),
                createdBy, createdOn, updatedBy, updatedOn, customerCategoryId, dao,
                cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee
            FROM @customer c
            LEFT JOIN customer.customerType t ON CAST (t.customerTypeNumber AS VARCHAR(10)) = c.customerTypeId --this is done in cases where customerTypeId is given as a number corresponding to customerTypeNumber

    IF @tranCounter = 0
        COMMIT TRANSACTION;

    EXEC core.auditCall @procid = @@procId, @params = @callParams
END TRY
BEGIN CATCH
    IF @@tranCount > 0
        ROLLBACK TRANSACTION;
    EXEC core.error
END CATCH;
