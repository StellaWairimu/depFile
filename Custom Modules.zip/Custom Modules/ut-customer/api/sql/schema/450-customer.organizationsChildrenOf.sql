CREATE FUNCTION [customer].[organizationsChildrenOf] -- returns all organizations that are parent FOR the given organization
(
    @actorId BIGINT -- the organization FOR which to RETURN parents
)
RETURNS TABLE AS
RETURN

WITH children(actorId, countryId, depth) AS
(
    SELECT @actorId AS actorId, o.countryId, 0 AS depth
    FROM customer.organization o
    WHERE o.actorId = @actorId AND o.isDeleted = 0 AND o.isEnabled = 1

    UNION ALL

    SELECT h.object, o.countryId, depth + 1
    FROM core.actorHierarchy h
    JOIN children a ON a.actorId = h.subject AND h.predicate = 'memberOf'
    JOIN customer.organization o ON o.actorId = h.subject AND o.isDeleted = 0 AND o.isEnabled = 1
)

SELECT DISTINCT actorId, countryId, depth
FROM children
