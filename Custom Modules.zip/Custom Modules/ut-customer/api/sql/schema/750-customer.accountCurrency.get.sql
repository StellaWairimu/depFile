ALTER PROCEDURE [customer].[accountCurrency.get]
    @actorId BIGINT
AS

SELECT 'accounts' AS resultSetName

SELECT ca.accountNumber, lv.itemCode AS 'currency', lv.itemName AS 'currencyName'
FROM [customer].[account] ca
    JOIN [loan].[vCurrency] lv ON ca.currencyId = lv.currencyId
WHERE ca.actorId = @actorId
