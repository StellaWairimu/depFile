ALTER VIEW [customer].[vIndustry]
AS
SELECT ind.industryId, ind.itemNameId, i.itemCode, i.itemSyncId, i.organizationId, i.countryId, i.itemName, i.itemTypeId
FROM customer.[industry] AS ind
JOIN core.itemName i ON i.itemNameId = ind.itemNameId
WHERE i.isEnabled = 1
