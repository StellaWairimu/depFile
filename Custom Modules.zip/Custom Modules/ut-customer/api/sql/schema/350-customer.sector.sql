CREATE TABLE [customer].[sector]( -- table that stores the sectors as they are defined in T24
    [sectorId] [INT] IDENTITY(1, 1) NOT NULL, -- the sector unique id
    [itemNameId] BIGINT NULL,
    CONSTRAINT pkCustomerSector PRIMARY KEY CLUSTERED(sectorId ASC),
    CONSTRAINT [fkcCustomerSector_itemNameId] FOREIGN KEY(itemNameId) REFERENCES [core].[itemName] (itemNameId)
)
