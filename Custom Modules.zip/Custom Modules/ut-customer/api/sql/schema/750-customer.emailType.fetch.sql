ALTER PROCEDURE [customer].[emailType.fetch] -- fetches all phopne types
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
-- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    SELECT 'emailTypes' AS resultSetName

    SELECT *
    FROM [customer].[emailType] emailType
