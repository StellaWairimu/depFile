ALTER PROCEDURE [customer].[address.editUnapproved] -- edits address information
    @address customer.addressUnapprovedTT READONLY, -- the edited address information
    @actorId BIGINT, -- customer id
    @noResultSet BIT = 0, -- a flag to show IF result IS expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @result customer.addressUnapprovedTT

BEGIN TRY

    DELETE p
    FROM [customer].[addressUnapproved] p
    LEFT JOIN @address pp ON p.addressUnapprovedId = pp.addressUnapprovedId
    WHERE p.actorId = @actorId AND pp.addressUnapprovedId IS NULL

    -- re-edit new AND existing addresss IN the unapproved TABLE
    UPDATE au
    SET value = au.value,
        addressTypeId = au.addressTypeId,
        statusId = au.statusId,
        city = au.city,
        lat = au.lat,
        lng = au.lng,
        addressZone1 = au.addressZone1,
        addressZone2 = au.addressZone2,
        addressZone3 = au.addressZone3,
        addressZone4 = au.addressZone4,
        updatedBy = @userId,
        updatedOn = SYSDATETIMEOFFSET()
    OUTPUT INSERTED.addressUnapprovedId, INSERTED.addressId, INSERTED.actorId, INSERTED.value, INSERTED.addressTypeId, INSERTED.statusId, INSERTED.city, INSERTED.isDeleted, INSERTED.updatedBy, INSERTED.updatedOn, INSERTED.lat, INSERTED.lng, INSERTED.addressZone1, INSERTED.addressZone2, INSERTED.addressZone3, INSERTED.addressZone4
    INTO @result (addressUnapprovedId, addressId, actorId, value, addressTypeId, statusId, city, isDeleted, updatedBy, updatedOn, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    FROM customer.addressUnapproved au
    JOIN @address s ON s.addressUnapprovedId = au.addressUnapprovedId

    -- insert new or existing edited addresss FOR approval
    INSERT INTO [customer].[addressUnapproved] (addressId, actorId, value, addressTypeId, statusId, city, isDeleted, updatedBy, updatedOn, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    OUTPUT INSERTED.addressUnapprovedId, INSERTED.addressId, INSERTED.actorId, INSERTED.value, INSERTED.addressTypeId, INSERTED.statusId, INSERTED.city, INSERTED.isDeleted, INSERTED.updatedBy, INSERTED.updatedOn, INSERTED.lat, INSERTED.lng, INSERTED.addressZone1, INSERTED.addressZone2, INSERTED.addressZone3, INSERTED.addressZone4
    INTO @result (addressUnapprovedId, addressId, actorId, value, addressTypeId, statusId, city, isDeleted, updatedBy, updatedOn, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    SELECT addressId, actorId, value, ISNULL(addressTypeId, 'home'), ISNULL(a.statusId, 'active'), city, 0, @userId, SYSDATETIMEOFFSET(), lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
    FROM @address a
    WHERE a.addressUnapprovedId IS NULL

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'address' AS resultSetName
        SELECT addressUnapprovedId, addressId, actorId, value, addressTypeId, statusId, city, isDeleted, updatedBy, updatedOn, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
