ALTER PROCEDURE [customer].[organization.delete] --the SP removes selected organization
    @actorIdList core.arrayNumberList READONLY, -- a list with organizations to remove
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
BEGIN TRY
        -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END


    IF EXISTS(SELECT statusId FROM [customer].[organizationUnapproved] o JOIN @actorIdList a ON o.actorId = a.value WHERE statusId = 'new' OR statusId = 'pending')
    BEGIN
        RAISERROR('customer.organizationInvalidStatus', 16, 1);
    END

    IF EXISTS(
        SELECT *
        FROM @actorIdList v
        LEFT JOIN customer.organization o ON v.value = o.actorId AND o.isDeleted = 0
        WHERE o.actorId IS NULL)
    RAISERROR('user.disabledOrDeletedOrganization', 16, 1)

    --CHECK IF an organization has members; IF there are active members (organization) WE CANNOT DELETE it
    IF EXISTS (
        SELECT TOP 1 ah.[object]
        FROM core.actorHierarchy ah
            JOIN customer.organization o ON o.actorId = ah.[object]
            JOIN @actorIdList ids ON ah.[object] = ids.value
            JOIN customer.organization oChild ON oChild.actorId = ah.subject
        WHERE ah.predicate = 'memberOf'
        AND oChild.isDeleted = 0 AND oChild.isEnabled = 1)
    BEGIN
        RAISERROR('customer.cannotDeleteHasOrganizations', 16, 1);
        RETURN 55555
    END
    ELSE IF--CHECK IF an organization has members; IF there are active members(Users) WE CANNOT LOCK it
        EXISTS (
            SELECT TOP 1 ah.[object]
            FROM core.actorHierarchy ah
                JOIN customer.organization o ON o.actorId = ah.[object]
                JOIN @actorIdList ids ON ah.[object] = ids.value
                JOIN [user].[user] uChild ON uChild.actorId = ah.subject
            WHERE ah.predicate = 'memberOf'
            AND uChild.isDeleted = 0 AND uChild.isEnabled = 1)
    BEGIN
        RAISERROR('customer.cannotDeleteHasUsers', 16, 1);
        RETURN 55555
    END
    ELSE IF--CHECK IF a role IS visibleFor the organization
        EXISTS (
            SELECT TOP 1 ah.[object]
            FROM core.actorHierarchy ah
                JOIN customer.organization o ON o.actorId = ah.[object]
                JOIN @actorIdList ids ON ah.[object] = ids.value
                JOIN [user].[role] r ON r.actorId = ah.[subject]
            WHERE ah.predicate = 'visibleFor'
            AND r.isDeleted = 0 AND r.isEnabled = 1)
    BEGIN
        RAISERROR('customer.cannotDeleteHasRoles', 16, 1);
        RETURN 55555
    END

    --check if user has access to the organization
    IF EXISTS(
        SELECT o.actorId
        FROM @actorIdList al
        LEFT JOIN customer.organizationsVisibleForUnapproved(@userId) o ON al.value = o.actorId
        WHERE o.actorId IS NULL)
            RAISERROR('customer.securityViolation', 16, 1)

    -- IF the organization IS previously edited, AND THEN deleted - UPDATE records IN unapproved TABLE
    UPDATE t
    SET t.organizationName = organizationName + ' deleted ' + CONVERT(VARCHAR(20), CURRENT_TIMESTAMP),
        t.isEnabled = 0,
        t.isDeleted = 1,
        t.updatedBy = @userId,
        t.updatedOn = SYSDATETIMEOFFSET(),
        t.statusId = 'pending'
    FROM [customer].[organizationUnapproved] t
    JOIN @actorIdList s ON t.actorId = s.value

    INSERT INTO [customer].[organizationUnapproved](actorId, frontEndRecordId, organizationName, code, executiveOfficer, tradeName, capital, currency, timeZone, primaryLanguageId, oldValues, isEnabled, isDeleted, cbsId, countryId, updatedBy, updatedOn, statusId, description)
    SELECT o.actorId, o.frontEndRecordId, o.organizationName + ' deleted ' + CONVERT(VARCHAR(20), CURRENT_TIMESTAMP), o.code, o.executiveOfficer, o.tradeName, o.capital, o.currency, o.timeZone, o.primaryLanguageId, o.oldValues, 0, 1, o.cbsId, o.countryId, @userId, SYSDATETIMEOFFSET(), 'pending', o.description
    FROM [customer].[organization] o
    JOIN @actorIdList a ON a.value = o.actorId
    LEFT JOIN [customer].[organizationUnapproved] ou ON o.actorId = ou.actorId
    WHERE ou.actorId IS NULL

EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
