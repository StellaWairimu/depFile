CREATE TABLE [customer].[referral](-- table that stores customer states
    [referralId] [BIGINT] IDENTITY(1000, 1) NOT NULL, --Referralunique ID
    [referralSource] [BIGINT] NOT NULL, --Customer referee
    [referralTarget] [BIGINT] NULL, --Customer referred
    [MSISDN] [VARCHAR](50) NOT NULL, --Referee's MSISDN
    [referralDate] [DATETIME2](0) NULL, -- Timestamp of the referral when it goes referral open date
    [referralStatusId] [TINYINT] NOT NULL, --Status of the referral
    [rejectReason] NVARCHAR(MAX) NULL, -- rejected reason
    [createdBy] BIGINT NOT NULL, -- id of the actor
    [createdOn] [DATETIME2](0) NOT NULL, -- date of the referral created
    [updatedBy] BIGINT NOT NULL, -- id of the actor
    [updatedOn] [DATETIME2](0) NOT NULL, --  date of the referral updated
    CONSTRAINT [PK_Referral_referralId] PRIMARY KEY CLUSTERED ([referralId]),
    CONSTRAINT [fkCustomerreferral_coreActor_referralSource] FOREIGN KEY([referralSource]) REFERENCES [core].[actor] ([actorId]),
    CONSTRAINT [fkCustomerreferral_coreActor_referralTarget] FOREIGN KEY([referralTarget]) REFERENCES [core].[actor] ([actorId]),
    CONSTRAINT [fkCustomerreferral_coreActor_createdBy] FOREIGN KEY([createdBy]) REFERENCES [core].[actor] ([actorId]),
    CONSTRAINT [fkCustomerreferral_coreActor_updatedBy] FOREIGN KEY([updatedBy]) REFERENCES [core].[actor] ([actorId]),
    CONSTRAINT [fkCustomerreferral_coreActor_referralStatusId] FOREIGN KEY([referralStatusId]) REFERENCES [customer].[referralStatus] ([referralStatusId])
)
