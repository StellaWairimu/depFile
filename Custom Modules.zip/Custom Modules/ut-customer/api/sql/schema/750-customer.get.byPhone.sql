ALTER PROCEDURE [customer].[get.byPhone]
    @phone VARCHAR(MAX)
AS

    DECLARE @countryCode VARCHAR(5)

    SET @countryCode = '+' + SUBSTRING(@phone, 0, 4)
    SET @phone = SUBSTRING(@phone, 4, LEN(@phone))

    SELECT 'customersByPhone' AS resultSetName
    SELECT TOP 1 p.phoneId, p.actorId, p.frontEndRecordId, p.phoneTypeId, p.phoneNumber, p.statusId, p.oldValues, p.udf, p.mnoId, p.isPrimary
    FROM [customer].[phone] p
    LEFT JOIN [customer].[customer] c ON c.actorId = p.actorId
    LEFT JOIN [customer].[country] cc ON cc.countryId = c.countryId
    WHERE p.phoneNumber = @phone
    AND (p.statusId = 'active' OR p.statusId = 'approved')
    AND cc.phonePrefix = @countryCode
    ORDER BY p.isPrimary DESC

