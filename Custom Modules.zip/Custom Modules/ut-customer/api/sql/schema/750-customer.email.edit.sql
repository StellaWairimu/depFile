ALTER PROCEDURE [customer].[email.edit] -- edits email information
    @email customer.emailUnapprovedTT READONLY, -- the edited email information
    @actorId BIGINT, -- customer id
    @noResultSet BIT = 0, -- a flag to show if result is expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @result customer.emailUnapprovedTT

BEGIN TRY
    DECLARE @tranCounter INT = @@TRANCOUNT;
    IF @tranCounter = 0
        BEGIN TRANSACTION

            DELETE p
            FROM customer.email p
            LEFT JOIN @email pp ON p.emailId = pp.emailId
            WHERE p.actorId = @actorId AND pp.emailId IS NULL

            UPDATE t
            SET t.value = s.value,
                t.emailTypeId = s.emailTypeId,
                t.statusId = s.statusId,
                t.isPrimary = s.isPrimary
            OUTPUT INSERTED.emailId, INSERTED.actorId, INSERTED.value, INSERTED.emailTypeId, INSERTED.statusId, INSERTED.isPrimary
            INTO @result (emailId, actorId, value, emailTypeId, statusId, isPrimary)
            FROM customer.email t
            INNER JOIN @email s ON t.emailId = s.emailId

            INSERT INTO customer.email (actorId, value, emailTypeId, statusId, isPrimary)
            OUTPUT INSERTED.emailId, INSERTED.actorId, INSERTED.value, INSERTED.emailTypeId, INSERTED.statusId, INSERTED.isPrimary
            INTO @result (emailId, actorId, value, emailTypeId, statusId, isPrimary)
            SELECT actorId, value, emailTypeId, statusId, isPrimary
            FROM @email a
            WHERE a.emailId IS NULL

            IF @tranCounter = 0
        COMMIT TRANSACTION

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'email' AS resultSetName
        SELECT actorId, value, emailTypeId, statusId, isPrimary
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
