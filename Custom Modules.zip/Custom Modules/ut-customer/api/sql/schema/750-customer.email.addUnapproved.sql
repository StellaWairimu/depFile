ALTER PROCEDURE customer.[email.addUnapproved] -- create new emails in customer.email/customer.emailunapproved table
    @email customer.emailTT READONLY, -- in this parameter the stored procedure receives all fields of emails
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
    DECLARE @oldValues XML
    DECLARE @Today DATETIME2 = GETDATE()

-- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @result customer.emailUnapprovedTT

    INSERT INTO [customer].[emailUnapproved] (emailId, actorId, value, emailTypeId, statusId, isDeleted, updatedBy, updatedOn, isPrimary)
    OUTPUT INSERTED.emailUnapprovedId, INSERTED.emailId, INSERTED.actorId, INSERTED.value, INSERTED.emailTypeId, INSERTED.statusId, INSERTED.isDeleted, INSERTED.updatedBy, INSERTED.updatedOn, INSERTED.isPrimary
    INTO @result (emailUnapprovedId, emailId, actorId, value, emailTypeId, statusId, isDeleted, updatedBy, updatedOn, isPrimary)
    SELECT emailId, actorId, value, ISNULL(emailTypeId, 'home'), ISNULL(a.statusId, 'active'), 0, @userId, SYSDATETIMEOFFSET(), isPrimary
    FROM @email a

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'email' AS resultSetName
        SELECT emailUnapprovedId, emailId, actorId, value, emailTypeId, statusId, isDeleted, updatedBy, updatedOn, isPrimary
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
