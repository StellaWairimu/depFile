ALTER PROCEDURE customer.[phone.addApproved] -- approve new phones IN customer.phone TABLE
    @actorId BIGINT, -- customer id
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE @result customer.phoneTT

    INSERT INTO customer.phone (actorId, frontEndRecordId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary)
    OUTPUT INSERTED.phoneId, INSERTED.actorId, INSERTED.frontEndRecordId, INSERTED.phoneTypeId, INSERTED.phoneNumber, INSERTED.statusId, INSERTED.mnoId, INSERTED.isPrimary
    INTO @result (phoneId, actorId, frontEndRecordId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary)
    SELECT actorId, frontEndRecordId, phoneTypeId, phoneNumber, ISNULL(statusId, 'active'), mnoId, isPrimary
    FROM customer.phoneUnapproved pu
    WHERE pu.phoneId IS NULL AND pu.actorId = @actorId

    DELETE FROM customer.phoneUnapproved WHERE actorId = @actorId

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'phone' AS resultSetName
        SELECT phoneId, actorId, frontEndRecordId, phoneTypeId, phoneNumber, statusId, mnoId, isPrimary FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
