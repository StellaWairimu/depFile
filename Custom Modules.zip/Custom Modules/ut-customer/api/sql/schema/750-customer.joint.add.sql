ALTER PROCEDURE [customer].[joint.add]
    @joint customer.jointTT READONLY,
    @members core.arrayList READONLY,
    -----------------------------------
    @account customer.accountTT READONLY,
    @email customer.emailTT READONLY,
    @phone customer.phoneTT READONLY,
    @address customer.addressTT READONLY,
    -----------------------------------
    @noResultSet BIT = 0,
    @meta core.metaDataTT READONLY
AS
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
    DECLARE
        @jointTT customer.jointTT,
        @actorHierarchyTT core.actorHierarchyTT,
        @accountTT customer.accountTT,
        @emailTT customer.emailTT,
        @phoneTT customer.phoneTT,
        @addressTT customer.addressTT,
        @actorId BIGINT

    SET @noResultSet = ISNULL(@noResultSet, 0)
    BEGIN TRY
    -- checks if the user has a right to make the operation
        DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
        EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
        IF @return != 0
        BEGIN
            RETURN 55555
        END

            IF ((SELECT COUNT(1) FROM @joint) <> 1)
            BEGIN
                RAISERROR('customer.jointDataNotSingle', 16, 1);
            END

            SET @actorId = (SELECT actorId FROM @joint)

            INSERT INTO @jointTT SELECT * FROM @joint
            INSERT INTO @accountTT SELECT * FROM @account
            INSERT INTO @emailTT SELECT * FROM @email
            INSERT INTO @phoneTT SELECT * FROM @phone
            INSERT INTO @addressTT SELECT * FROM @address

            DECLARE @TranCounter INT;
            SET @TranCounter = @@TRANCOUNT;
            IF @TranCounter > 0
                SAVE TRANSACTION ProcedureSave;
            ELSE
                BEGIN TRANSACTION;

                    IF @actorId IS NULL
                    BEGIN
                        EXEC [core].[actor.add]
                            @actorType = 'joint',
                            @actorId = @actorId OUT,
                            @meta = @meta

                        UPDATE @jointTT SET actorId = @actorId
                        UPDATE @accountTT SET actorId = @actorId
                        UPDATE @emailTT SET actorId = @actorId
                        UPDATE @phoneTT SET actorId = @actorId
                        UPDATE @addressTT SET actorId = @actorId
                    END

                    INSERT INTO [customer].[joint] SELECT * FROM @jointTT
                    INSERT INTO @actorHierarchyTT (subject, predicate, object) SELECT value, 'memberOf', @actorId FROM @members

                    EXEC [core].[actorHierarchy.add]
                        @actorHierarchy = @actorHierarchyTT,
                        @meta = @meta,
                        @noResultSet = 1

                    EXEC [customer].[account.add]
                        @account = @accountTT,
                        @meta = @meta,
                        @noResultSet = 1

                    EXEC [customer].[email.add]
                        @email = @emailTT,
                        @meta = @meta,
                        @noResultSet = 1

                    EXEC [customer].[phone.add]
                        @phone = @phoneTT,
                        @meta = @meta,
                        @noResultSet = 1

                    EXEC [customer].[address.add]
                        @address = @addressTT,
                        @meta = @meta,
                        @noResultSet = 1

                    IF(@noResultSet = 0)
                        EXEC customer.[joint.get]
                            @actorId = @actorId,
                            @meta = @meta

                    IF @TranCounter = 0
                COMMIT TRANSACTION;

        EXEC core.auditCall @procid = @@PROCID, @params = @callParams

    END TRY
    BEGIN CATCH
        IF @TranCounter = 0
            ROLLBACK TRANSACTION;
        ELSE IF @@TRANCOUNT > 0 AND XACT_STATE() <> -1
            ROLLBACK TRANSACTION ProcedureSave;

        EXEC [core].[error]
    END CATCH;
