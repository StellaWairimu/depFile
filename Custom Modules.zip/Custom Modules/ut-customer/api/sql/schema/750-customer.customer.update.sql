ALTER PROCEDURE customer.[customer.update] -- update all changed fields in customer table
    @customer customer.customerTTU READONLY, -- in this parameter the stored procedure receives all changed fields
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE
        @result customer.customerTT,
        @oldValuesXML XML,
        @newXML XML,
        @actorId BIGINT,
        @userId BIGINT

    SET @actorId = (SELECT actorId FROM @customer)
    SET @userId = (SELECT [auth.actorId] FROM @meta)

    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    SET @oldValuesXML = (
        SELECT *
        FROM customer.customer
        WHERE actorId = @actorId
        FOR XML PATH('oldUdf') , type, ELEMENTS XSINIL)

    SET @newXML = (SELECT * FROM @customer FOR XML PATH('udf'))

    UPDATE c
    SET c.customerNumber = CASE WHEN ctt.customerNumberUpdated = 1 THEN ctt.customerNumber ELSE c.customerNumber END,
        c.frontEndRecordId = CASE WHEN ctt.frontEndRecordIdUpdated = 1 THEN ctt.frontEndRecordId ELSE c.frontEndRecordId END,
        c.customerTypeId = CASE WHEN ctt.customerTypeIdUpdated = 1 THEN ctt.customerTypeId ELSE c.customerTypeId END,
        c.kycId = CASE WHEN ctt.kycIdUpdated = 1 THEN ctt.kycId ELSE c.kycId END,
        c.statusId = CASE WHEN ctt.statusIdUpdated = 1 THEN ctt.statusId ELSE c.statusId END ,
        c.stateId = CASE WHEN ctt.stateIdUpdated = 1 THEN ctt.stateId ELSE c.stateId END , --'pending',
        c.[description] = CASE WHEN ctt.descriptionUpdated = 1 THEN ctt.[description] ELSE c.[description] END ,
        c.oldValues = core.mergeXML(@oldValuesXML, @userId, @newXML),
        c.udf = CASE WHEN ctt.udfUpdated = 1 THEN ctt.udf ELSE c.udf END,
        c.updatedOn = SYSDATETIMEOFFSET(),
        c.updatedBy = @userId
    OUTPUT INSERTED.* INTO @result
    FROM customer.customer c
    INNER JOIN @customer ctt ON ctt.actorId = c.actorId

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'customer' AS resultSetName
        SELECT * FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH

