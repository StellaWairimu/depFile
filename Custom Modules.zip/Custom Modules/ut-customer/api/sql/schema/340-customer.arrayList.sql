CREATE TYPE [customer].[arrayList] AS TABLE
(
    [value] [NVARCHAR] (100)
)
