/*
IF NOT EXISTS (SELECT 1 FROM   sys.indexes i JOIN sys.objects o ON i.object_id = o.object_id WHERE  o.object_id IN (SELECT object_id FROM   sys.objects WHERE  TYPE = 'U') AND i.name = 'ukCustomerNumberCountry')
BEGIN
    ALTER TABLE [customer].[customer] ADD CONSTRAINT  [ukCustomerNumberCountry] UNIQUE ([customerNumber] ASC,[countryId] ASC)
END
 */
IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'isPrimary' AND Object_ID = OBJECT_ID(N'customer.phoneUnapproved') )
AND NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE parent_object_id = OBJECT_ID('customer.phoneUnapproved'))
BEGIN
    ALTER TABLE [customer].[phoneUnapproved] ADD DEFAULT(0) FOR isPrimary
END
IF EXISTS( SELECT * FROM sys.columns c JOIN sys.types t ON t.system_type_id = c.system_type_id WHERE c.Name = N'personUnapprovedId' AND t.name = 'INT' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
BEGIN
    ALTER TABLE [customer].personUnapproved DROP CONSTRAINT pkCustomerPersonUnapproved
    ALTER TABLE [customer].personUnapproved ALTER COLUMN personUnapprovedId BIGINT NOT NULL --IDENTITY(1,1)
    ALTER TABLE [customer].personUnapproved ADD CONSTRAINT pkCustomerPersonUnapproved PRIMARY KEY CLUSTERED(personUnapprovedId ASC)
END
IF NOT EXISTS (SELECT * FROM sys.columns c WHERE c.name = 'customerTypeNumber' AND Object_ID = OBJECT_ID(N'customer.customerType'))
    ALTER TABLE customer.customerType ADD customerTypeNumber INT IDENTITY(1, 1)

IF NOT EXISTS( SELECT 1 FROM sys.objects WHERE Name = N'uqcustomerTypeNumber' )
BEGIN
    ALTER TABLE [customer].[customerType] ADD CONSTRAINT uqcustomerTypeNumber UNIQUE ([customerTypeNumber] ASC)
END


IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'middleName' AND Object_ID = OBJECT_ID(N'customer.person') )
BEGIN
    ALTER TABLE customer.person ADD middleName NVARCHAR (50)
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'middleName' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
BEGIN
    ALTER TABLE customer.personUnapproved ADD middleName NVARCHAR (50)
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'customerTypeId' AND Object_ID = OBJECT_ID(N'customer.kyc') )
BEGIN
    ALTER TABLE customer.kyc ADD customerTypeId INT
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'organizationId' AND Object_ID = OBJECT_ID(N'customer.kyc') )
BEGIN
    ALTER TABLE customer.kyc ADD organizationId BIGINT
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'isDeleted' AND Object_ID = OBJECT_ID(N'customer.kyc') )
BEGIN
    ALTER TABLE customer.kyc ADD isDeleted BIT NOT NULL DEFAULT(0)
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'itemNameId' AND Object_ID = OBJECT_ID(N'customer.kyc') )
BEGIN
    ALTER TABLE customer.kyc ADD itemNameId BIGINT
END

IF NOT EXISTS( SELECT 1 FROM sys.objects WHERE Name = N'fkCustomerKyc_customerType' )
BEGIN
    ALTER TABLE customer.kyc ADD CONSTRAINT [fkCustomerKyc_customerType] FOREIGN KEY(customerTypeId) REFERENCES customer.[customerType] (customerTypeNumber)
END

IF NOT EXISTS( SELECT 1 FROM sys.objects WHERE Name = N'fkCustomerKyc_customerOrganization' )
BEGIN
    ALTER TABLE customer.kyc ADD CONSTRAINT [fkCustomerKyc_customerOrganization] FOREIGN KEY(organizationId) REFERENCES customer.[organization] (actorId)
END

IF NOT EXISTS( SELECT 1 FROM sys.objects WHERE Name = N'fkCustomerKyc_itemName' )
BEGIN
    ALTER TABLE customer.kyc ADD CONSTRAINT [fkCustomerKyc_itemName] FOREIGN KEY(itemNameId) REFERENCES core.[itemName] (itemNameId)
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'createdBy' AND Object_ID = OBJECT_ID(N'customer.kyc') )
BEGIN
    ALTER TABLE customer.kyc ADD createdBy BIGINT
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'createdOn' AND Object_ID = OBJECT_ID(N'customer.kyc') )
BEGIN
    ALTER TABLE customer.kyc ADD createdOn DATETIME2 (0)
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'updatedBy' AND Object_ID = OBJECT_ID(N'customer.kyc') )
BEGIN
    ALTER TABLE customer.kyc ADD updatedBy BIGINT
END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'updatedOn' AND Object_ID = OBJECT_ID(N'customer.kyc') )
BEGIN
    ALTER TABLE customer.kyc ADD updatedOn DATETIME2 (0)
END

IF NOT EXISTS( SELECT 1 FROM sys.objects WHERE Name = N'ukkycConditionAttribute_kycIdattributeId' )
BEGIN
    ALTER TABLE [customer].[kycConditionAttribute] ADD CONSTRAINT ukkycConditionAttribute_kycIdattributeId UNIQUE (kycId, attributeId)
END


----------------------
IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'kycId' AND is_identity = 0 AND Object_ID = OBJECT_ID(N'customer.kyc'))
BEGIN
    IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fkCustomerCustomer_customerKyc')
    BEGIN
        ALTER TABLE customer.customer DROP CONSTRAINT fkCustomerCustomer_customerKyc
    END

    IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fkkycConditionAttribute_kyc')
    BEGIN
        ALTER TABLE customer.kycConditionAttribute DROP CONSTRAINT fkkycConditionAttribute_kyc
    END

    ALTER TABLE customer.kyc DROP CONSTRAINT pkCustomerKyc

    ALTER TABLE [customer].[kyc] ADD kycId_new SMALLINT IDENTITY(0, 1) NOT NULL

    ALTER TABLE [customer].[kyc] DROP COLUMN kycId

    EXEC sp_rename 'customer.kyc.kycId_new', 'kycId', 'COLUMN'

    ALTER TABLE customer.kyc ADD CONSTRAINT pkCustomerKyc PRIMARY KEY (kycId)
    ALTER TABLE customer.customer ADD CONSTRAINT fkCustomerCustomer_customerKyc FOREIGN KEY(kycId) REFERENCES customer.[kyc] (kycId)
    ALTER TABLE customer.kycConditionAttribute ADD CONSTRAINT fkkycConditionAttribute_kyc FOREIGN KEY(kycId) REFERENCES customer.[kyc] (kycId)
END
----------------------

DECLARE @dropFKCustomerPerson NVARCHAR (255)
    IF EXISTS (
        SELECT obj.name AS FK_NAME
        FROM sys.foreign_key_columns fkc
        JOIN sys.objects obj ON obj.object_id = fkc.constraint_object_id
        JOIN sys.tables tab1 ON tab1.object_id = fkc.parent_object_id
        JOIN sys.schemas sch ON tab1.schema_id = sch.schema_id
        WHERE sch.name = 'customer'
        AND tab1.name = 'person'
        AND obj.name = 'fkCustomerPerson_customerEmployementId')
    SET @dropFKCustomerPerson = 1

DECLARE @dropFKCustomerPersonUnapproved NVARCHAR (255)
    IF EXISTS (
        SELECT obj.name AS FK_NAME
        FROM sys.foreign_key_columns fkc
        JOIN sys.objects obj ON obj.object_id = fkc.constraint_object_id
        JOIN sys.tables tab1 ON tab1.object_id = fkc.parent_object_id
        JOIN sys.schemas sch ON tab1.schema_id = sch.schema_id
        WHERE sch.name = 'customer'
            AND tab1.name = 'personUnapproved'
            AND obj.name = 'fkCustomerPersonUnapproved_customeremployementId')
    SET @dropFKCustomerPersonUnapproved = 1


DECLARE @dropFKCustomerPersonEmployment NVARCHAR (255)
    IF EXISTS (
        SELECT obj.name AS FK_NAME
        FROM sys.foreign_key_columns fkc
        JOIN sys.objects obj ON obj.object_id = fkc.constraint_object_id
        JOIN sys.tables tab1 ON tab1.object_id = fkc.parent_object_id
        JOIN sys.schemas sch ON tab1.schema_id = sch.schema_id
        WHERE sch.name = 'customer'
            AND tab1.name = 'person'
            AND obj.name = 'fkCustomerPerson_customerEmploymentId')
    SET @dropFKCustomerPersonEmployment = 1

DECLARE @dropFKCustomerPersonUnapprovedEmployement NVARCHAR (255)
    IF EXISTS (
        SELECT obj.name AS FK_NAME
        FROM sys.foreign_key_columns fkc
        JOIN sys.objects obj ON obj.object_id = fkc.constraint_object_id
        JOIN sys.tables tab1 ON tab1.object_id = fkc.parent_object_id
        JOIN sys.schemas sch ON tab1.schema_id = sch.schema_id
        WHERE sch.name = 'customer'
            AND tab1.name = 'personUnapproved'
            AND obj.name = 'fkCustomerPersonUnapproved_customeremploymentId')
    SET @dropFKCustomerPersonUnapprovedEmployement = 1

---

IF EXISTS ( SELECT * FROM sys.tables WHERE name = 'employement')
BEGIN
    IF @dropFKCustomerPerson = 1
        BEGIN
            ALTER TABLE [customer].[person] DROP CONSTRAINT [fkCustomerPerson_customerEmployementId]
            SET @dropFKCustomerPerson = 0
        END
    IF @dropFKCustomerPersonUnapproved = 1
        BEGIN
            ALTER TABLE [customer].[personUnapproved] DROP CONSTRAINT [fkCustomerPersonUnapproved_customeremployementId]
            SET @dropFKCustomerPersonUnapproved = 0
        END

    IF @dropFKCustomerPersonEmployment = 1
        BEGIN
            ALTER TABLE [customer].[person] DROP CONSTRAINT [fkCustomerPerson_customerEmploymentId]
            SET @dropFKCustomerPersonEmployment = 0
        END
    IF @dropFKCustomerPersonUnapprovedEmployement = 1
        BEGIN
            ALTER TABLE [customer].[personUnapproved] DROP CONSTRAINT [fkCustomerPersonUnapproved_customeremploymentId]
            SET @dropFKCustomerPersonUnapprovedEmployement = 0
        END

    DROP TABLE customer.employement
        IF NOT EXISTS ( SELECT * FROM sys.tables WHERE name = 'employment')
        BEGIN
            CREATE TABLE [customer].[employment](
            [employmentId] TINYINT IDENTITY(1, 1) NOT NULL,
            [itemNameId] BIGINT NULL,
            CONSTRAINT pkCustomeremployment PRIMARY KEY CLUSTERED(employmentId ASC),
            CONSTRAINT [fkCustomeremployment_itemNameId] FOREIGN KEY(itemNameId) REFERENCES [core].[itemName] (itemNameId))
        END
END

IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employementId' AND Object_ID = OBJECT_ID(N'customer.employment') )
BEGIN
    IF @dropFKCustomerPerson = 1
        BEGIN
            ALTER TABLE [customer].[person] DROP CONSTRAINT [fkCustomerPerson_customerEmployementId]
            SET @dropFKCustomerPerson = 0
        END

    IF @dropFKCustomerPersonEmployment = 1
        BEGIN
            ALTER TABLE [customer].[person] DROP CONSTRAINT [fkCustomerPerson_customerEmploymentId]
            SET @dropFKCustomerPersonEmployment = 0
        END

    IF @dropFKCustomerPersonUnapproved = 1
        BEGIN
            ALTER TABLE [customer].[personUnapproved] DROP CONSTRAINT [fkCustomerPersonUnapproved_customeremployementId]
            SET @dropFKCustomerPersonUnapproved = 0
        END

    IF @dropFKCustomerPersonUnapprovedEmployement = 1
        BEGIN
            ALTER TABLE [customer].[personUnapproved] DROP CONSTRAINT [fkCustomerPersonUnapproved_customeremploymentId]
            SET @dropFKCustomerPersonUnapprovedEmployement = 0
        END
    EXEC sp_RENAME '[customer].[employment].employementId', 'employmentId', 'COLUMN'

END
--


IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employementId' AND Object_ID = OBJECT_ID(N'customer.person') )
BEGIN
    IF @dropFKCustomerPerson = 1
        BEGIN
            ALTER TABLE [customer].[person] DROP CONSTRAINT [fkCustomerPerson_customerEmployementId]
            SET @dropFKCustomerPerson = 0
        END

    IF @dropFKCustomerPersonEmployment = 1
        BEGIN
            ALTER TABLE [customer].[person] DROP CONSTRAINT [fkCustomerPerson_customerEmploymentId]
            SET @dropFKCustomerPersonEmployment = 0
        END

    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE Name = N'employmentId' AND Object_ID = OBJECT_ID(N'customer.person'))
        BEGIN
            EXEC sp_RENAME '[customer].[person].employementId' , 'employmentId', 'COLUMN'
        END
END

IF EXISTS(SELECT 1 FROM sys.columns WHERE Name = N'employementId' AND Object_ID = OBJECT_ID(N'customer.personUnapproved'))
BEGIN

    IF @dropFKCustomerPersonUnapproved = 1
        BEGIN
            ALTER TABLE [customer].[personUnapproved] DROP CONSTRAINT [fkCustomerPersonUnapproved_customeremployementId]
            SET @dropFKCustomerPersonUnapproved = 0
        END

    IF @dropFKCustomerPersonUnapprovedEmployement = 1
        BEGIN
            ALTER TABLE [customer].[personUnapproved] DROP CONSTRAINT [fkCustomerPersonUnapproved_customeremploymentId]
            SET @dropFKCustomerPersonUnapprovedEmployement = 0
        END

    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE Name = N'employmentId' AND Object_ID = OBJECT_ID(N'customer.personUnapproved'))
        BEGIN
            EXEC sp_RENAME '[customer].[personUnapproved].employementId' , 'employmentId', 'COLUMN'
        END
END

IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employementDate' AND Object_ID = OBJECT_ID(N'customer.person') )
BEGIN
    IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employmentDate' AND Object_ID = OBJECT_ID(N'customer.person') )
        BEGIN
            EXEC sp_RENAME '[customer].[person].employementDate' , 'employmentDate', 'COLUMN'
        END
END

IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employementDate' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
BEGIN
    IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employmentDate' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
        BEGIN
            EXEC sp_RENAME '[customer].[personUnapproved].employementDate' , 'employmentDate', 'COLUMN'
        END
END

IF EXISTS (
    SELECT column_id
    FROM sys.COLUMNS
    WHERE OBJECT_NAME(object_id) = 'personUnapproved'
    AND name = 'employmentDate')
    AND 25 <> (
        SELECT ORDINAL_POSITION
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = 'customer'
            AND TABLE_NAME = 'personUnapproved'
            AND COLUMN_NAME = 'employmentDate')

    BEGIN
        ALTER TABLE [customer].[personUnapproved] DROP CONSTRAINT [fkCustomerPersonUnapproved_customerIncomeRangeId]
        ALTER TABLE [customer].[personUnapproved] DROP CONSTRAINT [fkCustomerPersonUnapproved_customerEmployerCategoryId]
        ALTER TABLE [customer].[personUnapproved] DROP COLUMN employmentDate
        ALTER TABLE [customer].[personUnapproved] DROP COLUMN incomeRangeId
        ALTER TABLE [customer].[personUnapproved] DROP COLUMN employerName
        ALTER TABLE [customer].[personUnapproved] DROP COLUMN employerCategoryId
    END

IF EXISTS (
    SELECT column_id
    FROM sys.columns
    WHERE OBJECT_NAME(object_id) = 'person'
        AND name = 'employmentDate')
        AND 22 <> (
            SELECT ORDINAL_POSITION
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = 'customer'
                AND TABLE_NAME = 'person'
                AND COLUMN_NAME = 'employmentDate')

    BEGIN
        ALTER TABLE [customer].[person] DROP CONSTRAINT [fkCustomerPerson_customerIncomeRangeId]
        ALTER TABLE [customer].[person] DROP CONSTRAINT [fkCustomerPerson_customerEmployerCategoryId]
        ALTER TABLE [customer].[person] DROP COLUMN employmentDate
        ALTER TABLE [customer].[person] DROP COLUMN incomeRangeId
        ALTER TABLE [customer].[person] DROP COLUMN employerName
        ALTER TABLE [customer].[person] DROP COLUMN employerCategoryId
    END

------

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'educationId' AND Object_ID = OBJECT_ID(N'customer.person') )
    BEGIN
        ALTER TABLE customer.person ADD educationId TINYINT
        ALTER TABLE customer.person WITH CHECK ADD CONSTRAINT [fkCustomerPerson_customerEducationid] FOREIGN KEY([educationId]) REFERENCES customer.education ([educationId])
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'educationId' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
    BEGIN
        ALTER TABLE customer.personUnapproved ADD educationId TINYINT
        ALTER TABLE customer.personUnapproved WITH CHECK ADD CONSTRAINT [fkCustomerPersonUnapproved_customerEducationid] FOREIGN KEY([educationId]) REFERENCES customer.education ([educationId])
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employmentId' AND Object_ID = OBJECT_ID(N'customer.person') )
    BEGIN
        ALTER TABLE customer.person ADD employmentId TINYINT
        ALTER TABLE customer.person WITH CHECK ADD CONSTRAINT [fkCustomerPerson_customeremploymentId] FOREIGN KEY([employmentId])
        REFERENCES customer.employment ([employmentId])
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employmentId' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
    BEGIN
        ALTER TABLE customer.personUnapproved ADD employmentId TINYINT
        ALTER TABLE customer.personUnapproved WITH CHECK ADD CONSTRAINT [fkCustomerPersonUnapproved_customeremploymentId] FOREIGN KEY([employmentId]) REFERENCES customer.employment ([employmentId])
    END

--

    IF NOT EXISTS (
        SELECT obj.name AS FK_NAME
        FROM sys.foreign_key_columns fkc
        JOIN sys.objects obj ON obj.object_id = fkc.constraint_object_id
        JOIN sys.tables tab1 ON tab1.object_id = fkc.parent_object_id
        JOIN sys.schemas sch ON tab1.schema_id = sch.schema_id
        WHERE sch.name = 'customer'
            AND tab1.name = 'person'
            AND obj.name = 'fkCustomerPerson_customerEmploymentId')
BEGIN
    ALTER TABLE customer.person WITH CHECK ADD CONSTRAINT [fkCustomerPerson_customeremploymentId] FOREIGN KEY([employmentId])
    REFERENCES customer.employment ([employmentId])
END

    IF NOT EXISTS (
        SELECT obj.name AS FK_NAME
        FROM sys.foreign_key_columns fkc
        JOIN sys.objects obj ON obj.object_id = fkc.constraint_object_id
        JOIN sys.tables tab1 ON tab1.object_id = fkc.parent_object_id
        JOIN sys.schemas sch ON tab1.schema_id = sch.schema_id
        WHERE sch.name = 'customer'
            AND tab1.name = 'personUnapproved'
            AND obj.name = 'fkCustomerPersonUnapproved_customeremploymentId')

        BEGIN
            ALTER TABLE customer.personUnapproved WITH CHECK ADD CONSTRAINT [fkCustomerPersonUnapproved_customeremploymentId] FOREIGN KEY([employmentId]) REFERENCES customer.employment ([employmentId])
        END
--

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employmentDate' AND Object_ID = OBJECT_ID(N'customer.person') )
    BEGIN
        ALTER TABLE customer.person ADD employmentDate DATE
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employmentDate' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
    BEGIN
        ALTER TABLE customer.personUnapproved ADD employmentDate DATE
    END


IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'incomeRangeId' AND Object_ID = OBJECT_ID(N'customer.person') )
    BEGIN
        ALTER TABLE customer.person ADD incomeRangeId TINYINT
        ALTER TABLE customer.person WITH CHECK ADD CONSTRAINT [fkCustomerPerson_customerIncomeRangeId] FOREIGN KEY([incomeRangeId]) REFERENCES customer.incomeRange ([incomeRangeId])
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'incomeRangeId' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
    BEGIN
        ALTER TABLE customer.personUnapproved ADD incomeRangeId TINYINT
        ALTER TABLE customer.personUnapproved WITH CHECK ADD CONSTRAINT [fkCustomerPersonUnapproved_customerIncomeRangeId] FOREIGN KEY([incomeRangeId]) REFERENCES customer.incomeRange ([incomeRangeId])
    END


IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employerName' AND Object_ID = OBJECT_ID(N'customer.person') )
    BEGIN
        ALTER TABLE customer.person ADD employerName TINYINT
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employerName' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
    BEGIN
        ALTER TABLE customer.personUnapproved ADD employerName TINYINT
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employerCategoryId' AND Object_ID = OBJECT_ID(N'customer.person') )
    BEGIN
        ALTER TABLE customer.person ADD employerCategoryId TINYINT
        ALTER TABLE customer.person WITH CHECK ADD CONSTRAINT [fkCustomerPerson_customerEmployerCategoryId] FOREIGN KEY([employerCategoryId]) REFERENCES customer.employerCategory ([employerCategoryId])
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employerCategoryId' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
    BEGIN
        ALTER TABLE customer.personUnapproved ADD employerCategoryId TINYINT
        ALTER TABLE customer.personUnapproved WITH CHECK ADD CONSTRAINT [fkCustomerPersonUnapproved_customerEmployerCategoryId] FOREIGN KEY([employerCategoryId]) REFERENCES customer.employerCategory ([employerCategoryId])
    END


IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'itemNameId' AND Object_ID = OBJECT_ID(N'customer.maritalStatus') )
    BEGIN
        ALTER TABLE customer.maritalStatus ADD itemNameId BIGINT
        ALTER TABLE customer.maritalStatus WITH CHECK ADD CONSTRAINT [fkCustomerMaritalStatusId_itemNameId] FOREIGN KEY([itemNameId]) REFERENCES core.itemName ([itemNameId])
    END


IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'workingHourStart' AND Object_ID = OBJECT_ID(N'customer.organization') )
    BEGIN
        ALTER TABLE [customer].[organization] DROP COLUMN workingHourStart
    END

IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'workingHourEnd' AND Object_ID = OBJECT_ID(N'customer.organization') )
    BEGIN
        ALTER TABLE [customer].[organization] DROP COLUMN workingHourEnd
    END

IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'weekendStart' AND Object_ID = OBJECT_ID(N'customer.organization') )
    BEGIN
        ALTER TABLE [customer].[organization] DROP COLUMN weekendStart
    END
--
IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'workingHourStart' AND Object_ID = OBJECT_ID(N'customer.organizationUnapproved') )
    BEGIN
        ALTER TABLE [customer].[organizationUnapproved] DROP COLUMN workingHourStart
    END

IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'workingHourEnd' AND Object_ID = OBJECT_ID(N'customer.organizationUnapproved') )
    BEGIN
        ALTER TABLE [customer].[organizationUnapproved] DROP COLUMN workingHourEnd
    END

IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'weekendStart' AND Object_ID = OBJECT_ID(N'customer.organizationUnapproved') )
    BEGIN
        ALTER TABLE [customer].[organizationUnapproved] DROP COLUMN weekendStart
    END

IF (SELECT [CHARACTER_MAXIMUM_LENGTH] FROM INFORMATION_SCHEMA.COLUMNS WHERE [COLUMN_NAME] = 'firstName' AND [TABLE_NAME] = 'person') < 100
    BEGIN
        ALTER TABLE [customer].[person] ALTER COLUMN firstName NVARCHAR(100) NOT NULL
    END

IF (SELECT [CHARACTER_MAXIMUM_LENGTH] FROM INFORMATION_SCHEMA.COLUMNS WHERE [COLUMN_NAME] = 'lastName' AND [TABLE_NAME] = 'person') < 100
    BEGIN
        ALTER TABLE [customer].[person] ALTER COLUMN lastName NVARCHAR(100) NOT NULL
    END

IF (SELECT [CHARACTER_MAXIMUM_LENGTH] FROM INFORMATION_SCHEMA.COLUMNS WHERE [COLUMN_NAME] = 'firstName' AND [TABLE_NAME] = 'personUnapproved') < 100
    BEGIN
        ALTER TABLE [customer].[personUnapproved] ALTER COLUMN firstName NVARCHAR(100) NOT NULL
    END

IF (SELECT [CHARACTER_MAXIMUM_LENGTH] FROM INFORMATION_SCHEMA.COLUMNS WHERE [COLUMN_NAME] = 'lastName' AND [TABLE_NAME] = 'personUnapproved') < 100
    BEGIN
        ALTER TABLE [customer].[personUnapproved] ALTER COLUMN lastName NVARCHAR(100) NOT NULL
    END

IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employementDate' AND Object_ID = OBJECT_ID(N'customer.person') ) AND
    EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employmentDate' AND Object_ID = OBJECT_ID(N'customer.person') )
    BEGIN
        ALTER TABLE [customer].[person] DROP COLUMN employementDate
    END

IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employementDate' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') ) AND
    EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employmentDate' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
    BEGIN
        ALTER TABLE [customer].[personUnapproved] DROP COLUMN employementDate
    END

IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employementId' AND Object_ID = OBJECT_ID(N'customer.person') ) AND
    EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employmentId' AND Object_ID = OBJECT_ID(N'customer.person') )
    BEGIN
        IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fkCustomerPerson_customerEmployementId')
        BEGIN
            ALTER TABLE customer.person DROP CONSTRAINT [fkCustomerPerson_customerEmployementId]
        END

        ALTER TABLE [customer].[person] DROP COLUMN employementId
    END

IF EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employementId' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') ) AND
    EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'employmentId' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
    BEGIN
        IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fkCustomerPersonUnapproved_customerEmployementId')
        BEGIN
            ALTER TABLE customer.personUnapproved DROP CONSTRAINT [fkCustomerPersonUnapproved_customerEmployementId]
        END

        ALTER TABLE [customer].[personUnapproved] DROP COLUMN employementId
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'familyMembers' AND Object_ID = OBJECT_ID(N'customer.person') )
    BEGIN
        ALTER TABLE [customer].[person] ADD familyMembers TINYINT
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'familyMembers' AND Object_ID = OBJECT_ID(N'customer.personUnapproved') )
    BEGIN
        ALTER TABLE [customer].[personUnapproved] ADD familyMembers TINYINT
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'organizationTypeId' AND Object_ID = OBJECT_ID(N'customer.organization') )
    BEGIN
        ALTER TABLE [customer].[organization] ADD organizationTypeId TINYINT NOT NULL DEFAULT(1)
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'organizationTypeId' AND Object_ID = OBJECT_ID(N'customer.organizationUnapproved') )
    BEGIN
        ALTER TABLE [customer].organizationUnapproved ADD organizationTypeId TINYINT NOT NULL DEFAULT(1)
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'description' AND Object_ID = OBJECT_ID(N'customer.organization') )
    BEGIN
        ALTER TABLE [customer].[organization] ADD [description] NVARCHAR(1000)
    END

IF NOT EXISTS( SELECT 1 FROM sys.columns WHERE Name = N'description' AND Object_ID = OBJECT_ID(N'customer.organizationUnapproved') )
    BEGIN
        ALTER TABLE [customer].organizationUnapproved ADD [description] NVARCHAR(1000) NULL
    END
