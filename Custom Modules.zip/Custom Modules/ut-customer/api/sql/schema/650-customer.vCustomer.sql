CREATE VIEW [customer].vCustomer
AS
    SELECT
        ca.actorId,
        xx.name,
        cc.customerTypeId,
        cc.statusId,
        ca.actorType
    FROM
        customer.customer cc
    JOIN (
        SELECT
            actorId,
            firstName + ' ' + lastName AS name
        FROM
            customer.person
        UNION
        SELECT
            actorId,
            organizationName AS name
        FROM
            customer.organization
        UNION
        SELECT
            actorId,
            jointName AS name
        FROM
            customer.joint
    ) AS xx ON xx.actorId = cc.actorId
    JOIN
        [core].actor ca ON ca.actorId = cc.actorId
