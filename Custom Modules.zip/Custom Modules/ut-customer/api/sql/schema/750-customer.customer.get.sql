ALTER PROCEDURE customer.[customer.get] -- gets the main information for customer
    @actorId BIGINT, -- this is the customer id
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
SET NOCOUNT ON;


BEGIN TRY
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
    -- checks if the user has a right to make the operation
    IF @actorId != @userId
    BEGIN
        DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
        EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
        IF @return != 0
            RETURN 55555
    END

    --Error message
    IF @actorId IS NULL
        BEGIN
            RAISERROR('customer.customerNotSubmitted', 16, 1);
        END

    IF NOT EXISTS (SELECT * FROM core.actor WHERE actorId = @actorId)
        BEGIN
            RAISERROR('customer.customerNotExists', 16, 1);
        END


    ------------------ EXISTING CUSTOMER
    IF EXISTS (SELECT actorId FROM [customer].[customer] WHERE actorId = @actorId )
        BEGIN
        ------------------ EXISTING EDITED CUSTOMER - RETURN resultSets - approved + unapproved
            IF EXISTS (SELECT actorId FROM [customer].[customerUnapproved] WHERE actorId = @actorId)

            BEGIN
                SELECT 'customerUnapproved' AS resultSetName, 1 AS single
                    SELECT
                        customerUnapprovedId, c.actorId, c.frontEndRecordId, c.customerNumber, c.customerTypeId, c.kycId, c.stateId, c.statusId, c.createdBy, c.createdOn, c.updatedBy, c.updatedOn, c.customerCategoryId, c.dao, c.description, c.cbsId, c.countryId, c.industryId, c.sectorId, c.loanCycle, c.organizationId, c.prospectClient, c.adminFee, c.udf,
                        k.display AS kycValue,
                        s.display AS stateValue,
                        cbs.ut5Key AS cbsPort,
                        country.name AS country,
                        country.phonePrefix AS phonePrefix,
                        country.countryId AS departmentId,
                        0 AS isNew
                    FROM [customer].[customerUnapproved] c
                    JOIN customer.[state] s ON c.stateId = s.stateId
                    LEFT JOIN customer.kyc k ON k.kycId = c.kycId
                    LEFT JOIN core.cbs cbs ON c.cbsId = cbs.cbsId
                    LEFT JOIN core.country country ON c.countryId = country.countryId
                    WHERE c.actorId = @actorId
                END

                SELECT 'customer' AS resultSetName, 1 AS single
                SELECT
                    NULL AS customerUnapprovedId, c.actorId, c.frontEndRecordId, c.customerNumber, c.customerTypeId, c.kycId, c.stateId, c.statusId, c.createdBy, c.createdOn, c.updatedBy, c.updatedOn, c.customerCategoryId, c.dao, c.description, c.cbsId, c.countryId, c.industryId, c.sectorId, c.loanCycle, c.organizationId, c.prospectClient, c.adminFee, c.udf,
                    k.display AS kycValue,
                    s.display AS stateValue,
                    cbs.ut5Key AS cbsPort,
                    country.name AS country,
                    country.phonePrefix AS phonePrefix,
                    country.countryId AS departmentId,
                    0 AS isNew
                FROM [customer].[customer] c
                JOIN customer.[state] s ON c.stateId = s.stateId
                LEFT JOIN customer.kyc k ON k.kycId = c.kycId
                LEFT JOIN core.cbs cbs ON c.cbsId = cbs.cbsId
                LEFT JOIN core.country country ON c.countryId = country.countryId
                WHERE c.actorId = @actorId

        END
        ELSE
        BEGIN
        ------------------------ NEW CUSTOMERS
            SELECT 'customer' AS resultSetName, 1 AS single
            SELECT
                customerUnapprovedId, c.actorId, c.frontEndRecordId, c.customerNumber, c.customerTypeId, c.kycId, c.stateId, c.statusId, c.createdBy, c.createdOn, c.updatedBy, c.updatedOn, c.customerCategoryId, c.dao, c.description, c.cbsId, c.countryId, c.industryId, c.sectorId, c.loanCycle, c.organizationId, c.prospectClient, c.adminFee, c.udf,
                k.display AS kycValue,
                s.display AS stateValue,
                cbs.ut5Key AS cbsPort,
                country.name AS country,
                country.phonePrefix AS phonePrefix,
                country.countryId AS departmentId,
                1 AS isNew
            FROM [customer].[customerUnapproved] c
            JOIN customer.[state] s ON c.stateId = s.stateId
            LEFT JOIN customer.kyc k ON k.kycId = c.kycId
            LEFT JOIN core.cbs cbs ON c.cbsId = cbs.cbsId
            LEFT JOIN core.country country ON c.countryId = country.countryId
            WHERE c.actorId = @actorId
        END

    EXEC [customer].[person.get] @actorId = @actorId, @meta = @meta

    IF OBJECT_ID('ledger.[account.get]') IS NOT NULL EXEC [ledger].[account.get] @ownerId = @actorId, @meta = @meta

    EXEC [customer].[address.get] @actorId = @actorId, @meta = @meta

    EXEC [customer].[email.get] @actorId = @actorId, @meta = @meta

    EXEC [customer].[phone.get] @actorId = @actorId, @meta = @meta

    EXEC [document].[document.get] @actorId = @actorId, @meta = @meta

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    EXEC [core].[error]
END CATCH
