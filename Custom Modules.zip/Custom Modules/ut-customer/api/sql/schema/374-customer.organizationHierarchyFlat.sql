CREATE TABLE [customer].[organizationHierarchyFlat]( --table that stores hierarchy of the actor and organizations
    [subject] [BIGINT] NOT NULL, --Organization id for which predicate is
    [object] [BIGINT] NOT NULL, --Organization id
    [parentActorId] [BIGINT] NOT NULL, --parent Organization id where privileges came from
    [relationDepth] INT NOT NULL, -- level of the relation
    CONSTRAINT [pkOrganizationHierarchyFlat] PRIMARY KEY CLUSTERED ([subject], [object], [parentActorId]),
    CONSTRAINT [fkOrganizationHierarchyFlat_subjectCustomerOrganization] FOREIGN KEY([subject]) REFERENCES [customer].[organization](actorId),
    CONSTRAINT [fkOrganizationHierarchyFlat_objectCustomerOrganization] FOREIGN KEY([object]) REFERENCES [customer].[organization](actorId),
    CONSTRAINT [fkOrganizationHierarchyFlat_parentActorIdCustomerOrganization] FOREIGN KEY([parentActorId]) REFERENCES [customer].[organization](actorId)
)
