ALTER PROCEDURE [customer].[address.get]
    --@addressId INT = NULL,
    @actorId BIGINT = NULL,
    @meta core.metaDataTT READONLY
AS
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @addressIds [core].[arrayNumberList]
    -------error

    IF @actorId IS NULL --AND @addressId IS NULL
        RAISERROR('customer.notGivenParameters', 16, 1)

    --INSERT INTO @addressIds (value) SELECT @addressId

    --IF NOT EXISTS (SELECT * FROM @addressIds)
    --INSERT INTO @addressIds (value)
    --SELECT addressId FROM customer.address
    --WHERE actorId = @actorId

    ------------------ EXISTING address
    IF EXISTS (SELECT actorId FROM customer.address WHERE actorId = @actorId)--AND ISNULL(@addressId, addressId) = addressId)
    BEGIN
    ------------------ EXISTING EDITED address - RETURN resultSets - approved + unapproved
        IF EXISTS (SELECT actorId FROM customer.addressUnapproved WHERE actorId = @actorId) --AND ISNULL(@addressId, addressId) = addressId)
        BEGIN
            SELECT 'customerAddressUnapproved' AS resultSetName

            SELECT au.addressUnapprovedId, au.addressId, au.actorId, au.value, au.frontEndRecordId, au.addressTypeId, au.statusId, au.city, au.isDeleted, au.updatedBy, au.updatedOn, au.lat, au.lng, au.addressZone1 AS addressZone1Id, au.addressZone2 AS addressZone2Id, au.addressZone3 AS addressZone3Id, au.addressZone4 AS addressZone4Id, i1.itemName AS addressZone1, i2.itemName AS addressZone2, i3.itemName AS addressZone3, i4.itemName AS addressZone4
            FROM [customer].[addressUnapproved] au
            LEFT JOIN core.itemName i1 ON i1.itemNameId = au.addressZone1
            LEFT JOIN core.itemName i2 ON i2.itemNameId = au.addressZone2
            LEFT JOIN core.itemName i3 ON i3.itemNameId = au.addressZone3
            LEFT JOIN core.itemName i4 ON i4.itemNameId = au.addressZone4
            WHERE actorId = @actorId --AND ISNULL(@addressId, addressId) = addressId

        END

    SELECT 'customerAddress' AS resultSetName

    SELECT a.addressId, a.actorId, a.value, a.frontEndRecordId, a.addressTypeId, a.statusId, a.city, a.lat, a.lng, a.addressZone1 AS addressZone1Id, a.addressZone2 AS addressZone2Id, a.addressZone3 AS addressZone3Id, a.addressZone4 AS addressZone4Id, i1.itemName AS addressZone1, i2.itemName AS addressZone2, i3.itemName AS addressZone3, i4.itemName AS addressZone4
    FROM [customer].[address] a
    LEFT JOIN core.itemName i1 ON i1.itemNameId = a.addressZone1
    LEFT JOIN core.itemName i2 ON i2.itemNameId = a.addressZone2
    LEFT JOIN core.itemName i3 ON i3.itemNameId = a.addressZone3
    LEFT JOIN core.itemName i4 ON i4.itemNameId = a.addressZone4
    WHERE actorId = @actorId --AND ISNULL(@addressId, addressId) = addressId

    END
    ELSE
        BEGIN
            ------------------------ NEW address
            SELECT 'customerAddress' AS resultSetName

            SELECT au.addressUnapprovedId, au.addressId, au.actorId, au.value, au.frontEndRecordId, au.addressTypeId, au.statusId, au.city, au.isDeleted, au.updatedBy, au.updatedOn, au.lat, au.lng, au.addressZone1 AS addressZone1Id, au.addressZone2 AS addressZone2Id, au.addressZone3 AS addressZone3Id, au.addressZone4 AS addressZone4Id, i1.itemName AS addressZone1, i2.itemName AS addressZone2, i3.itemName AS addressZone3, i4.itemName AS addressZone4
            FROM [customer].[addressUnapproved] au
            LEFT JOIN core.itemName i1 ON i1.itemNameId = au.addressZone1
            LEFT JOIN core.itemName i2 ON i2.itemNameId = au.addressZone2
            LEFT JOIN core.itemName i3 ON i3.itemNameId = au.addressZone3
            LEFT JOIN core.itemName i4 ON i4.itemNameId = au.addressZone4
            WHERE actorId = @actorId --AND ISNULL(@addressId, addressId) = addressId

        END

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    EXEC [core].[error]
END CATCH
