ALTER PROCEDURE [customer].[address.editApproved] -- edits address information
    @actorId BIGINT, -- customer id
    @noResultSet BIT = 0, -- a flag to show IF result IS expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @result customer.addressTT

BEGIN TRY
    DELETE p
    FROM customer.address p
    LEFT JOIN customer.addressUnapproved pu ON p.addressId = pu.addressId
    WHERE p.actorId = @actorId AND pu.addressId IS NULL

    UPDATE t
    SET t.value = au.value,
        t.addressTypeId = au.addressTypeId,
        t.statusId = au.statusId,
        t.city = au.city,
        t.lat = au.lat,
        t.lng = au.lng,
        t.addressZone1 = au.addressZone1,
        t.addressZone2 = au.addressZone2,
        t.addressZone3 = au.addressZone3,
        t.addressZone4 = au.addressZone4
    OUTPUT INSERTED.addressId, INSERTED.actorId, INSERTED.value, INSERTED.addressTypeId, INSERTED.statusId, INSERTED.city, INSERTED.lat, INSERTED.lng, INSERTED.addressZone1, INSERTED.addressZone2, INSERTED.addressZone3, INSERTED.addressZone4
    INTO @result (addressId, actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    FROM customer.address t
    INNER JOIN customer.addressUnapproved au ON t.addressId = au.addressId
    WHERE au.actorId = @actorId

    INSERT INTO customer.address (actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    OUTPUT INSERTED.addressId, INSERTED.actorId, INSERTED.value, INSERTED.addressTypeId, INSERTED.statusId, INSERTED.city, INSERTED.lat, INSERTED.lng, INSERTED.addressZone1, INSERTED.addressZone2, INSERTED.addressZone3, INSERTED.addressZone4
    INTO @result (addressId, actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    SELECT actorId, value, ISNULL(addressTypeId, 'home'), ISNULL(au.statusId, 'active'), city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
    FROM customer.addressUnapproved au
    WHERE au.addressId IS NULL AND au.actorId = @actorId

    DELETE FROM customer.addressUnapproved WHERE actorId = @actorId

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'address' AS resultSetName
        SELECT addressId, actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
