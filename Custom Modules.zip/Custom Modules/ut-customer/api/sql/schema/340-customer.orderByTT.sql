CREATE TYPE [customer].[orderByTT] AS TABLE(
    [column] VARCHAR(128),
    [direction] VARCHAR(4)
)
