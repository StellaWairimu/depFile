ALTER PROCEDURE customer.[person.add] -- create new persons in customer.person/customer.personunapproved table
    @person customer.personTT READONLY, -- in this parameter the stored procedure receives all fields of persons
    @email customer.emailTT READONLY, -- in this parameter the stored procedure receives all fields of person's email
    @phone customer.phoneTT READONLY, -- in this parameter the stored procedure receives all fields of person's phone
    @address customer.addressTT READONLY, -- in this parameter the stored procedure receives all fields of person's address
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation

-- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @result customer.personTT

    INSERT INTO customer.person (actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, udf, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers)
    OUTPUT INSERTED.actorId, INSERTED.firstName, INSERTED.lastName, INSERTED.nationalId, INSERTED.dateOfBirth, INSERTED.placeOfBirth, INSERTED.nationality, INSERTED.gender, INSERTED.bioId, INSERTED.udf, INSERTED.phoneModel, INSERTED.computerModel, INSERTED.isEnabled, INSERTED.isDeleted, INSERTED.maritalStatusId, INSERTED.age, INSERTED.middleName, INSERTED.educationId, INSERTED.employmentId, INSERTED.employmentDate, INSERTED.incomeRangeId, INSERTED.employerName, INSERTED.employerCategoryId, INSERTED.familyMembers
    INTO @result (actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, udf, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers)
    SELECT p.actorId, p.firstName, p.lastName, p.nationalId, p.dateOfBirth, p.placeOfBirth, CASE WHEN c.name IS NOT NULL THEN c.name ELSE p.nationality END AS nationality, p.gender, p.bioId, p.udf, p.phoneModel, p.computerModel, p.isEnabled, p.isDeleted, p.maritalStatusId, p.age, p.middleName, p.educationId, p.employmentId, p.employmentDate, p.incomeRangeId, p.employerName, p.employerCategoryId, p.familyMembers
    FROM @person AS p
    LEFT JOIN core.country c ON CAST(c.countryId AS VARCHAR(50)) = p.nationality


    EXEC customer.[email.add] @email = @email,
        @meta = @meta,
        @noResultSet = 1


    EXEC customer.[phone.add] @phone = @phone,
        @meta = @meta,
        @noResultSet = 1


    EXEC customer.[address.add] @address = @address,
        @meta = @meta,
        @noResultSet = 1


    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'person' AS resultSetName, 1 AS single
        SELECT actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
