ALTER PROCEDURE [customer].[joint.update]
    @joint customer.jointTT READONLY,
    @noResultSet BIT = 0,
    @meta core.metaDataTT READONLY
AS
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
    DECLARE @result customer.jointTT

BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    UPDATE
        TARGET
    SET
        TARGET.jointName = ISNULL(SOURCE.jointName, TARGET.jointName)
    OUTPUT
        INSERTED.* INTO @result
    FROM
        customer.joint TARGET
    INNER JOIN
        @joint SOURCE
    ON
        TARGET.actorId = SOURCE.actorId

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'joint' AS resultSetName
        SELECT * FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
