ALTER PROCEDURE customer.[attachment.delete] -- update changed data of attachements IN document.attachement table
    @actorId BIGINT, -- IN this parameter the stored procedure receives all changed fields of customer
    @attachment document.attachmentTT READONLY, --in this parameter the stored procedure receives all changed fields of attachments
    @noResultSet BIT = 0, -- this is the flag about the waited result
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @result document.attachmentTT
DECLARE @tranCounter INT

BEGIN TRY
-- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    SET @tranCounter = @@TRANCOUNT;

    IF @tranCounter = 0
        BEGIN TRANSACTION

            DELETE d
                FROM document.attachment d
            JOIN @attachment dd ON d.documentId = dd.documentId

            IF @TranCounter = 0
        COMMIT TRANSACTION

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        EXEC customer.[file.get]
            @actorId = @actorId,
            @meta = @meta
    END
    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION
    EXEC [core].[error]
    RETURN 5555
END CATCH
