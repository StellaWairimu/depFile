ALTER PROCEDURE [customer].[organization.editApproved] -- edits organization's approved information
    @actorId BIGINT, -- the Id of the organization that is approved
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @parentsCheck AS TABLE (actorId BIGINT, [state] VARCHAR (10))
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation

BEGIN TRY


    IF NOT EXISTS (SELECT actorId FROM customer.organizationsVisibleFor(@userId) WHERE actorId = @actorId)
        RAISERROR('customer.securityViolation', 16, 1)

    --fetch all parents of the organization - existing, added, removed
    INSERT INTO @parentsCheck
    SELECT [object], [state]
    FROM
        (
            SELECT [object], CASE WHEN isDeleted = 0 THEN 'added' ELSE 'deleted' END AS [state]
            FROM [core].[actorHierarchyUnapproved]
            WHERE [subject] = @actorId AND predicate = 'memberOf'

            UNION

            SELECT [object], 'existing' AS [state]
            FROM [core].[actorHierarchy]
            WHERE [subject] = @actorId AND predicate = 'memberOf'
        ) a

    -- check if user is not trying to edit the parents of his own organization - violation
    IF NOT EXISTS(
        SELECT p.actorId
        FROM @parentsCheck p
        JOIN customer.organizationsVisibleFor(@userId) o ON o.actorId = p.actorId
        WHERE [state] = 'existing')
        AND EXISTS (SELECT 1 FROM @parentsCheck WHERE [state] <> 'existing')
            RAISERROR('customer.securityViolation', 16, 1)

    -- check if user has access to the parent organizations he is trying to add/remove
    IF EXISTS(
    SELECT p.actorId
    FROM @parentsCheck p
    LEFT JOIN customer.organizationsVisibleFor(@userId) o ON o.actorId = p.actorId
    WHERE o.actorId IS NULL AND [state] <> 'existing')
        RAISERROR('customer.securityViolation', 16, 1)

        --checks IF among parents there are disabled or deleted organizations
    IF EXISTS(
        SELECT * FROM @parentsCheck p
        LEFT JOIN customer.organization o ON p.actorId = o.actorId AND o.isEnabled = 1 AND o.isDeleted = 0
        WHERE o.actorId IS NULL AND [state] <> 'deleted')
            RAISERROR('customer.disabledOrDeletedOrganization', 16, 1)

    DECLARE @parentChanged INT = 0 -- variable to keep whether at least one of the parents IS changed

    DECLARE @grantedRoles core.arrayNumberList, @revokedRoles core.arrayNumberList, @parents core.arrayNumberList

    INSERT INTO @grantedRoles SELECT [object] FROM [core].[actorHierarchyUnapproved] WHERE [subject] = @actorId AND predicate = 'role' AND isDeleted = 0
    INSERT INTO @revokedRoles SELECT [object] FROM [core].[actorHierarchyUnapproved] WHERE [subject] = @actorId AND predicate = 'role' AND isDeleted = 1

    DECLARE @TranCounter INT = @@TRANCOUNT;
    IF @TranCounter = 0
        BEGIN TRANSACTION

            UPDATE t
            SET t.organizationName = s.organizationName,
                t.code = s.code,
                t.executiveOfficer = s.executiveOfficer,
                t.tradeName = s.tradeName,
                t.capital = s.capital,
                t.currency = s.currency,
                t.timeZone = s.timeZone,
                t.primaryLanguageId = s.primaryLanguageId,
                t.cbsId = s.cbsId,
                t.countryId = s.countryId
            FROM customer.organization t
            JOIN [customer].[organizationUnapproved] s ON t.actorId = s.actorId
            WHERE t.actorId = @actorId

            DELETE FROM [customer].[organizationUnapproved] WHERE actorId = @actorId

            DELETE a
            FROM [core].[actorHierarchy] a
            JOIN
            (
                SELECT [object] AS value
                FROM [core].[actorHierarchyUnapproved]
                WHERE [subject] = @actorId AND predicate = 'memberOf' AND isDeleted = 1
            ) v ON a.[subject] = @actorId AND a.predicate = 'memberOf' AND a.[object] = v.value

            SET @parentChanged += @@ROWCOUNT

            INSERT INTO [core].actorHierarchy ([subject], predicate, [object])
            SELECT @actorId, 'memberOf', [object]
            FROM [core].[actorHierarchyUnapproved]
            WHERE [subject] = @actorId AND predicate = 'memberOf' AND isDeleted = 0

            SET @parentChanged += @@ROWCOUNT

            EXEC [user].[role.grant]
                @actorId = @actorId,
                @granted = @grantedRoles,
                @revoked = @revokedRoles,
                @defaultRoleId = NULL,
                @meta = @meta

            DELETE FROM [core].[actorHierarchyUnapproved] WHERE [subject] = @actorId

            IF @parentChanged > 0 -- means that at least one parent IS changed (a new parent IS added or/AND IS removed) so we need to rebuild
            BEGIN
                -- retrieve corresponding parents in order to pass them to the SP
                INSERT INTO @parents
                SELECT [object]
                FROM [core].actorHierarchy
                WHERE subject = @actorId
                    AND predicate = 'memberOf'

                EXECUTE [customer].[organizationHierarchyFlat.rebuild] @actorId = @actorId, @meta = @meta, @actorIdParents = @parents -- rebuild the customer.organizationHierarchyFlat TABLE
            END

            EXEC [customer].[email.editApproved]
                @actorId = @actorId,
                @meta = @meta,
                @noResultSet = 1

            EXEC [customer].[phone.editApproved]
                @actorId = @actorId,
                @meta = @meta,
                @noResultSet = 1

            EXEC [customer].[address.editApproved]
                @actorId = @actorId,
                @meta = @meta,
                @noResultSet = 1

    IF @TranCounter = 0
        COMMIT TRANSACTION

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
