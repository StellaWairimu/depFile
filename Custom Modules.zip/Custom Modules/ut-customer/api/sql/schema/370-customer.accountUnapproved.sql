CREATE TABLE customer.accountUnapproved(
    accountUnapprovedId BIGINT IDENTITY(1, 1) NOT NULL,
    accountId INT NULL,
    actorId BIGINT NOT NULL,
    frontEndRecordId VARCHAR (10),
    accountTypeId INT NOT NULL,
    accountNumber VARCHAR (20),
    accountName VARCHAR (20),
    statusId VARCHAR (20) NOT NULL,
    oldValues XML NULL,
    currencyId INT NOT NULL,
    balance MONEY NOT NULL,
    accountOpenedOn DATE NOT NULL,
    accountLastTrx MONEY NULL,
    accountLastTrxOn DATE NULL,
    [isDeleted] BIT NOT NULL, -- a flag to show if the account will be deleted or inserted/edited
    [updatedBy] BIGINT NOT NULL, -- the id of the user updating the account
    [updatedOn] DATETIMEOFFSET(7) NOT NULL, -- the datetime the account is updated on
    CONSTRAINT pkCustomerAccountUnapproved PRIMARY KEY CLUSTERED(accountUnapprovedId ASC),
    CONSTRAINT fkCustomerAccountUnapproved_coreActor FOREIGN KEY(actorId) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerAccountUnapproved_updatedByCoreActor FOREIGN KEY(updatedBy) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerAccountUnapproved_customerAccountType FOREIGN KEY(accountTypeId) REFERENCES customer.accountType (accountTypeId),
    CONSTRAINT fkCustomerAccountUnapproved_coreCurrencyId FOREIGN KEY(currencyId) REFERENCES core.currency (currencyId),
    CONSTRAINT fkCustomerAccountUnapproved_coreStatus FOREIGN KEY(statusId) REFERENCES core.[status] (statusId)
)
