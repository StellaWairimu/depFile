ALTER PROCEDURE [customer].[kycAttribute.list] -- this sp lists all attributes for a kyc based on the customer type, used for kyc create
    @customerTypeId INT, -- the customer type, eg. corporate/individual
    @meta core.metaDataTT READONLY -- information for the logged user
AS
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    DECLARE @customerType VARCHAR(20) = (SELECT customerTypeId FROM [customer].[customerType] WHERE [customerTypeNumber] = @customerTypeId)
    DECLARE @itemTypeId INT =
        (CASE WHEN @customerType = 'individual' THEN (SELECT itemTypeId FROM core.itemType WHERE alias = 'kycAttributesIndividual')
        ELSE (SELECT itemTypeId FROM core.itemType WHERE alias = 'kycAttributesCorporate') END)

    DECLARE @languageId BIGINT = (
        SELECT languageId
        FROM [core].[language] cl
        JOIN [user].[session] us ON us.[language] = cl.[iso2Code]
        WHERE us.[actorId] = @userId)

    SELECT 'kycAttributes' AS resultSetName

    SELECT itt.itemNameId, itt.itemNameTranslation
    FROM [core].[itemType] it
    JOIN [core].[itemName] itn ON it.itemTypeId = itn.itemTypeId
    JOIN [core].[itemTranslation] itt ON itt.itemNameId = itn.itemNameId
    WHERE it.itemTypeId = @itemTypeId AND itt.languageId = @languageId
