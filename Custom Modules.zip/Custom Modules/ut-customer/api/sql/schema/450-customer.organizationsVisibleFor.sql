CREATE FUNCTION [customer].[organizationsVisibleFor]-- return the complete list of organizations visible for user
(
    @actor BIGINT-- user identifier
)

RETURNS TABLE AS
RETURN

    -- if it is called with actor which is an user then get his assigned BU(s) and all their children
    SELECT o.actorId AS actorId,
        o.countryId AS countryId,
        hf.relationDepth AS depth,
        o.organizationName AS organizationName,
        o.organizationTypeId
    FROM [core].[actorHierarchy] h
    INNER JOIN [customer].[organizationHierarchyFlat] hf ON hf.[subject] = h.[object]
    INNER JOIN [customer].[organization] o ON o.actorId = hf.[object] AND o.isDeleted = 0 AND o.isEnabled = 1
    WHERE h.[subject] = @actor
        AND h.[predicate] = 'memberOf'
        AND NOT EXISTS (SELECT actorId FROM [customer].[organization] WHERE [actorId] = @actor)-- if it is an user

    UNION ALL -- it is a union but ALWAYS only one of the select will return the result set

    -- if it is called with actor which is a BU then return this BU and all its children
    SELECT o.actorId AS actorId,
        o.countryId AS countryId,
        hf.relationDepth AS depth,
        o.organizationName AS organizationName,
        o.organizationTypeId
    FROM [customer].[organizationHierarchyFlat] hf
    INNER JOIN [customer].[organization] o ON o.actorId = hf.[object] AND o.isDeleted = 0 AND o.isEnabled = 1
    WHERE hf.[subject] = @actor
        AND EXISTS (SELECT actorId FROM [customer].[organization] WHERE [actorId] = @actor)-- if it is a organization
