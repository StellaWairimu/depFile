ALTER PROCEDURE customer.[address.addApproved] -- approve new addresss IN customer.address TABLE
    @actorId BIGINT, -- customer id
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE @result customer.addressTT

    INSERT INTO customer.address (actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    OUTPUT INSERTED.addressId, INSERTED.actorId, INSERTED.value, INSERTED.addressTypeId, INSERTED.statusId, INSERTED.city, INSERTED.lat, INSERTED.lng, INSERTED.addressZone1, INSERTED.addressZone2, INSERTED.addressZone3, INSERTED.addressZone4
    INTO @result (addressId, actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    SELECT actorId, value, addressTypeId, ISNULL(statusId, 'active'), city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
    FROM customer.addressUnapproved pu
    WHERE pu.addressId IS NULL AND pu.actorId = @actorId

    DELETE FROM customer.addressUnapproved WHERE actorId = @actorId

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'address' AS resultSetName
        SELECT addressId, actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
