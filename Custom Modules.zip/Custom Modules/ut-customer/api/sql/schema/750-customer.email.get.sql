ALTER PROCEDURE [customer].[email.get]
    -- @emailId INT = NULL,
    @actorId BIGINT = NULL,
    @meta core.metaDataTT READONLY
AS
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    -------error

    IF @actorId IS NULL --AND @emailId IS NULL
        RAISERROR('customer.notGivenParameters', 16, 1)

    ------------------ EXISTING email
    IF EXISTS (SELECT actorId FROM customer.email WHERE actorId = @actorId) --AND ISNULL(@emailId, emailId) = emailId)
    BEGIN
        ------------------ EXISTING EDITED email - RETURN resultSets - approved + unapproved
        IF EXISTS (SELECT actorId FROM customer.emailUnapproved WHERE actorId = @actorId) -- AND ISNULL(@emailId, emailId) = emailId)
        BEGIN
            SELECT 'customerEmailUnapproved' AS resultSetName

            SELECT emailUnapprovedId, emailId, actorId, value, frontEndRecordId, emailTypeId, statusId, oldValues, isDeleted, updatedBy, updatedOn, isPrimary
            FROM [customer].[emailUnapproved]
            WHERE actorId = @actorId --AND ISNULL(@emailId, emailId) = emailId

        END

        SELECT 'customerEmail' AS resultSetName

        SELECT emailId, actorId, value, frontEndRecordId, emailTypeId, statusId, oldValues, isPrimary
        FROM [customer].[email]
        WHERE actorId = @actorId --AND ISNULL(@emailId, emailId) = emailId

    END
    ELSE
        BEGIN
            ------------------------ NEW email
            SELECT 'customerEmail' AS resultSetName

            SELECT emailUnapprovedId, emailId, actorId, value, frontEndRecordId, emailTypeId, statusId, oldValues, isDeleted, updatedBy, updatedOn, isPrimary
            FROM [customer].[emailUnapproved]
            WHERE actorId = @actorId --AND ISNULL(@emailId, emailId) = emailId

        END

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    EXEC [core].[error]
END CATCH
