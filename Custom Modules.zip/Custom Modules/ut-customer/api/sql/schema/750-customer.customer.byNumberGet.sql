ALTER PROCEDURE [customer].[customer.byNumberGet] -- return customer ids by array of customer numbers and cbsId
    @customerNumbers customer.arrayList READONLY, -- searched customer number(s)
    @cbsId INT -- id of the core banking system
AS

SELECT 'customer' AS resultSetName
SELECT cc.actorId, cc.customerNumber
FROM customer.customer cc
JOIN @customerNumbers c ON c.[value] = cc.customerNumber AND cc.cbsId = @cbsId

