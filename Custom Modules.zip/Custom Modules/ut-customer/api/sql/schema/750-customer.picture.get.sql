ALTER PROCEDURE customer.[picture.get] -- gets the profile picture for customer
    @actorId BIGINT, -- this is the customer id
    @sizeId VARCHAR(10) = 'DEFAULT', -- size of the image
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
SET NOCOUNT ON;

DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
-- checks if the user has a right to make the operation
IF @actorId != @userId
BEGIN
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
        RETURN 55555
END


SELECT 'filename' AS resultSetName, 1 AS single;

SELECT da.filename
FROM [document].[attachment] da
JOIN document.actorDocument dad ON dad.documentId = da.documentId
JOIN document.document dd ON dd.documentId = dad.documentId
WHERE dad.actorId = @actorId AND dd.documentTypeId = 'profile' AND da.attachmentSizeId = @sizeId AND dd.statusId = 'active'
