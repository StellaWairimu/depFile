ALTER PROCEDURE [customer].[customer.discard]
    @actorId BIGINT, -- customer id
    @accountIds [core].[arrayNumberList] READONLY, --table for edit account
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta


    EXEC [customer].[person.discard] @actorId = @actorId, @meta = @meta

    EXEC [customer].[email.discard] @actorId = @actorId, @meta = @meta


    EXEC [customer].[phone.discard] @actorId = @actorId, @meta = @meta

    EXEC [customer].[address.discard] @actorId = @actorId, @meta = @meta

    IF EXISTS (SELECT * FROM @accountIds)
    BEGIN
        EXEC [ledger].[account.discard] @accountIds = @accountIds, @meta = @meta
    END

    EXEC [document].[document.discard] @actorId = @actorId, @meta = @meta

    DELETE FROM customer.customerUnapproved
    WHERE actorId = @actorId


END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
