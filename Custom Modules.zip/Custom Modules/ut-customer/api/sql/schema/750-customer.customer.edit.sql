ALTER PROCEDURE [customer].[customer.edit] -- edits customer information
    @customer customer.customerUnapprovedTT READONLY, -- the edited customer information
    -----------------------------------------
    @person customer.personUnapprovedTT READONLY, -- table with personal information about the new customer, if it is a person
    -- @joint customer.jointUnapprovedTT READONLY, -- table with information about the new customer, if it is a joint
    @organization customer.organizationUnapprovedTT READONLY, -- table with information about the new customer, if it is an organization
    -----------------------------------------
    @account ledger.accountUnapprovedTT READONLY, -- in this parameter the stored procedure receives all fields of account
    @accountPerson ledger.accountPersonUnapprovedTT READONLY, -- in this parameter the stored procedure receives all fields of account to which person
    @accountClosed [core].[arrayNumberList] READONLY, -- in this parameter the stored procedure receives all fields of closed accounts
    @email customer.emailUnapprovedTT READONLY, -- information about the e-mails of the customer
    @phone customer.phoneUnapprovedTT READONLY, -- information about the phone numbers of the customer
    @address customer.addressUnapprovedTT READONLY, -- information about the addresses of the customer
    @document document.documentUnapprovedTT READONLY, --information about the document
    @attachment document.attachmentCustomTT READONLY, --information about the document attachment
    @actorDocument [document].[actorDocumentCustomTT] READONLY, --information about the document AND document order
    ------------------------------------------------
    @actorId BIGINT = NULL, -- the id of the customer, that will be created
    @noResultSet BIT = 0, -- a flag to show if result is expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation

AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @result customer.customerUnapprovedTT
DECLARE @businessUnitId BIGINT = (SELECT organizationId FROM @customer)

IF @actorId IS NULL SET @actorId = (SELECT actorId FROM @customer)

DECLARE
    @personTT customer.personUnapprovedTT,
    @accountTT ledger.accountUnapprovedTT,
    @emailTT customer.emailUnapprovedTT,
    @phoneTT customer.phoneUnapprovedTT,
    @addressTT customer.addressUnapprovedTT,
    @actorDocumentTT [document].[actorDocumentCustomTT]


INSERT INTO @personTT SELECT * FROM @person
INSERT INTO @accountTT SELECT * FROM @account
INSERT INTO @emailTT SELECT * FROM @email
INSERT INTO @phoneTT SELECT * FROM @phone
INSERT INTO @addressTT SELECT * FROM @address
INSERT INTO @actorDocumentTT SELECT * FROM @actorDocument

UPDATE @personTT SET actorId = @actorId
UPDATE @emailTT SET actorId = @actorId
UPDATE @phoneTT SET actorId = @actorId
UPDATE @addressTT SET actorId = @actorId
UPDATE @accountTT SET ownerId = @actorId, businessUnitId = @businessUnitId
UPDATE @actorDocumentTT SET actorId = @actorId

BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    IF (SELECT dateOfBirth FROM @person ) >= CONVERT(DATE, GETDATE())
        RAISERROR('customer.wrongDateOfBirth', 16, 1);

    DECLARE @DisableCustomerMCH BIT = 0
    IF EXISTS (SELECT TOP 1 * FROM core.configuration WHERE [key] = 'DisableCustomerM/C' AND [value] = 1)
    SET @DisableCustomerMCH = 1

    DECLARE @tranCounter INT = @@TRANCOUNT;
    IF @tranCounter = 0
        BEGIN TRANSACTION

            IF @DisableCustomerMCH = 1
            BEGIN
                EXEC customer.[person.edit]
                    @person = @personTT,
                    @email = @emailTT,
                    @phone = @phoneTT,
                    @address = @addressTT,
                    @noResultSet = 1,
                    @meta = @meta

                IF EXISTS (SELECT * FROM @account)
                    EXEC ledger.[account.edit]
                        @account = @accountTT,
                        @accountPerson = @accountPerson,
                        @noResultSet = 1,
                        @forCustomer = 1,
                        @meta = @meta

                IF EXISTS (SELECT * FROM @accountClosed)
                    EXEC ledger.[account.closeMain] @accountIds = @accountClosed, @meta = @meta

                EXEC document.[document.edit]
                    @document = @document,
                    @attachment = @attachment,
                    @actorId = @actorId,
                    @actorDocument = @actorDocumentTT,
                    @meta = @meta

                UPDATE a
                SET kycId = b.kycId ,
                stateId = ISNULL (b.stateId, a.stateId),
                statusId = ISNULL (b.statusId, a.statusId),
                customerCategoryId = b.customerCategoryId,
                [description] = b.[description],
                countryId = b.countryId,
                industryId = b.industryId,
                sectorId = b.sectorId,
                loanCycle = b.loanCycle,
                organizationId = b.organizationId,
                adminFee = b.adminFee,
                a.udf = b.udf,
                a.updatedBy = @userId,
                a.updatedOn = SYSDATETIMEOFFSET()
                FROM customer.customer a
                JOIN @customer b ON a.actorId = b.actorId
            END
            ELSE
            BEGIN
                EXEC customer.[person.editUnapproved]
                    @person = @personTT,
                    @email = @emailTT,
                    @phone = @phoneTT,
                    @address = @addressTT,
                    @noResultSet = 1,
                    @meta = @meta

                IF EXISTS (SELECT * FROM @account )
                    EXEC ledger.[account.editUnapproved]
                        @account = @accountTT,
                        @accountPerson = @accountPerson,
                        --@DisableAccountMCH = 0,
                        @noResultSet = 1,
                        @forCustomer = 1,
                        @meta = @meta

                IF EXISTS (SELECT * FROM @accountClosed)
                    EXEC ledger.[account.closeUnapproved] @accountIds = @accountClosed, @meta = @meta

                EXEC document.[document.editUnapproved]
                    @document = @document,
                    @attachment = @attachment,
                    @actorDocument = @actorDocumentTT,
                    @meta = @meta

                IF EXISTS (SELECT * FROM customer.customerUnapproved a JOIN @customer b ON a.actorId = b.actorId)
                    UPDATE a
                    SET kycId = b.kycId ,
                        stateId = ISNULL (b.stateId, a.stateId),
                        statusId = 'pending',
                        customerCategoryId = b.customerCategoryId,
                        [description] = b.[description],
                        countryId = b.countryId,
                        industryId = b.industryId,
                        sectorId = b.sectorId,
                        loanCycle = b.loanCycle,
                        organizationId = b.organizationId,
                        adminFee = b.adminFee,
                        a.udf = b.udf,
                        a.updatedBy = @userId,
                        a.updatedOn = SYSDATETIMEOFFSET()
                    FROM customer.customerUnapproved a
                    JOIN @customer b ON a.actorId = b.actorId
                ELSE
                    INSERT INTO customer.customerUnapproved (actorId, frontEndRecordId, customerNumber, customerTypeId, kycId, stateId, statusId, createdBy, createdOn, updatedBy, updatedOn, oldValues, customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee, udf)
                    SELECT actorId, frontEndRecordId, customerNumber, customerTypeId, kycId, stateId, 'pending', @userId, SYSDATETIMEOFFSET(), @userId, SYSDATETIMEOFFSET(), oldValues, customerCategoryId, dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee, udf
                    FROM @customer
            END

            IF @tranCounter = 0
        COMMIT TRANSACTION

    IF (ISNULL(@noResultSet, 0) = 0)
        EXEC customer.[customer.get] @actorid = @actorid, @meta = @meta

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
