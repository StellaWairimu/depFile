CREATE PROCEDURE [customer].[organization.observerList] -- lists all organizations
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS

DECLARE @userId BIGINT

SELECT @userId = [auth.actorId] FROM @meta AS m

-- checks if the user has a right to make the operation
DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
IF @return != 0
BEGIN
    RETURN 55555
END

IF OBJECT_ID('tempdb..#hierarchyData') IS NOT NULL
    DROP TABLE #hierarchyData

IF OBJECT_ID('tempdb..#branchCode') IS NOT NULL
    DROP TABLE #branchCode

CREATE TABLE #hierarchyData (actorId BIGINT, countryId INT, depth INT)
CREATE TABLE #branchCode (code BIGINT, countryId INT)

IF EXISTS
(
    SELECT actorid

        FROM customer.organization o
        JOIN core.actorHierarchy h ON o.actorId = h.object AND subject = @userId AND predicate = 'memberOf'
        WHERE code IS NULL OR organizationName = 'Implementation'
)
BEGIN

    INSERT INTO #hierarchyData
    SELECT actorId, countryId, depth FROM customer.organizationsVisibleFor(@userId)

END

ELSE
BEGIN

    IF NOT EXISTS
    (
        SELECT subject
            FROM core.actorHierarchy a
            JOIN
                (
                SELECT DISTINCT actorId
                    FROM core.actorHierarchy a
                    JOIN [user].actorAction b ON a.object = b.actorid AND b.actionId = 'loan.branch.parentFetch'
                ) AS r ON a.object = r.actorId
            JOIN( SELECT object FROM core.actorHierarchy WHERE subject = @userId) c ON a.subject = c.object

    )

        BEGIN

            INSERT INTO #hierarchyData
            SELECT actorId, countryId, depth
            FROM customer.organizationsVisibleFor(@userId)
            WHERE depth = 1

        END

    ELSE

        BEGIN

            INSERT INTO #branchCode
            SELECT DISTINCT (code / 100) * 100 code, countryId
            FROM customer.organization a
            JOIN core.actorHierarchy b ON a.actorId = b.object AND subject = @userId AND predicate = 'memberOf'
            WHERE a.isDeleted = 0 AND a.isEnabled = 1

            INSERT INTO #hierarchyData
            SELECT b.actorId, b.countryId, b.depth
            FROM customer.organization a
            CROSS APPLY customer.organizationsVisibleFor(a.actorId) b
            JOIN #branchCode c ON a.code = CAST(c.code AS NVARCHAR(500)) AND b.countryId = c.countryId

        END

END

SELECT 'organizations' AS resultSetName

SELECT hd.actorId, o.organizationName, o.code
FROM #hierarchyData hd
JOIN customer.organization o ON hd.actorId = o.actorId
ORDER BY o.code
