ALTER PROCEDURE [customer].[account.remove]
    @accountId core.arrayList READONLY,
    @noResultSet BIT = 0,
    @meta core.metaDataTT READONLY
AS
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
    DECLARE @accountTT customer.accountTT
    SET @noResultSet = ISNULL(@noResultSet, 0)
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    UPDATE
        x
    SET
        statusId = 'deleted'
    OUTPUT
        INSERTED.* INTO @accountTT
    FROM
        customer.account x
    JOIN
        @accountId ids
    ON
        x.accountId = ids.value

    IF(@noResultSet = 0)
    BEGIN
        SELECT 'account' AS resultSetName
        SELECT * FROM @accountTT
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
