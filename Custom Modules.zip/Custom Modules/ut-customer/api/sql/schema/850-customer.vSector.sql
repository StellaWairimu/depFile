ALTER VIEW [customer].[vSector]
AS
SELECT s.sectorId, s.itemNameId, i.itemCode, i.itemSyncId, i.organizationId, i.countryId, i.itemName, i.itemTypeId
FROM customer.[sector] AS s
JOIN core.itemName i ON i.itemNameId = s.itemNameId
WHERE i.isEnabled = 1
