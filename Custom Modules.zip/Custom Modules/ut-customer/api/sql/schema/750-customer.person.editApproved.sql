ALTER PROCEDURE [customer].[person.editApproved] -- edits person information
    @actorId BIGINT, -- customer id
    @noResultSet BIT = 0, -- a flag to show if result is expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML

BEGIN TRY
    DECLARE @tranCounter INT = @@TRANCOUNT;
    IF @tranCounter = 0
        BEGIN TRANSACTION

            IF EXISTS (SELECT * FROM customer.person t WHERE actorId = @actorId)
            BEGIN
                UPDATE t
                SET t.firstName = pu.firstName,
                    t.middleName = pu.middleName,
                    t.lastName = pu.lastName,
                    t.nationalId = pu.nationalId,
                    t.dateOfBirth = pu.dateOfBirth,
                    t.placeOfBirth = pu.placeOfBirth,
                    t.nationality = pu.nationality,
                    t.gender = pu.gender,
                    t.bioId = pu.bioId,
                    t.phoneModel = pu.phoneModel,
                    t.computerModel = pu.computerModel,
                    t.maritalStatusId = pu.maritalStatusId,
                    t.age = pu.age,
                    t.employerName = pu.employerName,
                    t.employerCategoryId = pu.employerCategoryId,
                    t.employmentDate = pu.employmentDate,
                    t.educationId = pu.educationId,
                    t.employmentId = pu.employmentId,
                    t.familyMembers = pu.familyMembers,
                    t.incomeRangeId = pu.incomeRangeId
                FROM customer.person t
                INNER JOIN customer.personUnapproved pu ON t.actorId = pu.actorId
                WHERE pu.actorId = @actorId
            END
            ELSE
                INSERT INTO customer.person (actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers)
                SELECT actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers
                FROM customer.personUnapproved pu
                WHERE pu.actorId = @actorId

            DELETE FROM customer.personUnapproved WHERE actorId = @actorId

            EXEC customer.[email.editApproved] @actorId = @actorId, @meta = @meta, @noResultSet = 1

            EXEC customer.[phone.editApproved] @actorId = @actorId, @meta = @meta, @noResultSet = 1

            EXEC customer.[address.editApproved] @actorId = @actorId, @meta = @meta, @noResultSet = 1

            IF @tranCounter = 0
        COMMIT TRANSACTION

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'person' AS resultSetName
        SELECT actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers
        FROM customer.person
        WHERE actorId = @actorId
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
