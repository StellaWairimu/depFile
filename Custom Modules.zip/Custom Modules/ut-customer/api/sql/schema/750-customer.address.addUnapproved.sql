ALTER PROCEDURE customer.[address.addUnapproved] -- CREATE new addresss IN customer.address/customer.addressUnapproved TABLE
    @address customer.addressTT READONLY, -- IN this parameter the stored PROCEDURE receives all fields of addresss
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
    DECLARE @oldValues XML
    DECLARE @Today DATETIME2 = GETDATE()

-- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @result customer.addressUnapprovedTT

    INSERT INTO [customer].[addressUnapproved] (addressId, actorId, value, addressTypeId, statusId, city, isDeleted, updatedBy, updatedOn, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    OUTPUT INSERTED.addressUnapprovedId, INSERTED.addressId, INSERTED.actorId, INSERTED.value, INSERTED.addressTypeId, INSERTED.statusId, INSERTED.city, INSERTED.isDeleted, INSERTED.updatedBy, INSERTED.updatedOn, INSERTED.lat, INSERTED.lng, INSERTED.addressZone1, INSERTED.addressZone2, INSERTED.addressZone3, INSERTED.addressZone4
    INTO @result (addressUnapprovedId, addressId, actorId, value, addressTypeId, statusId, city, isDeleted, updatedBy, updatedOn, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    SELECT addressId, actorId, value, ISNULL(addressTypeId, 'home'), ISNULL(a.statusId, 'active'), city, 0, @userId, SYSDATETIMEOFFSET(), lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
    FROM @address a

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'address' AS resultSetName
        SELECT addressUnapprovedId, addressId, actorId, value, addressTypeId, statusId, city, isDeleted, updatedBy, updatedOn, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
