ALTER PROCEDURE [customer].[organization.fetchDeleted] -- List information for deleted business unit
    @searchString NVARCHAR(100), -- the string to be searched in organization name
    @pageSize INT = 25, -- how many rows will be returned per page
    @pageNumber INT = 1, -- which page number to display
    @sortBy VARCHAR(50) = 'name', -- on which column results to be sorted
    @sortOrder VARCHAR(4) = 'ASC', -- what kind of sort to be used ascending or descending
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
SET NOCOUNT ON

--checks IF the user has a RIGHT to make the operation
DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
IF @return != 0
BEGIN
    RETURN 55555
END

IF OBJECT_ID('tempdb..#deletedOrganization') IS NOT NULL
    DROP TABLE #deletedOrganization

CREATE TABLE #deletedOrganization(actorId BIGINT, organizationName NVARCHAR(200), rowNum INT, recordsTotal INT )

;WITH CTE AS
(
    SELECT o.actorId, o.organizationName,
    ROW_NUMBER() OVER(ORDER BY
        CASE WHEN @sortOrder = 'ASC' THEN
            CASE
            WHEN @sortBy = 'name' THEN organizationName
            END
        END,
        CASE WHEN @sortOrder = 'DESC' THEN
            CASE
            WHEN @sortBy = 'name' THEN organizationName
            END
        END DESC) rowNum,
            COUNT( * ) OVER(PARTITION BY 1) AS recordsTotal
    FROM [customer].[organization] o
    JOIN [customer].[organizationType] ot ON o.organizationTypeId = ot.organizationTypeId
    WHERE o.isDeleted = 1
        AND (@searchString IS NULL OR o.organizationName LIKE '%' + @searchString + '%' ) AND ot.organizationType = 'businessUnit'
)
INSERT INTO #DeletedOrganization(actorId, organizationName, rowNum, recordsTotal)
SELECT actorId, organizationName, rowNum, recordsTotal
FROM CTE
WHERE rowNum BETWEEN ((@pageNumber - 1) * @pageSize) + 1 AND @pageSize * (@pageNumber)

SELECT 'organization' AS resultSetName

SELECT actorId, organizationName
FROM #DeletedOrganization o
ORDER BY rowNum

SELECT 'pagination' AS resultSetName

SELECT TOP 1 @pageSize AS pageSize, recordsTotal AS recordsTotal, @pageNumber AS pageNumber, (recordsTotal - 1) / @pageSize + 1 AS pagesTotal
FROM #deletedOrganization

DROP TABLE #deletedOrganization
