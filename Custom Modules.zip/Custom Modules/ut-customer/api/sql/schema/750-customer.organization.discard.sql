ALTER PROCEDURE [customer].[organization.discard] -- supports the discard functionality, where the maker or sa discards all unapproved changes for the selected BU
    @actorId BIGINT, -- the id of the organization to be rejected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @statusId VARCHAR(20) = (SELECT statusId FROM [customer].[organizationUnapproved] WHERE actorId = @actorId)
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @callParams XML
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    --check if user has access to the organization
    IF NOT EXISTS(
        SELECT o.actorId
        FROM customer.organizationsVisibleForUnapproved(@userId) o
        JOIN [customer].[organization] org ON o.actorId = org.actorId
        WHERE org.actorId = @actorId)

    AND NOT EXISTS(
        SELECT o.actorId
        FROM customer.organizationsVisibleForUnapproved(@userId) o
        JOIN [customer].[organizationUnapproved] org ON o.actorId = org.actorId
        WHERE org.actorId = @actorId)
            RAISERROR('customer.securityViolation', 16, 1)

    IF @statusId IS NULL OR @statusId = 'new' OR @statusId = 'pending'
    BEGIN
        RAISERROR('customer.organizationInvalidStatus', 16, 1)
    END

    BEGIN TRANSACTION

        DELETE FROM [customer].[organizationUnapproved] WHERE actorId = @actorId
        DELETE FROM [core].[actorHierarchyUnapproved] WHERE [subject] = @actorId
        DELETE FROM [customer].[emailUnapproved] WHERE actorId = @actorId
        DELETE FROM [customer].[phoneUnapproved] WHERE actorId = @actorId
        DELETE FROM [customer].[addressUnapproved] WHERE actorId = @actorId

    COMMIT TRANSACTION

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
