ALTER PROCEDURE customer.[organization.getByDepth] -- this SP lists all organizations availble for user for predifined depth
    @key NVARCHAR(50) = 'KYCLevelForBranchesDepth', -- key in core configuration table to search the required depth value
    @organizationTypeList core.arrayList READONLY, -- type of organizations to fetch
    @meta core.metaDataTT READONLY -- information for the logged user
AS

    DECLARE @organizationTypeIds core.arrayNumberList
    DECLARE @userId BIGINT =
    (
        SELECT [auth.actorId]
        FROM @meta
    )
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
        BEGIN
            RETURN 55555
        END

    DECLARE @KYCLevelForBranchesDepth TINYINT =
    (
        SELECT [value]
        FROM core.[configuration]
        WHERE [key] = @key
    )

    IF @KYCLevelForBranchesDepth IS NULL
    BEGIN
        RAISERROR('customer.defaultKYCLevelForBranchesIsNotDefined', 16, 1);
        RETURN 55555
    END

    DECLARE @languageId BIGINT =
    (
        SELECT languageId
        FROM core.[language] AS cl
        JOIN [user].[session] AS us ON us.[language] = cl.iso2Code
        WHERE us.actorId = @userId
    )

    IF NOT EXISTS(SELECT * FROM @organizationTypeList)
        INSERT INTO @organizationTypeIds
        SELECT organizationTypeId
        FROM customer.organizationType
        WHERE organizationType = ('businessUnit')
    ELSE
        INSERT INTO @organizationTypeIds
        SELECT organizationTypeId
        FROM @organizationTypeList otl
        JOIN customer.organizationType ot ON ot.organizationType = otl.[value]

    SELECT 'organizations' AS resultSetName

    --;WITH orgs AS
    --(
    --     SELECT o.actorId, 1 AS depth
    --     FROM customer.organization AS o
    --     JOIN [customer].[organizationType] ot ON o.organizationTypeId = ot.organizationTypeId
    --     JOIN @organizationTypes ol ON ol.[value] = ot.organizationType
    --     LEFT JOIN core.actorHierarchy AS cur ON o.actorId = cur.[subject] AND [predicate] = 'memberOf'
    --     WHERE cur.[subject] IS NULL

    --     UNION ALL

    --     SELECT o.actorId, depth + 1
    --     FROM orgs AS par
    --     JOIN core.actorHierarchy AS ch ON ch.[object] = par.actorId AND [predicate] = 'memberOf'
    --     JOIN customer.organization AS o ON o.actorId = ch.[subject]
    --     JOIN [customer].[organizationType] ot ON o.organizationTypeId = ot.organizationTypeId
    --     JOIN @organizationTypes ol ON ol.[value] = ot.organizationType
    --     WHERE depth + 1 <= @KYCLevelForBranchesDepth
    --)

    SELECT actorId, organizationName
    FROM customer.organizationsVisibleFor(@userId) o
    JOIN @organizationTypeIds ol ON ol.[value] = o.organizationTypeId
    JOIN customer.organizationHierarchyFlat orf ON o.actorId = orf.object
    LEFT JOIN core.actorHierarchy ah ON ah.subject = orf.subject AND ah.predicate = 'memberOf'
    WHERE ah.object IS NULL AND relationDepth = @KYCLevelForBranchesDepth
