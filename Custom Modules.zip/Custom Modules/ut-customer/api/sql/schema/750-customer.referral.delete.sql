ALTER PROCEDURE [customer].[referral.delete]
    @referralId BIGINT,
    @meta core.metaDataTT READONLY
AS
BEGIN TRY
    DECLARE @callParams XML

    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    IF NOT EXISTS (
        SELECT * FROM [customer].[referral] r
        JOIN [customer].[referralStatus] rs ON r.referralStatusId = rs.referralStatusId
        JOIN [core].[itemName] ci ON rs.itemNameId = ci.itemNameId
        WHERE ci.itemCode IN ('referralNew', 'referralNewRejected')
        AND rs.referralStatusId = r.referralStatusId
        AND referralId = @referralId)
    BEGIN
        RAISERROR('customer.referralDeleteNotAllowed', 16, 1);
        RETURN
    END

    DELETE FROM [customer].[referral] WHERE referralId = @referralId

EXEC core.auditCall @procid = @@PROCID, @params = @callParams

END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
