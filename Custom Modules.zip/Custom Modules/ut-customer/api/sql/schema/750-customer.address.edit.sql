ALTER PROCEDURE [customer].[address.edit] -- edits address information
    @address customer.addressUnapprovedTT READONLY, -- the edited address information
    @actorId BIGINT, -- customer id
    @noResultSet BIT = 0, -- a flag to show IF result IS expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @result customer.addressUnapprovedTT

BEGIN TRY
    DECLARE @tranCounter INT = @@TRANCOUNT;
    IF @tranCounter = 0
        BEGIN TRANSACTION

            DELETE p
            FROM customer.address p
            LEFT JOIN @address pp ON p.addressId = pp.addressId
            WHERE p.actorId = @actorId AND pp.addressId IS NULL

            UPDATE t
            SET t.value = s.value,
                t.addressTypeId = s.addressTypeId,
                t.statusId = s.statusId,
                t.city = s.city,
                t.lat = s.lat,
                t.lng = s.lng,
                t.addressZone1 = s.addressZone1,
                t.addressZone2 = s.addressZone2,
                t.addressZone3 = s.addressZone3,
                t.addressZone4 = s.addressZone4
            OUTPUT INSERTED.addressId, INSERTED.actorId, INSERTED.value, INSERTED.addressTypeId, INSERTED.statusId, INSERTED.city, INSERTED.lat, INSERTED.lng, INSERTED.addressZone1, INSERTED.addressZone2, INSERTED.addressZone3, INSERTED.addressZone4
            INTO @result (addressId, actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
            FROM customer.address t
            INNER JOIN @address s ON t.addressId = s.addressId

            INSERT INTO customer.address (actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
            OUTPUT INSERTED.addressId, INSERTED.actorId, INSERTED.value, INSERTED.addressTypeId, INSERTED.statusId, INSERTED.city, INSERTED.lat, INSERTED.lng, INSERTED.addressZone1, INSERTED.addressZone2, INSERTED.addressZone3, INSERTED.addressZone4
            INTO @result (addressId, actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
            SELECT actorId, value, ISNULL(addressTypeId, 'home'), ISNULL(a.statusId, 'active'), city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
            FROM @address a
            WHERE a.addressId IS NULL

            IF @tranCounter = 0
        COMMIT TRANSACTION

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'address' AS resultSetName
        SELECT addressId, actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
