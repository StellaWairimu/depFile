ALTER PROCEDURE customer.[person.rollbackMS] -- delete a newly created customer
    @actorsId [core].[arrayNumberList] READONLY -- customer for delete
AS
DECLARE @callParams XML

BEGIN TRY

    DELETE p
    FROM customer.person p
    JOIN @actorsId a ON A.value = p.actorId

    DELETE e
    FROM customer.email e
    JOIN @actorsId a ON A.value = e.actorId

    DELETE ph
    FROM customer.phone ph
    JOIN @actorsId a ON A.value = ph.actorId

    DELETE ad
    FROM customer.address ad
    JOIN @actorsId a ON a.value = ad.actorId

    DELETE c
    FROM customer.customer c
    JOIN @actorsId a ON A.value = c.actorId

    EXEC core.auditCall @procid = @@procId, @params = @callParams
END TRY
BEGIN CATCH
    IF @@tranCount > 0
        ROLLBACK TRANSACTION;
    EXEC core.error
END CATCH;
