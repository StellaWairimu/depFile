ALTER PROCEDURE [customer].[phone.get]
    --  @phoneId INT = NULL,
    @actorId BIGINT = NULL,
    @meta core.metaDataTT READONLY
AS
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    -------error

    IF @actorId IS NULL --AND @phoneId IS NULL
        RAISERROR('customer.notGivenParameters', 16, 1)

    ------------------ EXISTING PHONE
    IF EXISTS (SELECT actorId FROM customer.phone WHERE actorId = @actorId) --AND ISNULL(@phoneId, phoneId) = phoneId)
    BEGIN
        ------------------ EXISTING EDITED PHONE - RETURN resultSets - approved + unapproved
        IF EXISTS (SELECT actorId FROM customer.phoneUnapproved WHERE actorId = @actorId) --AND ISNULL(@phoneId, phoneId) = phoneId)
        BEGIN
            SELECT 'customerPhoneUnapproved' AS resultSetName

            SELECT p.*, mno.ut5Key AS mnoKey, mno.name AS mnoName
            FROM [customer].[phoneUnapproved] p
            LEFT JOIN customer.mno mno ON mno.mnoId = p.mnoId
            WHERE actorId = @actorId --AND ISNULL(@phoneId, phoneId) = phoneId

        END

        SELECT 'customerPhone' AS resultSetName

        SELECT p.*, mno.ut5Key AS mnoKey, mno.name AS mnoName
        FROM [customer].[phone] p
        LEFT JOIN customer.mno mno ON mno.mnoId = p.mnoId
        WHERE actorId = @actorId --AND ISNULL(@phoneId, phoneId) = phoneId

    END
    ELSE
        BEGIN
            ---------------------- NEW PHONE
            SELECT 'customerPhone' AS resultSetName

            SELECT p.*, mno.ut5Key AS mnoKey, mno.name AS mnoName
            FROM [customer].[phoneUnapproved] p
            LEFT JOIN customer.mno mno ON mno.mnoId = p.mnoId
            WHERE actorId = @actorId --AND ISNULL(@phoneId, phoneId) = phoneId

        END

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    EXEC [core].[error]
END CATCH
