CREATE FUNCTION [customer].[kycAttributeType] -- returns all KYC attributes for specifuc customer type
(
    @customerType INT -- the customer type
)
RETURNS TABLE AS
RETURN

SELECT *
FROM (
    SELECT itemNameId, CASE WHEN alias = 'kycAttributesCorporate' THEN 'corporate' ELSE 'individual' END AS customerType
    FROM core.itemName imn
    JOIN core.itemType imt ON imt.itemTypeId = imn.itemtypeId
    WHERE alias IN ('kycAttributesIndividual', 'kycAttributesCorporate')) a
    JOIN [customer].[customerType] ct ON ct.customerTYpeId = a.customerType
WHERE customerTypeNumber = @customerType
