CREATE TABLE customer.[addressUnapproved]( -- table that stores all unapproved customer addresses
    addressUnapprovedId BIGINT IDENTITY(1, 1) NOT NULL, -- the id of the addressUnapproved
    addressId INT NULL, -- the id of the address
    actorId BIGINT NOT NULL, -- the id of the actor, who the address belongs to
    value NVARCHAR (200) NOT NULL, -- the value of the address, incl. city, street, etc.
    frontEndRecordId VARCHAR (10), -- an id, needed for the frontend of the mobile app
    addressTypeId VARCHAR (20) NOT NULL, -- the addressTypeId, e.g. home, work
    statusId VARCHAR (20) NOT NULL, -- the statusId of the address, e.g. active/inactive
    oldValues XML NULL, -- history of old values of customer addresses
    city NVARCHAR(100), -- the city
    [isDeleted] BIT NOT NULL, -- a flag to show if the address will be deleted or inserted/edited
    [updatedBy] BIGINT NOT NULL, -- the id of the user updating the address
    [updatedOn] DATETIMEOFFSET(7) NOT NULL, -- the datetime the address is updated on
    lat VARCHAR(50) NULL, -- the latitude of the respective address
    lng VARCHAR(50) NULL, -- the longitude of the respective address
    addressZone1 BIGINT NULL,
    addressZone2 BIGINT NULL,
    addressZone3 BIGINT NULL,
    addressZone4 BIGINT NULL,
    CONSTRAINT pkCustomerAddressUnapproved PRIMARY KEY CLUSTERED(addressUnapprovedId ASC),
    CONSTRAINT fkCustomerAddressUnapproved_coreActor FOREIGN KEY(actorId) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerAddressUnapproved_updatedByCoreActor FOREIGN KEY(updatedBy) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerAddressUnapproved_customerAddress FOREIGN KEY(addressId) REFERENCES [customer].[address] (addressId),
    CONSTRAINT fkCustomerAddressUnapproved_customerAddressType FOREIGN KEY(addressTypeId) REFERENCES customer.addressType (addressTypeId),
    CONSTRAINT fkCustomerAddressUnapproved_coreStatus FOREIGN KEY(statusId) REFERENCES core.status (statusId)
)
