ALTER PROCEDURE [customer].[externalSystemCredentials.check]
    @systemName VARCHAR(50),
    @meta core.metaDataTT READONLY
AS
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
DECLARE @externalSystemId INT = (SELECT externalSystemId FROM [core].externalSystem WHERE name = @systemName)

IF NOT EXISTS (
    SELECT * FROM [user].userToExternalUser uu
    JOIN [user].externalUser ue
    ON uu.externalUserId = ue.externalUserId
    WHERE uu.userId = @userId AND ue.externalSystemId = @externalSystemId)
BEGIN
    RAISERROR('user.externalSystemNotAllowedForThisUser', 16, 1)
END
