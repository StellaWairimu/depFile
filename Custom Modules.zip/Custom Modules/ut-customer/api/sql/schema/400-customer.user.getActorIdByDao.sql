ALTER PROCEDURE [customer].[user.getActorIdByDao] -- gets information FOR an organization
    @dao BIGINT, -- the id of the user
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation

    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    SELECT 'organizations' AS resultSetName

    SELECT TOP 1 b.actorId, b.frontEndRecordId, b.organizationName, b.code, b.executiveOfficer, b.tradeName, b.capital, b.currency, b.timeZone,
        b.primaryLanguageId, b.oldValues, b.isEnabled, b.isDeleted, b.cbsId, b.countryId, b.organizationTypeId, b.description
    FROM core.actorHierarchy AS h
        JOIN customer.organization AS o ON o.actorId = h.object
        JOIN customer.organization AS b ON b.code = @dao AND b.countryId = o.countryId
    WHERE h.subject = @userId AND h.predicate = 'memberOf'
