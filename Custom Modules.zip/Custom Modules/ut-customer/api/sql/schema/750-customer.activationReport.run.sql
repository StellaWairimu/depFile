ALTER PROCEDURE [customer].[activationReport.run] -- returns customer activation report, filtered BY provided parameters
    @customerNumber NVARCHAR(20), -- the customer number to filter BY, IF provided
    @dao NVARCHAR(10), -- the dao to filter BY, IF provided
    @from DATE, -- the start DATE to filter BY
    @to DATE, -- the END DATE to filter BY
    @tz VARCHAR(10), -- the time zone to switch to
    @pageSize INT = 20, -- how many rows will be returned per page
    @pageNumber INT = 1, -- which page number to display
    @orderBy core.orderByTT READONLY, -- field AND direction of sorting
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @sortBy VARCHAR(50) = (SELECT field FROM @orderBy), @sortOrder VARCHAR(4) = (SELECT dir FROM @orderBy)
DECLARE @startRow INT = (@pageNumber - 1) * @pageSize + 1
DECLARE @endRow INT = @startRow + @pageSize - 1
SET NOCOUNT ON
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @actorId BIGINT = (SELECT [auth.actorId] FROM @meta)
    DECLARE @languageId BIGINT = (
        SELECT languageId
        FROM [core].[language] cl
        JOIN [user].[session] us ON us.[language] = cl.[iso2Code]
        WHERE us.[actorId] = @actorId)
    DECLARE @actionTypeId INT = (SELECT itemTypeId FROM core.itemType WHERE name = 'actionType')
    DECLARE @actionNameId BIGINT = (SELECT itemNameId FROM core.itemName WHERE itemTypeId = @actionTypeId AND itemName = 'IDENTITY.register')

    DECLARE @start DATETIMEOFFSET(0) = TODATETIMEOFFSET(@from, '+00:00'), @end DATE = TODATETIMEOFFSET(DATEADD(d, 1, @to), '+00:00')

    CREATE TABLE #Report
        (customerNumber NVARCHAR(20), customerDAO NVARCHAR(10), firstName NVARCHAR(50), lastName NVARCHAR(50), phoneNumber VARCHAR(50),
        actionStatus VARCHAR(20), installationId NVARCHAR(200), activationDateTime DATETIMEOFFSET(0), activationDate VARCHAR(10),
        activationHour VARCHAR(10), recordsTotal INT, rowNum INT);

    WITH CTE AS
    (
        SELECT a.customerNumber, a.customerDAO, a.firstName, a.lastName, a.phoneNumber, CASE WHEN a.actionStatus = 'success' THEN 'yes' ELSE 'no' END AS actionStatus, installationId,
            SWITCHOFFSET(a.operationDate, @tz) AS activationDateTime, CONVERT(VARCHAR(10), CAST(SWITCHOFFSET(a.operationDate, @tz) AS DATE), 104) AS activationDate, CAST(CAST(SWITCHOFFSET(a.operationDate, @tz) AS TIME(0)) AS VARCHAR(10)) AS activationHour,
            ROW_NUMBER() OVER(ORDER BY
                CASE WHEN @sortOrder = 'ASC' THEN
                    CASE
                        WHEN @sortBy = 'customerNumber' THEN customerNumber
                        WHEN @sortBy = 'customerDAO' THEN customerDAO
                        WHEN @sortBy = 'firstName' THEN firstName
                        WHEN @sortBy = 'lastName' THEN lastName
                        WHEN @sortBy = 'phoneNumber' THEN phoneNumber
                        WHEN @sortBy = 'actionStatus' THEN actionStatus
                        WHEN @sortBy = 'installationId' THEN installationId
                        WHEN @sortBy = 'activationDate' THEN CONVERT(VARCHAR(50), SWITCHOFFSET(a.operationDate, @tz))
                    END
                END,
                CASE WHEN @sortOrder = 'DESC' THEN
                    CASE
                        WHEN @sortBy = 'customerNumber' THEN customerNumber
                        WHEN @sortBy = 'customerDAO' THEN customerDAO
                        WHEN @sortBy = 'firstName' THEN firstName
                        WHEN @sortBy = 'lastName' THEN lastName
                        WHEN @sortBy = 'phoneNumber' THEN phoneNumber
                        WHEN @sortBy = 'actionStatus' THEN actionStatus
                        WHEN @sortBy = 'installationId' THEN installationId
                        WHEN @sortBy = 'activationDate' THEN CONVERT(VARCHAR(50), SWITCHOFFSET(a.operationDate, @tz))
                    END
                END DESC) rowNum,
            COUNT( * ) OVER(PARTITION BY 1) AS recordsTotal
        FROM [customer].[activityReport] a
        WHERE a.operationDate >= @start AND a.operationDate < @end
            AND (@dao IS NULL OR a.customerDAO = @dao)
            AND (@customerNumber IS NULL OR customerNumber = @customerNumber)
            AND a.itemNameId = @actionNameId
    )

    INSERT INTO #Report(customerNumber, customerDAO, firstName, lastName, phoneNumber, actionStatus, installationId, activationDateTime, activationDate, activationHour, recordsTotal, rowNum)
    SELECT customerNumber, customerDAO, firstName, lastName, phoneNumber, actionStatus, installationId, activationDateTime, activationDate, activationHour, recordsTotal, rowNum
    FROM CTE
    WHERE rowNum BETWEEN @startRow AND @endRow

    SELECT 'customerActivityReport' AS resultSetName

    SELECT customerNumber, customerDAO, firstName, lastName, phoneNumber, actionStatus, installationId, activationDateTime, activationDate, activationHour
    FROM #Report
    ORDER BY rowNum

    SELECT 'pagination' AS resultSetName

    SELECT TOP 1 @pageSize AS pageSize, recordsTotal AS recordsTotal, @pageNumber AS pageNumber, (recordsTotal - 1) / @pageSize + 1 AS pagesTotal
    FROM #Report

    DROP TABLE #Report

END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
