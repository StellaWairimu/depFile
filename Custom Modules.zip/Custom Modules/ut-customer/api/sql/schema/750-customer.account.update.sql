ALTER PROCEDURE [customer].[account.update]
    @account customer.accountTT READONLY,
    @noResultSet BIT = 0,
    @meta core.metaDataTT READONLY
AS
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
    DECLARE @result customer.accountTT
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    UPDATE
        TARGET
    SET
        TARGET.actorId = ISNULL(SOURCE.actorId, TARGET.actorId),
        TARGET.accountTypeId = ISNULL(SOURCE.accountTypeId, TARGET.accountTypeId),
        TARGET.accountName = ISNULL(SOURCE.accountName, TARGET.accountName),
        TARGET.statusId = ISNULL(SOURCE.statusId, TARGET.statusId)
    OUTPUT
        INSERTED.* INTO @result
    FROM
        customer.account TARGET
    INNER JOIN
        @account SOURCE
    ON
        TARGET.accountId = SOURCE.accountId

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'account' AS resultSetName
        SELECT * FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
