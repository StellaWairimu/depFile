ALTER PROCEDURE [customer].[account.add]
    @account customer.accountTT READONLY,
    @noResultSet BIT = 0,
    @meta core.metaDataTT READONLY
AS
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
    DECLARE @result customer.accountTT
    SET @noResultSet = ISNULL(@noResultSet, 0)
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    INSERT INTO
        [customer].[account] (actorId, accountTypeId, accountNumber, accountName, statusId, currencyId, balance, accountOpenedOn)
    OUTPUT
        INSERTED.* INTO @result
    SELECT
        actorId, accountTypeId, accountNumber, accountName, ISNULL(statusId, 'active'), currencyId, balance, GETDATE() FROM @account

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'account' AS resultSetName
        SELECT * FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION;

    EXEC core.error
    RETURN 55555
END CATCH
