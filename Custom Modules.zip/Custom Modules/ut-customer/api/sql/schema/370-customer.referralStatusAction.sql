CREATE TABLE [customer].[referralStatusAction] -- in this table is put the configuration of the statuses and actions, i.e. from which status with which action the object goes in the the next status
(
    fromStatusId TINYINT NOT NULL, --the status in which the object is currently
    actionId TINYINT NOT NULL, --what action can be performed
    toStatusId TINYINT NOT NULL, --in which status the object will be after the action is performed
    permission VARCHAR(100), -- which SP is called or some "dummy" permission in order to check what actions can perform the logged user
    CONSTRAINT [pkreferralStatusAction] PRIMARY KEY CLUSTERED (fromStatusId, actionId, toStatusId),
    CONSTRAINT fkreferralStatusAction_actionId FOREIGN KEY(actionId) REFERENCES [customer].[referralAction] (referralActionId),
    CONSTRAINT fkreferralStatusAction_fromStatusId FOREIGN KEY(fromStatusId) REFERENCES [customer].[referralStatus] (referralStatusId),
    CONSTRAINT fkreferralStatusAction_toStatusId FOREIGN KEY(toStatusId) REFERENCES [customer].[referralStatus] (referralStatusId)
)
