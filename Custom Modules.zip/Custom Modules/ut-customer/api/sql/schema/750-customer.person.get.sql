ALTER PROCEDURE [customer].[person.get]
    @actorId BIGINT = NULL,
    @meta core.metaDataTT READONLY
AS
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    -------error

    IF @actorId IS NULL
        RAISERROR('customer.notGivenParameters', 16, 1)

    ------------------ EXISTING person
    IF EXISTS (SELECT actorId FROM customer.person WHERE actorId = @actorId)
    BEGIN
    ------------------ EXISTING EDITED person - RETURN resultSets - approved + unapproved
        IF EXISTS (SELECT actorId FROM customer.personUnapproved WHERE actorId = @actorId)
        BEGIN
            SELECT 'unapprovedperson' AS resultSetName, 1 AS single

            SELECT personUnapprovedId, actorId, frontEndRecordId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, udf, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, updatedBy, updatedOn, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers
            FROM [customer].[personUnapproved] p
            WHERE actorId = @actorId

        END

        SELECT 'person' AS resultSetName, 1 AS single

        SELECT NULL AS personUnapprovedId, actorId, frontEndRecordId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, udf, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, NULL AS updatedBy, NULL AS updatedOn, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers
        FROM [customer].[person] p
        WHERE actorId = @actorId

    END
    ELSE
        BEGIN
        ------------------------ NEW person
            SELECT 'person' AS resultSetName, 1 AS single

            SELECT personUnapprovedId, actorId, frontEndRecordId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, udf, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, updatedBy, updatedOn, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers
            FROM [customer].[personUnapproved] p
            WHERE actorId = @actorId
        END

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    EXEC [core].[error]
END CATCH
