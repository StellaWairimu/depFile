ALTER PROCEDURE [customer].[activityReport.add]
    @activity customer.activityReportTT READONLY,
    @meta core.metaDataTT READONLY
AS
SET NOCOUNT ON
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @actorId BIGINT = (SELECT [auth.actorId] FROM @meta)
    DECLARE @activityTT customer.activityReportTT
    DECLARE @actionTypeId INT = (SELECT itemTypeId FROM core.itemType WHERE name = 'actionType')

    INSERT INTO @activityTT
    SELECT * FROM @activity

    UPDATE @activityTT
    SET actorId = @actorId

    INSERT INTO customer.activityReport(actorId, customerNumber, customerDAO, firstName, lastName, phoneNumber, installationId, [action], actionStatus, operationDate, channel, itemNameId)
    SELECT a.actorId, c.customerNumber, o.code, p.firstName, p.lastName, ph.phoneNumber,
    CASE WHEN h.identifier IS NULL
        THEN a.installationId
        ELSE h.identifier
    END,
    a.[action], a.actionStatus, SWITCHOFFSET(a.operationDate, '+00:00'), a.channel, i.itemNameId
    FROM @activityTT a
    JOIN core.itemName i ON a.[action] = i.itemName AND i.itemTypeId = @actionTypeId
    LEFT JOIN [user].[hash] h ON h.actorId = a.actorId AND [type] = 'password'
    LEFT JOIN customer.customer c ON a.actorId = c.actorId
    LEFT JOIN customer.organization o ON o.actorId = c.organizationId
    LEFT JOIN customer.person p ON p.actorId = a.actorId
    LEFT JOIN customer.phone ph ON ph.actorId = a.actorId AND ph.statusId = 'approved' AND ph.isPrimary = 1
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
