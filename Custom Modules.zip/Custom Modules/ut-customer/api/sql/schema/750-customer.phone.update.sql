ALTER PROCEDURE customer.[phone.update] -- update changed phone data in customer.phone table
    @phone customer.phoneTTU READONLY, -- in this parameter the stored procedure receives all changed fields for phones
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
    DECLARE @result customer.phoneTT

    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    DECLARE @phoneXML TABLE (phoneId BIGINT, oldXmlValues XML, newXml XML, resultXml XML)
    INSERT INTO @phoneXML(phoneId, oldXmlValues, newXml)
    SELECT
        phoneId,
        (SELECT * FROM customer.phone WHERE phoneId = p.phoneId FOR XML PATH('oldUdf') , TYPE, ELEMENTS XSINIL),
        (SELECT * FROM @phone pIn WHERE pIn.phoneId = p.phoneId FOR XML PATH('udf'))
    FROM @phone p
    WHERE p.phoneId IS NOT NULL

    UPDATE @phoneXML
    SET resultXml = core.mergeXML(oldXmlValues, @userId, newXML)

    UPDATE p
    SET p.actorId = CASE WHEN ptt.actorIdUpdated = 1 THEN ptt.actorId ELSE p.actorId END,
        p.phoneTypeId = CASE WHEN ptt.phoneTypeIdUpdated = 1 THEN ptt.phoneTypeId ELSE p.phoneTypeId END,
        p.phoneNumber = CASE WHEN ptt.phoneNumberUpdated = 1 THEN ptt.phoneNumber ELSE p.phoneNumber END,
        p.statusId = CASE WHEN ptt.statusIdUpdated = 1 THEN ptt.statusId ELSE p.statusId END,
        p.oldValues = resultXml,
        p.mnoId = CASE WHEN ptt.mnoIdUpdated = 1 THEN ptt.mnoId ELSE p.mnoId END,
        p.isPrimary = CASE WHEN ptt.isPrimaryUpdated = 1 THEN ptt.isPrimary ELSE p.isPrimary END
        --p.updatedOn = SYSDATETIMEOFFSET(),
        --p.updatedBy = (SELECT [auth.actorId] FROM @meta )
    OUTPUT INSERTED.* INTO @result
    FROM customer.phone p
    JOIN @phone ptt ON ptt.phoneId = p.phoneId
    JOIN @phoneXML phXml ON phXml.phoneId = p.phoneId


    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'phone' AS resultSetName
        SELECT * FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
