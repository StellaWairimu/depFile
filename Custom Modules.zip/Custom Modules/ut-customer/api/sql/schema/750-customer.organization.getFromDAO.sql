ALTER PROCEDURE [customer].[organization.getFromDAO] -- gets information for an organization
    @dao NVARCHAR(50) = NULL, -- the dao of the organization
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation

    -- checks if the user has a right to make the operation
    -- DECLARE @actionID VARCHAR(100) =  OBJECT_SCHEMA_NAME(@@PROCID) + '.' +  OBJECT_NAME(@@PROCID), @return INT = 0
    -- EXEC @return = [user].[permission.check] @actionId =  @actionID, @objectId = NULL, @meta = @meta
    -- IF @return != 0
    -- BEGIN
    --     RETURN 55555
    -- END
    IF OBJECT_ID('tempdb..#organizationsVisibleFor') IS NOT NULL
    DROP TABLE #organizationsVisibleFor

    SELECT * INTO #organizationsVisibleFor FROM [customer].[organizationsVisibleFor](@userId)

    SELECT 'organization' AS resultSetName
    SELECT cbsId, o.countryId, o.actorId AS organizationId
    FROM #organizationsVisibleFor AS u
        JOIN [customer].[organization] AS o ON o.actorId = u.actorId AND code = @dao
