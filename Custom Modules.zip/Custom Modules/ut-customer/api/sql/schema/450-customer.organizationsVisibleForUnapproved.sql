ALTER FUNCTION [customer].[organizationsVisibleForUnapproved]
(
    @actor BIGINT
)
RETURNS TABLE AS
RETURN

WITH approved AS
(
    SELECT DISTINCT o.actorId AS actorId
    FROM [core].[actorHierarchy] h
    INNER JOIN [customer].[organizationHierarchyFlat] hf ON hf.[subject] = h.[object]
    INNER JOIN [customer].[organization] o ON o.actorId = hf.[object] AND o.isDeleted = 0
    WHERE h.[subject] = @actor AND h.[predicate] = 'memberOf'
)
, unApproved AS
(
    SELECT DISTINCT ou.actorId
    FROM approved a
    JOIN core.actorHierarchyUnapproved h ON h.object = a.actorId AND predicate = 'memberOf'
    JOIN customer.organizationUnapproved ou ON h.subject = ou.actorId
    LEFT JOIN customer.organization o ON o.actorId = ou.actorId
    WHERE o.actorId IS NULL AND h.isDeleted = 0
)

SELECT a.actorId
FROM approved a

UNION ALL

SELECT u.actorId
FROM unApproved u
