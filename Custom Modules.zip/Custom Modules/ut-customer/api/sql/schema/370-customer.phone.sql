CREATE TABLE customer.phone( -- table that stores all customer phone numbers
    phoneId INT IDENTITY(1000, 1) NOT NULL, -- the id of the phone
    actorId BIGINT NOT NULL, -- the id of the actor, who the phone belongs to
    frontEndRecordId VARCHAR(10), -- an id, needed for the frontend of the mobile app
    phoneTypeId VARCHAR (20) NOT NULL, -- the phoneTypeId, e.g. home, work
    phoneNumber VARCHAR(50) NOT NULL, -- the customer phone number, without country prefix
    statusId VARCHAR (20) NOT NULL, -- the statusId of the phone, e.g. active/inactive
    oldValues XML NULL, -- history of old values of customer phones
    udf XML, -- user defined fields
    mnoId TINYINT, -- the Mobile Network Operator
    isPrimary BIT NOT NULL DEFAULT(0), -- a flag to show if the phone is used for otpSend, if OTP access policy is assigned
    CONSTRAINT pkCustomerPhone PRIMARY KEY CLUSTERED(phoneId ASC),
    CONSTRAINT fkCustomerPhone_coreActor FOREIGN KEY(actorId) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerPhone_customerPhoneType FOREIGN KEY(phoneTypeId) REFERENCES customer.phoneType (phoneTypeId),
    CONSTRAINT fkCustomerPhone_coreStatus FOREIGN KEY(statusId) REFERENCES core.[status] (statusId),
    CONSTRAINT fkCustomerPhone_customerMNO FOREIGN KEY(mnoId) REFERENCES customer.mno(mnoId)
)
