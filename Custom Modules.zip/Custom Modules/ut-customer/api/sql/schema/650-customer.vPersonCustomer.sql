CREATE VIEW [customer].vPersonCustomer
AS
    SELECT
        p.firstName,
        p.lastName,
        p.nationalId,
        c.customerNumber,
        ph.phoneNumber,
        ca.value [address],
        da.[filename] photo
    FROM
        core.actor a
    JOIN
        customer.person p ON a.actorId = p.actorId
    JOIN
        customer.customer c ON p.actorId = c.actorId
    LEFT JOIN
        customer.phone ph ON c.actorId = ph.actorId
    LEFT JOIN
        customer.[address] ca ON ph.actorId = ca.actorId
    LEFT JOIN
        document.actorDocument ad ON ca.actorId = ad.actorId
    LEFT JOIN
        document.[attachment] da ON ad.documentId = da.documentId
    LEFT JOIN
        document.document dd ON da.documentId = dd.documentId
    WHERE
        a.actorType = 'person'
    AND
        ph.phoneTypeId IS NULL OR ph.phoneTypeId = 'home'
    AND
        ca.addressTypeId IS NULL OR ca.addressTypeId = 'home'
    AND
        da.attachmentSizeId IS NULL OR da.attachmentSizeId = 'small'
    AND
        dd.documentTypeId IS NULL OR dd.documentTypeId = 'profile'
