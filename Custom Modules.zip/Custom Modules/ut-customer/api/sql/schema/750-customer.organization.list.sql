ALTER PROCEDURE [customer].[organization.list] -- lists all organizations
    @organizationTypeList core.arrayList READONLY, -- type of organizations to fetch
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
-- checks if the user has a right to make the operation
DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
IF @return != 0
BEGIN
    RETURN 55555
END

DECLARE @organizationTypeIds core.arrayNumberList
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)

IF NOT EXISTS(SELECT * FROM @organizationTypeList)
    INSERT INTO @organizationTypeIds
    SELECT organizationTypeId
    FROM customer.organizationType
    WHERE organizationType = ('businessUnit')
ELSE
    INSERT INTO @organizationTypeIds
    SELECT organizationTypeId
    FROM @organizationTypeList otl
    JOIN customer.organizationType ot ON ot.organizationType = otl.[value]

SELECT 'allBranches' AS resultSetName

SELECT o.actorId, o.organizationName
FROM customer.organizationsVisibleFor(@userId) o
JOIN @organizationTypeIds ot ON ot.[value] = o.organizationTypeId
