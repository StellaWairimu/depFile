CREATE TABLE [customer].[education]( --table that stores education of the person
    [educationId] TINYINT IDENTITY(1, 1) NOT NULL, -- industry id
    [itemNameId] BIGINT NULL,
    CONSTRAINT pkCustomerEsducation PRIMARY KEY CLUSTERED(educationId ASC),
    CONSTRAINT [fkCustomerEducation_itemNameId] FOREIGN KEY(itemNameId) REFERENCES [core].[itemName] (itemNameId)
)
