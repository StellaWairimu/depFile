ALTER PROCEDURE [customer].[referral.add] -- create new referral in customer.referral table
    @referral [customer].[referralTT] READONLY, -- in this parameter the stored procedure receives all fields of referral
    @channel VARCHAR(25) = 'web', -- channel to decide the referral status
    @noResultSet BIT = 0, -- this is the flag about the waited result
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
BEGIN TRY

    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user creating the role
    DECLARE @MSISDN VARCHAR(50) = (SELECT MSISDN FROM @referral), @referralDate DATETIME2(0) = NULL
    DECLARE @referralStatusId TINYINT = (
        CASE WHEN @channel = 'mobile' THEN (
            SELECT referralStatusId FROM [customer].[referralStatus] rs
            JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
            WHERE ci.itemCode = 'referralOpen')
        ELSE (
            SELECT referralStatusId FROM [customer].[referralStatus] rs
            JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
            WHERE ci.itemCode = 'referralNew')
        END)
    DECLARE @referralSource BIGINT = (SELECT referralSource FROM @referral)
    DECLARE @openReferralLimitationId INT = (SELECT value FROM core.configuration WHERE [key] = 'openReferralLimitation')
    DECLARE @referralCount TINYINT = (SELECT COUNT(*) FROM customer.referral r
        INNER JOIN customer.referralStatus rs ON r.referralStatusId = rs.referralstatusId
        INNER JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
        WHERE r.referralSource = @referralSource
        AND ci.itemCode NOT IN ('referralDeactivated', 'referralExpired'))
    DECLARE @referralId BIGINT
    DECLARE @auditId BIGINT

    -- checks if the user has a right to make the operation
    IF (@channel != 'mobile')
        BEGIN
            DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
            EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

            IF @return != 0
            BEGIN
                RETURN 55555
            END
        END
    ELSE
        SET @referralDate = GETDATE()


    IF EXISTS (SELECT MSISDN FROM [customer].[referral] r
        INNER JOIN customer.referralStatus rs ON r.referralStatusId = rs.referralstatusId
        INNER JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
        WHERE ci.itemCode NOT IN ('referralDeactivated', 'referralExpired')
        AND r.MSISDN = @MSISDN)
        BEGIN
            RAISERROR('customer.referralMsisdnExists', 16, 1);
            RETURN
        END
    IF EXISTS (SELECT phoneNumber FROM [customer].[phone] cp WHERE cp.phoneNumber = @MSISDN)
        BEGIN
            RAISERROR('customer.customerMsisdnExists', 16, 1);
            RETURN
        END

    IF (@referralCount >= @openReferralLimitationId)
        BEGIN
            RAISERROR('customer.referralLimitExceeded', 16, 1);
        END

        INSERT INTO [customer].[referral](referralSource, referralTarget, MSISDN, referralDate, referralStatusId, createdBy, createdOn, updatedBy, updatedOn)
        SELECT referralSource, referralTarget, MSISDN, @referralDate, @referralStatusId, @userId, GETDATE(), @userId, GETDATE()
        FROM @referral

        SET @referralId = SCOPE_IDENTITY()


    EXEC [customer].[referral.get] @referralId, @meta

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams

END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
