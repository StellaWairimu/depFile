ALTER PROCEDURE [customer].[user.getDao] -- gets information for an organization
    @actorId BIGINT, -- the id of the user
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation

    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    SELECT 'organizations' AS resultSetName

    SELECT org.actorId, org.frontEndRecordId, org.organizationName, org.code, org.executiveOfficer, org.tradeName, org.capital, org.currency, org.timeZone,
        org.primaryLanguageId, org.oldValues, org.isEnabled, org.isDeleted, org.cbsId, org.countryId, org.organizationTypeId, org.description, cbs.ut5Key AS cbsPort
    FROM [user].parentOrganizationsForUser(@actorId) co
    JOIN customer.organization org ON org.actorId = co.actorId
    JOIN core.cbs AS cbs ON cbs.cbsId = org.cbsId
    WHERE code IS NOT NULL
    ORDER BY depth
