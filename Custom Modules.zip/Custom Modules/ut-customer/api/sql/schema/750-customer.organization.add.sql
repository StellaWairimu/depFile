ALTER PROCEDURE [customer].[organization.add] -- adds a new organization
    @organization customer.organizationTT READONLY, -- the organization fields
    @roles core.arrayNumberList READONLY, -- the roles which this organization has
    @parent core.arrayNumberList READONLY, -- the Ids of the parent organizations
    -----------------------------------
    @email customer.emailTT READONLY, -- information about the e-mails of the organization
    @phone customer.phoneTT READONLY, -- information about the phone numbers of the organization
    @address customer.addressTT READONLY, -- information about the addresses of the organization
    -----------------------------------
    @noResultSet BIT = 0, -- flag, show whether to return the inserted data
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE
    @organizationTT customer.organizationTT,
    @actorHierarchyTT core.actorHierarchyTT,
    @emailTT customer.emailTT,
    @phoneTT customer.phoneTT,
    @addressTT customer.addressTT,
    @actorId BIGINT,
    @emptyList core.ArrayNumberList

SET @noResultSet = ISNULL(@noResultSet, 0)
BEGIN TRY
-- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    IF ((SELECT COUNT(1) FROM @organization) <> 1)
    BEGIN
        RAISERROR('customer.organizationDataNotSingle', 16, 1);
    END

--checks IF among @parents there are related units IN the hierarchy graph
    IF EXISTS(
        SELECT g.actorId FROM @parent p
        CROSS APPLY core.actorGraph(p.[value], 'memberOf', 'object') g
        JOIN @parent pp ON g.actorId = pp.[value]
        WHERE g.[level] <> 0)
        RAISERROR('customer.recursion', 16, 1)

--checks IF among parents there are disabled or deleted organizations
    IF EXISTS(
        SELECT * FROM @parent p
        LEFT JOIN customer.organization o ON p.value = o.actorId AND o.isEnabled = 1 AND o.isDeleted = 0
        WHERE o.actorId IS NULL)
    RAISERROR('customer.disabledOrDeletedOrganization', 16, 1)

    IF EXISTS(
    SELECT p.value
    FROM @parent p
    LEFT JOIN customer.organizationsVisibleFor(@userId) o ON o.actorId = p.value
    WHERE o.actorId IS NULL)
        RAISERROR('customer.securityViolation', 16, 1)

    INSERT INTO @organizationTT SELECT * FROM @organization
    INSERT INTO @emailTT SELECT * FROM @email
    INSERT INTO @phoneTT SELECT * FROM @phone
    INSERT INTO @addressTT SELECT * FROM @address

    BEGIN TRANSACTION;

        EXEC [core].[actor.add]
            @actorType = 'organization',
            @actorId = @actorId OUT,
            @meta = @meta

        UPDATE @organizationTT SET actorId = @actorId
        UPDATE @emailTT SET actorId = @actorId
        UPDATE @phoneTT SET actorId = @actorId
        UPDATE @addressTT SET actorId = @actorId

        INSERT INTO [customer].[organizationUnapproved](actorId, frontEndRecordId, organizationName, code, executiveOfficer, tradeName, capital, currency, timeZone, primaryLanguageId, oldValues, isEnabled, isDeleted, cbsId, countryId, updatedBy, updatedOn, statusId)
        SELECT actorId, frontEndRecordId, organizationName, code, executiveOfficer, tradeName, capital, currency, timeZone,
        primaryLanguageId, oldValues, 0, 0, cbsId, countryId, @userId, SYSDATETIMEOFFSET(), 'new'
        FROM @organizationTT

        INSERT INTO @actorHierarchyTT ([subject], predicate, [object])
        SELECT @actorId, 'memberOf', p.value
        FROM @parent p

        EXEC [core].[actorHierarchy.addUnapproved]
            @actorHierarchy = @actorHierarchyTT,
            @meta = @meta,
            @noResultSet = 1

        EXEC [user].[role.grantUnapproved]
            @actorId = @actorId,
            @granted = @roles,
            @revoked = @emptyList,
            @defaultRoleId = NULL,
            @meta = @meta

        EXEC [customer].[email.addUnapproved]
            @email = @emailTT,
            @meta = @meta,
            @noResultSet = 1

        EXEC [customer].[phone.addUnapproved]
            @phone = @phoneTT,
            @meta = @meta,
            @noResultSet = 1

        EXEC [customer].[address.addUnapproved]
            @address = @addressTT,
            @meta = @meta,
            @noResultSet = 1

    COMMIT TRANSACTION;

    IF(@noResultSet = 0)
        EXEC customer.[organization.get] @actorId = @actorId, @meta = @meta

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH;
