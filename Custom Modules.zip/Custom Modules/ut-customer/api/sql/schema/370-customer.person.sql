CREATE TABLE customer.person( -- table that stores information about all customers, that are persons
    actorId BIGINT NOT NULL, -- the id of the person
    frontEndRecordId VARCHAR (10), -- an id, needed for the frontend of the mobile app
    firstName NVARCHAR(100) NOT NULL, -- the first name of the person
    lastName NVARCHAR(100) NOT NULL, -- the last name of the person
    nationalId VARCHAR(50), -- the nationalId number of the person, which identifies the person IN their country
    dateOfBirth DATE NULL, -- the date of birth of the person
    placeOfBirth NVARCHAR(100) NULL, -- the place of birth of the person
    nationality NVARCHAR(100) NULL, -- the nationality of the person
    gender NVARCHAR(20) NULL, -- the gender of the person
    bioId BIGINT NULL, -- the bioId of the person, which refers to personal biometric data
    oldValues XML NULL, -- history of previous values of person information
    udf XML, -- user defined fields
    phoneModel NVARCHAR(100), -- the phone model of the person
    computerModel NVARCHAR(100), -- the computer model of the person
    isEnabled BIT NOT NULL DEFAULT(1), -- a flag to show if the person is enabled or locked
    isDeleted BIT NOT NULL DEFAULT(0), -- a flag to show if the person is deleted or active
    maritalStatusId TINYINT, -- marital status of the person
    age TINYINT,
    middleName NVARCHAR(50), -- the middle name of the person
    educationId TINYINT, --person education
    employmentId TINYINT, --employment relationship
    employmentDate DATE, --date of appointment of the person
    incomeRangeId TINYINT, --remuneration of the person
    employerName NVARCHAR(50), --name of employer
    employerCategoryId TINYINT, -- category of employer,
    familyMembers TINYINT, --Number of Family Members
    CONSTRAINT pkCustomerPerson PRIMARY KEY CLUSTERED(actorId ASC),
    CONSTRAINT fkCustomerPerson_customerMaritalStatus FOREIGN KEY(maritalStatusId) REFERENCES customer.maritalStatus (maritalStatusId),
    CONSTRAINT fkCustomerPerson_coreActor FOREIGN KEY(actorId) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerPerson_customerEducationid FOREIGN KEY(educationId) REFERENCES customer.education (educationId),
    CONSTRAINT fkCustomerPerson_customeremploymentId FOREIGN KEY(employmentId) REFERENCES customer.employment (employmentId),
    CONSTRAINT fkCustomerPerson_customerIncomeRangeId FOREIGN KEY(incomeRangeId) REFERENCES customer.incomeRange (incomeRangeId),
    CONSTRAINT fkCustomerPerson_customerEmployerCategoryId FOREIGN KEY(employerCategoryId) REFERENCES customer.employerCategory (employerCategoryId)
)
