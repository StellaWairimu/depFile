ALTER PROCEDURE customer.[email.addApproved] -- approve new emails in customer.email table
    @actorId BIGINT, -- customer id
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE @result customer.emailTT

    INSERT INTO customer.email (actorId, value, emailTypeId, statusId, isPrimary)
    OUTPUT INSERTED.emailId, INSERTED.actorId, INSERTED.value, INSERTED.emailTypeId, INSERTED.statusId, INSERTED.isPrimary
    INTO @result (emailId, actorId, value, emailTypeId, statusId, isPrimary)
    SELECT actorId, value, emailTypeId, ISNULL(statusId, 'active'), isPrimary
    FROM customer.emailUnapproved pu
    WHERE pu.emailId IS NULL AND pu.actorId = @actorId

    DELETE FROM customer.emailUnapproved WHERE actorId = @actorId

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'email' AS resultSetName
        SELECT emailId, actorId, value, emailTypeId, statusId, isPrimary
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
