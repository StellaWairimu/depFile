ALTER PROCEDURE customer.[file.updateState] -- update customer state and oldvalues = null in following tables: customer.phone, customer.person,customer.customer and customer.address
    @actorId BIGINT, -- in this parameter the stored procedure receives actorid of customer
    @stateId VARCHAR(20), -- in this parameter the stored procedure receives the new stateid of customer
    @description NVARCHAR(MAX), -- additional information related to changing the state. i.e. rejection reasons
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML

DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @tranCounter INT = @@TRANCOUNT, @Today DATETIMEOFFSET = SYSDATETIMEOFFSET()

BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    IF @stateId IN ( 'rejected', 'blocked', 'up_to_date' )
    BEGIN
        DECLARE @kyc SMALLINT = (SELECT kycId FROM customer.customer WHERE actorId = @actorId)
        --CHECK whether we have to increase the KYC level
        IF @stateId = 'up_to_date' AND @kyc < 3
        BEGIN
            --CHECK FOR kyc 1 first
            IF EXISTS (
                SELECT *
                FROM customer.person p
                JOIN customer.address a ON a.actorId = p.actorId
                JOIN document.actorDocument ad ON ad.actorId = p.actorId
                JOIN document.document d ON d.documentId = ad.documentId
                WHERE p.actorId = @actorId
                    AND firstName IS NOT NULL AND lastName IS NOT NULL AND placeOfBirth IS NOT NULL AND dateOfBirth IS NOT NULL
                    AND d.documentNumber IS NOT NULL AND d.expirationDate IS NOT NULL
            )
            BEGIN
                --CHECK whether kyc should be 2 or 3
                --CHECK FOR phone
                IF EXISTS (
                    SELECT *
                    FROM customer.phone p
                    WHERE p.actorId = @actorId AND phoneNumber IS NOT NULL
                )
                AND
                --CHECK FOR aatachment FOR proof of address
                EXISTS (
                    SELECT *
                    FROM document.attachment a
                    JOIN document.document d ON a.documentId = d.documentId
                    JOIN document.actorDocument ad ON ad.documentId = d.documentId
                    WHERE ad.actorId = @actorId AND d.documentTypeId = 'proof_of_address'
                )
                BEGIN
                    --CHECK FOR aatachment FOR signature, IF it has it will level 3
                    IF EXISTS(
                        SELECT *
                        FROM document.attachment a
                        JOIN document.document d ON a.documentId = d.documentId
                        JOIN document.actorDocument ad ON ad.documentId = d.documentId
                        WHERE ad.actorId = @actorId AND d.documentTypeId = 'signature'
                    )
                        SET @kyc = 3
                    ELSE
                        SET @kyc = 2
                END
                ELSE IF @kyc = 0
                    SET @kyc = 1
            END
        END

        IF @tranCounter = 0
            BEGIN TRANSACTION

                UPDATE customer.person
                SET oldValues = NULL
                WHERE actorId = @actorId

                UPDATE customer.phone
                SET oldValues = NULL
                WHERE actorId = @actorId

                UPDATE customer.[address]
                SET oldValues = NULL
                WHERE actorId = @actorId

                UPDATE d
                SET d.oldValues = NULL
                FROM document.actorDocument ad
                JOIN document.document d ON d.documentId = ad.documentId
                WHERE ad.actorId = @actorId

                UPDATE a
                SET a.oldValues = NULL
                FROM document.actorDocument ad
                JOIN document.attachment a ON a.documentId = ad.documentId
                WHERE ad.actorId = @actorId

                UPDATE customer.customer
                SET oldValues = NULL,
                    stateId = @stateId,
                    [updatedBy] = @userId,
                    updatedOn = @Today,
                    description = @description,
                    kycId = @kyc
                WHERE actorId = @actorId

                IF @TranCounter = 0
            COMMIT TRANSACTION;

        IF (ISNULL(@noResultSet, 0) = 0)
        BEGIN
            EXEC customer.[file.get]
                @actorId = @actorId,
                @meta = @meta
        END
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    EXEC [core].[error]
    RETURN 5555
END CATCH

