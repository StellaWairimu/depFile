CREATE TYPE [customer].[pagingTT] AS TABLE(
    [pageNumber] INT,
    [pageSize] INT
)
