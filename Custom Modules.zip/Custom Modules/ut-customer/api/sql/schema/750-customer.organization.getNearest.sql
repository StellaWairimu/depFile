ALTER PROCEDURE customer.[organization.getNearest] -- gets organizations nearest the given point using euclidean distance
    @lat DECIMAL, -- latitude
    @lon DECIMAL, -- longiture
    @count INT, -- count of organizations to return
    @root BIGINT, -- root organization, pass NULL for all
    @meta core.metaDataTT READONLY-- information for the user that makes the operation
AS
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta);
WITH nearest AS (
    SELECT
        ROW_NUMBER() OVER (ORDER BY SQUARE(a.lat - @lat) + SQUARE(a.lng - @lon) DESC) cnt,
        a.actorId,
        a.value,
        a.lat,
        a.lng
    FROM
        customer.organizationsVisibleFor(@userId) AS o
    JOIN
        customer.address a ON a.actorId = o.actorId
    WHERE
        (@root IS NULL OR o.actorId IN (SELECT actorId FROM customer.organizationsVisibleFor(@root))) AND
        ISNUMERIC(a.lat) = 1 AND
        ISNUMERIC(a.lng) = 1
)
SELECT
    n.actorId,
    o.organizationName,
    o.description,
    n.value [address],
    n.lat,
    n.lng
FROM
    nearest n
JOIN
    customer.organization o ON o.actorId = n.actorId
WHERE
    cnt <= @count
