ALTER PROCEDURE [customer].[kyc.fetchDeleted] -- List information for deleted kycs
    @customerTypeId INT, -- filter by customer type
    @businessUnitId INT, -- filter by business unit
    @pageSize INT = 25, -- how many rows will be returned per page
    @pageNumber INT = 1, -- which page number to display
    @sortBy VARCHAR(50) = 'display', -- on which column results to be sorted
    @sortOrder VARCHAR(4) = 'ASC', -- what kind of sort to be used ascending or descending
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
SET NOCOUNT ON

--checks IF the user has a RIGHT to make the operation
DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
IF @return != 0
BEGIN
    RETURN 55555
END
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
DECLARE @languageId BIGINT = ISNULL(
    (SELECT languageId
    FROM [core].[language] cl
    JOIN [user].[session] us ON us.[language] = cl.[iso2Code]
    WHERE us.[actorId] = @userId), (SELECT [languageId] FROM [core].[language] WHERE [name] = 'English')
    )

IF OBJECT_ID('tempdb..#deletedKyc') IS NOT NULL
    DROP TABLE #deletedKyc

CREATE TABLE #deletedKyc(
    [kycId] SMALLINT, [display] VARCHAR(50), [description] VARCHAR(100),
    organizationName NVARCHAR(100), customerType VARCHAR(100), rowNum INT, recordsTotal INT );

WITH CTE AS
(
    SELECT DISTINCT kycId, it.itemNameTranslation + ' deleted ' + CASE WHEN k.updatedOn IS NULL THEN ' ' ELSE (CONVERT(NVARCHAR(30), k.updatedOn, 109)) END AS display, k.[description],
        k.statusId, ct.[customerTypeId] AS customerType, organizationName,
        ROW_NUMBER() OVER (
            ORDER BY
                CASE WHEN @sortBy = 'display' AND @sortOrder = 'ASC' THEN it.itemNameTranslation END,
                CASE WHEN @sortBy = 'display' AND @sortOrder = 'DESC' THEN it.itemNameTranslation END DESC,
                CASE WHEN @sortOrder = 'ASC' AND @sortBy != 'display' THEN
                    CASE
                        WHEN @sortBy = 'description' THEN ct.[description]
                        WHEN @sortBy = 'customerType' THEN ct.customerTypeId
                    END
                END,
                CASE WHEN @sortOrder = 'DESC' AND @sortBy != 'display' THEN
                    CASE
                        WHEN @sortBy = 'description' THEN ct.[description]
                        WHEN @sortBy = 'customerType' THEN ct.customerTypeId
                    END
                END DESC) rowNum,
            COUNT(*) OVER(PARTITION BY 1) AS recordsTotal
    FROM [customer].[kyc] k
    JOIN [customer].[customerType] ct ON k.customerTypeId = ct.customerTypeNumber
    JOIN [customer].[organization] o ON k.organizationId = o.actorId
    JOIN core.itemTranslation it ON it.itemNameId = k.itemNameId AND it.languageId = @languageId
    JOIN core.itemName itn ON itn.itemNameId = it.itemNameId
    WHERE k.isDeleted = 1
        AND @businessUnitId = k.organizationId
        AND (@customerTypeId IS NULL OR @customerTypeId = k.customerTypeId)
)
INSERT INTO #deletedKyc(kycId, display, [description], customerType, organizationName, rowNum, recordsTotal)
SELECT kycId, display, [description], customerType, organizationName, rowNum, recordsTotal
FROM CTE
WHERE rowNum BETWEEN ((@pageNumber - 1) * @pageSize) + 1 AND @pageSize * (@pageNumber)

SELECT 'kyc' AS resultSetName

SELECT kycId, display, [description], customerType, organizationName
FROM #deletedKyc o
ORDER BY rowNum

SELECT 'pagination' AS resultSetName

SELECT TOP 1 @pageSize AS pageSize, recordsTotal AS recordsTotal, @pageNumber AS pageNumber, (recordsTotal - 1) / @pageSize + 1 AS pagesTotal
FROM #deletedKyc

DROP TABLE #deletedKyc
