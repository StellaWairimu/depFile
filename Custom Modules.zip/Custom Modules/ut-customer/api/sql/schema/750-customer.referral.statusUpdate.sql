ALTER PROCEDURE [customer].[referral.statusUpdate] -- to do status action
    @referralId BIGINT, -- id of the referral
    @actionName VARCHAR(100), -- name of the referral action to do
    @rejectReason VARCHAR(max),
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
BEGIN TRY
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)

    DECLARE @currentStatusId TINYINT

    SELECT @currentStatusId = referralStatusId
    FROM [customer].[referral] t
    WHERE referralId = @referralId

    IF @currentStatusId IS NULL
        RAISERROR('customer.referralNotFound', 16, 1);

    DECLARE @actionId VARCHAR(100), @toStatusId TINYINT

    SELECT @actionId = rsa.permission, @toStatusId = toStatusId
    FROM [customer].[referralStatusAction] rsa
    JOIN [customer].[referralAction] ra ON ra.referralActionId = rsa.actionId
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName AND rsa.fromStatusId = @currentStatusId


    DECLARE @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionId, @objectId = NULL, @meta = @meta
    IF @return != 0
        BEGIN
            RETURN 55555
        END

    IF @toStatusId IS NOT NULL
        BEGIN
            UPDATE t
            SET
                t.referralStatusId = @toStatusId,
                t.referralDate = (CASE WHEN @actionName = 'newReferralAprrove' THEN GETDATE() ELSE t.referralDate END),
                t.rejectReason = ISNULL(t.rejectReason, @rejectReason),
                t.updatedOn = GETDATE(),
                t.updatedBy = @userId
            FROM [customer].[referral] t
            WHERE referralId = @referralId
        END
    ELSE
        RAISERROR('customer.referralStatusInvalidAction', 16, 1);

END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
