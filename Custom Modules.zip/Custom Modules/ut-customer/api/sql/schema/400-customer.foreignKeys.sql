IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fkExternalSystem_Organization')
BEGIN
    ALTER TABLE core.externalSystem ADD CONSTRAINT [fkExternalSystem_Organization] FOREIGN KEY([organizationId]) REFERENCES [customer].[organization] ([actorId])
END
