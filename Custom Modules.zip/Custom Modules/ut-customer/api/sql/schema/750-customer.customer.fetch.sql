ALTER PROCEDURE [customer].[customer.fetch] -- fetch all customers with the requested parameters
    @statusList core.arrayList READONLY, -- list with the requested statuses
    @stateList [core].[arrayList] READONLY,
    @filterBy [customer].[filterByTT] READONLY, -- information for filters
    @orderBy [customer].[orderByTT] READONLY, -- information for ordering
    @paging [customer].[pagingTT] READONLY, --information for paging
    @cbsId VARCHAR(100) = NULL, --cbs id to filter by
    @nationalId VARCHAR(50) = NULL, --nationalId to filter by
    @meta core.metaDataTT READONLY-- information for the user that makes the operation

AS
SET NOCOUNT ON;
-- checks IF the user has а RIGHT to fetch customers
DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)

EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
IF @return != 0
BEGIN
    RETURN 55555
END

DECLARE @customerType NVARCHAR(100) = NULL
DECLARE
    @pageSize INT = 20, -- how many rows will be returned per page
    @pageNumber INT = 1, -- which page number to display
    @customerNumber NVARCHAR(100) = NULL, -- the customer number to filter by, if provided
    @firstName NVARCHAR(200) = NULL, -- the full name to filter by
    @lastName NVARCHAR(200) = NULL, -- the full name to filter by
    @phoneNumber VARCHAR(50) = NULL, -- the phone to filter by
    @sortBy VARCHAR(50) = 'firstName', -- on which column results to be sorted
    @sortOrder VARCHAR(4) = 'ASC' -- what kind of sort to be used ascending or descending


IF EXISTS (SELECT * FROM @filterBy)
BEGIN
    SELECT @customerNumber = customerNumber, @lastName = lastName, @firstName = firstName,
        @customerType = customerType, @phoneNumber = phoneNumber
    FROM @filterBy
END

IF EXISTS (SELECT * FROM @orderBy)
BEGIN
    SELECT @sortBy = [COLUMN], @sortOrder = [direction]
    FROM @orderBy
    WHERE [column] IN ('customerNumber', 'firstName', 'lastName', 'createdOn', 'branch', 'statusValue', 'stateValue',
        'kycId', 'customerType', 'primaryPhone', 'cbsId', 'nationalId')
        AND [direction] IN ('ASC', 'DESC')
END

IF EXISTS (SELECT * FROM @paging)
BEGIN
    SELECT
        @pageNumber = CASE WHEN (pageNumber > 0) THEN pageNumber ELSE 1 END,
        @pageSize = CASE WHEN ([pageSize] > 0) THEN [pageSize] ELSE 20 END
    FROM @paging
END

DECLARE @startRow INT = ( @pageNumber - 1) * @pageSize + 1
DECLARE @endRow INT = @startRow + @pageSize - 1

SET @customerNumber = '%' + @customerNumber + '%'
SET @firstName = '%' + @firstName + '%'
SET @lastName = '%' + @lastName + '%'
SET @phoneNumber = '%' + @phoneNumber + '%'


DECLARE @hasStatus BIT = CASE WHEN (SELECT COUNT(1) FROM @statusList WHERE value IS NOT NULL) = 0 THEN 0 ELSE 1 END

IF OBJECT_ID('tempdb..#Cust') IS NOT NULL
    DROP TABLE #Cust


CREATE TABLE #Cust(
    actorId BIGINT, customerNumber NVARCHAR(20), firstName NVARCHAR(101), lastName NVARCHAR(101), createdOn DATETIMEOFFSET (7),
    agencyName VARCHAR (100), statusValue VARCHAR(100), stateValue VARCHAR(100),
    kycId SMALLINT, customerType VARCHAR(100), documentFileName VARCHAR(100), primaryPhone VARCHAR(50), recordsTotal INT, rowNum INT,
    cbsId VARCHAR(100), nationalId VARCHAR(50));

WITH CTE AS
(
    SELECT TOP 1000 c.actorId, c.customerNumber, firstName, lastName, c.createdOn, o.organizationName AS agencyName,
        statusValue, stateValue, c.kycId, customerType, phoneNumber AS primaryPhone, nationalId, cbsId,
        ROW_NUMBER() OVER(
            ORDER BY
                CASE WHEN @sortOrder = 'ASC' THEN
                    CASE
                        WHEN @sortBy = 'customerNumber' THEN c.customerNumber
                        WHEN @sortBy = 'firstName' THEN c.firstName
                        WHEN @sortBy = 'lastname' THEN c.lastname
                        WHEN @sortBy = 'createdOn' THEN CONVERT(VARCHAR(100), c.createdOn)
                        WHEN @sortBy = 'branch' THEN o.organizationName
                        WHEN @sortBy = 'statusValue' THEN statusValue
                        WHEN @sortBy = 'stateValue' THEN stateValue
                        WHEN @sortBy = 'kycId' THEN CONVERT(VARCHAR(100), kycId)
                        WHEN @sortBy = 'primaryPhone' THEN phoneNumber
                        WHEN @sortBy = 'cbsId' THEN cbsId
                        WHEN @sortBy = 'nationalId' THEN nationalId
                        WHEN @sortBy = 'customerType' THEN customerType
                    END
            END,
            CASE WHEN @sortOrder = 'DESC' THEN
                CASE
                    WHEN @sortBy = 'customerNumber' THEN c.customerNumber
                    WHEN @sortBy = 'firstName' THEN c.firstName
                    WHEN @sortBy = 'lastname' THEN c.lastname
                    WHEN @sortBy = 'createdOn' THEN CONVERT(VARCHAR(100), c.createdOn)
                    WHEN @sortBy = 'branch' THEN o.organizationName
                    WHEN @sortBy = 'statusValue' THEN statusValue
                    WHEN @sortBy = 'stateValue' THEN stateValue
                    WHEN @sortBy = 'kycId' THEN CONVERT(VARCHAR(100), kycId)
                    WHEN @sortBy = 'primaryPhone' THEN phoneNumber
                    WHEN @sortBy = 'cbsId' THEN cbsId
                    WHEN @sortBy = 'nationalId' THEN nationalId
                    WHEN @sortBy = 'customerType' THEN customerType
                END
            END DESC) AS rowNum,
        COUNT( * ) OVER(PARTITION BY 1) AS recordsTotal
    FROM customer.organizationsVisibleFor(@userId) AS o
    JOIN
    (
        SELECT TOP 1000 cu.actorId, cu.organizationId, cu.customerNumber, pu.firstName, pu.lastName, phoneNumber,
				cu.createdOn, cu.statusId, s.[description] AS statusValue, st.[display] AS stateValue, c.kycId, ct.[description] AS customerType,
				pu.nationalId, cbs.[name] cbsId
        FROM customer.customerUnapproved cu
        JOIN core.[status] s ON s.statusId = cu.statusId
        JOIN customer.[state] st ON st.stateId = cu.stateId
        JOIN customer.customerType ct ON ct.customerTypeId = cu.customerTypeId
        JOIN customer.personUnapproved pu ON pu.actorId = cu.actorId
        LEFT JOIN customer.customer c ON c.actorId = cu.actorId
        LEFT JOIN customer.phoneUnapproved AS phone ON phone.actorId = cu.actorId ---AND phone.isPrimary = 1
        LEFT JOIN @statusList a ON a.value = cu.statusId
        LEFT JOIN [core].[cbs] cbs ON cbs.cbsId = cu.cbsId
        WHERE c.actorId IS NULL
            AND (@customerNumber IS NULL OR cu.customerNumber LIKE @customerNumber)
            AND (@phoneNumber IS NULL OR phone.phoneNumber LIKE @phoneNumber)
            AND (@customerType IS NULL OR cu.customerTypeId = @customerType)
            AND (@firstName IS NULL OR pu.firstName LIKE @firstName)
            AND (@lastName IS NULL OR pu.lastName LIKE @lastName)
            AND (@hasStatus = 0 OR a.value IS NOT NULL)
            AND (@cbsId IS NULL OR cbs.[name] = @cbsId)
            AND (@nationalId IS NULL OR pu.nationalId = @nationalId)

        UNION ALL

        SELECT TOP 1000 cc.actorId, cc.organizationId, cc.customerNumber, p.firstName, p.lastName, phoneNumber,
				cc.createdOn, ISNULL (cu.statusId, cc.statusId) AS statusId, s.[description] AS statusValue, st.[display] AS stateValue,
				cc.kycId, ct.[description] AS customerType, p.nationalId, cbs.[name] cbsId
        FROM customer.customer cc
        JOIN customer.person p ON p.actorId = cc.actorId
        JOIN customer.[state] st ON st.stateId = cc.stateId
        JOIN customer.customerType ct ON ct.customerTypeId = cc.customerTypeId
        LEFT JOIN customer.customerUnapproved cu ON cu.actorId = p.actorId
        LEFT JOIN customer.phone AS phone ON phone.actorId = cc.actorId -- AND phone.isPrimary = 1
        LEFT JOIN @statusList a ON a.value = ISNULL (cu.statusId, cc.statusId)
        JOIN core.[status] s ON s.statusId = ISNULL (cu.statusId, cc.statusId)
        LEFT JOIN [core].[cbs] cbs ON cbs.cbsId = cc.cbsId
        WHERE (@customerNumber IS NULL OR cc.customerNumber LIKE @customerNumber)
            AND (@phoneNumber IS NULL OR phone.phoneNumber LIKE @phoneNumber)
            AND (@customerType IS NULL OR cc.customerTypeId = @customerType)
            AND (@firstName IS NULL OR p.firstName LIKE @firstName)
            AND (@lastName IS NULL OR p.lastName LIKE @lastName)
            AND (@hasStatus = 0 OR a.value IS NOT NULL)
            AND (@cbsId IS NULL OR cbs.[name] = @cbsId)
            AND (@nationalId IS NULL OR p.nationalId = @nationalId)
    ) AS c ON o.actorId = c.organizationId
)

INSERT INTO #Cust(actorId, customerNumber, firstName, lastName, stateValue, createdOn, agencyName, kycId, recordsTotal, rowNum, statusValue, customerType, primaryPhone, cbsId, nationalId)
SELECT DISTINCT actorId, customerNumber, firstName, lastName, stateValue, createdOn, agencyName, kycId, recordsTotal, rowNum, statusValue, customerType, primaryPhone, cbsId, nationalId
FROM CTE
WHERE rowNum BETWEEN @startRow AND @endRow

SELECT 'customer' AS resultSetName
SELECT c.actorId, customerNumber, firstName + ' ' + lastName AS fullName, stateValue, createdOn, agencyName, kycId, statusValue, customerType, primaryPhone,
    cbsId, nationalId,
    rowNum, recordsTotal
FROM #Cust c
ORDER BY rowNum

SELECT 'pagination' AS resultSetName
SELECT TOP 1 @pageSize AS pageSize, recordsTotal AS recordsTotal, @pageNumber AS pageNumber, (recordsTotal - 1) / @pageSize + 1 AS pagesTotal
FROM #Cust

DROP TABLE #Cust
