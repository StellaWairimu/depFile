CREATE PROCEDURE [customer].[education.list] -- lists all education
    @meta core.metaDataTT READONLY -- information for the user that makes the operation

AS

-- checks if the user has a right to make the operation
DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
IF @return != 0
BEGIN
    RETURN 55555
END

DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
DECLARE @languageId BIGINT = (
    SELECT languageId
    FROM [core].[language] cl
    JOIN [user].[session] us ON us.[language] = cl.[iso2Code]
    WHERE us.[actorId] = @userId)

SELECT 'education' AS resultSetName

SELECT e.educationId, itr.itemNameTranslation
FROM customer.education e
    JOIN core.itemName i ON e.itemNameId = i.itemNameId
    JOIN core.itemTranslation itr ON e.itemNameId = itr.itemNameId
    JOIN core.itemType it ON it.itemTypeId = i.itemTypeId
WHERE
    it.name = 'education'
    AND itr.languageId = @languageId
