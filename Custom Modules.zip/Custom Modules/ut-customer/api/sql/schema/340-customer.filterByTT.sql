CREATE TYPE [customer].[filterByTT] AS TABLE(
    customerNumber NVARCHAR(100),
    firstName NVARCHAR(100),
    lastName NVARCHAR(100),
    fullName NVARCHAR(200),
    agencyId BIGINT,
    customerType NVARCHAR(100),
    phoneNumber NVARCHAR(50)
)


