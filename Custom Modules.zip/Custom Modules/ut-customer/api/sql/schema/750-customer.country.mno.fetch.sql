ALTER PROCEDURE [customer].[country.mno.fetch] -- to list alias, key column and value
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)

    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    SELECT 'countryMno' AS resultSetName

    SELECT
        core.country.countryId,
        core.country.name,
        core.country.countryCode,
        core.country.itemNameId,
        core.country.phonePrefix,
        customer.mno.mnoId,
        customer.mno.name AS mnoName,
        customer.mno.ut5Key,
        customer.mno.statusId
    FROM
        core.country
        JOIN customer.mno ON customer.mno.countryId = core.country.countryId
