ALTER PROCEDURE customer.[customer.approve]
    @actorId BIGINT, -- customer id
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)

    -- check if the maker and the checker are different users
    IF EXISTS (
        SELECT c.updatedBy
        FROM [customer].[customerUnapproved] c
        LEFT JOIN [user].[vSystemUser] su ON su.actorid = c.updatedBy
        WHERE c.actorId = @actorId
            AND c.updatedBy = @userId
            AND su.actorid IS NULL)
        RAISERROR('customer.cannotPerformThisOperation', 16, 1)

    IF NOT EXISTS (SELECT * FROM customer.customer c WHERE c.actorId = @actorId)
    BEGIN
        EXEC customer.[customer.addApproved] @actorId = @actorId, @noResultSet = @noResultSet, @meta = @meta
    END
    ELSE
    BEGIN
        EXEC customer.[customer.editApproved] @actorId = @actorId, @noResultSet = @noResultSet, @meta = @meta
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
