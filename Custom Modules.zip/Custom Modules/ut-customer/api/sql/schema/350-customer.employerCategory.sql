CREATE TABLE [customer].[employerCategory]( --table that stores employer category of the person
    [employerCategoryId] TINYINT IDENTITY(1, 1) NOT NULL, -- employer category id
    [itemNameId] BIGINT NULL,
    CONSTRAINT pkCustomeremployerCategory PRIMARY KEY CLUSTERED(employerCategoryId ASC),
    CONSTRAINT [fkEmployerCategory_itemNameId] FOREIGN KEY(itemNameId) REFERENCES [core].[itemName] (itemNameId)
)
