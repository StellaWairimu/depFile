ALTER PROCEDURE [customer].[organization.edit] -- edits organization information
    @organization customer.organizationTT READONLY, -- the edited organization information
    @grantedRoles core.arrayNumberList READONLY, -- the subroles that will be added
    @revokedRoles core.arrayNumberList READONLY, -- the subroles that will be removed from the organization
    @parentsAdded core.arrayNumberList READONLY, -- added parent organizations
    @parentsRemoved core.arrayNumberList READONLY, -- removed parent organizations
    -----------------------------------
    @email customer.emailUnapprovedTT READONLY, -- edited e-mails of the organization
    @phone customer.phoneUnapprovedTT READONLY, -- edited phone numbers of the organization
    @address customer.addressUnapprovedTT READONLY, -- edited addresses of the organization
    -----------------------------------
    @noResultSet BIT = 0, -- a flag to show if result is expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
    DECLARE @actorId BIGINT = (SELECT actorId FROM @organization) -- the id of the organization, that will be edited
    DECLARE @result customer.organizationUnapprovedTT
    DECLARE @parentsAll core.arrayNumberList
    DECLARE @revokedRolesNew core.arrayNumberList
    DECLARE @statusId VARCHAR(20) = (SELECT statusId FROM [customer].[organizationUnapproved] WHERE actorId = @actorId)

BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    IF @statusId = 'new' OR @statusId = 'pending'
    BEGIN
        RAISERROR('customer.organizationInvalidStatus', 16, 1);
    END

    --get all updated parents - needed FOR roles CHECK
    INSERT INTO @parentsAll (value)
    SELECT a.[object]
    FROM [core].[actorHierarchy] a
    WHERE a.[subject] = @actorId AND a.predicate = 'memberOf'

    -- check if user has visibility to the organization
    IF NOT EXISTS (SELECT actorId FROM customer.organizationsVisibleFor(@userId) WHERE actorId = @actorId)
        RAISERROR('customer.securityViolation', 16, 1)

    -- check if user has visibility to the existing parents of the organization
    IF NOT EXISTS(
    SELECT p.value
    FROM @parentsAll p
    JOIN customer.organizationsVisibleFor(@userId) o ON o.actorId = p.value)
        AND (EXISTS (SELECT 1 FROM @parentsAdded UNION ALL SELECT 1 FROM @parentsRemoved))
        RAISERROR('customer.securityViolation', 16, 1)

    -- check if user has visibility to the added parents of the organization
    IF EXISTS(
    SELECT p.value
    FROM @parentsAdded p
    LEFT JOIN customer.organizationsVisibleFor(@userId) o ON o.actorId = p.value
    WHERE o.actorId IS NULL)
        RAISERROR('customer.securityViolation', 16, 1)

    -- check if user has visibility to the deleted parents of the organization
    IF EXISTS(
    SELECT p.value
    FROM @parentsRemoved p
    LEFT JOIN customer.organizationsVisibleFor(@userId) o ON o.actorId = p.value
    WHERE o.actorId IS NULL)
        RAISERROR('customer.securityViolation', 16, 1)

    INSERT INTO @parentsAll (value)
    SELECT a.value
    FROM @parentsAdded a

    DELETE a
    FROM @parentsAll a
    JOIN @parentsRemoved r ON a.value = r.value

    --checks IF among parents there are disabled or deleted organizations
    IF EXISTS(
        SELECT *
        FROM @parentsAll p
        LEFT JOIN customer.organization o ON p.value = o.actorId AND o.isEnabled = 1 AND o.isDeleted = 0
        WHERE o.actorId IS NULL)
    RAISERROR('customer.disabledOrDeletedOrganization', 16, 1)

    --checks IF among @parents there are related units IN the hierarchy graph
    IF EXISTS(
        SELECT g.actorId
        FROM @parentsAll p
        CROSS APPLY core.actorGraph(p.[value], 'memberOf', 'object') g
        JOIN @parentsAll pp ON g.actorId = pp.[value]
        WHERE g.[level] <> 0)
    RAISERROR('customer.recursion', 16, 1)

    --IF EXISTS(SELECT g.actorId
				--FROM @parentsAll p
				--CROSS APPLY core.actorGraph(p.[value],'memberOf','subject') g
				--LEFT JOIN @parentsAll pp ON g.actorId = pp.[value]
				--WHERE (g.[level] <> 0 AND pp.[value] IS NOT NULL) OR (g.actorId = @actorId AND g.[level] > 0))
			 --RAISERROR('customer.recursion', 16, 1)

    ----checks IF among @parentsAdded the current BU IS parent somewhere IN the hierarchy graph
    IF EXISTS(
        SELECT g.actorId
        FROM @parentsAdded pa
        CROSS APPLY core.actorGraph(pa.[value], 'memberOf', 'subject') g
        WHERE g.actorId = @actorId)
        RAISERROR('customer.recursion', 16, 1)

    --adds to @revokedRoles roles that were visible only IN removed BUs, i.e. are NOT unchecked, but are no longer visible
    INSERT INTO @revokedRolesNew (value)
    SELECT v.value
    FROM @revokedRoles v

    UNION

    SELECT DISTINCT v.roleId
    FROM @parentsRemoved pr --BUs that are removed now
    CROSS APPLY core.rolesVisibleFor(pr.value) v --roles that are visible FOR the removed BUs
    OUTER APPLY(
        SELECT *
        FROM @parentsAll a
        CROSS APPLY core.rolesVisibleFor(a.value) vv
        WHERE v.roleId = vv.roleId
    ) aa --CHECK whether the roles that are visible IN the removed BUs are NOT visible IN BUs IN that the actor IS still member of, IF so, don't remove these roles
    JOIN
        (SELECT [subject], predicate, [object] FROM core.actorHierarchy
        UNION ALL
        SELECT [subject], predicate, [object] FROM core.actorHierarchyUnapproved
        )ah ON [object] = v.roleId AND predicate = 'role' AND [subject] = @actorId-- to remove only roles relevant to the BU
    WHERE aa.roleId IS NULL

    BEGIN TRANSACTION

        UPDATE t
        SET t.organizationName = s.organizationName,
            t.code = s.code,
            t.executiveOfficer = s.executiveOfficer,
            t.tradeName = s.tradeName,
            t.capital = s.capital,
            t.currency = s.currency,
            t.timeZone = s.timeZone,
            t.primaryLanguageId = s.primaryLanguageId,
            t.cbsId = s.cbsId,
            t.countryId = s.countryId,
            t.updatedBy = @userId,
            t.updatedOn = SYSDATETIMEOFFSET(),
            t.statusId = 'pending',
            t.isDeleted = s.isDeleted,
            t.isEnabled = s.isEnabled,
            t.oldValues = s.oldValues
        OUTPUT INSERTED.* INTO @result
        FROM customer.organizationUnapproved t
        JOIN @organization s ON t.actorId = s.actorId

        INSERT INTO customer.organizationUnapproved(actorId, frontEndRecordId, organizationName, code, executiveOfficer, tradeName, capital, currency, timeZone, primaryLanguageId, oldValues, isEnabled, isDeleted, cbsId, countryId, updatedBy, updatedOn, statusId)
        OUTPUT INSERTED.* INTO @result
        SELECT o.actorId, o.frontEndRecordId, o.organizationName, o.code, o.executiveOfficer, o.tradeName, o.capital, o.currency, o.timeZone,
        o.primaryLanguageId, o.oldValues, o.isEnabled, o.isDeleted, o.cbsId, o.countryId, @userId, SYSDATETIMEOFFSET(), 'pending'
        FROM @organization o
        LEFT JOIN customer.organizationUnapproved co ON o.actorId = co.actorId
        WHERE co.actorId IS NULL

        IF @statusId = 'rejected' AND EXISTS(SELECT actorId FROM [customer].[organization] WHERE actorId = @actorId)
        DELETE FROM [core].[actorHierarchyUnapproved] WHERE [subject] = @actorId

        -- re-edit of new
        UPDATE ah
        SET isDeleted = CASE WHEN va.value IS NOT NULL THEN 0 WHEN vr.value IS NOT NULL THEN 1 ELSE isDeleted END
        FROM core.actorHierarchyUnapproved ah
        LEFT JOIN @parentsAdded va ON va.value = [object]
        LEFT JOIN @parentsRemoved vr ON vr.value = [object]
        WHERE [subject] = @actorId AND ah.predicate = 'memberOf'
        AND ( (isDeleted = 1 AND va.[value] IS NOT NULL ) OR (isDeleted = 0 AND vr.[value] IS NOT NULL))

        INSERT INTO [core].[actorHierarchyUnapproved] ([subject], predicate, [object], isDefault, isDeleted, updatedBy, updatedOn)
        SELECT @actorId, 'memberOf', v.value, 0, 0, @userId, SYSDATETIMEOFFSET()
        FROM @parentsAdded v
        LEFT JOIN core.actorHierarchyUnapproved ah ON ah.[subject] = @actorId AND ah.predicate = 'memberOf' AND v.value = [object]
        WHERE ah.[object] IS NULL -- IF we only change DEFAULT BU, there IS a record IN the unapproved TABLE to only show which IS the DEFAULT BU AND should NOT be inserted IN the main TABLE

        INSERT INTO [core].[actorHierarchyUnapproved] ([subject], predicate, [object], isDeleted, updatedBy, updatedOn)
        SELECT @actorId, 'memberOf', v.value, 1, @userId, SYSDATETIMEOFFSET()
        FROM @parentsRemoved v
        LEFT JOIN core.actorHierarchyUnapproved ah ON ah.[subject] = @actorId AND ah.predicate = 'memberOf' AND v.value = [object] -- re-edit of new
        WHERE ah.[object] IS NULL

        EXEC [user].[role.grantUnapproved]
            @actorId = @actorId,
            @granted = @grantedRoles,
            @revoked = @revokedRolesNew,
            @defaultRoleId = NULL,
            @meta = @meta

        EXEC [customer].[email.editUnapproved]
            @email = @email,
            @actorId = @actorId,
            @meta = @meta,
            @noResultSet = 1

        EXEC [customer].[phone.editUnapproved]
            @phone = @phone,
            @actorId = @actorId,
            @meta = @meta,
            @noResultSet = 1

        EXEC [customer].[address.editUnapproved]
            @address = @address,
            @actorId = @actorId,
            @meta = @meta,
            @noResultSet = 1

    COMMIT TRANSACTION

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'organization' AS resultSetName
        SELECT * FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
