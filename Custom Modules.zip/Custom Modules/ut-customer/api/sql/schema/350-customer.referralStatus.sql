CREATE TABLE [customer].[referralStatus](
    [referralStatusId] [TINYINT] IDENTITY(1, 1) NOT NULL, --StatusuniqueId
    [itemNameId] [BIGINT] NOT NULL, --Id for itemname
    CONSTRAINT [PK_Status_referralStatusId] PRIMARY KEY CLUSTERED ([referralStatusId]),
    CONSTRAINT [fkReferralStatus_coreItemName] FOREIGN KEY([itemNameId]) REFERENCES [core].[itemName] ([itemNameId])
)
