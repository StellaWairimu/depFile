ALTER PROCEDURE customer.[file.get] -- get the main info for person/joint/organization and customer - document, bio info, addresses, phones for the actorid passed
    @actorId BIGINT, -- this is the actor id
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
SET NOCOUNT ON;
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
    DECLARE @actorType VARCHAR(50)

    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    SELECT @actorType = actorType FROM core.actor WHERE actorId = @actorId

    --IF @actorType = 'person'
    --BEGIN
    --    EXEC customer.[person.get]
    --    @actorId = @actorId,
    --    @meta = @meta
    --END
    --ELSE
    IF @actorType = 'joint'
    BEGIN
        EXEC customer.[joint.get]
            @actorId = @actorId,
            @meta = @meta
    END
    ELSE IF @actorType = 'organization'
    BEGIN
        EXEC customer.[organization.get]
            @actorId = @actorId,
            @meta = @meta
    END
    ELSE IF @actorType <> 'person' OR @actorType IS NULL-- broken customer logic & build failure.. temporary fix!!!
    BEGIN
        RAISERROR('customer.unsupportedActorType', 16, 1);
    END
    IF EXISTS ( SELECT 1 FROM customer.customer WHERE actorId = @actorId )
    BEGIN
        EXEC customer.[customer.get]
            @actorId = @actorId,
            --@person = 0,
            @meta = @meta
    END

    --IF EXISTS ( SELECT 1 FROM customer.phone WHERE actorId = @actorId )
    --BEGIN
    --    EXEC customer.[phone.get]
    --    @actorId = @actorId,
    --    @meta = @meta
    --END

    --IF EXISTS ( SELECT 1 FROM customer.[address] WHERE actorId = @actorId )
    --BEGIN
    --    EXEC customer.[address.get]
    --    @actorId = @actorId,
    --    @meta = @meta
    --END

    SELECT 'bio' AS resultSetName
    EXEC [user].[hash.fetch]
        @actorId = @actorId,
        @type = 'bio'

    IF EXISTS ( SELECT 1 FROM document.actorDocument WHERE actorId = @actorId )
    BEGIN
        SELECT 'documentAttachment' AS resultSetName

        SELECT
            ad.actorId AS actorId,
            ad.documentId AS documentId,
            d.documentTypeId AS documentTypeId,
            d.statusId AS documentStatusId,
            d.expirationDate AS expirationDate,
            d.documentNumber AS documentNumber,
            d.oldValues AS documentOldValues,
            at.attachmentId AS attachmentId,
            at.contentType AS attachmentContentType,
            at.extension AS attachmentExtension,
            at.[filename] AS attachmentFilename,
            at.attachmentSizeId AS attachmentSizeId,
            at.[page] AS attachmentPage,
            at.oldValues AS attachmentOldValues
        FROM document.actorDocument ad
        JOIN document.document d ON d.documentId = ad.documentId
        LEFT JOIN document.attachment at ON at.documentId = d.documentId
        WHERE ad.actorId = @actorId
    END
