CREATE TABLE customer.emailUnapproved( -- table that stores unapproved e-mails
    emailUnapprovedId BIGINT IDENTITY(1, 1) NOT NULL, -- the id of the unapproved record
    emailId INT NULL, -- the id of the e-mail
    actorId BIGINT NOT NULL, -- the id of the actor, who the e-mail belongs to
    value VARCHAR (50) NOT NULL, -- the e-mail value
    frontEndRecordId VARCHAR (10), -- an id, needed for the frontend of the mobile app
    emailTypeId VARCHAR (20) NOT NULL, -- the emailTypeId, e.g. personal, work
    statusId VARCHAR (20) NOT NULL, -- the statusId of the e-mail, e.g. active/inactive
    oldValues XML NULL, -- history of old values of customer e-mails
    [isDeleted] BIT NOT NULL, -- a flag to show if the e-mail will be deleted or inserted/edited
    [updatedBy] BIGINT NOT NULL, -- the id of the user updating the e-mail
    [updatedOn] DATETIMEOFFSET(7) NOT NULL, -- the datetime the e-mail is updated on
    isPrimary BIT NOT NULL DEFAULT(0), -- a flag to show if the email if primary
    CONSTRAINT pkCustomerEmailUnapproved PRIMARY KEY CLUSTERED(emailUnapprovedId ASC),
    CONSTRAINT fkCustomerEmailUnapproved_coreActor FOREIGN KEY(actorId) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerEmailUnapproved_updatedByCoreActor FOREIGN KEY(updatedBy) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerEmailUnapproved_customerEmail FOREIGN KEY(emailId) REFERENCES [customer].[email] (emailId),
    CONSTRAINT fkCustomerEmailUnapproved_customerEmailType FOREIGN KEY(emailTypeId) REFERENCES customer.emailType (emailTypeId),
    CONSTRAINT fkCustomerEmailUnapproved_coreStatus FOREIGN KEY(statusId) REFERENCES core.[status] (statusId)
)
