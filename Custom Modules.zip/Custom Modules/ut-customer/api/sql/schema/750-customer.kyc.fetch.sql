ALTER PROCEDURE [customer].[kyc.fetch] -- this sp gets all existing kyc levels in db
    @isActive VARCHAR(20), -- filter by status
    @customerTypeId INT, -- filter by customer type
    @businessUnitId INT, -- filter by business unit
    @orderBy [core].orderByTT READONLY, -- information for ordering
    @paging [core].[pagingTT] READONLY, --information for paging (to be changed to core when ldap merged)
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)

    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    DECLARE @pageSize INT = 20
    DECLARE @pageNumber INT = 1
    DECLARE @sortBy VARCHAR(50) = 'display'
    DECLARE @sortOrder VARCHAR(4) = 'ASC'
    DECLARE @languageId BIGINT = ISNULL(
        (SELECT languageId
        FROM [core].[language] cl
        JOIN [user].[session] us ON us.[language] = cl.[iso2Code]
        WHERE us.[actorId] = @userId), (SELECT [languageId] FROM [core].[language] WHERE [name] = 'English')
        )
    SELECT @sortBy = ISNULL([field], 'display'), @sortOrder = ISNULL([dir], 'ASC')
    FROM @orderBy

    SELECT @pageNumber = ISNULL(pageNumber, 1), @pageSize = ISNULL([pageSize], 20)
    FROM @paging

    DECLARE @startRow INT = ( @pageNumber - 1) * @pageSize + 1
    DECLARE @endRow INT = @startRow + @pageSize - 1

    IF OBJECT_ID('tempdb..#kyc') IS NOT NULL
        DROP TABLE #kyc

    CREATE TABLE #kyc (
        [kycId] SMALLINT, [display] VARCHAR(10), [description] VARCHAR(100),
        [statusId] VARCHAR(20), [customerTypeId] VARCHAR(20), [organizationId] BIGINT,
        organizationName NVARCHAR(100), customerType VARCHAR(100), customerTypeDescription VARCHAR(100),
        rowNum INT, recordsTotal INT);

    WITH CTE AS
    (
        SELECT kycId, display, [description], statusId, customerTypeId, customerType,
            customerTypeDescription, organizationId, organizationName,
            ROW_NUMBER() OVER (ORDER BY
                CASE WHEN @sortBy = 'display' AND @sortOrder = 'ASC' THEN itemOrder END,
                CASE WHEN @sortBy = 'display' AND @sortOrder = 'DESC' THEN itemOrder END DESC,
                CASE WHEN @sortOrder = 'ASC' AND @sortBy != 'display' THEN
                    CASE
                        WHEN @sortBy = 'description' THEN [description]
                        WHEN @sortBy = 'customerType' THEN customerType
                        WHEN @sortBy = 'statusId' THEN statusId
                    END
                END,
                CASE WHEN @sortOrder = 'DESC' AND @sortBy != 'display' THEN
                    CASE
                        WHEN @sortBy = 'description' THEN [description]
                        WHEN @sortBy = 'customerType' THEN customerType
                        WHEN @sortBy = 'statusId' THEN statusId
                    END
                END DESC) rowNum,
            COUNT( * ) OVER(PARTITION BY 1) AS recordsTotal
        FROM
        (
            SELECT k.kycId, it.itemNameTranslation AS display, k.[description], k.statusId, k.customerTypeId,
                ct.[customerTypeId] AS customerType, ct.[description] AS customerTypeDescription, k.organizationId, o.organizationName, itn.itemOrder
            FROM [customer].[kyc] k
            JOIN [customer].[customerType] ct ON k.customerTypeId = ct.customerTypeNumber
            JOIN [customer].[organization] o ON k.organizationId = o.actorId
            JOIN customer.organizationsVisibleFor(@userId) cur ON cur.actorId = k.organizationId
            JOIN core.itemTranslation it ON it.itemNameId = k.itemNameId AND it.languageId = @languageId
            JOIN core.itemName itn ON itn.itemNameId = it.itemNameId
            WHERE k.isDeleted = 0
            AND @businessUnitId = k.organizationId
            AND (@isActive IS NULL OR @isActive = k.statusId)
            AND (@customerTypeId IS NULL OR @customerTypeId = k.customerTypeId)

        ) AS r
    )

    INSERT INTO #kyc(
        kycId, display, [description], statusId, customerTypeId, customerType,
        customerTypeDescription, organizationId, organizationName, rowNum, recordsTotal)
    SELECT
        kycId, display, [description], statusId, customerTypeId, customerType,
        customerTypeDescription, organizationId, organizationName, rowNum, recordsTotal
    FROM CTE
    WHERE rowNum BETWEEN @startRow AND @endRow


    SELECT 'kyc' AS resultSetName

    SELECT
        kycId, display, [description], customerTypeId, customerType, customerTypeDescription,
        organizationId, organizationName, statusId
    FROM #kyc
    ORDER BY rowNum


    SELECT 'pagination' AS resultSetName

    SELECT TOP 1 @pageSize AS pageSize, recordsTotal AS recordsTotal, @pageNumber AS pageNumber, (recordsTotal - 1) / @pageSize + 1 AS pagesTotal
    FROM #kyc

    DROP TABLE #kyc
