ALTER PROCEDURE [customer].[organization.get] -- gets information for an organization
    @actorId BIGINT = NULL, -- the id of the organization
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @callParams XML
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
DECLARE @rolesAll core.arrayNumberList
DECLARE @parentsAll core.arrayNumberList
DECLARE @actorHierarchyAll [core].actorHierarchyTT

BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
    IF @return != 0
    BEGIN
        RETURN 55555
    END

    --check if user has access to the organization
    IF NOT EXISTS(
        SELECT o.actorId
        FROM customer.organizationsVisibleForUnapproved(@userId) o
        JOIN [customer].[organization] org ON o.actorId = org.actorId
        WHERE org.actorId = @actorId)

    AND NOT EXISTS(
        SELECT o.actorId
        FROM customer.organizationsVisibleForUnapproved(@userId) o
        JOIN [customer].[organizationUnapproved] org ON o.actorId = org.actorId
        WHERE org.actorId = @actorId)

    AND EXISTS( -- this is only for integration tests to pass - user can get information about main organization not visible for him
        SELECT subject
        FROM core.actorHierarchy
        WHERE subject = @actorId AND predicate = 'memberOf'
        UNION ALL
        SELECT subject
        FROM core.actorHierarchyUnapproved
        WHERE subject = @actorId AND predicate = 'memberOf')

            RAISERROR('customer.securityViolation', 16, 1)


        ------------------ EXISTING ORGANIZATION
    IF EXISTS(SELECT actorId FROM customer.organization o WHERE o.actorId = @actorId)
    BEGIN
        ------------------ EXISTING EDITED ORGANIZATION - SET final states = approved + unapproved
        IF EXISTS(SELECT actorId FROM customer.organizationUnapproved o WHERE o.actorId = @actorId)
        BEGIN
            --get all updated permissions AND roles assigned to the role
            INSERT INTO @actorHierarchyAll ([subject], predicate, [object])
            SELECT [subject], predicate, [object]
            FROM
            (SELECT [subject], predicate, [object] FROM core.actorHierarchy
            WHERE [subject] = @actorId
            UNION ALL
            SELECT ahu.[subject], ahu.predicate, ahu.[object] FROM core.actorHierarchyUnapproved ahu
            WHERE ahu.[subject] = @actorId AND ahu.isDeleted = 0
            ) a

            DELETE a
            FROM @actorHierarchyAll a
            JOIN core.actorHierarchyUnapproved ahu ON a.[object] = ahu.[object]
            WHERE ahu.[subject] = @actorId AND isDeleted = 1

            INSERT INTO @rolesAll (value)
            SELECT [object]
            FROM @actorHierarchyAll ah
            WHERE predicate = 'role'

            INSERT INTO @parentsAll (value)
            SELECT [object]
            FROM @actorHierarchyAll ah
            WHERE predicate = 'memberOf'

            ---------UNAPPROVED RESULTSETS
            SELECT 'organization.infoUnapproved' AS resultSetName
            SELECT actorId, frontEndRecordId, organizationName, code, executiveOfficer, tradeName, capital, currency, timeZone, primaryLanguageId, oldValues, isEnabled, isDeleted, o.cbsId, countryId, updatedBy, statusId, rejectReason, 0 AS isNew, cbs.[name] AS cbsName
            FROM [customer].[organizationUnapproved] o
            LEFT JOIN [core].[cbs] cbs ON o.cbsId = cbs.cbsId
            WHERE o.actorId = @actorId

            SELECT 'organization.emailUnapproved' AS resultSetName
            SELECT emailUnapprovedId, emailId, actorId, [value], frontEndRecordId, emailTypeId, statusId, oldValues, isPrimary
            FROM [customer].[emailUnapproved]
            WHERE actorId = @actorId AND isDeleted = 0

            SELECT 'organization.addressUnapproved' AS resultSetName
            SELECT addressUnapprovedId, addressId, actorId, value, frontEndRecordId, addressTypeId, statusId, oldValues, city, lat, lng, addressZone1 AS addressZone1Id, addressZone2 AS addressZone2Id, addressZone3 AS addressZone3Id, addressZone4 AS addressZone4Id, i1.itemName AS addressZone1, i2.itemName AS addressZone2, i3.itemName AS addressZone3, i4.itemName AS addressZone4, a.updatedBy, a.updatedOn
            FROM [customer].[addressUnapproved] a
            LEFT JOIN core.itemName i1 ON i1.itemNameId = a.addressZone1
            LEFT JOIN core.itemName i2 ON i2.itemNameId = a.addressZone2
            LEFT JOIN core.itemName i3 ON i3.itemNameId = a.addressZone3
            LEFT JOIN core.itemName i4 ON i4.itemNameId = a.addressZone4
            WHERE actorId = @actorId AND isDeleted = 0

            SELECT 'organization.phoneUnapproved' AS resultSetName
            SELECT phoneUnapprovedId, phoneId, actorId, frontEndRecordId, phoneTypeId, phoneNumber, statusId, oldValues, udf, mnoId, isPrimary
            FROM [customer].[phoneUnapproved]
            WHERE actorId = @actorId AND isDeleted = 0

            SELECT 'organization.parentsUnapproved' AS resultSetName
            SELECT o.actorId, o.organizationName
            FROM @parentsAll ah
            JOIN customer.organization o ON ah.[value] = o.actorId AND o.isEnabled = 1

            SELECT 'organization.rolesUnapproved' AS resultSetName
            SELECT r.actorId, r.name
            FROM @rolesAll ra
            JOIN [user].[role] r ON ra.[value] = r.actorId AND r.isEnabled = 1
        END

        ---------APPROVED RESULTSETS

        SELECT 'organization.info' AS resultSetName
        SELECT o.actorId, o.frontEndRecordId, o.organizationName, o.code, o.executiveOfficer, o.tradeName, o.capital, o.currency, o.timeZone, o.primaryLanguageId, o.oldValues, o.isEnabled, o.isDeleted, o.cbsId, o.countryId, NULL AS updatedBy, CASE WHEN ou.statusId IS NULL THEN 'approved' ELSE ou.statusId END AS statusId, rejectReason, 0 AS isNew, cbs.[name] AS cbsName,
        CASE WHEN @actorId IN (SELECT ah.[object]
            FROM core.actorHierarchy ah
            JOIN customer.organization o ON o.actorId = ah.[object] AND o.isEnabled = 1
            WHERE [subject] = @userId AND predicate = 'memberOf') THEN 1 ELSE 0 END AS isOwn
        FROM [customer].[organization] o
        LEFT JOIN [customer].[organizationUnapproved] ou ON ou.actorId = o.actorId
        LEFT JOIN [core].[cbs] cbs ON o.cbsId = cbs.cbsId
        WHERE o.actorId = @actorId

        SELECT 'organization.email' AS resultSetName
        SELECT NULL AS emailUnapprovedId, e.*
        FROM [customer].[email] e
        WHERE actorId = @actorId

        SELECT 'organization.address' AS resultSetName
        SELECT NULL AS addressUnapprovedId, addressId, actorId, value, frontEndRecordId, addressTypeId, statusId, oldValues, city, lat, lng, addressZone1 AS addressZone1Id, addressZone2 AS addressZone2Id, addressZone3 AS addressZone3Id, addressZone4 AS addressZone4Id, i1.itemName AS addressZone1, i2.itemName AS addressZone2, i3.itemName AS addressZone3, i4.itemName AS addressZone4, NULL updatedBy, NULL updatedOn
        FROM [customer].[address] a
        LEFT JOIN core.itemName i1 ON i1.itemNameId = a.addressZone1
        LEFT JOIN core.itemName i2 ON i2.itemNameId = a.addressZone2
        LEFT JOIN core.itemName i3 ON i3.itemNameId = a.addressZone3
        LEFT JOIN core.itemName i4 ON i4.itemNameId = a.addressZone4
        WHERE a.actorId = @actorId

        SELECT 'organization.phone' AS resultSetName
        SELECT NULL AS phoneUnapprovedId, p.*, NULL updatedBy, NULL updatedOn
        FROM [customer].[phone] p
        WHERE actorId = @actorId

        SELECT 'organization.parents' AS resultSetName
        SELECT o.actorId, o.organizationName
        FROM core.actorHierarchy ah
        JOIN customer.organization o ON ah.[object] = o.actorId
        WHERE ah.[subject] = @actorId AND ah.[predicate] = 'memberOf' AND o.isEnabled = 1

        SELECT 'organization.roles' AS resultSetName
        SELECT r.actorId, r.name
        FROM core.actorHierarchy ah
        JOIN [user].[role] r ON ah.[object] = r.actorId
        WHERE ah.[subject] = @actorId AND ah.[predicate] = 'role' AND r.isEnabled = 1
    END
    ELSE
    ------------------------ NEW ORGANIZATION
    BEGIN
        SELECT 'organization.info' AS resultSetName
        SELECT actorId, frontEndRecordId, organizationName, code, executiveOfficer, tradeName, capital, currency, timeZone, primaryLanguageId, oldValues, isEnabled, isDeleted, o.cbsId, countryId, updatedBy, statusId, rejectReason, 1 AS isNew, cbs.[name] AS cbsName
        FROM [customer].[organizationUnapproved] o
        LEFT JOIN [core].[cbs] cbs ON o.cbsId = cbs.cbsId
        WHERE o.actorId = @actorId

        SELECT 'organization.email' AS resultSetName
        SELECT emailUnapprovedId, emailId, actorId, [value], frontEndRecordId, emailTypeId, statusId, oldValues, isPrimary
        FROM [customer].[emailUnapproved]
        WHERE actorId = @actorId AND isDeleted = 0

        SELECT 'organization.address' AS resultSetName
        SELECT addressUnapprovedId, addressId, actorId, value, frontEndRecordId, addressTypeId, statusId, oldValues, city, lat, lng, addressZone1 AS addressZone1Id, addressZone2 AS addressZone2Id, addressZone3 AS addressZone3Id, addressZone4 AS addressZone4Id, i1.itemName AS addressZone1, i2.itemName AS addressZone2, i3.itemName AS addressZone3, i4.itemName AS addressZone4, a.updatedBy, a.updatedOn
        FROM [customer].[addressUnapproved] a
        LEFT JOIN core.itemName i1 ON i1.itemNameId = a.addressZone1
        LEFT JOIN core.itemName i2 ON i2.itemNameId = a.addressZone2
        LEFT JOIN core.itemName i3 ON i3.itemNameId = a.addressZone3
        LEFT JOIN core.itemName i4 ON i4.itemNameId = a.addressZone4
        WHERE actorId = @actorId AND isDeleted = 0

        SELECT 'organization.phone' AS resultSetName
        SELECT phoneUnapprovedId, phoneId, actorId, frontEndRecordId, phoneTypeId, phoneNumber, statusId, oldValues, udf, mnoId, isPrimary
        FROM [customer].[phoneUnapproved]
        WHERE actorId = @actorId AND isDeleted = 0

        SELECT 'organization.parents' AS resultSetName
        SELECT o.actorId, o.organizationName
        FROM core.actorHierarchyUnapproved ah
        JOIN customer.organization o ON ah.[object] = o.actorId
        WHERE ah.[subject] = @actorId AND ah.[predicate] = 'memberOf' AND o.isEnabled = 1

        SELECT 'organization.roles' AS resultSetName
        SELECT r.actorId, r.name
        FROM core.actorHierarchyUnapproved ah
        JOIN [user].[role] r ON ah.[object] = r.actorId
        WHERE ah.[subject] = @actorId AND ah.[predicate] = 'role' AND r.isEnabled = 1
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
