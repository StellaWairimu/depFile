CREATE TABLE [customer].[activityReport](
    [Id] [BIGINT] IDENTITY(1, 1) NOT NULL,
    [actorId] [BIGINT] NULL,
    [customerNumber] [NVARCHAR](20) NULL,
    [customerDAO] [NVARCHAR](10) NULL,
    [firstName] [NVARCHAR](50) NULL,
    [lastName] [NVARCHAR](50) NULL,
    [phoneNumber] [VARCHAR](50) NULL,
    [installationId] [NVARCHAR](200) NULL,
    [action] [VARCHAR](50) NOT NULL,
    [actionStatus] [VARCHAR](20) NOT NULL,
    [operationDate] [DATETIMEOFFSET](0) NOT NULL,
    [channel] [VARCHAR](20) NOT NULL,
    [itemNameId] BIGINT NOT NULL,
    CONSTRAINT [PK_customer.activityReport] PRIMARY KEY CLUSTERED([Id] ASC),
    CONSTRAINT fkCustomerActivityReport_CoreItemName FOREIGN KEY(itemNameId) REFERENCES core.itemName (itemNameId)
)
