ALTER PROCEDURE [customer].[person.edit] -- edits person information
    @person customer.personUnapprovedTT READONLY, -- the edited person information
    @email customer.emailUnapprovedTT READONLY, -- information about the e-mails of the person
    @phone customer.phoneUnapprovedTT READONLY, -- information about the phone numbers of the person
    @address customer.addressUnapprovedTT READONLY, -- information about the addresses of the person
    @noResultSet BIT = 0, -- a flag to show if result is expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
    DECLARE @result customer.personUnapprovedTT

BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @actorId BIGINT = (SELECT TOP 1 actorId FROM @person)

    DECLARE @tranCounter INT = @@TRANCOUNT;
    IF @tranCounter = 0
        BEGIN TRANSACTION

            UPDATE t
            SET t.firstName = s.firstName,
                t.middleName = s.middleName,
                t.lastName = s.lastName,
                t.nationalId = s.nationalId,
                t.dateOfBirth = s.dateOfBirth,
                t.placeOfBirth = s.placeOfBirth,
                t.nationality = CASE WHEN c.name IS NOT NULL THEN c.name ELSE s.nationality END,
                t.gender = s.gender,
                t.bioId = s.bioId,
                t.phoneModel = s.phoneModel,
                t.computerModel = s.computerModel,
                t.maritalStatusId = s.maritalStatusId,
                t.age = s.age,
                t.employerName = s.employerName,
                t.employerCategoryId = s.employerCategoryId,
                t.employmentDate = s.employmentDate,
                t.educationId = s.educationId,
                t.employmentId = s.employmentId,
                t.familyMembers = s.familyMembers,
                t.incomeRangeId = s.incomeRangeId
            FROM customer.person t
            JOIN @person s ON t.actorId = s.actorId
            LEFT JOIN core.country c ON CAST(c.countryId AS VARCHAR(50)) = s.nationality

            INSERT INTO customer.person (actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers)
            SELECT ph.actorId, ph.firstName, ph.lastName, ph.nationalId, ph.dateOfBirth, ph.placeOfBirth, CASE WHEN c.name IS NOT NULL THEN c.name ELSE ph.nationality END AS nationality, ph.gender, ph.bioId, ph.phoneModel, ph.computerModel, ph.isEnabled, 0, ph.maritalStatusId, ph.age, ph.middleName, ph.educationId, ph.employmentId, ph.employmentDate, ph.incomeRangeId, ph.employerName, ph.employerCategoryId, ph.familyMembers
            FROM @person ph
            LEFT JOIN customer.person p ON p.actorId = ph.actorId
            LEFT JOIN core.country c ON CAST(c.countryId AS VARCHAR(50)) = ph.nationality
            WHERE p.actorId IS NULL

            EXEC [customer].[email.edit]
                @email = @email,
                @actorId = @actorId,
                @meta = @meta,
                @noResultSet = @noResultSet

            EXEC [customer].[phone.edit]
                @phone = @phone,
                @actorId = @actorId,
                @meta = @meta,
                @noResultSet = @noResultSet

            EXEC [customer].[address.edit]
                @address = @address,
                @actorId = @actorId,
                @meta = @meta,
                @noResultSet = @noResultSet

            IF @tranCounter = 0
        COMMIT TRANSACTION

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'person' AS resultSetName

        SELECT actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers
        FROM customer.person
        WHERE actorId = @actorId
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
