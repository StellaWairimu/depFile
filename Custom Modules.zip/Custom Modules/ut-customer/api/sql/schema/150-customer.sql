CREATE SCHEMA [customer]
