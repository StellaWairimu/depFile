CREATE TABLE customer.customerUnapproved( -- table that stores information about all customers
    customerUnapprovedId BIGINT IDENTITY(1, 1) NOT NULL, -- the id of the unapproved record
    actorId BIGINT NOT NULL, -- the id of the customer
    frontEndRecordId VARCHAR (10), -- an id, needed for the frontend of the mobile app
    customerNumber NVARCHAR (20), -- the customer number
    customerTypeId VARCHAR (20) NOT NULL, -- the customerTypeId of the customer, e.g. client
    kycId SMALLINT, -- the kycId of the customer, e.g. 'Level 1', 'Pulse', 'Full KYC'
    stateId VARCHAR (20), -- the stateId of the customer, e.g. pending, blocked, etc.
    statusId VARCHAR (20) NOT NULL, -- the statusId of the customer, e.g. active, approved, deleted etc.
    createdBy BIGINT, -- the id of the user, that created the customer
    createdOn DATETIMEOFFSET (7), -- the exact time the user was created
    updatedBy BIGINT, -- the id of the user, that updated the customer
    updatedOn DATETIMEOFFSET (7), -- the exact time the user was updated
    oldValues XML, -- history of previous values of customer information
    customerCategoryId SMALLINT, -- the id of the customer category, related to loans - e.g. AAA, AA, monitored, etc.
    dao VARCHAR(10), -- district account officer id
    [description] NVARCHAR(max), -- description
    [cbsId] INT, -- the core banking system id, relevant to the customer
    [countryId] INT, -- the country id of the customer
    industryId INT, -- industry of the customer
    sectorId INT, -- sector of the customer
    loanCycle VARCHAR(10), --the loan cycle as in T24
    organizationId BIGINT, -- DAO id from customer.organization table
    prospectClient VARCHAR(1), -- is prospect client
    adminFee DECIMAL NULL, -- admin fee
    udf XML NULL, -- stores all non standart properties related to a customer
    rejectReason NVARCHAR(MAX) NULL, -- the reason for rejecting unapproved record
    -- currentVersion timestamp NULL , -- the current version of re-edit of the record
    CONSTRAINT pkCustomerCustomerUnapproved PRIMARY KEY CLUSTERED(customerUnapprovedId ASC),
    CONSTRAINT fkCustomerCustomerUnapproved_coreActor FOREIGN KEY(actorId) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerCustomerUnapproved_customerCustomerType FOREIGN KEY(customerTypeId) REFERENCES customer.customerType (customerTypeId),
    CONSTRAINT fkCustomerCustomerUnapproved_customerKyc FOREIGN KEY(kycId) REFERENCES customer.kyc (kycId),
    CONSTRAINT fkCustomerCustomerUnapproved_customerState FOREIGN KEY(stateId) REFERENCES customer.[state] (stateId),
    CONSTRAINT fkCustomerCustomerUnapproved_coreStatus FOREIGN KEY(statusId) REFERENCES core.status (statusId),
    CONSTRAINT fkCustomerCustomerUnapproved_createdByCoreActor FOREIGN KEY(createdBy) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerCustomerUnapproved_updatedByCoreActor FOREIGN KEY(updatedBy) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerCustomerUnapproved_customerCustomerCategory FOREIGN KEY(customerCategoryId) REFERENCES customer.customerCategory (customerCategoryId),
    CONSTRAINT fkcustomerCustomerUnapproved_coreCBS FOREIGN KEY(cbsId) REFERENCES core.[cbs] (cbsId),
    CONSTRAINT fkcustomerCustomerUnapproved_customerCountry FOREIGN KEY(countryId) REFERENCES core.[country] (countryId),
    CONSTRAINT fkcustomerCustomerUnapproved_customerIndustry FOREIGN KEY(industryId) REFERENCES customer.industry (industryId),
    CONSTRAINT fkcustomerCustomerUnapproved_customerSector FOREIGN KEY(sectorId) REFERENCES customer.sector (sectorId),
    CONSTRAINT fkCustomerCustomerUnapproved_customerOrganizationId FOREIGN KEY (organizationId) REFERENCES [customer].[organization] (actorId)
)
