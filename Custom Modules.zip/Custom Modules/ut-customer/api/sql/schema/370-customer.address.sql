CREATE TABLE customer.[address]( -- table that stores all customer addresses information
    addressId INT IDENTITY(1000, 1) NOT NULL, -- the id of the address
    actorId BIGINT, -- the id of the actor, who the address belongs to
    value NVARCHAR (200) NOT NULL, -- the value of the address, incl. city, street, etc.
    frontEndRecordId VARCHAR (10), -- an id, needed for the frontend of the mobile app
    addressTypeId VARCHAR (20) NOT NULL, -- the addressTypeId, e.g. home, work
    statusId VARCHAR (20) NOT NULL, -- the statusId of the address, e.g. active/inactive
    oldValues XML NULL, -- history of old values of customer addresses
    city NVARCHAR(100), -- the city
    lat VARCHAR(50) NULL, -- the latitude of the respective address
    lng VARCHAR(50) NULL, -- the longitude of the respective address
    addressZone1 BIGINT NULL,
    addressZone2 BIGINT NULL,
    addressZone3 BIGINT NULL,
    addressZone4 BIGINT NULL,
    CONSTRAINT pkCustomerAddress PRIMARY KEY CLUSTERED(addressId ASC),
    CONSTRAINT fkCustomerAddress_coreActor FOREIGN KEY(actorId) REFERENCES core.actor (actorId),
    CONSTRAINT fkCustomerAddress_customerAddressType FOREIGN KEY(addressTypeId) REFERENCES customer.addressType (addressTypeId),
    CONSTRAINT fkCustomerAddress_coreStatus FOREIGN KEY(statusId) REFERENCES core.status (statusId)
)
