ALTER PROCEDURE customer.[address.add] -- create new addresss IN customer.address/customer.addressUnapproved TABLE
    @address customer.addressTT READONLY, -- IN this parameter the stored PROCEDURE receives all fields of addresss
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML
BEGIN TRY
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation

-- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    DECLARE @result customer.addressTT

    INSERT INTO customer.address (actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    OUTPUT INSERTED.addressId, INSERTED.actorId, INSERTED.value, INSERTED.addressTypeId, INSERTED.statusId, INSERTED.city, INSERTED.lat, INSERTED.lng, INSERTED.addressZone1, INSERTED.addressZone2, INSERTED.addressZone3, INSERTED.addressZone4
    INTO @result (addressId, actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4)
    SELECT actorId, value, addressTypeId, ISNULL(statusId, 'active'), city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
    FROM @address
    WHERE addressId IS NULL

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'address' AS resultSetName
        SELECT addressId, actorId, value, addressTypeId, statusId, city, lat, lng, addressZone1, addressZone2, addressZone3, addressZone4
        FROM @result
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
