ALTER PROCEDURE [customer].[person.editUnapproved] -- edits person information
    @person customer.personUnapprovedTT READONLY, -- the edited person information
    @email customer.emailUnapprovedTT READONLY, -- information about the e-mails of the person
    @phone customer.phoneUnapprovedTT READONLY, -- information about the phone numbers of the person
    @address customer.addressUnapprovedTT READONLY, -- information about the addresses of the person
    @noResultSet BIT = 0, -- a flag to show if result is expected
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
    DECLARE @callParams XML
    DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta) -- the id of the user that makes the operation
    DECLARE @result customer.personUnapprovedTT

    DECLARE @actorId BIGINT = (SELECT TOP 1 actorId FROM @person)

BEGIN TRY
    -- checks if the user has a right to make the operation
    DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
    EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta

    -- re-edit new AND existing persons IN the unapproved TABLE
    UPDATE pu
    SET pu.firstName = p.firstName,
        pu.middleName = p.middleName,
        pu.lastName = p.lastName,
        pu.nationalId = p.nationalId,
        pu.dateOfBirth = p.dateOfBirth,
        pu.placeOfBirth = p.placeOfBirth,
        pu.nationality = CASE WHEN c.name IS NOT NULL THEN c.name ELSE p.nationality END,
        pu.gender = p.gender,
        pu.bioId = p.bioId,
        pu.phoneModel = p.phoneModel,
        pu.computerModel = p.computerModel,
        pu.maritalStatusId = p.maritalStatusId,
        pu.age = p.age,
        pu.updatedBy = @userId,
        pu.updatedOn = SYSDATETIMEOFFSET(),
        pu.employerName = p.employerName,
        pu.employerCategoryId = p.employerCategoryId,
        pu.employmentDate = p.employmentDate,
        pu.educationId = p.educationId,
        pu.employmentId = p.employmentId,
        pu.familyMembers = p.familyMembers,
        pu.incomeRangeId = p.incomeRangeId
    FROM customer.personUnapproved pu
    JOIN @person p ON p.actorId = pu.actorId
    LEFT JOIN core.country c ON CAST(c.countryId AS VARCHAR(50)) = p.nationality

    -- insert new or existing edited persons FOR approval
    INSERT INTO [customer].[personUnapproved] (actorId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, updatedBy, updatedOn, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers)
    SELECT ph.actorId, ph.firstName, ph.lastName, ph.nationalId, ph.dateOfBirth, ph.placeOfBirth, CASE WHEN c.name IS NOT NULL THEN c.name ELSE ph.nationality END AS nationality, ph.gender, ph.bioId, ph.phoneModel, ph.computerModel, ph.isEnabled, ph.isDeleted, ph.maritalStatusId, ph.age, @userId, SYSDATETIMEOFFSET(), ph.middleName, ph.educationId, ph.employmentId, ph.employmentDate, ph.incomeRangeId, ph.employerName, ph.employerCategoryId, ph.familyMembers
    FROM @person ph
    LEFT JOIN customer.personUnapproved pu ON pu.actorId = ph.actorId
    LEFT JOIN core.country c ON CAST(c.countryId AS VARCHAR(50)) = ph.nationality
    WHERE pu.actorId IS NULL
    -- ph.personUnapprovedId IS NULL

    EXEC customer.[email.editUnapproved] @email = @email, @actorId = @actorId, @noResultSet = 1, @meta = @meta

    EXEC customer.[phone.editUnapproved] @phone = @phone, @actorId = @actorId, @noResultSet = 1, @meta = @meta

    EXEC customer.[address.editUnapproved] @address = @address, @actorId = @actorId, @noResultSet = 1, @meta = @meta

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'person' AS resultSetName, 1 AS single
        SELECT personUnapprovedId, actorId, frontEndRecordId, firstName, lastName, nationalId, dateOfBirth, placeOfBirth, nationality, gender, bioId, udf, phoneModel, computerModel, isEnabled, isDeleted, maritalStatusId, age, updatedBy, updatedOn, middleName, educationId, employmentId, employmentDate, incomeRangeId, employerName, employerCategoryId, familyMembers
        FROM [customer].[personUnapproved]
        WHERE actorId = @actorId
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    EXEC core.error
    RETURN 55555
END CATCH
