ALTER PROCEDURE customer.[customer.byPhoneGet] -- gets customer id by phone number
    @phoneNumber VARCHAR(50), -- searched customer phone number. The number will be send from ui with country prefix(without zeros and +), e.g. 359123456
    @countryId INT, -- the countryId of customer
    @meta core.metaDataTT READONLY -- information for the user that makes the operation
AS
DECLARE @userId BIGINT = (SELECT [auth.actorId] FROM @meta)
DECLARE @phonePrefix VARCHAR(10)

-- checks IF the user has a RIGHT to get user
DECLARE @actionID VARCHAR(100) = OBJECT_SCHEMA_NAME(@@PROCID) + '.' + OBJECT_NAME(@@PROCID), @return INT = 0
EXEC @return = [user].[permission.check] @actionId = @actionID, @objectId = NULL, @meta = @meta
IF @return != 0
BEGIN
    RETURN 55555
END

IF @countryId IS NULL
    SELECT @phonePrefix = phonePrefix, @countryId = c.countryId
    FROM [customer].[country] cc
    JOIN [customer].[customer] c ON cc.countryId = c.countryId
    WHERE c.actorId = @userId -- IF the transation IS local, we get the countryId of the user initiating the TRANSACTION

--DECLARE @phoneNumberWithoutPrefix VARCHAR(50) = customer.normalizePhone (@phoneNumber, @phonePrefix, 0)
DECLARE @phoneNumberWithoutPrefix VARCHAR(50) = SUBSTRING(@phoneNumber, LEN(@phonePrefix), LEN(@phoneNumber));

SELECT 'customerId' AS resultSetName, 1 AS single

SELECT TOP 1 p.actorId
FROM customer.phone p
JOIN customer.mno m ON p.mnoId = m.mnoId
JOIN core.country c ON m.countryId = c.countryId
WHERE p.phoneNumber = @phoneNumberWithoutPrefix AND p.statusId IN ('active', 'approved') AND p.isPrimary = 1 AND c.countryId = @countryId
