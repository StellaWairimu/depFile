ALTER PROCEDURE [customer].[smtpConfiguration.get] -- this sp gets the smtp server configuration for user by his email address
    @customerEmail NVARCHAR(50) -- the email of the customer
AS
    DECLARE @externalSystemId TINYINT;

    SET @externalSystemId =
        (
            SELECT TOP 1 es.externalSystemId
            FROM customer.email ce
            JOIN [core].[actorHierarchy] cp ON cp.[subject] = ce.actorId
            CROSS APPLY [customer].[organizationsChildrenOf] (cp.[object]) oc
            JOIN core.externalSystem es ON es.organizationId = oc.actorId
            JOIN core.externalSystemType est ON est.externalSystemTypeId = es.externalSystemTypeId
            WHERE [predicate] = 'memberOf' AND ce.[value] = @customerEmail AND est.[key] = 'smtp'
            ORDER BY depth
        )

    SELECT 'serverInfo' AS resultSetName, 1 AS single;

    SELECT es.hostNameIp, es.port, es.encryptionType, eu.userName, eu.password, eu.cryptArgs, es.serverTimeout
    FROM core.externalSystem AS es
    LEFT JOIN [user].externalUser AS eu ON eu.externalSystemId = es.externalSystemId
    WHERE es.externalSystemId = @externalSystemId;

    SELECT 'serverAttributes' AS resultSetName;

    SELECT esa.attributeName, esav.[value]
    FROM core.externalSystem AS es
    JOIN core.externalSystemAttributesValues AS esav ON esav.externalSystemId = es.externalSystemId
    JOIN core.externalSystemAttributes AS esa ON esa.attributeId = esav.attributeId
    WHERE es.externalSystemId = @externalSystemId;

