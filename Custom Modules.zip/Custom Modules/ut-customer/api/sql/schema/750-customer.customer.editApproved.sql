ALTER PROCEDURE customer.[customer.editApproved]
    @actorId BIGINT, -- customer id
    @meta core.metaDataTT READONLY, -- information for the user that makes the operation
    @noResultSet BIT = 0 -- this is the flag about the waited result
AS
DECLARE @callParams XML

BEGIN TRY

    EXEC customer.[person.editApproved] @actorId = @actorId, @noResultSet = @noResultSet, @meta = @meta

    EXEC ledger.[account.approve] @ownerId = @actorId, @meta = @meta

    EXEC document.[document.editApproved] @actorId = @actorId, @noResultSet = @noResultSet, @meta = @meta

    UPDATE c
    SET c.frontEndRecordId = cu.frontEndRecordId,
        c.customerNumber = cu.customerNumber,
        c.customerTypeId = cu.customerTypeId,
        c.kycId = cu.kycId,
        c.stateId = cu.stateId,
        c.statusId = 'approved',
        c.createdBy = cu.createdBy,
        c.createdOn = cu.createdOn,
        c.updatedBy = cu.updatedBy,
        c.updatedOn = cu.updatedOn,
        c.oldValues = cu.oldValues,
        c.customerCategoryId = cu.customerCategoryId,
        c.dao = cu.dao,
        c.description = cu.description,
        c.cbsId = cu.cbsId,
        c.countryId = cu.countryId,
        c.industryId = cu.industryId,
        c.sectorId = cu.sectorId,
        c.loanCycle = cu.loanCycle,
        c.organizationId = cu.organizationId,
        c.prospectClient = cu.prospectClient,
        c.adminFee = cu.adminFee,
        c.udf = cu.udf
    FROM [customer].[customer] c
    JOIN customer.customerUnapproved cu ON c.actorId = cu.actorId
    WHERE cu.actorId = @actorId

    DELETE FROM customer.customerUnapproved WHERE actorId = @actorId

    IF (ISNULL(@noResultSet, 0) = 0)
    BEGIN
        SELECT 'customer' AS resultSetName
        SELECT actorId, customerNumber, customerTypeId, kycId, stateId, statusId, createdBy, createdOn, updatedBy, updatedOn, customerCategoryId,
            dao, description, cbsId, countryId, industryId, sectorId, loanCycle, organizationId, prospectClient, adminFee
        FROM customer.customer
        WHERE actorId = @actorId
    END

    EXEC core.auditCall @procid = @@PROCID, @params = @callParams
END TRY
BEGIN CATCH
    IF @@trancount > 0
        ROLLBACK TRANSACTION
    EXEC core.error
    RETURN 55555
END CATCH
