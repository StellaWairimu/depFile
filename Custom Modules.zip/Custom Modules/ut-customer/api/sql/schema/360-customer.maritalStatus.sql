CREATE TABLE customer.maritalStatus( -- table that stores marital statuses
    maritalStatusId TINYINT IDENTITY(1, 1) NOT NULL, -- the id of the marital status
    cbsName NVARCHAR (50) NOT NULL, -- the value in T24
    name NVARCHAR(100), -- Name of the marital status
    itemNameId BIGINT, --translate of marital status
    CONSTRAINT pkCustomerMaritalStatus PRIMARY KEY CLUSTERED(maritalStatusId ASC),
    CONSTRAINT [fkCustomerMaritalStatusId_itemNameId] FOREIGN KEY(itemNameId) REFERENCES [core].[itemName] (itemNameId)
)
