CREATE TABLE [customer].[incomeRange]( --table that stores income range of the person
    [incomeRangeId] TINYINT IDENTITY(1, 1) NOT NULL, -- income range id
    [itemNameId] BIGINT NULL,
    CONSTRAINT pkCustomerIncomeRange PRIMARY KEY CLUSTERED(incomeRangeId ASC),
    CONSTRAINT [fkCustomerIncomeRange_itemNameId] FOREIGN KEY(itemNameId) REFERENCES [core].[itemName] (itemNameId)
)
