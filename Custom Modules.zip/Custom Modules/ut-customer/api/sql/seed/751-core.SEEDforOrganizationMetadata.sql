DECLARE @dataModel XML
SET @dataModel =
    '<object name = "organization" type = "businessObject" mainTableSchema = "customer" mainTableName = "organization" >
    <components>
    <component name = "get">
        <variables>
            <variable name = "@objectId" isSPParam = "1" definition = "BIGINT"/>
            <variable name = "@eventDate" isSPParam = "1" definition = "DATETIME2(3)"/>
        </variables>
    <subObjects>
        <subObject name ="organization.info" isSingle="1">
            <relations>
                <relation schemaName="customer" tableName="organization" tableAlias="o" joinType="FROM" joinOrder="1">
                    <fields>
                        <field sourceColumn = "actorId" />
                        <field sourceColumn = "frontEndRecordId" />
                        <field sourceColumn = "organizationName" />
                        <field sourceColumn = "code" />
                        <field sourceColumn = "executiveOfficer" />
                        <field sourceColumn = "tradeName" />
                        <field sourceColumn = "capital" />
                        <field sourceColumn = "currency" />
                        <field sourceColumn = "timeZone" />
                        <field sourceColumn = "primaryLanguageId" />
                        <field sourceColumn = "oldValues" />
                        <field sourceColumn = "isEnabled" />
                        <field sourceColumn = "isDeleted" />
                        <field sourceColumn = "cbsId" />
                        <field sourceColumn = "countryId" />
                    </fields>
                    <conditions>
                        <condition columnName = "actorId" definition = " = @objectId" />
                    </conditions>
                </relation>
                <relation schemaName="core" tableName="cbs" tableAlias="cbs" columnName="cbsId"  parentRelationAlias="o" parentColumn="cbsId" joinType="LEFT JOIN" joinOrder="2" >
                    <field sourceColumn = "name" columnAlias="cbsName" />
                </relation>
                <relation schemaName = "core" tableName = "country" tableAlias = "cc" columnName = "countryId" parentRelationAlias = "o" parentColumn = "countryId" joinType = "LEFT JOIN" joinOrder = "3">
                    <fields>
                        <field sourceColumn = "name" columnAlias = "countryName" />
                    </fields>
                </relation>
                <relation schemaName="core" tableName="language" tableAlias="cl" columnName="languageId" parentRelationAlias="o" parentColumn="primaryLanguageId" joinType="LEFT JOIN" joinOrder="4" additionalConditions="">
                <fields>
                    <field sourceColumn="name" columnAlias="primaryLanguageName" />
                </fields>
                </relation>
            </relations>
        </subObject>
        <subObject name ="organization.parents" isSingle="0">
            <relations>
                <relation schemaName="core" tableName="actorHierarchy" tableAlias="ah" joinType="FROM" joinOrder="1" >
                    <conditions>
                        <condition columnName = "[subject]" definition = " = @objectId" />
                        <condition columnName = "predicate" definition = " = ''memberOf''" />
                    </conditions>
                </relation>
                <relation schemaName="customer" tableName="organization" tableAlias="o" joinType="JOIN" columnName="actorId"  parentRelationAlias="ah" parentColumn="[object]" joinOrder="2">
                    <fields>
                        <field sourceColumn = "actorId" />
                        <field sourceColumn = "organizationName" />
                    </fields>
                </relation>
            </relations>
        </subObject>
        <subObject name ="organization.roles" isSingle="0">
            <relations>
                <relation schemaName="core" tableName="actorHierarchy" tableAlias="ah" joinType="FROM" joinOrder="1" >
                    <conditions>
                        <condition columnName = "[subject]" definition = " = @objectId" />
                        <condition columnName = "predicate" definition = " = ''role''" />
                    </conditions>
                </relation>
                <relation schemaName="user" tableName="role" tableAlias="r" joinType="JOIN" columnName="actorId"  parentRelationAlias="ah" parentColumn="[object]" joinOrder="2">
                    <fields>
                        <field sourceColumn = "actorId" />
                        <field sourceColumn = "name" />
                    </fields>
                </relation>
            </relations>
        </subObject>
        <subObject name = "organization.address" isSingle = "0" >
            <relations>
                <relation schemaName = "customer" tableName = "address" tableAlias = "a" joinType = "FROM" joinOrder = "1">
                    <fields>
                        <field sourceColumn = "addressId" />
                        <field sourceColumn = "actorId" />
                        <field sourceColumn = "value" />
                        <field sourceColumn = "frontEndRecordId" />
                        <field sourceColumn = "addressTypeId" />
                        <field sourceColumn = "statusId" />
                        <field sourceColumn = "city" />
                        <field sourceColumn = "lat" />
                        <field sourceColumn = "lng" />
                        <field sourceColumn = "addressZone1" columnAlias = "addressZone1Id" />
                        <field sourceColumn = "addressZone2" columnAlias = "addressZone2Id" />
                        <field sourceColumn = "addressZone3" columnAlias = "addressZone3Id" />
                        <field sourceColumn = "addressZone4" columnAlias = "addressZone4Id" />
                    </fields>
                    <conditions>
                        <condition columnName = "actorId" definition = " = @objectId" />
                    </conditions>
                </relation>
                <relation schemaName = "core" tableName = "itemName" tableAlias = "i1" columnName = "itemNameId" parentRelationAlias = "a" parentColumn = "addressZone1" joinType = "LEFT JOIN" joinOrder = "2">
                    <fields>
                        <field sourceColumn = "itemName" columnAlias = "addressZone1" />
                    </fields>
                </relation>
                <relation schemaName = "core" tableName = "itemName" tableAlias = "i2" columnName = "itemNameId" parentRelationAlias = "a" parentColumn = "addressZone2" joinType = "LEFT JOIN" joinOrder = "3">
                    <fields>
                        <field sourceColumn = "itemName" columnAlias = "addressZone2" />
                    </fields>
                </relation>
                <relation schemaName = "core" tableName = "itemName" tableAlias = "i3" columnName = "itemNameId" parentRelationAlias = "a" parentColumn = "addressZone3" joinType = "LEFT JOIN" joinOrder = "4">
                    <fields>
                        <field sourceColumn = "itemName" columnAlias = "addressZone3" />
                    </fields>
                </relation>
                <relation schemaName = "core" tableName = "itemName" tableAlias = "i4" columnName = "itemNameId" parentRelationAlias = "a" parentColumn = "addressZone4" joinType = "LEFT JOIN" joinOrder = "5">
                    <fields>
                        <field sourceColumn = "itemName" columnAlias = "addressZone4" />
                    </fields>
                </relation>
            </relations>
        </subObject>
        <subObject name = "organization.email" isSingle = "0" >
            <relations>
                <relation schemaName = "customer" tableName = "email" tableAlias = "a" joinType = "FROM" joinOrder = "1">
                    <fields>
                        <field sourceColumn = "emailId" />
                        <field sourceColumn = "actorId" />
                        <field sourceColumn = "value" />
                        <field sourceColumn = "frontEndRecordId" />
                        <field sourceColumn = "emailTypeId" />
                        <field sourceColumn = "statusId" />
                        <field sourceColumn = "oldValues" />
                        <field sourceColumn = "isPrimary" />
                    </fields>
                    <conditions>
                        <condition columnName = "actorId" definition = " = @objectId" />
                    </conditions>
                </relation>
        </relations>
        </subObject>
        <subObject name = "organization.phone" isSingle = "0" >
            <relations>
                <relation schemaName = "customer" tableName = "phone" tableAlias = "p" joinType = "FROM" joinOrder = "1">
                    <fields>
                        <field sourceColumn = "phoneId" />
                        <field sourceColumn = "actorId" />
                        <field sourceColumn = "frontEndRecordId" />
                        <field sourceColumn = "phoneTypeId" />
                        <field sourceColumn = "phoneNumber" />
                        <field sourceColumn = "statusId" />
                        <field sourceColumn = "oldValues" />
                        <field sourceColumn = "udf" />
                        <field sourceColumn = "mnoId" />
                        <field sourceColumn = "isPrimary" />
                    </fields>
                    <conditions>
                        <condition columnName = "actorId" definition = " = @objectId" />
                    </conditions>
                </relation>
                <relation schemaName = "customer" tableName = "mno" tableAlias = "mno" columnName = "mnoId" parentRelationAlias = "p" parentColumn = "mnoId" joinType = "LEFT JOIN" joinOrder = "2">
                    <fields>
                        <field sourceColumn = "ut5Key" columnAlias = "mnoKey" />
                        <field sourceColumn = "name" columnAlias = "mnoName" />
                    </fields>
                </relation>
            </relations>
        </subObject>
    </subObjects>
    </component>
    <component name = "fetch">
    <variables>
        <variable name = "@globalId" isSPParam = "1" definition = "UNIQUEIDENTIFIER"/>
        <variable name = "@eventDate" isSPParam = "1" definition = "DATETIME2(3)"/>
    </variables>
    <subObjects>
    <subObject name = "organizationFetch" isSingle = "0" >
        <relations>
        <relation schemaName = "customer" tableName = "organization" tableAlias = "co" joinType = "FROM" joinOrder = "1">
        <fields>
        <field sourceColumn = "actorId" columnAlias = "objectId" />
        <field sourceColumn = "organizationName" columnAlias = "shortDesc" />
        </fields>
        </relation>
        </relations>
        </subObject>
    </subObjects>
    </component>
    </components>
    </object>'

DECLARE @RC INT
DECLARE @removeDataFlag INT = 0
DECLARE @removeDataFlagLeaf INT = 1
DECLARE @updateFlag INT = 1
DECLARE @insertFlag INT = 1
DECLARE @noResultSet INT = 1

-- load object data
EXECUTE @RC = [meta].[dataModelXML.refresh]
    @dataModel,
    @removeDataFlag,
    @removeDataFlagLeaf,
    @updateFlag,
    @insertFlag,
    @noResultSet
