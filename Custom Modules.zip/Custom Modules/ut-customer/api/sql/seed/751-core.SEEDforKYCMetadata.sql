DECLARE @dataModel XML
SET @dataModel =
    '<object name = "kyc" type = "businessObject" mainTableSchema = "customer" mainTableName = "kyc" description="Kyc data model">
    <components>
    <component name = "get">
    <variables>
        <variable name = "@objectId" isSPParam = "1" definition = "BIGINT" />
        <variable name = "@eventDate" isSPParam = "1" definition = "DATETIME2(3)" />
    </variables>
    <subObjects>
        <subObject name = "kyc" isSingle = "1">
        <relations>
            <relation schemaName = "customer" tableName = "kyc" tableAlias = "k" joinType = "FROM" joinOrder = "1">
            <fields>
                <field sourceColumn = "kycId" fieldOrder = "1" />
                <field sourceColumn = "itemNameId" fieldOrder = "2" />
                <field sourceColumn = "description" fieldOrder = "3" />
                <field sourceColumn = "statusId" fieldOrder = "4" />
                <field sourceColumn = "organizationId" fieldOrder = "5" />
            </fields>
            <conditions>
            <condition columnName = "kycId" definition = " = @objectId" />
            </conditions>
        </relation>
        <relation schemaName = "customer" tableName = "customerType" tableAlias = "ct" columnName = "customerTypeNumber" parentRelationAlias = "k" parentColumn = "customerTypeId" joinType = "JOIN" joinOrder = "2" additionalConditions="">
            <fields>
                <field sourceColumn = "customerTypeId" columnAlias = "customerTypeId" fieldOrder = "6" />
                <field sourceColumn = "description" columnAlias = "customerType" fieldOrder = "7" />
                <field sourceColumn = "customerTypeNumber" columnAlias = "customerTypeNumber" fieldOrder = "8" />
            </fields>
        </relation>
        <relation schemaName = "customer" tableName = "organization" tableAlias = "o" columnName = "actorId" parentRelationAlias = "k" parentColumn = "organizationId" joinType = "JOIN" joinOrder = "3" additionalConditions="">
            <fields>
                <field sourceColumn = "organizationName" columnAlias = "organizationName" fieldOrder = "9" />
            </fields>
        </relation>
        <relation schemaName = "core" tableName = "itemTranslation" tableAlias = "it" columnName = "itemNameId" parentRelationAlias = "k" parentColumn = "itemNameId" joinType = "JOIN" joinOrder = "4" additionalConditions="">
            <fields>
                <field sourceColumn = "itemNameTranslation" columnAlias = "displayName" fieldOrder = "10" />
            </fields>
        </relation>
        <relation schemaName = "core" tableName = "itemName" tableAlias = "cin" columnName = "itemNameId" parentRelationAlias = "k" parentColumn = "itemNameId" joinType = "JOIN" joinOrder = "5" additionalConditions="">
            <fields>
                <field sourceColumn = "itemCode" columnAlias = "itemCode" fieldOrder = "11" />
            </fields>
        </relation>
        </relations>
    </subObject>
    <subObject name = "kycAttributes" isSingle = "0" >
        <relations>
        <relation schemaName = "customer" tableName = "kycConditionAttribute" tableAlias = "kca" joinType = "FROM" joinOrder = "1" additionalConditions="">
            <fields>
                <field sourceColumn = "kycConditionAttributeId" columnAlias = "kycConditionAttributeId" fieldOrder = "1" />
                <field sourceColumn = "conditionId" columnAlias = "conditionId" fieldOrder = "2" />
                <field sourceColumn = "attributeId" columnAlias = "attributeId" fieldOrder = "3" />
                <field sourceColumn = "conditionCheck" columnAlias = "conditionCheck" fieldOrder = "4" />
            </fields>
        </relation> 
            <relation schemaName = "customer" tableName = "kyc" tableAlias = "k" columnName = "kycId" parentRelationAlias = "kca" parentColumn = "kycId" joinType = "JOIN" joinOrder = "2" additionalConditions="">
            <conditions>
                <condition columnName = "kycId" definition = " = @objectId" />
                <condition columnName = "isDeleted" definition = " = 0" />
            </conditions>
        </relation>
        <relation schemaName = "core" tableName = "itemName" tableAlias = "cin" columnName = "itemNameId" parentRelationAlias = "kca" parentColumn = "attributeId" joinType = "JOIN" joinOrder = "3" additionalConditions="">
            <fields>
                <field sourceColumn = "itemCode" columnAlias = "itemCode" fieldOrder = "5" />
            </fields>
        </relation>
        <relation schemaName = "core" tableName = "itemTranslation" tableAlias = "it" columnName = "itemNameId" parentRelationAlias = "kca" parentColumn = "attributeId" joinType = "JOIN" joinOrder = "4" additionalConditions="">
            <fields>
                <field sourceColumn = "itemNameTranslation" columnAlias = "itemNameTranslation" fieldOrder = "6" />
            </fields>
        </relation>
        </relations>
    </subObject>
    </subObjects>
    </component>
    <component name = "fetch">
    <variables>
        <variable name = "@globalId" isSPParam = "1" definition = "UNIQUEIDENTIFIER"/>
        <variable name = "@eventDate" isSPParam = "1" definition = "DATETIME2(3)"/>
    </variables>
    <subObjects> 
    <subObject name = "customerKycFetch" isSingle = "0" >
        <relations>
        <relation schemaName = "customer" tableName = "kyc" tableAlias = "k" joinType = "FROM" joinOrder = "1" additionalConditions="">
            <fields>
            <field sourceColumn = "kycId" columnAlias = "objectId" fieldOrder = "1" />
            <field sourceColumn = "organizationId" columnAlias = "shortDesc" fieldOrder = "2" />
            </fields>
        </relation>
        </relations>
    </subObject>
    </subObjects>
    </component>
    </components>
    </object>'


DECLARE @RC INT
DECLARE @removeDataFlag INT = 0
DECLARE @removeDataFlagLeaf INT = 1
DECLARE @updateFlag INT = 1
DECLARE @insertFlag INT = 1
DECLARE @noResultSet INT = 1

-- load object data
EXECUTE @RC = [meta].[dataModelXML.refresh]
    @dataModel,
    @removeDataFlag,
    @removeDataFlagLeaf,
    @updateFlag,
    @insertFlag,
    @noResultSet
