DECLARE @customerActionCategoryId INT = (SELECT actionCategoryId FROM [user].[actionCategory] WHERE name = 'customer')

IF @customerActionCategoryId IS NULL
BEGIN
    INSERT INTO [user].[actionCategory](name)
    VALUES ('customer')

    SET @customerActionCategoryId = SCOPE_IDENTITY()
END

DECLARE @action [user].[actionTT]

INSERT INTO @action ([actionId], [actionCategoryId], [description], [valueMap])

VALUES ('customer.referral.add', @customerActionCategoryId, 'Add new referral', '{}'),
    ('customer.referral.get' , @customerActionCategoryId , 'Get referral', '{}'),
    ('customer.referral.fetch', @customerActionCategoryId , 'Fetch list of referrals', '{}'),
    ('customer.referral.delete', @customerActionCategoryId, 'Delete referral', '{}'),
    ('customer.referral.expired', @customerActionCategoryId, 'Expire referral', '{}'),
    ('customer.referral.getReferre', @customerActionCategoryId, 'Get referral customer', '{}'),
    ('customer.referral.statusFetch', @customerActionCategoryId, 'Fetch referral statuses', '{}'),
    ('customer.referral.statusUpdate', @customerActionCategoryId, 'Update referral status', '{}'),
    ('customer.referral.approveNew', @customerActionCategoryId, '', '{}'),
    ('customer.referral.reject', @customerActionCategoryId, '', '{}'),
    ('customer.referral.openAccount', @customerActionCategoryId, '', '{}'),
    ('customer.referral.deactivate', @customerActionCategoryId, '', '{}'),
    ('customer.referral.complete', @customerActionCategoryId, '', '{}'),
    ('customer.referral.approveDeactivation', @customerActionCategoryId, '', '{}'),
    ('customer.referral.rejectDeactivation', @customerActionCategoryId, '', '{}'),
    ('customer.referral.statusCheckerUpdate', @customerActionCategoryId, '', '{}'),
    ('customer.referral.statusMakerUpdate', @customerActionCategoryId, '', '{}'),
    ('customer.referral.approve', @customerActionCategoryId, '', '{}');
MERGE INTO [user].[action] AS dd
USING
(
    SELECT [actionId], [actionCategoryId], [description], [valueMap]
    FROM @action
) d ON dd.actionId = d.actionId

WHEN NOT MATCHED BY TARGET THEN
    INSERT ([actionId], [actionCategoryId], [description], [valueMap])
    VALUES ([actionId], [actionCategoryId], [description], [valueMap]);


