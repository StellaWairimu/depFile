DECLARE @dataModel XML
SET @dataModel =
    '<object name = "customer" type = "businessObject" mainTableSchema = "customer" mainTableName = "customer" >
    <components>
      <component name = "get">
      <variables>
        <variable name = "@objectId" isSPParam = "1" definition = "BIGINT"/> 
        <variable name = "@eventDate" isSPParam = "1" definition = "DATETIME2(3)"/>
        <variable name = "@languageId" isSPParam = "0" definition = "BIGINT
          SET @languageId = (SELECT languageId
                                        FROM [externalMain].[core.language] cl
                                        JOIN [externalMain].[user.session] us ON us.[language] = cl.[iso2Code]
                                        WHERE us.[actorId] = (SELECT [auth.actorId] FROM @meta)) "/>
      </variables>
      <subObjects>
        <subObject name = "customer" isSingle = "0">
          <relations>
        <relation schemaName = "customer" tableName = "customer" tableAlias = "c" joinType = "FROM" joinOrder = "1">
          <fields>
          <field sourceColumn = "actorId" />
          <field sourceColumn = "frontEndRecordId" />
          <field sourceColumn = "customerNumber" />
          <field sourceColumn = "customerTypeId" /> 
          <field sourceColumn = "kycId" />
          <field sourceColumn = "stateId" />
          <field sourceColumn = "statusId" />
          <field sourceColumn = "createdBy" />
          <field sourceColumn = "createdOn" />
          <field sourceColumn = "updatedBy" />
          <field sourceColumn = "updatedOn" />
          <field sourceColumn = "customerCategoryId" />
          <field sourceColumn = "dao" />
          <field sourceColumn = "description" />  
          <field sourceColumn = "cbsId" />  
          <field sourceColumn = "countryId" />  
          <field sourceColumn = "industryId" />  
          <field sourceColumn = "sectorId" />  
          <field sourceColumn = "loanCycle" /> 
          <field sourceColumn = "organizationId" />  
          <field sourceColumn = "prospectClient" />  
          <field sourceColumn = "adminFee" />  
          </fields>
          <conditions>
          <condition  columnName = "actorId" definition = " = @objectId" />
          </conditions>
        </relation> 
        <relation schemaName = "customer" tableName = "state" tableAlias = "s" columnName = "stateId" parentRelationAlias = "c" parentColumn = "stateId" joinType = "JOIN" joinOrder = "2">
          <fields>
          <field columnAlias = "stateValue" sourceColumn = "display" />
          </fields>
        </relation> 
        <relation schemaName = "customer" tableName = "kyc" tableAlias = "k" columnName = "kycId" parentRelationAlias = "c" parentColumn = "kycId" joinType = "LEFT JOIN" joinOrder = "3" >
          <fields>
          <field columnAlias = "kycValue" sourceColumn = "display" /> 
          </fields>
        </relation> 
        <relation schemaName = "core" tableName = "cbs" tableAlias = "cbs" columnName = "cbsId" parentRelationAlias = "c" parentColumn = "cbsId" joinType = "LEFT JOIN" joinOrder = "4" >
          <fields>
          <field columnAlias = "cbsPort"  sourceColumn = "ut5Key" />
          </fields>
        </relation> 
        <relation schemaName = "core" tableName = "country" tableAlias = "country" columnName = "countryId" parentRelationAlias = "c" parentColumn = "countryId" joinType = "LEFT JOIN" joinOrder = "5">
          <fields>
          <field columnAlias = "country"  sourceColumn = "name" /> 
          <field columnAlias = "departmentId" sourceColumn = "countryId" /> 
          </fields>
        </relation> 
        <relation schemaName = "customer" tableName = "industry" tableAlias = "ci" columnName = "industryId" parentRelationAlias = "c" parentColumn = "industryId" joinType = "LEFT JOIN" joinOrder = "6">
        </relation>      
        <relation schemaName = "core" tableName = "itemName" tableAlias = "i" columnName = "itemNameId" parentRelationAlias = "ci" parentColumn = "itemNameId" joinType = "LEFT JOIN" joinOrder = "7">
          <fields>
          <field sourceColumn = "itemName" columnAlias = "industryName" />  
          </fields>
        </relation>

              <relation schemaName = "customer" tableName = "organization" tableAlias = "o" columnName = "actorId" parentRelationAlias = "c" parentColumn = "organizationId" joinType = "LEFT JOIN" joinOrder = "8">
          <fields>
          <field sourceColumn = "organizationName" />
          </fields>
        </relation> 
          </relations>
        </subObject>
      <subObject name = "person" isSingle = "0" >
          <relations>
        <relation schemaName = "customer" tableName = "person" tableAlias = "p" joinType = "FROM" joinOrder = "1">
          <fields>
          <field sourceColumn = "actorId" />
          <field sourceColumn = "frontEndRecordId" />
          <field sourceColumn = "firstName" />
          <field sourceColumn = "lastName" /> 
          <field sourceColumn = "nationalId" />
          <field sourceColumn = "nationality" />
          <field sourceColumn = "dateOfBirth" />
          <field sourceColumn = "placeOfBirth" />
          <field sourceColumn = "gender" />
          <field sourceColumn = "bioId" />
          <field sourceColumn = "udf" />
          <field sourceColumn = "phoneModel" />
          <field sourceColumn = "computerModel" />
          <field sourceColumn = "isEnabled" />
          <field sourceColumn = "isDeleted" />
          <field sourceColumn = "maritalStatusId" />
          <field sourceColumn = "age" />
          <field sourceColumn = "middleName" />
          <field sourceColumn = "educationId" />
          <field sourceColumn = "employmentId" />
          <field sourceColumn = "employmentDate" />
          <field sourceColumn = "incomeRangeId" />
          <field sourceColumn = "employerName" />
          <field sourceColumn = "employerCategoryId" />
          <field sourceColumn = "familyMembers" />
          </fields>
          <conditions>
          <condition columnName = "actorId" definition = " = @objectId" />
          </conditions>
        </relation> 
            <relation schemaName = "customer" tableName = "education" tableAlias = "e" columnName = "educationId" parentRelationAlias = "p" parentColumn = "educationId" joinType = "LEFT JOIN" joinOrder = "2">
        </relation> 
            <relation schemaName = "core" tableName = "itemName" tableAlias = "i" columnName = "itemNameId" parentRelationAlias = "e" parentColumn = "itemNameId" joinType = "LEFT JOIN" joinOrder = "3">
          <fields>
          <field columnAlias = "educationName"   sourceColumn = "itemName" /> 
          </fields>
        </relation> 
        <relation schemaName = "customer" tableName = "employerCategory" tableAlias = "ec" columnName = "employerCategoryId" parentRelationAlias = "p" parentColumn = "employerCategoryId" joinType = "LEFT JOIN" joinOrder = "4">
        </relation> 
            <relation schemaName = "core" tableName = "itemName" tableAlias = "i1" columnName = "itemNameId" parentRelationAlias = "ec" parentColumn = "itemNameId" joinType = "LEFT JOIN" joinOrder = "5">
          <fields>
          <field columnAlias = "employerCategoryName"  sourceColumn = "itemName" /> 
          </fields>
        </relation>  
        <relation schemaName = "customer" tableName = "employment" tableAlias = "ee" columnName = "employmentId" parentRelationAlias = "p" parentColumn = "employmentId" joinType = "LEFT JOIN" joinOrder = "6">
        </relation> 
            <relation schemaName = "core" tableName = "itemName" tableAlias = "i2" columnName = "itemNameId" parentRelationAlias = "ee" parentColumn = "itemNameId" joinType = "LEFT JOIN" joinOrder = "7">
          <fields>
          <field columnAlias = "employmentName"  sourceColumn = "itemName" /> 
          </fields>
        </relation> 
        <relation schemaName = "customer" tableName = "incomeRange" tableAlias = "ir" columnName = "incomeRangeId" parentRelationAlias = "p" parentColumn = "incomeRangeId" joinType = "LEFT JOIN" joinOrder = "8">
        </relation>  
        <relation schemaName = "core" tableName = "itemName" tableAlias = "i3" columnName = "itemNameId" parentRelationAlias = "ir" parentColumn = "itemNameId" joinType = "LEFT JOIN" joinOrder = "9">
          <fields>
          <field sourceColumn = "itemName" columnAlias = "incomeRangeName" />  
          </fields>
        </relation>
        <relation schemaName = "customer" tableName = "maritalStatus" tableAlias = "ms" columnName = "maritalStatusId" parentRelationAlias = "p" parentColumn = "maritalStatusId" joinType = "LEFT JOIN" joinOrder = "10">
        </relation>  
        <relation schemaName = "core" tableName = "itemName" tableAlias = "i4" columnName = "itemNameId" parentRelationAlias = "ms" parentColumn = "itemNameId" joinType = "LEFT JOIN" joinOrder = "11">
          <fields>
          <field sourceColumn = "itemName" columnAlias = "maritalStatusName" />  
          </fields>
        </relation>
        </relations>
        </subObject>
      <subObject name = "account" isSingle = "0" >
          <relations>
        <relation schemaName = "ledger" tableName = "account" tableAlias = "a" joinType = "FROM" joinOrder = "1">
          <fields>
          <field sourceColumn = "accountId" />
          <field sourceColumn = "accountName" />
          <field sourceColumn = "accountNumber" />
          <field sourceColumn = "businessUnitId" />
          <field sourceColumn = "statusId" />
          <field sourceColumn = "stateId" />
          <field sourceColumn = "createdBy" />
          <field sourceColumn = "createdOn" />
          <field sourceColumn = "linkedAccount" />
          <field sourceColumn = "ownerId" />
          <field sourceColumn = "analytic1TypeId" />
          <field sourceColumn = "analytic2TypeId" />
          <field sourceColumn = "analytic3TypeId" />
          <field sourceColumn = "analytic4TypeId" />
          <field sourceColumn = "isDeleted" />
          <field sourceColumn = "checkAmount" />
          <field sourceColumn = "checkMask" />
          <field sourceColumn = "" definition = "CASE WHEN a.statusId = ''new'' THEN 1 ELSE 0 END" columnAlias = "isNew" />
          </fields>
          <conditions>
          <condition columnName = "ownerId" definition = " = @objectId" />
          </conditions>
        </relation> 
        <relation schemaName = "ledger" tableName = "balance" tableAlias = "b" columnName = "accountId" parentRelationAlias = "a" parentColumn = "accountId" joinType = "LEFT JOIN" joinOrder = "2">
          <fields>
          <field sourceColumn = "" definition = "isnull(b.credit - b.debit, 0)" columnAlias = "balance"/>
          </fields>
        </relation>   
        <relation schemaName = "ledger" tableName = "product" tableAlias = "pr" columnName = "productId" parentRelationAlias = "a" parentColumn = "productId" joinType = "JOIN" joinOrder = "3">
          <fields>
          <field sourceColumn = "productCode" />
          </fields>
        </relation> 
        <relation schemaName = "core" tableName = "itemName" tableAlias = "npr" columnName = "itemNameId" parentRelationAlias = "pr" parentColumn = "itemNameId" joinType = "JOIN" joinOrder = "4">
          <fields>
          <field sourceColumn = "itemNameId" columnAlias = "productNameId"/>
          </fields>
        </relation> 
        <relation schemaName = "core" tableName = "itemName" tableAlias = "npt" columnName = "itemNameId" parentRelationAlias = "pr" parentColumn = "productTypeId" joinType = "JOIN" joinOrder = "5">
          <fields>
          <field sourceColumn = "itemName" columnAlias = "productTypeName"/>
          </fields>
              </relation> 
        <relation schemaName = "core" tableName = "itemName" tableAlias = "ng" columnName = "itemNameId" parentRelationAlias = "npt" parentColumn = "parentItemNameId" joinType = "JOIN" joinOrder = "6">
          <fields>
          <field sourceColumn = "itemNameId" columnAlias = "productGroupId"/>
          </fields>      
        </relation>
        <relation schemaName = "core" tableName = "currency" tableAlias = "c" columnName = "currencyId" parentRelationAlias = "pr" parentColumn = "currencyId" joinType = "JOIN" joinOrder = "7">
        </relation>  
        <relation schemaName = "core" tableName = "itemName" tableAlias = "n" columnName = "itemNameId" parentRelationAlias = "c" parentColumn = "itemNameId" joinType = "JOIN" joinOrder = "8">
        </relation> 
        <relation schemaName = "ledger" tableName = "state" tableAlias = "s" columnName = "stateId" parentRelationAlias = "a" parentColumn = "stateId" joinType = "JOIN" joinOrder = "9">
        </relation>   
        <relation schemaName = "core" tableName = "itemName" tableAlias = "ss" columnName = "itemNameId" parentRelationAlias = "s" parentColumn = "itemNameId" joinType = "JOIN" joinOrder = "10">
        </relation> 
        <relation schemaName = "customer" tableName = "organization" tableAlias = "o" columnName = "actorId" parentRelationAlias = "a" parentColumn = "businessUnitId" joinType = "JOIN" joinOrder = "11">
          <fields>
          <field sourceColumn = "organizationName" />
          </fields>
        </relation> 
        <relation schemaName = "core" tableName = "itemTranslation" tableAlias = "it" columnName = "itemNameId" parentRelationAlias = "n" parentColumn = "itemNameId" joinType = "LEFT JOIN" joinOrder = "12" additionalConditions = " AND it.languageId  = @languageId">
          <fields>
          <field sourceColumn = "" definition = "isnull(it.itemNameTranslation, n.itemName)" columnAlias = "currencyName" />
          </fields>
        </relation> 
        <relation schemaName = "core" tableName = "itemTranslation" tableAlias = "ittn" columnName = "itemNameId" parentRelationAlias = "ng" parentColumn = "itemNameId" joinType = "LEFT JOIN" joinOrder = "13" additionalConditions = " AND ittn.languageId  = @languageId">
          <fields>
          <field sourceColumn = "" definition = "isnull(ittn.itemNameTranslation, ng.itemName)" columnAlias = "productGroup" />
          </fields>
        </relation> 
        <relation schemaName = "core" tableName = "itemTranslation" tableAlias = "ittnt" columnName = "itemNameId" parentRelationAlias = "npt" parentColumn = "itemNameId" joinType = "LEFT JOIN" joinOrder = "14">
        </relation> 
        <relation schemaName = "core" tableName = "itemTranslation" tableAlias = "ittnn" columnName = "itemNameId" parentRelationAlias = "npr" parentColumn = "itemNameId" joinType = "LEFT JOIN" joinOrder = "15" additionalConditions = " AND ittn.languageId  = @languageId">
          <fields>
          <field sourceColumn = "" definition = "isnull(ittnn.itemNameTranslation, npr.itemName)" columnAlias = "productName" />
          </fields>
        </relation> 
        <relation schemaName = "ledger" tableName = "state" tableAlias = "st" columnName = "stateId" parentRelationAlias = "a" parentColumn = "stateId" joinType = "JOIN" joinOrder = "17">
        </relation> 
        <relation schemaName = "core" tableName = "itemName" tableAlias = "inSt" columnName = "itemNameId" parentRelationAlias = "st" parentColumn = "itemNameId" joinType = "JOIN" joinOrder = "18">
          <fields>
          <field sourceColumn = "itemName" columnAlias = "stateName"/>
          <field sourceColumn = "itemCode" columnAlias = "stateCode"/>
          </fields>
        </relation>
        <relation schemaName = "core" tableName = "itemTranslation" tableAlias = "itts" columnName = "itemNameId" parentRelationAlias = "ss" parentColumn = "itemNameId" joinType = "LEFT JOIN" joinOrder = "18">
        </relation> 
          </relations>
        </subObject>  
      <subObject name = "accountPerson" isSingle = "0" >
          <relations>
        <relation schemaName = "ledger" tableName = "account" tableAlias = "a" joinType = "FROM" joinOrder = "1">
          <fields>
          <field sourceColumn = "accountId" />
          <field sourceColumn = "accountName" />
          <field sourceColumn = "updatedBy" />
          <field sourceColumn = "businessUnitId" />
          <field sourceColumn = "productId" />
          <field sourceColumn = "ownerId" />
          </fields>
          <conditions>
          <condition columnName = "ownerId" definition = " = @objectId" />
          </conditions>
        </relation> 
        <relation schemaName = "ledger" tableName = "accountPerson" tableAlias = "ap" columnName = "accountId" parentRelationAlias = "a" parentColumn = "accountId" joinType = "JOIN" joinOrder = "2">
          <fields>
          <field sourceColumn = "personId" />
          </fields>
        </relation> 
        <relation schemaName = "customer" tableName = "person" tableAlias = "p" columnName = "actorId" parentRelationAlias = "ap" parentColumn = "personId" joinType = "LEFT JOIN" joinOrder = "3">
        </relation> 
        <relation schemaName = "ledger" tableName = "balance" tableAlias = "b" columnName = "accountId" parentRelationAlias = "a" parentColumn = "accountId" joinType = "LEFT JOIN" joinOrder = "4">
          <fields>
          <field sourceColumn = "" definition = "isnull(b.credit - b.debit, 0)" columnAlias = "balance" />
          </fields>
        </relation>     
          </relations>
        </subObject>
      <subObject name = "address" isSingle = "0" >
          <relations>
        <relation schemaName = "customer" tableName = "address" tableAlias = "a" joinType = "FROM" joinOrder = "1">
          <fields>
          <field sourceColumn = "addressId" />
          <field sourceColumn = "actorId" />
          <field sourceColumn = "value" />
          <field sourceColumn = "frontEndRecordId" />
          <field sourceColumn = "addressTypeId" />
          <field sourceColumn = "statusId" />
          <field sourceColumn = "city" />
          <field sourceColumn = "lat" />
          <field sourceColumn = "lng" />
          <field sourceColumn = "addressZone1" columnAlias = "addressZone1Id" />
          <field sourceColumn = "addressZone2" columnAlias = "addressZone2Id" />
          <field sourceColumn = "addressZone3" columnAlias = "addressZone3Id" />
          <field sourceColumn = "addressZone4" columnAlias = "addressZone4Id" />    
          </fields>
          <conditions>
          <condition columnName = "actorId" definition = " = @objectId" />
          </conditions>
        </relation> 
        <relation schemaName = "core" tableName = "itemName" tableAlias = "i1" columnName = "itemNameId" parentRelationAlias = "a" parentColumn = "addressZone1" joinType = "LEFT JOIN" joinOrder = "2">
          <fields>
          <field sourceColumn = "itemName" columnAlias = "addressZone1" />  
          </fields>
        </relation> 
        <relation schemaName = "core" tableName = "itemName" tableAlias = "i2" columnName = "itemNameId" parentRelationAlias = "a" parentColumn = "addressZone2" joinType = "LEFT JOIN" joinOrder = "3">
          <fields>
          <field sourceColumn = "itemName" columnAlias = "addressZone2" />  
          </fields>
        </relation> 
        <relation schemaName = "core" tableName = "itemName" tableAlias = "i3" columnName = "itemNameId" parentRelationAlias = "a" parentColumn = "addressZone3" joinType = "LEFT JOIN" joinOrder = "4">
          <fields>
          <field sourceColumn = "itemName" columnAlias = "addressZone3" />  
          </fields>
        </relation>   
        <relation schemaName = "core" tableName = "itemName" tableAlias = "i4" columnName = "itemNameId" parentRelationAlias = "a" parentColumn = "addressZone4" joinType = "LEFT JOIN" joinOrder = "5">
          <fields>
          <field sourceColumn = "itemName" columnAlias = "addressZone4" />  
          </fields>
        </relation>     
          </relations>
        </subObject>    
      <subObject name = "email" isSingle = "0" >
          <relations>
        <relation schemaName = "customer" tableName = "email" tableAlias = "a" joinType = "FROM" joinOrder = "1">
          <fields>
          <field sourceColumn = "emailId" />
          <field sourceColumn = "actorId" />
          <field sourceColumn = "value" />
          <field sourceColumn = "frontEndRecordId" />
          <field sourceColumn = "emailTypeId" />
          <field sourceColumn = "statusId" />
          <field sourceColumn = "oldValues" />
          <field sourceColumn = "isPrimary" />  
          </fields>
          <conditions>
          <condition columnName = "actorId" definition = " = @objectId" />
          </conditions>
        </relation> 
          </relations>
        </subObject>
      <subObject name = "phone" isSingle = "0" >
          <relations>
        <relation schemaName = "customer" tableName = "phone" tableAlias = "p" joinType = "FROM" joinOrder = "1">
          <fields>
          <field sourceColumn = "phoneId" />
          <field sourceColumn = "actorId" />
          <field sourceColumn = "frontEndRecordId" />
          <field sourceColumn = "phoneTypeId" />
          <field sourceColumn = "phoneNumber" />
          <field sourceColumn = "statusId" />
          <field sourceColumn = "oldValues" />
          <field sourceColumn = "udf" />
          <field sourceColumn = "mnoId" />
          <field sourceColumn = "isPrimary" />
          </fields>
          <conditions>
          <condition columnName = "actorId" definition = " = @objectId" />
          </conditions>
        </relation>  
        <relation schemaName = "customer" tableName = "mno" tableAlias = "mno" columnName = "mnoId" parentRelationAlias = "p" parentColumn = "mnoId" joinType = "LEFT JOIN" joinOrder = "2">
          <fields>
          <field sourceColumn = "ut5Key" columnAlias = "mnoKey" />  
          <field sourceColumn = "name" columnAlias = "mnoName" />  
          </fields>
        </relation>   
          </relations>
        </subObject>
      <subObject name = "document" isSingle = "0" >
          <relations>
        <relation schemaName = "document" tableName = "document" tableAlias = "du" joinType = "FROM" joinOrder = "1">
          <fields>
          <field sourceColumn = "documentId" />
          <field sourceColumn = "documentTypeId" />
          <field sourceColumn = "statusId" />
          <field sourceColumn = "expirationDate" />
          <field sourceColumn = "oldValues" />
          <field sourceColumn = "documentNumber" />
          <field sourceColumn = "description" />
          <field sourceColumn = "createdDate" />
          <field sourceColumn = "countryId" />
          </fields>
        </relation>  
        <relation schemaName = "document" tableName = "actorDocument" tableAlias = "adu" columnName = "documentId" parentRelationAlias = "du" parentColumn = "documentId" joinType = "JOIN" joinOrder = "2">
          <fields>
          <field sourceColumn = "documentOrder" />
          </fields>
          <conditions>
          <condition columnName = "actorId" definition = " = @objectId" />
          </conditions>
        </relation>   
        <relation schemaName = "document" tableName = "documentType" tableAlias = "dt" columnName = "documentTypeId" parentRelationAlias = "du" parentColumn = "documentTypeId" joinType = "LEFT JOIN" joinOrder = "3">
        </relation>  
        <relation schemaName = "core" tableName = "itemTranslation" tableAlias = "itt" columnName = "itemNameId" parentRelationAlias = "dt" parentColumn = "itemNameId" joinType = "LEFT JOIN" joinOrder = "4" additionalConditions = " AND itt.languageId  = @languageId">
          <fields>
          <field sourceColumn = "itemNameTranslation" columnAlias = "documentTypeName" />  
          </fields>
        </relation>
        <relation schemaName = "core" tableName = "country" tableAlias = "cc" columnName = "countryid" parentRelationAlias = "du" parentColumn = "countryid" joinType = "LEFT JOIN" joinOrder = "5">
          <fields>
          <field sourceColumn = "name" columnAlias = "countryName" />  
          </fields>  
        </relation>      
          </relations>
        </subObject>
      <subObject name = "attachment" isSingle = "0" >
          <relations>
        <relation schemaName = "document" tableName = "attachment" tableAlias = "au" joinType = "FROM" joinOrder = "1">
          <fields>
          <field sourceColumn = "attachmentId" />
          <field sourceColumn = "contentType" />
          <field sourceColumn = "extension" />
          <field sourceColumn = "filename" />
          <field sourceColumn = "documentId" />
          <field sourceColumn = "attachmentSizeId" />
          <field sourceColumn = "page" />
          <field sourceColumn = "oldValues" />
          </fields>
        </relation>  
        <relation schemaName = "document" tableName = "actorDocument" tableAlias = "adu" columnName = "documentId" parentRelationAlias = "au" parentColumn = "documentId" joinType = "JOIN" joinOrder = "2">
          <fields>
          <field sourceColumn = "documentOrder" />
          </fields>
          <conditions>
          <condition columnName = "actorId" definition = " = @objectId" />
          </conditions>
        </relation>   
        <relation schemaName = "document" tableName = "document" tableAlias = "d" columnName = "documentId" parentRelationAlias = "au" parentColumn = "documentId" joinType = "JOIN" joinOrder = "3">
        </relation>  
          </relations>
        </subObject>
      </subObjects>
      </component>  
      <component name = "fetch">
      <variables>
        <variable name = "@globalId" isSPParam = "1" definition = "UNIQUEIDENTIFIER"/> 
        <variable name = "@eventDate" isSPParam = "1" definition = "DATETIME2(3)"/> 
      </variables>
      <subObjects> 
      <subObject name = "customerFetch" isSingle = "0" >
          <relations>
        <relation schemaName = "customer" tableName = "customer" tableAlias = "c" joinType = "FROM" joinOrder = "1">
          <fields>
          <field sourceColumn = "actorId" columnAlias = "objectId" />
          <field sourceColumn = "customerNumber" columnAlias = "shortDesc" />
          </fields>
        </relation>  
          </relations>
        </subObject>  
      </subObjects>
      </component>
    </components>  
    </object>'

DECLARE @RC INT
DECLARE @removeDataFlag INT = 0
DECLARE @removeDataFlagLeaf INT = 1
DECLARE @updateFlag INT = 1
DECLARE @insertFlag INT = 1
DECLARE @noResultSet INT = 1

-- load object data
EXECUTE @RC = [meta].[dataModelXML.refresh]
    @dataModel,
    @removeDataFlag,
    @removeDataFlagLeaf,
    @updateFlag,
    @insertFlag,
    @noResultSet
