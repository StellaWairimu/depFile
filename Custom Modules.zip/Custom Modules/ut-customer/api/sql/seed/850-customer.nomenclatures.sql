-- account type
MERGE INTO customer.accountType AS target
USING
    (VALUES
        ('mwallet', 'mwallet', 'active'),
        ('savings', 'savings', 'active')
    ) AS source (accountTypeCode, description, statusId)
ON target.accountTypeCode = source.accountTypeCode
WHEN NOT MATCHED BY TARGET THEN
INSERT (accountTypeCode, description, statusId)
VALUES (accountTypeCode, description, statusId);

-- address type
MERGE INTO customer.addressType AS target
USING
    (VALUES
        ('home', 'home', 'active'),
        ('work', 'work', 'active')
    ) AS source (addressTypeId, description, statusId)
ON target.addressTypeId = source.addressTypeId
WHEN NOT MATCHED BY TARGET THEN
INSERT (addressTypeId, description, statusId)
VALUES (addressTypeId, description, statusId);

-- email type
MERGE INTO customer.emailType AS target
USING
    (VALUES
        ('personal', 'personal', 'active'),
        ('work', 'work', 'active')
    ) AS source (emailTypeId, description, statusId)
ON target.emailTypeId = source.emailTypeId
WHEN NOT MATCHED BY TARGET THEN
INSERT (emailTypeId, description, statusId)
VALUES (emailTypeId, description, statusId);

-- phone type
MERGE INTO customer.phoneType AS target
USING
    (VALUES
        ('personal', 'personal', 'active'),
        ('work', 'work', 'active'),
        ('home', 'home', 'active')
    ) AS source (phoneTypeId, description, statusId)
ON target.phoneTypeId = source.phoneTypeId
WHEN NOT MATCHED BY TARGET THEN
INSERT (phoneTypeId, description, statusId)
VALUES (phoneTypeId, description, statusId);

-- state
MERGE INTO customer.state AS target
USING
    (VALUES
        ('pending', 'Pending', 'must be validated by BO/CA for clients created with Pulse', 'active'),
        ('blocked', 'Blocked', 'blocked', 'active'),
        ('rejected', 'Rejected', 'Rejected by the Client Advisor', 'active'),
        ('up_to_date', 'Up to date', 'Up to date', 'active')
    ) AS source (stateId, display, description, statusId)
ON target.stateId = source.stateId
WHEN NOT MATCHED BY TARGET THEN
INSERT (stateId, display, description, statusId)
VALUES (stateId, display, description, statusId);

-- organization type
MERGE INTO customer.organizationType AS target
USING
    (VALUES
        (1, 'businessUnit'),
        (2, 'network'),
        (3, 'customer')
    ) AS source (organizationTypeId, organizationType)
ON target.organizationTypeId = source.organizationTypeId AND target.organizationType = source.organizationType
WHEN NOT MATCHED BY TARGET THEN
INSERT (organizationTypeId, organizationType)
VALUES (organizationTypeId, organizationType)
WHEN NOT MATCHED BY source THEN
DELETE;
