DECLARE @itemNameTranslationTT core.itemNameTranslationTT
DECLARE @meta core.metaDataTT

DECLARE @enLanguageId [TINYINT] = (SELECT languageId FROM [core].[language] WHERE iso2Code = 'en');

DECLARE @itemNameId BIGINT, @itemTypeId INT = (SELECT itemTypeId FROM [core].[itemType] WHERE [name] = 'referralStatus')
DECLARE @parentItemNameId BIGINT

IF @itemTypeId IS NULL
BEGIN
    INSERT INTO [core].[itemType]([alias], [name], [description], [table], [keyColumn], [nameColumn])
    VALUES('referralStatus', 'referralStatus', 'referralStatus', 'customer.referralStatus', 'itemNameId', NULL)

    SET @itemTypeId = SCOPE_IDENTITY()
END
ELSE IF ISNULL((SELECT keyColumn FROM core.itemType WHERE itemTypeId = @itemTypeId), '') <> 'itemNameId'
BEGIN
    UPDATE core.itemType
    SET keyColumn = 'itemNameId'
    WHERE itemTypeId = @itemTypeId
END


DELETE FROM @itemNameTranslationTT

INSERT INTO @itemNameTranslationTT(itemCode, itemName, itemNameTranslation, parentItemType, parentItemName )
VALUES ('referralNew', 'Referral New', 'Referral New', NULL, NULL),
    ('referralNewRejected', 'Referral New Rejected', 'Referral New Rejected', NULL, NULL),
    ('referralOpen', 'Referral Open', 'Referral Open', NULL, NULL),
    ('referralPending', 'Referral Pending', 'Referral Pending', NULL, NULL),
    ('referralExpired', 'Referral Expired', 'Referral Expired', NULL, NULL),
    ('deactivationPendingReferralOpen', 'Deactivation Pending Referral Open', 'Deactivation Pending Referral Open', NULL, NULL),
    ('deactivationPendingReferralPending', 'Deactivation Pending Referral Pending', 'Deactivation Pending Referral Pending', NULL, NULL),
    ('deactivationPendingReferralCompleted', 'Deactivation Pending Referral Completed', 'Deactivation Pending Referral Completed', NULL, NULL),
    ('referralDeactivated', 'Referral Deactivated', 'Referral Deactivated', NULL, NULL),
    ('referralCompleted', 'Referral Completed', 'Referral Completed', NULL, NULL)


EXEC core.[itemNameTranslation.upload]
    @itemNameTranslationTT = @itemNameTranslationTT,
    @languageId = @enLanguageId,
    @organizationId = NULL,
    @itemType = 'referralStatus',
    @meta = @meta

