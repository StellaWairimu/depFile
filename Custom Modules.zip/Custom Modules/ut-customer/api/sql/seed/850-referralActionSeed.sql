DECLARE @itemNameTranslationTT core.itemNameTranslationTT
DECLARE @meta core.metaDataTT

DECLARE @enLanguageId [TINYINT] = (SELECT languageId FROM [core].[language] WHERE iso2Code = 'en');

DECLARE @itemNameId BIGINT , @itemTypeId INT = (SELECT itemTypeId FROM [core].[itemType] WHERE [name] = 'referralAction')
DECLARE @parentItemNameId BIGINT

IF NOT EXISTS (SELECT * FROM [core].[itemType] WHERE [name] = 'referralAction')
BEGIN
    INSERT INTO [core].[itemType]([alias], [name], [description], [TABLE], [keyColumn], [nameColumn])
    VALUES('referralAction', 'referralAction', 'referralAction', 'customer.referralAction', 'itemNameId', NULL)
END
ELSE IF ISNULL((SELECT keyColumn FROM core.itemType WHERE itemTypeId = @itemTypeId), '') <> 'itemNameId'
BEGIN
    UPDATE core.itemType
    SET keyColumn = 'itemNameId'
    WHERE itemTypeId = @itemTypeId
END



DELETE FROM @itemNameTranslationTT

INSERT INTO @itemNameTranslationTT(itemCode, itemName, itemNameTranslation, parentItemType, parentItemName )
VALUES ('newReferralAprrove', 'newReferralAprrove', 'Approve new referral', NULL, NULL),
    ('newReferralReject', 'newReferralReject', 'Reject new referral', NULL, NULL),
    ('openAccount', 'openAccount', 'Referred customer opened an accouont - referralPending', NULL, NULL),
    ('expireReferral', 'expireReferral', 'Expire the referral', NULL, NULL),
    ('deactivateReferral', 'deactivateReferral', 'Deactivate the referral', NULL, NULL),
    ('deactivateReferralApprove', 'deactivateReferralApprove', 'Approve referral deactivation', NULL, NULL),
    ('deactivateReferralReject', 'deactivateReferralReject', 'Reject referral deactivation', NULL, NULL),
    ('markReferralCompleted', 'markReferralCompleted', 'Referred customer deposted amount - Complete Referral', NULL, NULL)

EXEC core.[itemNameTranslation.upload]
    @itemNameTranslationTT = @itemNameTranslationTT,
    @languageId = @enLanguageId,
    @organizationId = NULL,
    @itemType = 'referralAction',
    @meta = @meta
