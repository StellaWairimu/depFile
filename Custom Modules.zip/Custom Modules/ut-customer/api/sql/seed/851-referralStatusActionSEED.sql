DECLARE @fromStatusName VARCHAR(50) , @toStatusName VARCHAR(50) , @actionName VARCHAR(50), @module VARCHAR(50)
DECLARE @isFromStatusIdStart BIT, @isToStatusIdEnd BIT, @flagToConfirm BIT
DECLARE @actionOrder TINYINT, @fromStatusId TINYINT, @toStatusId TINYINT, @actionId TINYINT

--------------------------------------
SET @fromStatusName = 'referralNew'
SET @toStatusName = 'referralOpen'
SET @actionName = 'newReferralAprrove'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.approveNew')

--------------------------------------
SET @fromStatusName = 'referralNew'
SET @toStatusName = 'referralNewRejected'
SET @actionName = 'newReferralReject'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.reject')

--------------------------------------
SET @fromStatusName = 'referralOpen'
SET @toStatusName = 'referralPending'
SET @actionName = 'openAccount'

SET @isToStatusIdEnd = 0

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.openAccount')

--------------------------------------
SET @fromStatusName = 'referralOpen'
SET @toStatusName = 'deactivationPendingReferralOpen'
SET @actionName = 'deactivateReferral'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.deactivate')

--------------------------------------

SET @fromStatusName = 'referralPending'
SET @toStatusName = 'deactivationPendingReferralPending'
SET @actionName = 'deactivateReferral'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.deactivate')

--------------------------------------

SET @fromStatusName = 'referralPending'
SET @toStatusName = 'referralCompleted'
SET @actionName = 'markReferralCompleted'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.complete')

--------------------------------------

SET @fromStatusName = 'deactivationPendingReferralOpen'
SET @toStatusName = 'referralDeactivated'
SET @actionName = 'deactivateReferralApprove'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.approveDeactivation')

--------------------------------------

SET @fromStatusName = 'deactivationPendingReferralOpen'
SET @toStatusName = 'referralOpen'
SET @actionName = 'deactivateReferralReject'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.rejectDeactivation')

--------------------------------------

SET @fromStatusName = 'deactivationPendingReferralOpen'
SET @toStatusName = 'deactivationPendingReferralPending'
SET @actionName = 'openAccount'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.openAccount')

--------------------------------------

SET @fromStatusName = 'deactivationPendingReferralPending'
SET @toStatusName = 'referralDeactivated'
SET @actionName = 'deactivateReferralApprove'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.approveDeactivation')

--------------------------------------

SET @fromStatusName = 'deactivationPendingReferralPending'
SET @toStatusName = 'referralPending'
SET @actionName = 'deactivateReferralReject'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.rejectDeactivation')

--------------------------------------

SET @fromStatusName = 'deactivationPendingReferralPending'
SET @toStatusName = 'deactivationPendingReferralCompleted'
SET @actionName = 'markReferralCompleted'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.complete')

--------------------------------------

SET @fromStatusName = 'deactivationPendingReferralCompleted'
SET @toStatusName = 'referralDeactivated'
SET @actionName = 'deactivateReferralApprove'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.approveDeactivation')

--------------------------------------

SET @fromStatusName = 'deactivationPendingReferralCompleted'
SET @toStatusName = 'referralCompleted'
SET @actionName = 'deactivateReferralReject'

SET @fromStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @fromStatusName)
SET @toStatusId = (SELECT referralStatusId FROM [customer].[referralStatus] rs
    JOIN [core].[itemName] ci ON ci.itemNameId = rs.itemNameId
    WHERE ci.itemCode = @toStatusName)
SET @actionId = (SELECT referralActionId FROM [customer].[referralAction] ra
    JOIN [core].[itemName] ci ON ci.itemNameId = ra.itemNameId
    WHERE ci.itemCode = @actionName)

IF NOT EXISTS (SELECT * FROM [customer].[referralStatusAction] WHERE fromStatusId = @fromStatusId AND toStatusId = @toStatusId)
INSERT INTO [customer].[referralStatusAction] (fromStatusId, toStatusId, actionId, permission)
VALUES (@fromStatusId, @toStatusId, @actionId, 'customer.referral.rejectDeactivation')
