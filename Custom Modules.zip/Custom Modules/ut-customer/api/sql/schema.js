const path = require('path');
let bus;
function callMultiple(msg, $meta) {
    const linkedSp = this.methods[$meta.method];
    if (Array.isArray(msg)) {
        return Promise.all(msg.map(params => {
            return linkedSp.call(this, params, $meta).catch(x => x);
        }));
    }
    return linkedSp.call(this, msg, $meta);
}
function arrToObj(name) {
    return function(msg, $meta) {
        if (Array.isArray(msg)) {
            const params = {};
            params[name] = msg;
            return params;
        }
        return msg;
    };
}

function storeAttachments(msg, $meta) {
    return bus.importMethod('document.storeAttachments')(msg.attachment)
        .then(function(res) {
            Object.assign(msg.attachment, res);
            return msg;
        });
}

module.exports = function sql() {
    return {
        schema: [{path: path.join(__dirname, 'schema'), linkSP: true}],
        init: function(b) {
            bus = b;
        },
        'customer.person.add': callMultiple,
        'customer.organization.add': callMultiple,
        'customer.joint.add': callMultiple,
        'customer.account.add.request.send': arrToObj('account'),
        'customer.address.add.request.send': arrToObj('address'),
        'customer.email.add.request.send': arrToObj('email'),
        'customer.phone.add.request.send': arrToObj('phone'),
        'customer.document.add.request.send': storeAttachments,
        'customer.attachment.add.request.send': storeAttachments,
        'customer.attachment.update.request.send': storeAttachments,
        'customer.organization.getFromDAO.response.receive': function(msg, $meta) {
            if (msg && Array.isArray(msg.organization) && msg.organization[0]) {
                return msg.organization[0];
            }
            return {};
        }
    };
};
