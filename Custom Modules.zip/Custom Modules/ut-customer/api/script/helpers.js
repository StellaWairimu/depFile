const kycValidatorsMapping = {
    'NOT NULL': (customerInfo, documentInfo, rule) => {
        const customValidationProperties = ['idDocumentType', 'idNumber', 'idPlaceOfIsssue', 'idDateOfIssue', 'idDocument2', 'idNumber2', 'idPhoto', 'customerPhoto', 'signature'];
        if (customValidationProperties.indexOf(rule.itemCode) > -1) {
            switch (rule.itemCode) {
                case 'idDocumentType':
                    // Only for primary document in Identity tab
                    return documentInfo.some((doc) => doc.documentOrder === 1 && doc.documentTypeId);
                case 'idNumber':
                    // Only for primary document in Identity tab
                    return documentInfo.some((doc) => doc.documentOrder === 1 && doc.documentNumber);
                case 'idPlaceOfIsssue':
                    // Only for primary document in Identity tab
                    return documentInfo.some((doc) => doc.documentOrder === 1 && doc.idPlaceOfIsssue);
                case 'idDateOfIssue':
                    // Only for primary document in Identity tab
                    return documentInfo.some((doc) => doc.documentOrder === 1 && doc.idDateOfIssue);
                case 'idDocument2':
                    // Only for secondary document from General Info tab
                    return documentInfo.some((doc) => doc.documentOrder === 2 && doc.documentTypeId);
                case 'idNumber2':
                    // Only for secondary document from General Info tab
                    return documentInfo.some((doc) => doc.documentOrder === 2 && doc.documentNumber);
                case 'idPhoto':
                    // Only for primary id document from Identity tab (attachment required)
                    return documentInfo.some((doc) => doc.documentOrder === 1 && doc.documentTypeId === 'id_card' && doc.attachmentId);
                case 'customerPhoto':
                    // Only for primary profile picture from Identity tab (attachment required)
                    return documentInfo.some((doc) => doc.documentTypeId === 'profile' && doc.attachmentId);
                case 'signature':
                    // Only for document with type Signature uploaded from Documents tab (attachment required)
                    return documentInfo.some((doc) => doc.documentTypeId === 'signature' && doc.documentOrder === 255 && doc.attachmentId);
                default:
                    return false;
            }
        } else {
            const value = customerInfo[rule.itemCode];
            return value !== null && value !== undefined;
        }
    }
};

class CustomerHelpers {
    constructor(obj) {
        this.bus = obj.bus;
    }

    calculateKYCLevel(msg, $meta) {
        return this.bus.importMethod('customer.kycCalculation.get')(msg, $meta)
            .then((response) => {
                // customerInfo, documentInfo, kyc, kycAttributes
                response.kyc.forEach((kyc) => {
                    kyc.kycAttributes = response.kycAttributes.filter((kycAttr) => kycAttr.kycId === kyc.kycId);
                });
                delete response.kycAttributes;
                let fullfilledKycLevel = null;
                for (let i = 0; i < response.kyc.length; i++) {
                    const kyc = response.kyc[i];
                    const isFulfillingRule = kyc.kycAttributes.every((rule) => {
                        const ruleConditions = kyc.kycAttributes.filter((ruleToFilter) => ruleToFilter.conditionId === rule.conditionId);
                        return ruleConditions.some((ruleCondition) => kycValidatorsMapping[ruleCondition.conditionCheck](response.customerInfo[0], response.documentInfo, ruleCondition));
                    });
                    if (isFulfillingRule) {
                        fullfilledKycLevel = kyc;
                        break;
                    }
                }
                return { kyc: fullfilledKycLevel };
            })
            .then((response) => {
                return response;
            })
            .then((response) => {
                return response;
            });
    }
};

module.exports = CustomerHelpers;
