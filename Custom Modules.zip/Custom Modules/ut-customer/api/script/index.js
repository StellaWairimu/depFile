// const CustomerHelpers = require('./helpers');
// var customerHelpers;
const prepareHistory = require('../../history/prepare');
const historyConfig = require('../../history/config');
const UtCrypt = require('ut-crypt');

function bioAdd(bioCrypt, msg, $meta, self) {
    let cbsPort;
    // userAddPromise will be use to retry the method in catch block
    let userAddPromise;

    return self.bus.importMethod('user.visibleExternalSystem.fetch')(undefined, $meta)
        .then((res) => {
            const cbs =
                res &&
                Array.isArray(res.externalSystems) &&
                res.externalSystems.find((item) => item &&
                    typeof item.externalSystemName === 'string' &&
                    item.externalSystemName.startsWith('t24'));
            const systemName = (cbs && cbs.externalSystemName) || undefined;
            return self.bus.importMethod('customer.externalSystemCredentials.check')({ systemName }, $meta)
                .then(() => {
                    return self.bus.importMethod('customer.customer.get')({ actorId: msg.actorId }, $meta)
                        .then((customerResponse) => {
                            if (!customerResponse || !customerResponse.customer || !customerResponse.customer || !customerResponse.customer.customerNumber ||
                                !customerResponse.customer.departmentId || !customerResponse.customer.cbsPort) {
                                throw Error('Missing customer for T24 request');
                            };

                            msg.departmentId = customerResponse.customer.departmentId || 0;
                            cbsPort = customerResponse.customer.cbsPort;

                            // check if fingers can be registered in bio
                            return self.bus.importMethod('bio.canRegisterFingers')(msg, $meta)
                                .then(res => {
                                    if (res && res.data && !res.data.canRegister) {
                                        throw Error('Biometric fingerprints already registered!');
                                    }

                                    const data = {
                                        customerNumber: customerResponse.customer.customerNumber,
                                        flag: true,
                                        stat: msg.isMobile ? 'UNLOCKED' : 'LOCKED',
                                        date: new Date()
                                    };

                                    $meta.destination = cbsPort;
                                    return self.bus.importMethod('cbs/customer.customer.bio')(data, $meta)
                                        .then(res => {
                                            delete $meta.destination;

                                            // adds the fingers without check if they matched with others
                                            // IMPORTANT: Before you use this method invoke bio.canRegisterFinger first
                                            return self.bus.importMethod('bio.addWithoutVerification')(msg, $meta)
                                                .then(res => {
                                                    if (!bioCrypt) throw self.errors['customer.bioCrypt'];
                                                    const params = {
                                                        hash: Object.keys(msg.data).reduce(function(arr, key) {
                                                            const cryptFingerPrint = bioCrypt.encrypt(msg.data[key][0]);
                                                            const params = bioCrypt.params(); // crypt args
                                                            params.bio = {
                                                                id: msg.id,
                                                                departmentId: msg.departmentId
                                                            };

                                                            arr.push({
                                                                actorId: msg.actorId,
                                                                type: 'bio',
                                                                identifier: msg.actorId + '_' + key,
                                                                algorithm: msg.actorId === msg.id ? 'user' : 'customer',
                                                                failedAttempts: 0,
                                                                isEnabled: msg.isEnabled == null ? 1 : msg.isEnabled,
                                                                value: cryptFingerPrint,
                                                                expireDate: new Date(2030, 0, 0),
                                                                params: params
                                                            });
                                                            return arr;
                                                        }, [])
                                                    };

                                                    // there is no synchronization between Bio database and server database
                                                    // thats, why server db can throw an exception for duplicate keys, when
                                                    // fingers are deleted in Bio db and try to add new enrollment
                                                    // In catch block, it will delete bio credentials in user.hash table and after that
                                                    // it will add the new one
                                                    $meta.method = 'user.hash.add';
                                                    userAddPromise = self.bus.importMethod($meta.method)(params, $meta)
                                                        .catch(() => {
                                                            $meta.method = 'user.hash.deleteForBio';
                                                            return self.bus.importMethod($meta.method)({actorId: msg.actorId}, $meta)
                                                                .then(() => {
                                                                    $meta.method = 'user.hash.add';
                                                                    return self.bus.importMethod($meta.method)(params, $meta);
                                                                });
                                                        });

                                                    return userAddPromise
                                                        .then(res => {
                                                            let params;
                                                            if (msg.isMobile) {
                                                                params = {
                                                                    id: customerResponse.customer.customerNumber,
                                                                    departmentId: customerResponse.customer.departmentId,
                                                                    clientFileLockStatus: false
                                                                };
                                                            } else {
                                                                params = {
                                                                    id: customerResponse.customer.customerNumber,
                                                                    departmentId: customerResponse.customer.departmentId,
                                                                    clientFileLockStatus: true
                                                                };
                                                            }

                                                            $meta.method = 'bio.lockunlockcf';
                                                            return self.bus.importMethod($meta.method)(params, $meta)
                                                                .then((res) => {
                                                                    $meta.method = 'customer.customer.update';
                                                                    return self.bus.importMethod($meta.method)({
                                                                        customer: {
                                                                            actorId: msg.actorId,
                                                                            stateId: msg.stateId || 'pending'
                                                                        }
                                                                    }, $meta)
                                                                        .then(() => {
                                                                            return customerResponse;
                                                                        });
                                                                });
                                                        });
                                                });
                                        });
                                });
                        });
                });
        });
}

const historyTransform = function(objectName, data) {
    return this.bus.importMethod('history.history.transform')({
        config: historyConfig[objectName],
        data
    }).then(function(transformedData) {
        return { data: prepareHistory[objectName] && prepareHistory[objectName](transformedData, data) };
    });
};

const methods = ({debug, bioCrypt}) => ({
    start: function() {
        Object.assign(this.errors, this.errors.fetchErrors('customer'));
    },
    'customer.otp.send': function(msg, $meta) {
        const token = Math.floor(Math.random() * 9000) + 1000 + '';
        msg.type = 'smsToken';
        msg.value = token;
        const phoneNumber = msg.identifier;
        msg.identifier = msg.actorId + '_' + msg.identifier;
        const result = {
            type: msg.type,
            phoneId: msg.phoneId,
            actorId: msg.actorId,
            identifier: phoneNumber
        };
        return this.bus.importMethod('user.getHash')(msg)
            .then((hash) => {
                // hash.expireDate = new Date();
                hash.isEnabled = 1;
                $meta.method = 'user.hash.replace';
                return this.bus.importMethod($meta.method)({
                    hash: hash
                }, $meta);
            })
            .then((replacedHash) => {
                if (replacedHash && replacedHash[0] && replacedHash[0][0]) {
                    result.hashId = replacedHash[0][0].hashId;
                    result.expireDate = replacedHash[0][0].expireDate;
                }
                $meta.method = 'alert.message.send';
                return this.bus.importMethod($meta.method)({
                    port: msg.mnoKey,
                    recipient: msg.phonePrefix.replace('+', '') + phoneNumber,
                    template: 'customer.self.verifyPhone.otp',
                    data: {
                        hash: token
                    },
                    languageCode: msg.language,
                    priority: 1
                }, $meta);
            }).then((smsResponse) => {
                result.smsId = smsResponse.inserted.id;
                return result;
            });
    },
    'customer.otp.check': function(msg, $meta) {
        msg.type = 'smsToken';
        const phoneNumber = msg.identifier;
        msg.phoneNumber = phoneNumber;
        msg.identifier = msg.actorId + '_' + msg.identifier;
        const result = {
            type: msg.type,
            actorId: msg.actorId,
            phoneId: msg.phoneId,
            identifier: phoneNumber
        };
        return this.bus.importMethod('user.hash.return')({
            identifier: msg.identifier,
            type: msg.type,
            actorId: msg.actorId
        }).then((res) => {
            if (!res.hashParams) {
                throw this.errors['customer.phone.validate']();
            }
            return this.bus.importMethod('user.genHash')(msg.value, JSON.parse(res.hashParams.params));
        }).then((value) => {
            const params = {
                actorId: msg.actorId,
                identifier: msg.identifier,
                phoneNumber: phoneNumber,
                phoneId: msg.phoneId,
                type: msg.type,
                value: value
            };
            if (msg.approve === false) {
                $meta.method = 'user.hash.check';
            } else {
                $meta.method = 'customer.phone.validate';
                if (msg.stateId) {
                    params.stateId = msg.stateId;
                }
            }
            return this.bus.importMethod($meta.method)(params, $meta);
        }).then(() => {
            result.valid = true;
            $meta.method = 'customer.file.get';
            return this.bus.importMethod($meta.method)({actorId: msg.actorId}, $meta);
        }).then((result) => {
            if (result && result.customer && result.customer.customerNumber && result.customer.cbsPort && !msg.sendFromWeb) {
                $meta.method = 'cbs/customer.customer.update';
                $meta.destination = result.customer.cbsPort;
                return this.bus.importMethod($meta.method)(result, $meta);
            } else {
                return result;
            }
        }).then((res) => {
            if (!res.operation_successful && (res.field_errors && !res.field_errors['LIVE RECORD NOT CHANGED'])) {
                delete $meta.destination;
                $meta.method = 'db/customer.phone.revert';
                return this.bus.importMethod($meta.method)({actorId: msg.actorId}, $meta)
                    .then(() => {
                        throw new Error('T24 error!');
                    });
            } else if (!res.operation_successful && (res.field_errors && res.field_errors['LIVE RECORD NOT CHANGED'])) {
                delete $meta.destination;
                throw new Error('Phone number already exist!');
            }
            return result;
        });
    },
    'customer.file.approve': function(msg, $meta) {
        $meta.method = 'db/customer.customer.get';
        return this.bus.importMethod($meta.method)({ actorId: msg.actorId }, $meta)
            .then(res => {
                $meta.destination = res.customer.cbsPort;
                $meta.method = 'cbs/customer.customer.update';
                return this.bus.importMethod($meta.method)(res, $meta)
                    .then((res) => {
                        if (res.operation_successful || (!res.operation_successful && res.field_errors && Object.keys(res.field_errors).length === 1 &&
                          res.field_errors['LIVE RECORD NOT CHANGED'])) {
                            delete $meta.destination;
                            msg.stateId = 'up_to_date';
                            $meta.method = 'customer.file.updateState';
                            return this.bus.importMethod('db/' + $meta.method)(msg, $meta)
                                .then((res) => {
                                    return res;
                                });
                        } else if (!res.operation_successful && res.field_errors) {
                            let errorMessage = '';
                            const errors = Object.keys(res.field_errors);
                            errors.forEach(errorPropertyName => {
                                if (errorMessage.length) {
                                    errorMessage += `, ${errorPropertyName}`;
                                } else {
                                    errorMessage = errorPropertyName;
                                }
                            });

                            throw new Error(errorMessage);
                        }
                        return false;
                    })
                    .catch(e => {
                        if (e.code === 'notConnected') {
                            const Err = this.errors['customer.t24'] || Error;
                            throw new Err(e);
                        }
                        throw e;
                    });
            });
    },
    'customer.file.reject': function(msg, $meta) {
        msg.description = msg.description && JSON.stringify(msg.description);
        msg.stateId = 'rejected';
        $meta.method = 'customer.file.updateState';
        return this.bus.importMethod('db/' + $meta.method)(msg, $meta);
    },
    'customer.file.block': function(msg, $meta) {
        const description = msg && msg.description && JSON.parse(msg.description);
        msg.stateId = 'blocked';

        if (!description) {
            throw Error('Description is not defined');
        }

        $meta.method = 'db/customer.customer.get';
        return this.bus.importMethod($meta.method)({ actorId: msg.actorId }, $meta)
            .then(res => {
                $meta.destination = res.customer.cbsPort;
                $meta.method = 'cbs/customer.customer.block';
                return this.bus.importMethod($meta.method)(res, $meta)
                    .then((res) => {
                        if (res.operation_successful || (!res.operation_successful && res.field_errors && Object.keys(res.field_errors).length === 1 &&
                                res.field_errors['LIVE RECORD NOT CHANGED'])) {
                            delete $meta.destination;
                            $meta.method = 'db/customer.file.updateState';

                            return this.bus.importMethod($meta.method)(msg, $meta)
                                .then((res) => {
                                    return res;
                                });
                        } else if (!res.operation_successful && res.field_errors) {
                            let errorMessage = '';
                            const errors = Object.keys(res.field_errors);
                            errors.forEach(errorPropertyName => {
                                if (errorMessage.length) {
                                    errorMessage += `, ${errorPropertyName}`;
                                } else {
                                    errorMessage = errorPropertyName;
                                }
                            });

                            throw new Error(errorMessage);
                        }
                        return false;
                    })
                    .catch(e => {
                        if (e.code === 'notConnected') {
                            const Err = this.errors['customer.t24'] || Error;
                            throw new Err(e);
                        }
                        throw e;
                    });
            });
    },
    'customer.bio.add': function(msg, $meta) {
        const deviceSerialNumber = (msg.customer && msg.customer.deviceSerialNumber) || {};
        const self = this;

        delete msg.data.date;
        // Check if logged user has external system credentials - fix: MCTUNE-2474
        $meta.method = 'db/implementation.bioDevice.verify';
        return this.bus.importMethod($meta.method)({ serialNumber: deviceSerialNumber }, $meta)
            .then(() => {
                return bioAdd(bioCrypt, msg, $meta, self);
            })
            .catch(err => {
                if (err.message.indexOf('Method') > -1 && err.message.indexOf('not found') > -1) { // if db/imeplementation.bioDevice.verify does not exist in current implementation
                    return bioAdd(bioCrypt, msg, $meta, self);
                }

                throw err;
            });
    },
    'customer.bio.delete': function(msg, $meta) {
        const params = {
            id: msg.id,
            departmentId: msg.departmentId,
            deleteReason: msg.deleteReason
        };

        $meta.method = 'bio.deletebiodata';
        return this.bus.importMethod($meta.method)(params, $meta)
            .then(res => {
                $meta.method = 'user.hash.deleteForBio';
                return this.bus.importMethod($meta.method)({ actorId: msg.actorId }, $meta)
                    .then(() => {
                        return {};
                    });
            });
    },
    'customer.bio.verify': function(msg, $meta) {
        const deviceSerialNumber = (msg.customer && msg.customer.deviceSerialNumber) || {};
        let customerResponse = {};

        $meta.method = 'db/implementation.bioDevice.verify';
        return this.bus.importMethod($meta.method)({ serialNumber: deviceSerialNumber }, $meta)
            .then(() => {
                $meta.method = 'db/customer.customer.get';
                return this.bus.importMethod($meta.method)({ actorId: msg.actorId }, $meta)
                    .then(response => {
                        customerResponse = response;
                        const params = {
                            id: customerResponse.customer.customerNumber,
                            departmentId: customerResponse.customer.departmentId,
                            data: {
                                UK: [
                                    msg.fingerprint
                                ]
                            }
                        };

                        $meta.method = 'bio.check';
                        return this.bus.importMethod($meta.method)(params, $meta)
                            .then(() => {
                                const params = {
                                    id: customerResponse.customer.customerNumber,
                                    departmentId: customerResponse.customer.departmentId,
                                    clientFileLockStatus: false
                                };

                                $meta.method = 'bio.lockunlockcf';
                                return this.bus.importMethod($meta.method)(params, $meta)
                                    .then(() => {
                                        const params = {
                                            customerNumber: customerResponse.customer.customerNumber,
                                            stat: 'UNLOCKED',
                                            date: new Date()
                                        };

                                        $meta.destination = response.customer.cbsPort;
                                        $meta.method = 'cbs/customer.customer.bio';
                                        return this.bus.importMethod($meta.method)(params, $meta)
                                            .then((res) => {
                                                if (res && !res.operation_successful) {
                                                    throw Error('T24 failed!');
                                                }

                                                return {};
                                            });
                                    });
                            })
                            .catch(err => {
                                if (['-1', '-59', '-5'].includes(err.code)) {
                                    err.print = 'Error! Verification failed!';
                                }

                                throw err;
                            });
                    });
            });
    },
    /**
     * bio.check is created to determine if the customer can register new fingerprints
     * method sends hardcoded fingerprint template to check it
     * expected behaviour from BIO is to throw an exception and catch it here
     * code -59: when user has clientfile and don't have fingerprints
     * code -1: when user don't have clientfile and fingerprints
     * code -5: when the fingerprint template is not the same as registered
     */
    'customer.bio.check': function(msg, $meta) {
        const data = {
            id: msg.id,
            departmentId: msg.departmentId,
            data: {
                UK: [
                    'Rk1SACAyMAAAAAGkAAABQAHgAMUAxQEAAABkQUCfAN6aAIBuAMmcAECKARwhAIBGAXgpAICKAZ6VAICCAN4VAID1AQbkAIEUARZkAIEUAUrJAEBTAVirAICOATKwAIBGAakSAIBlAZIhAIDRAKSAAIBKAK0bAIC2AOQGAED7AYqrAICqAaohAICrAJuQAEB8AIoLAIDgAV61AEC3AGiLAIETAPjlAEB+AWEyAICIAIaSAIEFAYWzAIDMAQjsAIAvAXEpAICSAYgpAEEEAWnGAIEPAMZuAECYAPISAEBvAbYSAEEBASfSAIDSASfhAEClAKQHAEBbARarAIEEACL1AIEJAGr1AIDgAIX3AIAqAXcrAEBpAcMJAEDiACJ9AIEHAMPvAICdAJYGAIA8AVuuAID8AHbwAEDzAIV1AIA/AEiRAECXAdIOAIDeADt5AEBdAR8pAIB+ACh6AIDGAKQGAED4ADx1AIEEAFR1AIAhAWSmAEAmAYokAIBQAGecAEA2AFiQAIDlAHr3AIDoAELzAIAdAKCXAIA7AbYQAEEPAFPyAAAA'
                ]
            }
        };

        $meta.method = 'bio.check';
        return this.bus.importMethod($meta.method)(data, $meta)
            .catch((err) => {
                $meta.mtid = 'response';
                if (err.code === '-1' || err.code === '-59') {
                    if (err.code === '-59') {
                        $meta.method = 'user.hash.deleteForBio';
                        return this.bus.importMethod($meta.method)({actorId: msg.actorId}, $meta)
                            .catch((err) => {
                                throw err;
                            })
                            .then((res) => {
                                return {canRegisterNewFingerprints: true};
                            });
                    } else {
                        return {canRegisterNewFingerprints: true};
                    }
                } else if (err.code === '-5') {
                    return {canRegisterNewFingerprints: false, registeredFingerprints: err.registeredFingerprints};
                } else {
                    return {canRegisterNewFingerprints: 'ERROR! Unknown code!'};
                }
            });
    },
    'customer.bio.getClientFile': function(msg, $meta) {
        $meta.method = 'bio.getClientFile';
        return this.bus.importMethod($meta.method)(msg, $meta)
            .then(res => {
                return { clientFileLockStatus: res.info.clientFileLockStatus.toLowerCase() === 'true' };
            })
            .catch(() => {
                $meta.mtid = 'response';
                return {};
            });
    },
    'customer.account.activity': function(msg, $meta) {
        $meta.method = 'customer.file.get';
        return this.bus.importMethod($meta.method)({actorId: msg.actorId}, $meta)
            .then(customerFile => {
                if (!customerFile.customer || !customerFile.customer.cbsPort || !customerFile.customer.customerNumber) {
                    throw this.errors['customer.cbsPortMissing']();
                }
                $meta.destination = customerFile.customer.cbsPort;
                $meta.method = 'cbs/customer.customer.activity';
                return this.bus.importMethod($meta.method)(customerFile, $meta)
                    .then(cbsResponse => {
                        delete $meta.destination;
                        cbsResponse.balance = cbsResponse.balance.filter(account => msg.accountNumber === account.accountNumber);
                        cbsResponse.activity = cbsResponse.activity.filter(activity => msg.accountNumber === activity.account);
                        return cbsResponse;
                    });
            });
    },
    'customer.cbs.activity': function(msg, $meta) {
        $meta.method = 'db/customer.customer.get';
        const self = this;
        let countryId;

        return this.bus.importMethod($meta.method)({
            actorId: $meta.auth.actorId
        }, $meta).then((response) => {
            $meta.method = 'cbs/customer.customer.activity';
            $meta.destination = response.customer.cbsPort;
            if (!response.customer || !response.customer.cbsPort) {
                throw this.errors['customer.cbsPortMissing']();
            }

            countryId = response.customer.countryId;
            return this.bus.importMethod($meta.method)(response, $meta);
        })
            .then((cbsResponse) => {
                $meta.method = 'db/customer.accountCurrency.get';
                return this.bus.importMethod($meta.method)({actorId: $meta.auth.actorId})
                    .then((response) => {
                        if (Array.isArray(response.accounts) && Array.isArray(cbsResponse.balance)) {
                            cbsResponse.balance.forEach((acc) => {
                                const foundMatchingAccount = response.accounts.find((dbAcc) => dbAcc.accountNumber === acc.accountNumber);
                                acc.currency = foundMatchingAccount ? foundMatchingAccount.currencyName : null;
                            });
                        }
                        return cbsResponse;
                    });
            })
            .then(cbsResponse => {
                $meta.method = 'loan.item.fetch';
                return this.bus.importMethod($meta.method)([{
                    countryId: countryId,
                    schema: 'loan',
                    itemTypeName: ['currency']
                }])
                    .then((response) => {
                        cbsResponse.currency = [];

                        response.currency.forEach(item => {
                            cbsResponse.currency.push({
                                currencyId: item.currencyId,
                                itemCode: item.itemCode,
                                itemName: item.itemName
                            });
                        });

                        return cbsResponse;
                    });
            })
            .then(function(response) {
                return self.bus.importMethod('db/customer.activityReport.add')({
                    activity: {
                        action: 'customer.activity',
                        actionStatus: 'success',
                        operationDate: (new Date()).toISOString(),
                        channel: 'online'
                    }
                }, {
                    method: 'db/customer.activityReport.add',
                    auth: $meta.auth
                }).then(() => response);
            }).catch(function(err) {
                return self.bus.importMethod('db/customer.activityReport.add')({
                    activity: {
                        action: 'customer.activity',
                        actionStatus: 'failure',
                        operationDate: (new Date()).toISOString(),
                        channel: 'online'
                    }
                }, {
                    method: 'db/customer.activityReport.add',
                    auth: $meta.auth
                }).then(() => {
                    throw err;
                });
            });
    },
    'customer.activityReport.run.request.send': function(msg, $meta) {
        // default request - this will fetch all activities from 1 month before
        if (!msg.from && !msg.to) {
            const today = new Date();
            msg.from = new Date(today.getFullYear(), today.getMonth() - 1, 1);
            msg.to = today;
            msg.pageNumber = msg.pageNumber ? msg.pageNumber : 1;
            msg.pageSize = msg.pageSize ? msg.pageSize : 25;
        };

        const timezone = $meta.auth.timezone;
        msg.tz = timezone;
        return msg;
    },
    'customer.activationReport.run.request.send': function(msg, $meta) {
        // default request - this will fetch all activations from 1 month before
        if (!msg.from && !msg.to) {
            const today = new Date();
            msg.from = new Date(today.getFullYear(), today.getMonth() - 1, 1);
            msg.to = today;
            msg.pageNumber = msg.pageNumber ? msg.pageNumber : 1;
            msg.pageSize = msg.pageSize ? msg.pageSize : 25;
        };

        const timezone = $meta.auth.timezone;
        msg.tz = timezone;
        return msg;
    },
    'customer.customer.picture': function(msg, $meta) {
        $meta.method = 'customer.picture.get';
        return this.bus.importMethod($meta.method)({
            actorId: msg.actorId
        }, $meta).then((response) => {
            if (response.filename) {
                msg.picture = '/s/ut-document/repository/' + response.filename.filename;
            }
            return msg;
        });
    },
    'customer.selfregister': function(msg, $meta) {
        $meta.method = 'customer.customer.selfAdd';
        msg.isDebugMode = debug;
        return this.bus.importMethod($meta.method)(msg)
            .then((response) => {
                $meta.actorId = response.customer[0].actorId;
                return this.bus.importMethod('core.itemNameByItemType.fetch')({
                    itemType: 'secretQuestion'
                }, $meta).then(function(secretQuestions) {
                    const res = {
                        success: true,
                        actorId: response.customer[0].actorId,
                        secretQuestions: secretQuestions.itemNameByType
                    };
                    if (debug && response.debugModePassword && response.debugModePassword[0] && response.debugModePassword[0].otp) res.token = response.debugModePassword[0].otp;
                    return res;
                });
            });
    },
    'customer.customer.create': function(msg, $meta) {
        let customer = {};
        let idCardDocument = {};
        let profileDocument = {};
        const customerFile = {
            address: msg.address,
            customer: msg.customer,
            person: {
                dateOfBirth: msg.person.dateOfBirth,
                firstName: msg.person.firstName,
                gender: msg.person.gender,
                lastName: msg.person.lastName,
                maritalStatusId: msg.person.maritalStatusId,
                nationality: msg.person.nationality,
                phoneModel: msg.person.phoneModel,
                placeOfBirth: msg.person.placeOfBirth,
                udf: {
                    childrenCount: msg.person.childrenCount,
                    deviceID: msg.person.deviceID,
                    financialInclusionStatus: msg.person.financialInclusionStatus,
                    incomeAmount: msg.person.incomeAmount,
                    incomeFrequency: msg.person.incomeFrequency
                }
            }
        };
        let branchCode = null;
        let cbsPort = null;
        let cbsId = null;
        let countryId = null;
        msg.document.forEach(function(doc) {
            if (doc.documentTypeId === 'id_card') {
                idCardDocument = doc;
            } else if (doc.documentTypeId === 'profile') {
                profileDocument = doc;
            }
        });
        $meta.method = 'db/implementation.user.getParentForCBS';
        return this.bus.importMethod($meta.method)({actorId: $meta.auth.actorId}, $meta)
            .then((organizations) => {
                if (!organizations.organizations && organizations.organizations.length) {
                    $meta.method = 'db/customer.customer.delete';
                    return this.bus.importMethod($meta.method)({actorId: customer.actorId}, $meta)
                        .then(() => {
                            const error = new Error('customer.user.getDao');
                            error.code = 'customer.user.getDao';
                            error.message = 'T24 port unknown';
                            throw error;
                        });
                }
                branchCode = organizations.organizations[0] && organizations.organizations[0].branchCode;
                cbsPort = organizations.organizations[0] && organizations.organizations[0].cbsPort;
                cbsId = organizations.organizations[0] && organizations.organizations[0].cbsId;
                countryId = organizations.organizations[0] && organizations.organizations[0].cbsId; // cbsId equals countryId
                $meta.method = 'db/customer.user.getActorIdByDao';
                return this.bus.importMethod($meta.method)({dao: branchCode}, $meta);
            }).then((result) => {
                customerFile.customer.stateId = 'up_to_date';
                customerFile.customer.organizationId = result.organizations && result.organizations[0] && result.organizations[0].actorId;
                customerFile.customer.dao = branchCode;
                customerFile.customer.cbsId = cbsId;
                customerFile.customer.countryId = countryId;
                $meta.method = 'db/customer.customer.add';
                return this.bus.importMethod($meta.method)(customerFile, $meta);
            }).then((response) => {
            // add card ID picture
                customer = response.customer;
                idCardDocument.attachment.documentId = customer.documentId;
                const data = {
                    actorId: customer.actorId,
                    attachment: [idCardDocument.attachment || {}],
                    customer: {
                        actorId: customer.actorId,
                        stateId: customer.stateId
                    },
                    document: {
                        documentTypeId: idCardDocument.documentTypeId,
                        statusId: idCardDocument.statusId
                    }
                };
                if (idCardDocument.documentNumber) data.document.documentNumber = idCardDocument.documentNumber;
                if (idCardDocument.expirationDate) data.document.expirationDate = idCardDocument.expirationDate;
                $meta.method = 'db/customer.document.add';
                return this.bus.importMethod($meta.method)(data, $meta)
                    .catch(() => {
                        $meta.method = 'db/customer.customer.delete';
                        return this.bus.importMethod($meta.method)({actorId: customer.actorId}, $meta)
                            .then(() => {
                                throw Error('Missing customer ID Card picture');
                            });
                    });
            }).then(() => {
            // add Profile picture
                const attachments = [];
                if (profileDocument.attachment) {
                    attachments.push(profileDocument.attachment);
                    attachments.push(Object.assign({}, profileDocument.attachment, {attachmentSizeId: 'avatar'}));
                }
                const data = {
                    actorId: customer.actorId,
                    attachment: attachments,
                    customer: {
                        actorId: customer.actorId,
                        stateId: customer.stateId
                    },
                    document: {
                        documentTypeId: profileDocument.documentTypeId,
                        statusId: profileDocument.statusId
                    }
                };
                $meta.method = 'db/customer.document.add';
                return this.bus.importMethod($meta.method)(data, $meta)
                    .catch(() => {
                        $meta.method = 'db/customer.customer.delete';
                        return this.bus.importMethod($meta.method)({actorId: customer.actorId}, $meta)
                            .then(() => {
                                throw Error('Missing customer Profile picture');
                            });
                    });
            }).then(() => {
                $meta.method = 'customer.file.get';
                return this.bus.importMethod($meta.method)({actorId: customer.actorId}, $meta);
            }).then((result) => {
                result.dao = branchCode;
                $meta.destination = cbsPort;
                $meta.method = 'cbs/customer.customer.createT24';
                return this.bus.importMethod($meta.method)(result, $meta);
            }).then((resp) => {
                const data = {
                    customer: {
                        actorId: customer.actorId,
                        customerNumber: resp.record_id
                    }
                };
                delete $meta.destination;
                $meta.method = 'db/customer.customer.update';
                return this.bus.importMethod($meta.method)(data, $meta);
            }).then(() => {
                $meta.method = 'customer.file.get';
                return this.bus.importMethod($meta.method)({actorId: customer.actorId}, $meta);
            }).catch((err) => {
                delete $meta.destination;
                $meta.method = 'db/customer.customer.delete';
                return this.bus.importMethod($meta.method)({actorId: customer.actorId}, $meta)
                    .then(() => {
                        throw err;
                    });
            });
    },
    'customer.file.get': function(msg, $meta) {
        $meta.method = 'db/customer.file.get';
        return this.bus.importMethod($meta.method)(msg, $meta).then((response) => {
            if (response.person && response.person.udf) {
                response.person.childrenCount = response.person.udf.childrenCount;
                response.person.deviceID = response.person.udf.deviceID;
                response.person.financialInclusionStatus = response.person.udf.financialInclusionStatus;
                response.person.incomeAmount = response.person.udf.incomeAmount;
                response.person.incomeFrequency = response.person.udf.incomeFrequency;
            }
            if (response.customer && response.customer.udf) {
                response.customer.contractSign = response.customer.udf.contractSign;
            }
            return response;
        });
    },
    'customer.file.getByDocumentNumber': function(msg, $meta) {
        $meta.method = 'db/implementation.file.getByDocumentNumber';
        return this.bus.importMethod($meta.method)(msg, $meta).then((response) => {
            if (response.person && response.person.udf) {
                response.person.childrenCount = response.person.udf.childrenCount;
                response.person.deviceID = response.person.udf.deviceID;
                response.person.financialInclusionStatus = response.person.udf.financialInclusionStatus;
                response.person.incomeAmount = response.person.udf.incomeAmount;
                response.person.incomeFrequency = response.person.udf.incomeFrequency;
                response.person.nickname = response.person.udf.nickname;
                response.person.emailAddress = response.person.udf.emailAddress;
                delete response.person.udf;
            }
            if (response.customer && response.customer.udf) {
                response.customer.contractSign = response.customer.udf.contractSign;
                response.customer.accountNumber = response.customer.udf.accountNumber;
                delete response.customer.udf;
            }
            return response;
        });
    },
    'customer.file.updateWithBio': function(msg, $meta) {
        const data = {
            id: msg.customerNumber,
            departmentId: msg.departmentId,
            data: {UK: [msg.bio]}
        };
        $meta.method = 'db/implementation.bioDevice.verify';
        return this.bus.importMethod($meta.method)({ serialNumber: msg.deviceSerialNumber }, $meta)
            .then(() => {
                $meta.method = 'bio.check';
                return this.bus.importMethod($meta.method)(data, $meta);
            })
            .then((response) => {
                $meta.method = 'customer.file.get';
                return this.bus.importMethod($meta.method)({actorId: msg.actorId}, $meta)
                    .then((resp) => {
                        const data = {
                            customer: {
                                customerNumber: msg.customerNumber,
                                lastChange: resp.bio[0].lastChange
                            }
                        };
                        $meta.destination = resp.customer.cbsPort;
                        $meta.method = 'cbs/customer.customer.createAccountT24';
                        return this.bus.importMethod($meta.method)(data, $meta)
                            .catch((err) => {
                                throw err;
                            })
                            .then((response) => {
                                if (response.fields && response.fields.ACCOUNT) {
                                    msg.t24Response = {
                                        nationality: response.fields.NATIONALITY,
                                        openingOn: new Date(),
                                        accountNumber: response.fields.ACCOUNT
                                    };

                                    return {
                                        actorId: resp.customer.actorId,
                                        contractSign: true,
                                        accountNumber: response.fields.ACCOUNT
                                    };
                                } else {
                                    throw response;
                                }
                            });
                    })
                    .then((resp) => {
                        delete $meta.destination;
                        $meta.method = 'db/customer.customer.get';
                        return this.bus.importMethod($meta.method)({
                            actorId: msg.actorId
                        }, $meta)
                            .then((res) => {
                                const data = {
                                    customer: {
                                        actorId: msg.actorId,
                                        udf: res.udf
                                    }
                                };
                                if (data.customer.udf) {
                                    data.customer.udf.contractSign = true;
                                    data.customer.udf.accountNumber = resp.accountNumber;
                                } else {
                                    data.customer.udf = {
                                        contractSign: true,
                                        accountNumber: resp.accountNumber
                                    };
                                }
                                $meta.method = 'db/customer.customer.update';
                                return this.bus.importMethod($meta.method)(data, $meta);
                            })
                            .then(() => {
                                const params = {
                                    actorId: msg.actorId,
                                    accountNumber: msg.t24Response.accountNumber,
                                    nationality: msg.t24Response.nationality,
                                    openingOn: msg.t24Response.openingOn
                                };

                                $meta.method = 'customer.account.baobab.send';
                                return this.bus.importMethod($meta.method)(params, $meta);
                            })
                            .then(() => {
                                return resp;
                            });
                    });
            })
            .catch(err => {
                throw err;
            });
    },
    'customer.account.baobab.send': function(msg, $meta) {
        let result;

        $meta.method = 'customer.file.get';
        return this.bus.importMethod($meta.method)({actorId: msg.actorId}, $meta)
            .then((r) => {
                result = r;
                const params = {
                    account: {
                        actorId: r.customer.actorId,
                        accountNumber: msg.accountNumber,
                        accountName: 'Baobab_Account',
                        statusId: 'active',
                        balance: 0,
                        accountOpenedOn: msg.openingOn
                    },
                    accountType: 'Baobab_Account',
                    countryCode: msg.nationality
                };

                $meta.method = 'customer.account.add';
                return this.bus.importMethod($meta.method)(params, $meta)
                    .then(response => {
                        let primaryPhone = {};
                        result.customerPhone.forEach(function(element) {
                            if (element.isPrimary) primaryPhone = element;
                        });
                        if (primaryPhone.phoneNumber) {
                            $meta.method = 'alert.message.send';
                            const nickname = result.person.udf && result.person.udf.nickname ? result.person.udf.nickname : result.person.firstName;
                            return this.bus.importMethod($meta.method)({
                                port: primaryPhone.mnoKey,
                                recipient: result.customer.phonePrefix.replace('+', '') + primaryPhone.phoneNumber,
                                template: 'customer.account.baobab.registered',
                                data: {
                                    nickname,
                                    accountNumber: msg.accountNumber
                                },
                                languageCode: $meta.languageCode,
                                priority: 1
                            }, $meta)
                                .then((smsResponse) => {
                                    return {smsId: smsResponse.inserted[0].id};
                                });
                        } else {
                            throw Error('Missing customer primary phone number.');
                        }
                    });
            });
    },
    'customer.bio.registered.send': function(msg, $meta) {
        $meta.method = 'customer.file.get';
        return this.bus.importMethod($meta.method)({actorId: msg.actorId}, $meta)
            .then((result) => {
                let primaryPhone = {};
                result.customerPhone.forEach(function(element) {
                    if (element.isPrimary) primaryPhone = element;
                });
                if (primaryPhone.phoneNumber) {
                    $meta.method = 'alert.message.send';
                    return this.bus.importMethod($meta.method)({
                        port: primaryPhone.mnoKey,
                        recipient: result.customer.phonePrefix.replace('+', '') + primaryPhone.phoneNumber,
                        template: 'customer.self.bio.registered',
                        data: {
                            firstName: result.person.firstName
                        },
                        languageCode: $meta.languageCode,
                        priority: 1
                    }, $meta)
                        .then((smsResponse) => {
                            return {smsId: smsResponse.inserted[0].id};
                        });
                } else {
                    throw Error('Missing customer primary phone number.');
                }
            });
    },
    'customer.customer.add.request.send': function(msg, $meta) {
        if (msg.attachment && msg.attachment.length) {
            return this.bus.importMethod('document.storeAttachments')(msg.attachment).then((stored) => {
                msg.attachment = stored;
                return msg;
            });
        } else return msg;
    },
    'customer.customer.edit.request.send': function(msg, $meta) {
        if (msg.attachment && msg.attachment.length) {
            const newAttachments = msg.attachment.filter(a => a.filename && a.filename.indexOf('_file') > -1);
            const oldAttachments = msg.attachment.filter(a => a.filename && a.filename.indexOf('_file') === -1);
            if (newAttachments.length === 0) return msg;
            return this.bus.importMethod('document.storeAttachments')(newAttachments).then((stored) => {
                msg.attachment = stored.reduce((prev, file) => {
                    prev.push(file);
                    return prev;
                }, []).concat(oldAttachments);
                return msg;
            }, []);
        } else return msg;
    },
    'customer.nanoloans.updateEligibility': function(msg, $meta) {
        $meta.method = 'customer.file.get';

        return this.bus.importMethod($meta.method)({actorId: msg.actorId}, $meta)
            .then(customerFile => {
                if (!customerFile.customer || !customerFile.customer.cbsPort || !customerFile.customer.customerNumber) {
                    throw this.errors['customer.cbsPortMissing']();
                }
                const data = {
                    state: msg.state,
                    customerNumber: customerFile.customer.customerNumber
                };
                $meta.destination = customerFile.customer.cbsPort;
                $meta.method = msg.nanoloanType === 'TAKA' ? 'cbs/customer.customer.optInOutTaka' : 'cbs/customer.customer.optInOutAlip';
                return this.bus.importMethod($meta.method)(data, $meta)
                    .then(t24result => {
                        delete $meta.destination;

                        const customer = customerFile.customer;
                        const udf = Object.assign({}, customer && customer.udf);
                        let nanoLoanArray;
                        if (Array.isArray(udf.nanoLoans)) {
                            nanoLoanArray = udf.nanoLoans;
                        } else if (udf.nanoLoans) {
                            nanoLoanArray = [udf.nanoLoans];
                        } else {
                            nanoLoanArray = [];
                        }
                        const index = nanoLoanArray.findIndex(loan => loan.nanoLoan.type === msg.nanoloanType);
                        if (index >= 0) {
                            nanoLoanArray[index].nanoLoan.isEligible = msg.state === 'ACCEPTED';
                        } else {
                            nanoLoanArray.push({
                                nanoLoan: {
                                    type: msg.nanoloanType,
                                    maxAmount: 0,
                                    isEligible: msg.state === 'ACCEPTED'
                                }
                            });
                        }
                        // Assign
                        udf.nanoLoans = nanoLoanArray;
                        customer.udf = udf;

                        $meta.method = 'customer.customer.edit';
                        return this.bus.importMethod($meta.method)({
                            actorId: msg.actorId,
                            customer: customer
                        }, $meta);
                    });
            });
    },
    'customer.nomenclatures.fetch': function(msg, $meta) {
        const promises = [];
        const converters = {};
        if (msg.fields && msg.fields.indexOf('documentType') > -1) {
            $meta = Object.assign({}, $meta, {method: 'document.documentType.fetch'});
            promises.push(this.bus.importMethod($meta.method)({}, $meta));
            converters.documentType = (prev, curr) => {
                prev.push({
                    key: curr.id,
                    value: curr.name
                });
                return prev;
            };
        }
        if (msg.fields && msg.fields.indexOf('country') > -1) {
            $meta = Object.assign({}, $meta, {method: 'core.country.fetch'});
            promises.push(this.bus.importMethod($meta.method)({}, $meta));
            converters.country = (prev, curr) => {
                prev.push({
                    key: curr.countryId,
                    value: curr.name
                });
                return prev;
            };
        }
        if (msg.fields && msg.fields.indexOf('maritalStatus') > -1) {
            $meta = Object.assign({}, $meta, {method: 'customer.maritalStatus.list'});
            promises.push(this.bus.importMethod($meta.method)({}, $meta));
            converters.maritalStatus = (prev, curr) => {
                prev.push({
                    key: curr.maritalStatusId,
                    value: curr.itemNameTranslation
                });
                return prev;
            };
        }
        if (msg.fields && msg.fields.indexOf('education') > -1) {
            $meta = Object.assign({}, $meta, {method: 'customer.education.list'});
            promises.push(this.bus.importMethod($meta.method)({}, $meta));
            converters.education = (prev, curr) => {
                prev.push({
                    key: curr.educationId,
                    value: curr.itemNameTranslation
                });
                return prev;
            };
        }
        if (msg.fields && msg.fields.indexOf('employment') > -1) {
            $meta = Object.assign({}, $meta, {method: 'customer.employment.list'});
            promises.push(this.bus.importMethod($meta.method)({}, $meta));
            converters.employment = (prev, curr) => {
                prev.push({
                    key: curr.employmentId,
                    value: curr.itemNameTranslation
                });
                return prev;
            };
        }
        if (msg.fields && msg.fields.indexOf('employerCategory') > -1) {
            $meta = Object.assign({}, $meta, {method: 'customer.employerCategory.list'});
            promises.push(this.bus.importMethod($meta.method)({}, $meta));
            converters.employerCategory = (prev, curr) => {
                prev.push({
                    key: curr.employerCategoryId,
                    value: curr.itemNameTranslation
                });
                return prev;
            };
        }
        if (msg.fields && msg.fields.indexOf('industry') > -1) {
            $meta = Object.assign({}, $meta, {method: 'customer.industry.list'});
            promises.push(this.bus.importMethod($meta.method)({}, $meta));
            converters.industry = (prev, curr) => {
                prev.push({
                    key: curr.industryId,
                    value: curr.itemNameTranslation
                });
                return prev;
            };
        }
        if (msg.fields && msg.fields.indexOf('incomeRange') > -1) {
            $meta = Object.assign({}, $meta, {method: 'customer.incomeRange.list'});
            promises.push(this.bus.importMethod($meta.method)({}, $meta));
            converters.incomeRange = (prev, curr) => {
                prev.push({
                    key: curr.incomeRangeId,
                    value: curr.itemNameTranslation
                });
                return prev;
            };
        }
        if (msg.fields && msg.fields.indexOf('phoneTypes') > -1) {
            $meta = Object.assign({}, $meta, {method: 'customer.phoneType.fetch'});
            promises.push(this.bus.importMethod($meta.method)({}, $meta));
            converters.phoneTypes = (prev, curr) => {
                prev.push({
                    key: curr.phoneTypeId,
                    value: curr.description
                });
                return prev;
            };
        }
        if (msg.fields && msg.fields.indexOf('addressTypes') > -1) {
            $meta = Object.assign({}, $meta, {method: 'customer.addressType.fetch'});
            promises.push(this.bus.importMethod($meta.method)({}, $meta));
            converters.addressTypes = (prev, curr) => {
                prev.push({
                    key: curr.addressTypeId,
                    value: curr.description
                });
                return prev;
            };
        }
        if (msg.fields && msg.fields.indexOf('emailTypes') > -1) {
            $meta = Object.assign({}, $meta, {method: 'customer.emailType.fetch'});
            promises.push(this.bus.importMethod($meta.method)({}, $meta));
            converters.emailTypes = (prev, curr) => {
                prev.push({
                    key: curr.emailTypeId,
                    value: curr.description
                });
                return prev;
            };
        }
        return Promise.all(promises).then(function(result) {
            return result.reduce((prev, res) => {
                const key = Object.keys(res)[0];
                prev.dictionary[key] = res[key].reduce(converters[key], []);
                return prev;
            }, { dictionary: {} });
        });
    },
    'customer.businessUnit.fetch': function(msg, $meta) {
        $meta.method = 'customer.organization.graphFetch';
        return this.bus.importMethod($meta.method)(msg, $meta).then(result => {
            return result.organization.reduce((prev, curr) => {
                prev.dictionary.businessUnit.push({
                    key: curr.id,
                    value: curr.title
                });
                return prev;
            }, { dictionary: { businessUnit: [] } });
        });
    },
    'customer.customer.historyTransform': function(msg, $meta) {
        return historyTransform.call(this, 'customer', msg.data);
    },
    'customer.kyc.historyTransform': function(msg, $meta) {
        return historyTransform.call(this, 'kyc', msg.data);
    },
    'customer.organization.historyTransform': function(msg, $meta) {
        return historyTransform.call(this, 'organization', msg.data);
    }
});

module.exports = function customer({config: {bio, debug}} = {config: {}}) {
    return methods({
        debug,
        bioCrypt: bio && bio.crypt && new UtCrypt(bio.crypt)
    });
};
