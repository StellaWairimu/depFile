module.exports = () => function utCustomer() {
    return {
        browser: () => [
            function ui({config}) {
                switch (config && config.service) {
                    case 'admin': return require('./ui/react/admin').ui(...arguments);
                    default: return require('./ui/react').ui(...arguments);
                }
            }
        ]
    };
};
