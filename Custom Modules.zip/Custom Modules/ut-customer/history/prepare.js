const { formatKYCAttributesAndCondition } = require('./helpers');
function prepareCustomerHistory(newCustomer, data) {
    const customerDelete = ['Attachments'];
    const doc = newCustomer.Documents;
    const attachment = data.attachment;
    const primary = doc.find((detail) => { return detail.documentTypeId === 'profile'; });
    const primaryDocument = doc.find(document => document.documentOrder === 1);
    const primaryAttachments = primaryDocument && attachment.filter(attachment => attachment.documentId === primaryDocument.documentId);
    const primaryDocumentFront = primaryAttachments && primaryAttachments.length === 1 ? primaryAttachments[0] : primaryAttachments && primaryAttachments.find(attachment => attachment.page === 1);
    const primaryDocumentBack = primaryAttachments && primaryAttachments.length > 1 && primaryAttachments.find(attachment => attachment.page === 2);
    primary && (newCustomer.Identity['Profile Pic'] = primary && (attachment.find((a) => { return a.documentId === primary.documentId; }) || {}).filename);
    if (primaryDocument) {
        newCustomer.Identity['Id Information'] = {
            'ID Type': primaryDocument.documentTypeName || primaryDocument.documentTypeId,
            'ID Number': primaryDocument.documentNumber,
            'Date Of Issue': new Date(primaryDocument.createdDate).toLocaleDateString(),
            'Place Of Issue': primaryDocument.countryName,
            'ID Front': primaryDocumentFront && primaryDocumentFront.filename,
            'ID Back': primaryDocumentBack && primaryDocumentBack.filename
        };
    }
    newCustomer['General Info']['Second Identity Document'] = doc.filter((detail) => { return detail.documentOrder === 2; }).map((detail) => {
        return ({
            'ID Document Type': detail.documentTypeName || detail.documentTypeId,
            'ID Number': detail.documentNumber,
            'File Name': (attachment.find((a) => { return a.documentId === detail.documentId; }) || {}).filename
        });
    });
    newCustomer.Documents = doc.filter((detail) => { return detail.statusId === 'approved' & detail.documentOrder === 255; }).map((detail) => {
        return ({
            'Group Name': detail.documentTypeName || detail.documentTypeId,
            'Document Description': detail.description,
            'Upload Date': new Date(detail.createdDate).toLocaleDateString(),
            'File Type': newCustomer.Attachments.find((attach) => { return attach.documentId === detail.documentId; }).extension,
            Status: detail.statusId,
            'File Name': (attachment.find((a) => { return a.documentId === detail.documentId; }) || {}).filename
        });
    });
    customerDelete.forEach((dele) => {
        delete newCustomer[dele];
    });
    return newCustomer;
}
function prepareKycHistory(newKyc, data) {
    const attributes = [];
    const conditions = formatKYCAttributesAndCondition(data.kycAttributes);
    Object.keys(conditions).forEach((conditionKey) => {
        const condition = conditions[conditionKey];
        let displayTitle = condition.name;
        if (condition.conditions && condition.conditions.length > 0) {
            condition.conditions.forEach((obj) => {
                displayTitle += ' ' + obj.condition.name + ' ' + obj.attribute.name;
            });
        }
        attributes.push(displayTitle);
    });
    newKyc.Attributes = attributes;
    return newKyc;
}
function prepareOrganizationHistory(newBu, data) {
    newBu.Parent = (data['organization.parents'] || []).map((pa) => { return pa.organizationName; });
    newBu.Addresses = (data['organization.address'] || []).map((ad) => { return ad.value; });
    newBu['Phone numbers'] = (data['organization.phone'] || []).map((ph) => { return ph.phoneNumber; });
    newBu['Assigned Roles'] = (data['organization.roles'] || []).map((ro) => { return ro.name; });
    return newBu;
}
module.exports = {
    customer: prepareCustomerHistory,
    kyc: prepareKycHistory,
    organization: prepareOrganizationHistory
};
