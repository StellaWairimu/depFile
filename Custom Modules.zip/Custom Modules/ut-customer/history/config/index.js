
module.exports = {
    customer: require('./customer'),
    kyc: require('./kyc'),
    organization: require('./organization')
};
