module.exports = {
    'General Info': {
        keys: [
            {key: 'kyc,customerType', title: 'Customer Type'},
            {key: 'kyc,description', title: 'Description'},
            {key: 'kyc,organizationName', title: 'BusinessUnit'},
            {key: 'kyc,displayName', title: 'KYC Level'},
            {key: 'kyc,statusId', title: 'Status'}
        ],
        single: true
    }
};
