module.exports = {
    Identity: {
        keys: [
            {key: 'person,firstName', title: 'First Name'},
            {key: 'person,middleName', title: 'Middle Name'},
            {key: 'person,middleName', title: 'Middle Name'},
            {key: 'person,lastName', title: 'Last Name'}
        ],
        single: true
    },
    'General Info': {
        keys: [
            {key: 'customer,customerTypeId', title: 'Type'},
            {key: 'person,dateOfBirth', title: 'Date of Birth', transform: (value) => { return value ? new Date(value).toLocaleDateString() : null; }},
            {key: 'person,gender', title: 'Gender'},
            {key: 'person,nationality', title: 'Nationality'},
            {key: 'person,language ', title: 'Language'},
            {key: 'person,maritalStatusName', title: 'Marital Status'},
            {key: 'person,familyMembers', title: 'Number of Family Members'},
            {key: 'customer,organizationName', title: 'Business Unit'},
            {key: 'person,educationName', title: 'Education'},
            {key: 'person,employmentName', title: 'Employment'},
            {key: 'person,employerName', title: 'Employer Name'},
            {key: 'person,employerCategoryName', title: 'Employer category'},
            {key: 'person,employmentDate', title: 'Date of Employment', transform: (value) => { return value ? new Date(value).toLocaleDateString() : null; }},
            {key: 'customer,industryName', title: 'Business Sector'},
            {key: 'person,incomeRangeName', title: 'Income Range'}
        ],
        single: true
    },
    Address: {
        keys: [
            {key: 'address,addressTypeId', title: 'Type'},
            {key: 'address,addressZone1Id', title: 'Address Zone 1'},
            {key: 'address,addressZone2Id', title: 'Address Zone 1'},
            {key: 'address,addressZone3Id', title: 'Address Zone 1'},
            {key: 'address,addressZone4Id', title: 'Address Zone 1'},
            {key: 'address,value', title: 'Address'}
        ],
        single: false
    },
    'Phone number': {
        keys: [
            {key: 'phone,phoneTypeId', title: 'Type'},
            {key: 'phone,phoneNumber', title: 'Number'}
        ],
        single: false
    },
    Email: {
        keys: [
            {key: 'email,emailTypeId', title: 'Type'},
            {key: 'email,value', title: 'Address'}
        ],
        single: false
    },
    Documents: {
        single: false,
        keys: [
            {key: 'document,documentId', title: 'documentId'},
            {key: 'document,documentTypeId', title: 'documentTypeId'},
            {key: 'document,documentTypeName', title: 'documentTypeName'},
            {key: 'document,createdDate', title: 'createdDate', transform: (value) => { return value ? new Date(value).toLocaleDateString() : null; }},
            {key: 'document,statusId', title: 'statusId'},
            {key: 'document,description', title: 'description'},
            {key: 'document,documentNumber', title: 'documentNumber'},
            {key: 'document,countryName', title: 'countryName'},
            {key: 'document,documentOrder', title: 'documentOrder'}
        ]
    },
    Attachments: {
        single: false,
        keys: [
            {key: 'attachment,documentId', title: 'documentId'},
            {key: 'attachment,extension', title: 'extension'}
        ]
    },
    Accounts: {
        single: false,
        keys: [
            {key: 'account,accountNumber', title: 'Account Number'},
            {key: 'account,accountName', title: 'Account Name'},
            {key: 'account,productType', title: 'Product Type'},
            {key: 'account,productName', title: 'Product Name'},
            {key: 'account,currencyName', title: 'Currency'},
            {key: 'account,balance', title: 'Balance'},
            {key: 'account,stateName', title: 'Account Status'},
            {key: 'account,statusId', title: 'Status'}
        ]
    }
};
