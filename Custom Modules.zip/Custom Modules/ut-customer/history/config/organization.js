const { timeZones } = require('../helpers');
module.exports = {
    'General Info': {
        keys: [
            {key: 'organization.info,organizationName', title: 'Name'},
            {key: 'organization.info,code', title: 'Dao/Code'},
            {key: 'organization.info,executiveOfficer', title: 'Executive Officer'},
            {key: 'organization.info,tradeName', title: 'Trade name'},
            {key: 'organization.info,isEnabled', title: 'Lock Status', transform: (isEnabled) => isEnabled ? 'Unlocked' : 'Locked'}
        ],
        single: true
    },
    'Language, Time Zone AND Currency': {
        keys: [
            {key: 'organization.info,currency', title: 'Currency'},
            {key: 'organization.info,timeZone', title: 'Time Zone', transform: (value) => { return (timeZones.find((t) => { return t.key === value; }) || {}).name; }},
            {key: 'organization.info,primaryLanguageName', title: 'Primary Language'},
            {key: 'organization.info,countryName', title: 'Country'}
        ],
        single: true
    }
};
