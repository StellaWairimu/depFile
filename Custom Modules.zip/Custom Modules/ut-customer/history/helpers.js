function formatKYCAttributesAndCondition(attributes) {
    // convert attributes from the request to the correct format used in the store
    if (attributes && attributes.length > 0) {
        const result = {};
        const tempObj = {};
        attributes.forEach((attribute) => {
            const obj = {
                id: attribute.attributeId,
                name: attribute.itemNameTranslation,
                kycConditionAttributeId: attribute.kycConditionAttributeId
            };
            const index = tempObj[attribute.conditionId] ? Object.keys(tempObj[attribute.conditionId]).length : 0;
            !tempObj[attribute.conditionId] && (tempObj[attribute.conditionId] = {});
            tempObj[attribute.conditionId][index] = obj;
        });
        Object.keys(tempObj).forEach((key) => {
            const firstLevelObj = tempObj[key];
            let id = null;
            Object.keys(firstLevelObj).forEach((objKey, index) => {
                const obj = firstLevelObj[objKey];
                if (index === 0) {
                    id = obj.id;
                    const value = {
                        id: obj.id,
                        name: obj.name,
                        kycConditionAttributeId: obj.kycConditionAttributeId,
                        conditions: []
                    };
                    result[obj.id] = value;
                } else {
                    !result[id].conditions && (result[id].conditions = {});
                    result[id].conditions[index - 1] = {
                        condition: {
                            key: '1',
                            name: 'OR'
                        },
                        attribute: {
                            key: obj.id,
                            name: obj.name,
                            kycConditionAttributeId: obj.kycConditionAttributeId
                        }
                    };
                }
            });
        });
        return result;
    } else {
        return {};
    }
}

const timeZones = [
    {key: '000', name: '(GMT-12:00) International Date Line West'},
    {key: '001', name: '(GMT-11:00) Midway Island, Samoa'},
    {key: '002', name: '(GMT-10:00) Hawaii'},
    {key: '003', name: '(GMT-09:00) Alaska'},
    {key: '004', name: '(GMT-08:00) Pacific Time (US and Canada); Tijuana'},
    {key: '010', name: '(GMT-07:00) Mountain Time (US and Canada)'},
    {key: '013', name: '(GMT-07:00) Chihuahua, La Paz, Mazatlan'},
    {key: '015', name: '(GMT-07:00) Arizona'},
    {key: '020', name: '(GMT-06:00) Central Time (US and Canada'},
    {key: '025', name: '(GMT-06:00) Saskatchewan'},
    {key: '030', name: '(GMT-06:00) Guadalajara, Mexico City, Monterrey'},
    {key: '033', name: '(GMT-06:00) Central America'},
    {key: '035', name: '(GMT-05:00) Eastern Time (US and Canada)'},
    {key: '040', name: '(GMT-05:00) Indiana (East)'},
    {key: '045', name: '(GMT-05:00) Bogota, Lima, Quito'},
    {key: '050', name: '(GMT-04:00) Atlantic Time (Canada)'},
    {key: '055', name: '(GMT-04:00) Caracas, La Paz'},
    {key: '056', name: '(GMT-04:00) Santiago'},
    {key: '060', name: '(GMT-03:30) Newfoundland and Labrador'},
    {key: '065', name: '(GMT-03:00) Brasilia'},
    {key: '070', name: '(GMT-03:00) Buenos Aires, Georgetown'},
    {key: '073', name: '(GMT-03:00) Greenland'},
    {key: '075', name: '(GMT-02:00) Mid-Atlantic'},
    {key: '080', name: '(GMT-01:00) Azores'},
    {key: '083', name: '(GMT-01:00) Cape Verde Islands'},
    {key: '085', name: '(GMT) Greenwich Mean Time: Dublin, Edinburgh, Lisbon, London'},
    {key: '090', name: '(GMT) Casablanca, Monrovia'},
    {key: '095', name: '(GMT+01:00) Belgrade, Bratislava, Budapest, Ljubljana, Prague'},
    {key: '100', name: '(GMT+01:00) Sarajevo, Skopje, Warsaw, Zagreb'},
    {key: '105', name: '(GMT+01:00) Brussels, Copenhagen, Madrid, Paris'},
    {key: '110', name: '(GMT+01:00) Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna'},
    {key: '113', name: '(GMT+01:00) West Central Africa'},
    {key: '115', name: '(GMT+02:00) Bucharest'},
    {key: '120', name: '(GMT+02:00) Cairo'},
    {key: '125', name: '(GMT+02:00) Helsinki, Kiev, Riga, Sofia, Tallinn, Vilnius'},
    {key: '130', name: '(GMT+02:00) Athens, Istanbul, Minsk'},
    {key: '135', name: '(GMT+02:00) Jerusalem'},
    {key: '140', name: '(GMT+02:00) Harare, Pretoria'},
    {key: '145', name: '(GMT+03:00) Moscow, St. Petersburg, Volgograd'},
    {key: '150', name: '(GMT+03:00) Kuwait, Riyadh'},
    {key: '155', name: '(GMT+03:00) Nairobi'},
    {key: '158', name: '(GMT+03:00) Baghdad'},
    {key: '160', name: '(GMT+03:30) Tehran'},
    {key: '165', name: '(GMT+04:00) Abu Dhabi, Muscat'},
    {key: '170', name: '(GMT+04:00) Baku, Tbilisi, Yerevan'},
    {key: '175', name: '(GMT+04:30) Kabul'},
    {key: '180', name: '(GMT+05:00) Ekaterinburg'},
    {key: '185', name: '(GMT+05:00) Islamabad, Karachi, Tashkent'},
    {key: '190', name: '(GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi'},
    {key: '193', name: '(GMT+05:45) Kathmandu'},
    {key: '195', name: '(GMT+06:00) Astana, Dhaka'},
    {key: '200', name: '(GMT+06:00) Sri Jayawardenepura'},
    {key: '201', name: '(GMT+06:00) Almaty, Novosibirsk'},
    {key: '203', name: '(GMT+06:30) Yangon Rangoon'},
    {key: '205', name: '(GMT+07:00) Bangkok, Hanoi, Jakarta'},
    {key: '207', name: '(GMT+07:00) Krasnoyarsk'},
    {key: '210', name: '(GMT+08:00) Beijing, Chongqing, Hong Kong SAR, Urumqi'},
    {key: '215', name: '(GMT+08:00) Kuala Lumpur, Singapore'},
    {key: '220', name: '(GMT+08:00) Taipei'},
    {key: '225', name: '(GMT+08:00) Perth'},
    {key: '227', name: '(GMT+08:00) Irkutsk, Ulaanbaatar'},
    {key: '230', name: '(GMT+09:00) Seoul'},
    {key: '235', name: '(GMT+09:00) Osaka, Sapporo, Tokyo'},
    {key: '240', name: '(GMT+09:00) Yakutsk'},
    {key: '245', name: '(GMT+09:30) Darwin'},
    {key: '250', name: '(GMT+09:30) Adelaide'},
    {key: '255', name: '(GMT+10:00) Canberra, Melbourne, Sydney'},
    {key: '260', name: '(GMT+10:00) Brisbane'},
    {key: '265', name: '(GMT+10:00) Hobart'},
    {key: '270', name: '(GMT+10:00) Vladivostok'},
    {key: '275', name: '(GMT+10:00) Guam, Port Moresby'},
    {key: '280', name: '(GMT+11:00) Magadan, Solomon Islands, New Caledonia'},
    {key: '285', name: '(GMT+12:00) Fiji Islands, Kamchatka, Marshall Islands'},
    {key: '290', name: '(GMT+12:00) Auckland, Wellington'},
    {key: '300', name: "(GMT+13:00) Nuku'alofa"}
];

module.exports = {
    timeZones,
    formatKYCAttributesAndCondition
};
