## [6.34.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.34.6...v6.34.7) (2020-07-27)


### Bug Fixes

* VFM-717 Customer get and approve now include the udf column ([40d2a85](https://git.softwaregroup.com/ut5/ut-customer/commit/40d2a85a04e0b99152f9a4f7e3bb2cc73c5f1a36))



## [6.34.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.34.5...v6.34.6) (2020-07-20)


### Bug Fixes

* You can now pass an existing actorId to customer.customer.add ([657375b](https://git.softwaregroup.com/ut5/ut-customer/commit/657375bba5ef044c76cc2370b768efd6e6c71a36))



## [6.34.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.34.4...v6.34.5) (2020-02-12)



## [6.34.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.34.3...v6.34.4) (2020-01-27)


### Bug Fixes

* tests ([886acd4](https://git.softwaregroup.com/ut5/ut-customer/commit/886acd4))



## [6.34.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.34.2...v6.34.3) (2019-10-01)



## [6.34.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.34.1...v6.34.2) (2019-10-01)


### Bug Fixes

* invalid selector ([ab169d8](https://git.softwaregroup.com/ut5/ut-customer/commit/ab169d8))



## [6.34.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.34.0...v6.34.1) (2019-09-30)


### Bug Fixes

* clear default margins ([c5857ab](https://git.softwaregroup.com/ut5/ut-customer/commit/c5857ab))
* remove margin from last child ([46265ea](https://git.softwaregroup.com/ut5/ut-customer/commit/46265ea))
* toolbox events ([26cd4f0](https://git.softwaregroup.com/ut5/ut-customer/commit/26cd4f0))



# [6.34.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.33.8...v6.34.0) (2019-07-07)


### Features

* create mergeJSON and  getNearest SP ([a9c349e](https://git.softwaregroup.com/ut5/ut-customer/commit/a9c349e))



## [6.33.8](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.33.7...v6.33.8) (2019-04-29)


### Bug Fixes

* fix bad export ([4a68a9c](https://git.softwaregroup.com/ut5/ut-customer/commit/4a68a9c))



## [6.33.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.33.6...v6.33.7) (2019-04-10)


### Bug Fixes

* improve example ([71b1caa](https://git.softwaregroup.com/ut5/ut-customer/commit/71b1caa))
* improve organization seed configuration ([2f21ad2](https://git.softwaregroup.com/ut5/ut-customer/commit/2f21ad2))
* linting ([60bc98f](https://git.softwaregroup.com/ut5/ut-customer/commit/60bc98f))



## [6.33.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.33.5...v6.33.6) (2019-04-03)


### Bug Fixes

* alter organizationsSeed ([35a9977](https://git.softwaregroup.com/ut5/ut-customer/commit/35a9977))



## [6.33.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.33.4...v6.33.5) (2019-04-03)


### Bug Fixes

* encoding ([c76b9a1](https://git.softwaregroup.com/ut5/ut-customer/commit/c76b9a1))



## [6.33.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.33.3...v6.33.4) (2019-04-03)


### Bug Fixes

* typo ([3e8e29b](https://git.softwaregroup.com/ut5/ut-customer/commit/3e8e29b))



## [6.33.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.33.2...v6.33.3) (2019-03-29)


### Bug Fixes

* move seeds from impl-standard ([889aa5d](https://git.softwaregroup.com/ut5/ut-customer/commit/889aa5d))



## [6.33.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.33.1...v6.33.2) (2019-03-28)


### Bug Fixes

* move seed config ([a7d3354](https://git.softwaregroup.com/ut5/ut-customer/commit/a7d3354))



## [6.33.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.33.0...v6.33.1) (2019-03-28)


### Bug Fixes

* move seed config ([9fa2e93](https://git.softwaregroup.com/ut5/ut-customer/commit/9fa2e93))



# [6.33.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.32.4...v6.33.0) (2019-03-27)


### Bug Fixes

* example ([77060b8](https://git.softwaregroup.com/ut5/ut-customer/commit/77060b8))
* move [@organization](https://git.softwaregroup.com/organization)TypeId variable declaration inside the if statement ([c2356b0](https://git.softwaregroup.com/ut5/ut-customer/commit/c2356b0))


### Features

* load organizations from json ([719bf58](https://git.softwaregroup.com/ut5/ut-customer/commit/719bf58))
* organizations seed ([0981603](https://git.softwaregroup.com/ut5/ut-customer/commit/0981603))



## [6.32.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.32.3...v6.32.4) (2019-03-22)



## [6.32.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.32.2...v6.32.3) (2019-02-10)



## [6.32.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.32.1...v6.32.2) (2019-02-06)



## [6.32.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.32.0...v6.32.1) (2019-02-02)


### Bug Fixes

* upgrade dependencies ([531f94e](https://git.softwaregroup.com/ut5/ut-customer/commit/531f94e))



# [6.32.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.32.0-rc-godfather.28...v6.32.0) (2019-02-02)



<a name="6.31.0"></a>
# [6.31.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.31.0-rc-einstein.9...v6.31.0) (2018-08-02)



<a name="6.30.0"></a>
# [6.30.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.30.0-rc-diesel.21...v6.30.0) (2018-06-07)



<a name="6.29.0"></a>
# [6.29.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.29.0-rc-cubalibre.6...v6.29.0) (2018-04-17)



<a name="6.28.1"></a>
## [6.28.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.28.0...v6.28.1) (2018-03-08)


### Bug Fixes

* remove dependency to when.js ([8c46ded](https://git.softwaregroup.com/ut5/ut-customer/commit/8c46ded))



<a name="6.28.0"></a>
# [6.28.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.28.0-rc-bahur.26...v6.28.0) (2018-03-02)



<a name="6.27.2"></a>
## [6.27.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.27.1...v6.27.2) (2017-12-14)


### Bug Fixes

* alter organizationsVisibleForUnapproved ([e8ea1b9](https://git.softwaregroup.com/ut5/ut-customer/commit/e8ea1b9))



<a name="6.27.1"></a>
## [6.27.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.26.0-rc-acapulco.31...v6.27.1) (2017-12-13)



<a name="6.26.0"></a>
# [6.26.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.26.0-rc-acapulco.0...v6.26.0) (2017-11-01)



<a name="6.25.4"></a>
## [6.25.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.25.3...v6.25.4) (2017-10-31)


### Bug Fixes

* PRP-890: fix issue with unavailable units when searching in the BU popup ([31f0f6e](https://git.softwaregroup.com/ut5/ut-customer/commit/31f0f6e))



<a name="6.25.4"></a>
## [6.25.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.25.3...v6.25.4) (2017-10-31)


### Bug Fixes

* PRP-890: fix issue with unavailable units when searching in the BU popup ([31f0f6e](https://git.softwaregroup.com/ut5/ut-customer/commit/31f0f6e))



<a name="6.25.3"></a>
## [6.25.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.25.0...v6.25.3) (2017-10-30)


### Bug Fixes

* fix/PRP-890: add option to disable business units in bu select popup ([e921011](https://git.softwaregroup.com/ut5/ut-customer/commit/e921011))
* PRP-973: fix customer.organization.lock to copy description into the unapproved table ([033aad5](https://git.softwaregroup.com/ut5/ut-customer/commit/033aad5))



<a name="6.25.2"></a>
## [6.25.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.25.0...v6.25.2) (2017-10-30)


### Bug Fixes

* fix/PRP-890: add option to disable business units in bu select popup ([e921011](https://git.softwaregroup.com/ut5/ut-customer/commit/e921011))
* PRP-973: fix customer.organization.lock to copy description into the unapproved table ([033aad5](https://git.softwaregroup.com/ut5/ut-customer/commit/033aad5))



<a name="6.25.1"></a>
## [6.25.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.25.0...v6.25.1) (2017-10-30)


### Bug Fixes

* fix/PRP-890: add option to disable business units in bu select popup ([e921011](https://git.softwaregroup.com/ut5/ut-customer/commit/e921011))



<a name="6.25.0"></a>
# [6.25.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.22.6...v6.25.0) (2017-10-27)


### Bug Fixes

* **customer.fetch:** UIS-2952 add search by fullName ([6cb2d22](https://git.softwaregroup.com/ut5/ut-customer/commit/6cb2d22))
* fix UIS-2935 ([7f9b4d8](https://git.softwaregroup.com/ut5/ut-customer/commit/7f9b4d8))
* UIS-2938 add sort by parent ([d400aaa](https://git.softwaregroup.com/ut5/ut-customer/commit/d400aaa))
* UIS-2938 order by parents case in order clause ([de941dd](https://git.softwaregroup.com/ut5/ut-customer/commit/de941dd))
* UIS-2938 order clause ([a36694e](https://git.softwaregroup.com/ut5/ut-customer/commit/a36694e))
* UIS-2952 titles case ([b9ebfd9](https://git.softwaregroup.com/ut5/ut-customer/commit/b9ebfd9))
* UIS-2953 sorting by referred MSISDN number ([f2bc755](https://git.softwaregroup.com/ut5/ut-customer/commit/f2bc755))
* UIS-3578 return descriptions, not ids ([622ce4a](https://git.softwaregroup.com/ut5/ut-customer/commit/622ce4a))
* UIS-3611: remove default selected Business Unit from the BusinessUnits popup ([13939b2](https://git.softwaregroup.com/ut5/ut-customer/commit/13939b2))
* update procedure parameter noResultSet ([11278ee](https://git.softwaregroup.com/ut5/ut-customer/commit/11278ee))



<a name="6.22.6"></a>
## [6.22.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.22.5...v6.22.6) (2017-08-17)


### Bug Fixes

* **organization.add:** UIS-3101 add check for parents recursion ([2d22b8c](https://git.softwaregroup.com/ut5/ut-customer/commit/2d22b8c))
* double call ([545c674](https://git.softwaregroup.com/ut5/ut-customer/commit/545c674))
* reorder call of tables ([737da60](https://git.softwaregroup.com/ut5/ut-customer/commit/737da60))
* reorder call of tables ([a5e9f22](https://git.softwaregroup.com/ut5/ut-customer/commit/a5e9f22))
* restructure rebuild due to deadlocks ([d4bcfe9](https://git.softwaregroup.com/ut5/ut-customer/commit/d4bcfe9))
* UIS-3101 add check for related parents ([c950c35](https://git.softwaregroup.com/ut5/ut-customer/commit/c950c35))
* **organization.edit:** UIS-3101 remove check for child input as parent ([54330af](https://git.softwaregroup.com/ut5/ut-customer/commit/54330af))



<a name="6.22.5"></a>
## [6.22.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.22.4...v6.22.5) (2017-08-09)


### Bug Fixes

* UIS-2765 No Confirmation message is displayed when editing a Customer ([a31fc02](https://git.softwaregroup.com/ut5/ut-customer/commit/a31fc02))
* UIS-2765 No Confirmation message is displayed when editing a Customer ([87168cc](https://git.softwaregroup.com/ut5/ut-customer/commit/87168cc))



<a name="6.22.4"></a>
## [6.22.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.22.3...v6.22.4) (2017-08-08)


### Bug Fixes

* add order from phoneNumber ([e648565](https://git.softwaregroup.com/ut5/ut-customer/commit/e648565))
* merge conflict ([dd21c96](https://git.softwaregroup.com/ut5/ut-customer/commit/dd21c96))
* UIS-2507 upload files without active session ([5baf23b](https://git.softwaregroup.com/ut5/ut-customer/commit/5baf23b))



<a name="6.22.3"></a>
## [6.22.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.22.2...v6.22.3) (2017-08-07)


### Bug Fixes

* restructure SPs ([f9eaee6](https://git.softwaregroup.com/ut5/ut-customer/commit/f9eaee6))



<a name="6.22.2"></a>
## [6.22.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.22.1...v6.22.2) (2017-08-07)


### Bug Fixes

* joi validation fix ([88a24b5](https://git.softwaregroup.com/ut5/ut-customer/commit/88a24b5))
* refactor ([46572c2](https://git.softwaregroup.com/ut5/ut-customer/commit/46572c2))
* refactor ([c72f82e](https://git.softwaregroup.com/ut5/ut-customer/commit/c72f82e))
* refactor for optimization ([5b624a0](https://git.softwaregroup.com/ut5/ut-customer/commit/5b624a0))
* update procedure customer.fetch ([6fcee2a](https://git.softwaregroup.com/ut5/ut-customer/commit/6fcee2a))



<a name="6.22.1"></a>
## [6.22.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.22.0...v6.22.1) (2017-08-04)


### Bug Fixes

* upgrade ut-front-react? ([b5b1651](https://git.softwaregroup.com/ut5/ut-customer/commit/b5b1651))



<a name="6.22.0"></a>
# [6.22.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.21.1...v6.22.0) (2017-08-04)


### Bug Fixes

* version bump ([2730f9f](https://git.softwaregroup.com/ut5/ut-customer/commit/2730f9f))



<a name="6.21.1"></a>
## [6.21.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.21.0...v6.21.1) (2017-08-01)


### Bug Fixes

* alter logic behind invalidProduct error message ([f03f772](https://git.softwaregroup.com/ut5/ut-customer/commit/f03f772))



<a name="6.21.0"></a>
# [6.21.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.20.2...v6.21.0) (2017-08-01)


### Bug Fixes

* ABT-1751 Error displayed when customer DOB is today ([27f7195](https://git.softwaregroup.com/ut5/ut-customer/commit/27f7195))
* ABT-1831 fixed bug on confirmation message for deactivating referral ([cb7d98a](https://git.softwaregroup.com/ut5/ut-customer/commit/cb7d98a))
* ABT-1955: avoid filtering business units when filterIds is empty array ([3954e4a](https://git.softwaregroup.com/ut5/ut-customer/commit/3954e4a))
* ABT-1996 include the missed M/C status ([bb9027d](https://git.softwaregroup.com/ut5/ut-customer/commit/bb9027d))
* ABT-702 fix condition for excluding documents from the first tab ([18fd679](https://git.softwaregroup.com/ut5/ut-customer/commit/18fd679))
* add actorid as a parameter into document.edit ([59e94e2](https://git.softwaregroup.com/ut5/ut-customer/commit/59e94e2))
* add check for is customer account ([7c6f8d4](https://git.softwaregroup.com/ut5/ut-customer/commit/7c6f8d4))
* add external user name ([c0658ac](https://git.softwaregroup.com/ut5/ut-customer/commit/c0658ac))
* alter fetchSP ([2a6df81](https://git.softwaregroup.com/ut5/ut-customer/commit/2a6df81))
* business unit ([d344cd6](https://git.softwaregroup.com/ut5/ut-customer/commit/d344cd6))
* business unit ([f7bacca](https://git.softwaregroup.com/ut5/ut-customer/commit/f7bacca))
* customer.fetch ([6029ddc](https://git.softwaregroup.com/ut5/ut-customer/commit/6029ddc))
* MCTUNE-2550 - fix some procedures by Vassil request ([424f6f9](https://git.softwaregroup.com/ut5/ut-customer/commit/424f6f9))
* MCTUNE-3045 - return currency array in the response of customer.cbs.activity ([8db90fd](https://git.softwaregroup.com/ut5/ut-customer/commit/8db90fd))
* MCTUNE-3246 - fil t24 customer update call ([054e082](https://git.softwaregroup.com/ut5/ut-customer/commit/054e082))
* MCTUNE-3246 - fixed dslkgskfds;ksd;fkds;lfksd ([b33cac7](https://git.softwaregroup.com/ut5/ut-customer/commit/b33cac7))
* MCTUNE-3285 - fixed dslkgskfds;ksd;fkds;lfksd ([df9d603](https://git.softwaregroup.com/ut5/ut-customer/commit/df9d603))
* MCTUNE-4251 - cannot validate phone number ([f0dcbd4](https://git.softwaregroup.com/ut5/ut-customer/commit/f0dcbd4))
* UATMC-408 - fixed prod issue ([e149f32](https://git.softwaregroup.com/ut5/ut-customer/commit/e149f32))
* UIS-2746 call the correct procedure for document types ([1972e80](https://git.softwaregroup.com/ut5/ut-customer/commit/1972e80))
* UIS-3101 linting caused by develop branch ([aed750d](https://git.softwaregroup.com/ut5/ut-customer/commit/aed750d))
* **organizationsVisibleFor:** UIS-3101 distinct result ([ed7cd8b](https://git.softwaregroup.com/ut5/ut-customer/commit/ed7cd8b))
* update procedure ([bd65dcb](https://git.softwaregroup.com/ut5/ut-customer/commit/bd65dcb))
* update procedure ([ee2a158](https://git.softwaregroup.com/ut5/ut-customer/commit/ee2a158))
* update procedure ([c25b593](https://git.softwaregroup.com/ut5/ut-customer/commit/c25b593))
* update procedure ([043b3a9](https://git.softwaregroup.com/ut5/ut-customer/commit/043b3a9))
* update procedure approved ([77a6371](https://git.softwaregroup.com/ut5/ut-customer/commit/77a6371))
* update procedure customer.add ([7c1067c](https://git.softwaregroup.com/ut5/ut-customer/commit/7c1067c))


### Features

* ABT-1955: add support for filtering organizations by a supplied array of filterIds ([d75728e](https://git.softwaregroup.com/ut5/ut-customer/commit/d75728e))
* ABT-1955: fix BU tree nesting identation ([9dfe2f3](https://git.softwaregroup.com/ut5/ut-customer/commit/9dfe2f3))
* ABT-1955: moving filtering logic to reducers, change store connections ([224a6d2](https://git.softwaregroup.com/ut5/ut-customer/commit/224a6d2))
* ABT-702 integrate the documents on edit customer ([00238be](https://git.softwaregroup.com/ut5/ut-customer/commit/00238be))
* ABT-702 integrate the documents tab into the customer ([820830a](https://git.softwaregroup.com/ut5/ut-customer/commit/820830a))
* procedure for smtp configuration get by user email ([2627935](https://git.softwaregroup.com/ut5/ut-customer/commit/2627935))
* procedure update ([f3d469f](https://git.softwaregroup.com/ut5/ut-customer/commit/f3d469f))



<a name="6.20.2"></a>
## [6.20.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.20.1...v6.20.2) (2017-07-26)



<a name="6.20.1"></a>
## [6.20.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.20.0...v6.20.1) (2017-07-26)



<a name="6.20.0"></a>
# [6.20.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.14...v6.20.0) (2017-07-25)


### Bug Fixes

* ABT-1751 Error displayed when customer DOB is today ([62a8dbc](https://git.softwaregroup.com/ut5/ut-customer/commit/62a8dbc))
* ABT-1996 include the missed M/C status ([1d1e9d6](https://git.softwaregroup.com/ut5/ut-customer/commit/1d1e9d6))
* ABT-2019: fix joi validations for customer.organization.getBUsParents ([3ed8708](https://git.softwaregroup.com/ut5/ut-customer/commit/3ed8708))
* **organization.approve:** UIS-3050 move resultset to approve SP ([81929ad](https://git.softwaregroup.com/ut5/ut-customer/commit/81929ad))
* ABT-702 fix condition for excluding documents from the first tab ([2882b9a](https://git.softwaregroup.com/ut5/ut-customer/commit/2882b9a))
* **organization.approve:** UIS-3050 remove resultSet from approve ([d157c58](https://git.softwaregroup.com/ut5/ut-customer/commit/d157c58))
* add check for is customer account ([df9818e](https://git.softwaregroup.com/ut5/ut-customer/commit/df9818e))
* add paramater - value pair when calling rebuild ([5f6b9c2](https://git.softwaregroup.com/ut5/ut-customer/commit/5f6b9c2))
* business unit ([9450a6e](https://git.softwaregroup.com/ut5/ut-customer/commit/9450a6e))
* business unit ([cdb0354](https://git.softwaregroup.com/ut5/ut-customer/commit/cdb0354))
* change organization rebuilding ([42f5279](https://git.softwaregroup.com/ut5/ut-customer/commit/42f5279))
* fix bug into closing acount ([17bd76a](https://git.softwaregroup.com/ut5/ut-customer/commit/17bd76a))
* header buttons type to make it highlighted ([935e4e0](https://git.softwaregroup.com/ut5/ut-customer/commit/935e4e0))
* MCTUNE-4251 - cannot validate phone number ([f51e4c9](https://git.softwaregroup.com/ut5/ut-customer/commit/f51e4c9))
* replace into clause because of the history triggers ([64f9691](https://git.softwaregroup.com/ut5/ut-customer/commit/64f9691))
* UIS-2927: fix joi validation for customer.organization.edit ([35e71ec](https://git.softwaregroup.com/ut5/ut-customer/commit/35e71ec))
* **organization.editApproved:** rebuild hierarchy only if parent BUs are added or removed ([06ed864](https://git.softwaregroup.com/ut5/ut-customer/commit/06ed864))
* UIS-2950: insert current time for createdOn and updatedOn when adding a customer, fix display of createdOn and branch in customers grid ([4bc691d](https://git.softwaregroup.com/ut5/ut-customer/commit/4bc691d))
* UIS-3050 tables lock order in organization SPs ([0b15c7f](https://git.softwaregroup.com/ut5/ut-customer/commit/0b15c7f))
* update procedure ([71ceb63](https://git.softwaregroup.com/ut5/ut-customer/commit/71ceb63))
* update procedure customer.add ([39d946b](https://git.softwaregroup.com/ut5/ut-customer/commit/39d946b))


### Features

* ABT-702 integrate the documents tab into the customer ([cee1b11](https://git.softwaregroup.com/ut5/ut-customer/commit/cee1b11))



<a name="6.19.14"></a>
## [6.19.14](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.13...v6.19.14) (2017-07-24)



<a name="6.19.13"></a>
## [6.19.13](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.12...v6.19.13) (2017-07-24)



<a name="6.19.12"></a>
## [6.19.12](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.11...v6.19.12) (2017-07-21)



<a name="6.19.11"></a>
## [6.19.11](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.10...v6.19.11) (2017-07-20)



<a name="6.19.10"></a>
## [6.19.10](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.9...v6.19.10) (2017-07-20)



<a name="6.19.9"></a>
## [6.19.9](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.8...v6.19.9) (2017-07-20)



<a name="6.19.8"></a>
## [6.19.8](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.7...v6.19.8) (2017-07-20)



<a name="6.19.7"></a>
## [6.19.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.6...v6.19.7) (2017-07-14)



<a name="6.19.6"></a>
## [6.19.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.5...v6.19.6) (2017-07-12)



<a name="6.19.5"></a>
## [6.19.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.4...v6.19.5) (2017-07-07)


### Bug Fixes

* MCTUNE-4251 - cannot validate phone number ([6588d9e](https://git.softwaregroup.com/ut5/ut-customer/commit/6588d9e))



<a name="6.19.4"></a>
## [6.19.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.3...v6.19.4) (2017-07-07)



<a name="6.19.3"></a>
## [6.19.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.2...v6.19.3) (2017-07-06)


### Bug Fixes

* MCTUNE-3246 - fixed dslkgskfds;ksd;fkds;lfksd ([2d3ad65](https://git.softwaregroup.com/ut5/ut-customer/commit/2d3ad65))
* MCTUNE-3285 - fixed dslkgskfds;ksd;fkds;lfksd ([88644a9](https://git.softwaregroup.com/ut5/ut-customer/commit/88644a9))



<a name="6.19.2"></a>
## [6.19.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.1...v6.19.2) (2017-07-05)


### Bug Fixes

* MCTUNE-3045 - return currency array in the response of customer.cbs.activity ([60c1921](https://git.softwaregroup.com/ut5/ut-customer/commit/60c1921))



<a name="6.19.1"></a>
## [6.19.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.19.0...v6.19.1) (2017-07-05)


### Bug Fixes

* add actorid as a parameter into document.edit ([36df48e](https://git.softwaregroup.com/ut5/ut-customer/commit/36df48e))



<a name="6.19.0"></a>
# [6.19.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.18.11...v6.19.0) (2017-07-05)


### Bug Fixes

* ABT-1831 fixed bug on confirmation message for deactivating referral ([978913b](https://git.softwaregroup.com/ut5/ut-customer/commit/978913b))
* ABT-1955: avoid filtering business units when filterIds is empty array ([92ad9ad](https://git.softwaregroup.com/ut5/ut-customer/commit/92ad9ad))
* add external user name ([651ea0f](https://git.softwaregroup.com/ut5/ut-customer/commit/651ea0f))


### Features

* ABT-1955: add support for filtering organizations by a supplied array of filterIds ([cb05f21](https://git.softwaregroup.com/ut5/ut-customer/commit/cb05f21))
* ABT-1955: fix BU tree nesting identation ([be5c8ea](https://git.softwaregroup.com/ut5/ut-customer/commit/be5c8ea))
* ABT-1955: moving filtering logic to reducers, change store connections ([cebede0](https://git.softwaregroup.com/ut5/ut-customer/commit/cebede0))
* procedure for smtp configuration get by user email ([d2c301b](https://git.softwaregroup.com/ut5/ut-customer/commit/d2c301b))
* procedure update ([0cdfaf9](https://git.softwaregroup.com/ut5/ut-customer/commit/0cdfaf9))



<a name="6.18.11"></a>
## [6.18.11](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.18.10...v6.18.11) (2017-07-03)



<a name="6.18.10"></a>
## [6.18.10](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.18.9...v6.18.10) (2017-07-03)


### Bug Fixes

* MCTUNE-2550 - fix some procedures by Vassil request ([c90bcce](https://git.softwaregroup.com/ut5/ut-customer/commit/c90bcce))



<a name="6.18.9"></a>
## [6.18.9](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.18.8...v6.18.9) (2017-07-02)



<a name="6.18.8"></a>
## [6.18.8](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.18.7...v6.18.8) (2017-07-02)



<a name="6.18.7"></a>
## [6.18.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.18.6...v6.18.7) (2017-07-02)



<a name="6.18.6"></a>
## [6.18.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.18.5...v6.18.6) (2017-07-01)


### Bug Fixes

* MCTUNE-3246 - fil t24 customer update call ([7f055b1](https://git.softwaregroup.com/ut5/ut-customer/commit/7f055b1))



<a name="6.18.5"></a>
## [6.18.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.18.4...v6.18.5) (2017-07-01)



<a name="6.18.4"></a>
## [6.18.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.18.3...v6.18.4) (2017-06-29)



<a name="6.18.3"></a>
## [6.18.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.18.2...v6.18.3) (2017-06-28)



<a name="6.18.2"></a>
## [6.18.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.18.1...v6.18.2) (2017-06-28)



<a name="6.18.1"></a>
## [6.18.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.18.0...v6.18.1) (2017-06-28)



<a name="6.18.0"></a>
# [6.18.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.17.7...v6.18.0) (2017-06-28)


### Bug Fixes

* ABT-1426 add joi validation for graphFetch ([32d0ac0](https://git.softwaregroup.com/ut5/ut-customer/commit/32d0ac0))
* ABT-1426 organization info resultset in get ([55a2111](https://git.softwaregroup.com/ut5/ut-customer/commit/55a2111))
* ABT-1426 revert organization SP changes ([08340b4](https://git.softwaregroup.com/ut5/ut-customer/commit/08340b4))
* ABT-1634: add missing error styles for BusinessUnitsBox ([75c73fd](https://git.softwaregroup.com/ut5/ut-customer/commit/75c73fd))
* ABT-1690: fix linting ([4d3e2a8](https://git.softwaregroup.com/ut5/ut-customer/commit/4d3e2a8))
* ABT-1690: fix one linting error ([2824fc2](https://git.softwaregroup.com/ut5/ut-customer/commit/2824fc2))
* ABT-473 default organizationTypeId ([375aab1](https://git.softwaregroup.com/ut5/ut-customer/commit/375aab1))


### Features

* ABT-1426 edit and approve network ([08d82d7](https://git.softwaregroup.com/ut5/ut-customer/commit/08d82d7))
* ABT-1690: (WIP) make business units box fetch networks ([a27e67d](https://git.softwaregroup.com/ut5/ut-customer/commit/a27e67d))
* ABT-1690: change var name for consistency ([fcb17d2](https://git.softwaregroup.com/ut5/ut-customer/commit/fcb17d2))
* ABT-1690: fix business units store connection for customers ([9b71b45](https://git.softwaregroup.com/ut5/ut-customer/commit/9b71b45))
* ABT-1690: make BusinessUnits container respect requiresFetch value in the store ([45f8348](https://git.softwaregroup.com/ut5/ut-customer/commit/45f8348))
* ABT-1690: pass organizationTypeList parameter when fetching business units in the BusinessUnit container ([a9a265b](https://git.softwaregroup.com/ut5/ut-customer/commit/a9a265b))
* ABT-473 add description to organization ([ed3b899](https://git.softwaregroup.com/ut5/ut-customer/commit/ed3b899))
* ABT-473 add new params to organization.add ([ce47b0b](https://git.softwaregroup.com/ut5/ut-customer/commit/ce47b0b))
* ABT-473 add organization type as filter ([823175e](https://git.softwaregroup.com/ut5/ut-customer/commit/823175e))
* ABT-473 add role hierarchy ([77e361b](https://git.softwaregroup.com/ut5/ut-customer/commit/77e361b))
* ABT-473 set default to organization type ([9cb6ada](https://git.softwaregroup.com/ut5/ut-customer/commit/9cb6ada))



<a name="6.17.7"></a>
## [6.17.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.17.6...v6.17.7) (2017-06-27)



<a name="6.17.6"></a>
## [6.17.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.17.5...v6.17.6) (2017-06-27)


### Bug Fixes

* ABT-1837 check if actorType is null ([42c085b](https://git.softwaregroup.com/ut5/ut-customer/commit/42c085b))
* convert type ([307a76a](https://git.softwaregroup.com/ut5/ut-customer/commit/307a76a))



<a name="6.17.5"></a>
## [6.17.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.17.4...v6.17.5) (2017-06-27)


### Bug Fixes

* update customer add procedure and update customer number ([d589b5a](https://git.softwaregroup.com/ut5/ut-customer/commit/d589b5a))



<a name="6.17.4"></a>
## [6.17.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.17.3...v6.17.4) (2017-06-27)


### Bug Fixes

* ABT-1837 temporary custom if statement ([25a7ca5](https://git.softwaregroup.com/ut5/ut-customer/commit/25a7ca5))
* MCTUNE-3168 - When validate phone number from loan mobile app and t24 request failed, the number become as confirmed in loan app, but should not be ([1ca11a9](https://git.softwaregroup.com/ut5/ut-customer/commit/1ca11a9))



<a name="6.17.3"></a>
## [6.17.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.17.2...v6.17.3) (2017-06-27)


### Bug Fixes

* ABT-1837 remove duplicated person resultset ([6112b6b](https://git.softwaregroup.com/ut5/ut-customer/commit/6112b6b))



<a name="6.17.2"></a>
## [6.17.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.17.1...v6.17.2) (2017-06-27)


### Bug Fixes

* ABT-1837 invalid syntax ([159aa8f](https://git.softwaregroup.com/ut5/ut-customer/commit/159aa8f))
* ABT-1837 resultsets in customer.get ([56df624](https://git.softwaregroup.com/ut5/ut-customer/commit/56df624))



<a name="6.17.1"></a>
## [6.17.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.17.0...v6.17.1) (2017-06-27)


### Bug Fixes

* ABT-1837 customer.get in file.get ([2a8878f](https://git.softwaregroup.com/ut5/ut-customer/commit/2a8878f))



<a name="6.17.0"></a>
# [6.17.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.16.2...v6.17.0) (2017-06-27)


### Bug Fixes

* ABT-1837 primary language tests ([2be5323](https://git.softwaregroup.com/ut5/ut-customer/commit/2be5323))


### Features

* change display state of referrals ([3485310](https://git.softwaregroup.com/ut5/ut-customer/commit/3485310))
* Split referral statuses ABT-1662 Shenba's changes ([9a88d9e](https://git.softwaregroup.com/ut5/ut-customer/commit/9a88d9e))



<a name="6.16.2"></a>
## [6.16.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.16.1...v6.16.2) (2017-06-26)



<a name="6.16.1"></a>
## [6.16.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.16.0...v6.16.1) (2017-06-26)


### Bug Fixes

* add person and custoemr unapprovedID into the alter scripts ([d529364](https://git.softwaregroup.com/ut5/ut-customer/commit/d529364))
* add person and custoemr unapprovedID into the alter scripts ([32051f7](https://git.softwaregroup.com/ut5/ut-customer/commit/32051f7))
* MCTUNE-2600-fix ALTER conflict for customer.organizationsVisibleFor function on project start ([1ce25a2](https://git.softwaregroup.com/ut5/ut-customer/commit/1ce25a2))



<a name="6.16.0"></a>
# [6.16.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.15.2...v6.16.0) (2017-06-23)


### Bug Fixes

* add procedure ([92e25da](https://git.softwaregroup.com/ut5/ut-customer/commit/92e25da))
* add procedure for disable/enable MC ([1de7ef0](https://git.softwaregroup.com/ut5/ut-customer/commit/1de7ef0))
* add procedure for enable disable MC for customer ([bcfad33](https://git.softwaregroup.com/ut5/ut-customer/commit/bcfad33))
* add procedure for reject and discard ([ce6fc3e](https://git.softwaregroup.com/ut5/ut-customer/commit/ce6fc3e))
* alter get SPs ([b201aab](https://git.softwaregroup.com/ut5/ut-customer/commit/b201aab))
* alter tests ([037ffce](https://git.softwaregroup.com/ut5/ut-customer/commit/037ffce))
* apply fixes ([af2edff](https://git.softwaregroup.com/ut5/ut-customer/commit/af2edff))
* change customer discard and editApproved ([b431fc1](https://git.softwaregroup.com/ut5/ut-customer/commit/b431fc1))
* create configuration with enable/disable MC for test ([7863940](https://git.softwaregroup.com/ut5/ut-customer/commit/7863940))
* fix tests ([fc927e0](https://git.softwaregroup.com/ut5/ut-customer/commit/fc927e0))
* fixes ([64b6a13](https://git.softwaregroup.com/ut5/ut-customer/commit/64b6a13))
* procedure customer.customer.add ([cdb6fb2](https://git.softwaregroup.com/ut5/ut-customer/commit/cdb6fb2))
* test update ([5aa565b](https://git.softwaregroup.com/ut5/ut-customer/commit/5aa565b))
* tests ([2ab8cdf](https://git.softwaregroup.com/ut5/ut-customer/commit/2ab8cdf))
* unaprovedTTp ([3d4085b](https://git.softwaregroup.com/ut5/ut-customer/commit/3d4085b))
* update address ([82fa3ae](https://git.softwaregroup.com/ut5/ut-customer/commit/82fa3ae))
* update customer.edit ([3389c40](https://git.softwaregroup.com/ut5/ut-customer/commit/3389c40))
* update customer.edit procedure ([b394931](https://git.softwaregroup.com/ut5/ut-customer/commit/b394931))
* update joi validation and tests ([88835a1](https://git.softwaregroup.com/ut5/ut-customer/commit/88835a1))
* update procedure ([ae6536d](https://git.softwaregroup.com/ut5/ut-customer/commit/ae6536d))
* update procedure and joi validation ([b5b3047](https://git.softwaregroup.com/ut5/ut-customer/commit/b5b3047))
* update procedure customer.customer.edit  and in check VALUE = 1 ([dd7fc34](https://git.softwaregroup.com/ut5/ut-customer/commit/dd7fc34))
* update procedure customer.customer.edit with not account ([d350f20](https://git.softwaregroup.com/ut5/ut-customer/commit/d350f20))
* update procedure customer.fetch ([431a906](https://git.softwaregroup.com/ut5/ut-customer/commit/431a906))
* update procedure for customer ([7e2effe](https://git.softwaregroup.com/ut5/ut-customer/commit/7e2effe))
* update procedure for customer, person and joi validation ([5e74b89](https://git.softwaregroup.com/ut5/ut-customer/commit/5e74b89))
* update procedure for edit customer ([cced3ad](https://git.softwaregroup.com/ut5/ut-customer/commit/cced3ad))
* update procedure for MC ([8cd3b3d](https://git.softwaregroup.com/ut5/ut-customer/commit/8cd3b3d))


### Features

* customer MC ([037fb38](https://git.softwaregroup.com/ut5/ut-customer/commit/037fb38))



<a name="6.15.2"></a>
## [6.15.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.15.1...v6.15.2) (2017-06-23)



<a name="6.15.1"></a>
## [6.15.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.15.0...v6.15.1) (2017-06-22)



<a name="6.15.0"></a>
# [6.15.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.14.1...v6.15.0) (2017-06-20)


### Bug Fixes

* MCTUNE-2550 - package.json ([dba0488](https://git.softwaregroup.com/ut5/ut-customer/commit/dba0488))
* MCTUNE-2550 - package.json ([5ef1648](https://git.softwaregroup.com/ut5/ut-customer/commit/5ef1648))
* MCTUNE-2550 - senegal/in fix ([57d1242](https://git.softwaregroup.com/ut5/ut-customer/commit/57d1242))
* MCTUNE-2600 ([95ea811](https://git.softwaregroup.com/ut5/ut-customer/commit/95ea811))
* MCTUNE-2600-fix ALTER conflict for customer.organizationsVisibleFor function on project start ([dc5b89d](https://git.softwaregroup.com/ut5/ut-customer/commit/dc5b89d))
* MCTUNE-2910 - fix phone procedure ([c5b1fc0](https://git.softwaregroup.com/ut5/ut-customer/commit/c5b1fc0))
* MCTUNE-2945 Wrong value for MCI.EMPLOYEE ([74f39f8](https://git.softwaregroup.com/ut5/ut-customer/commit/74f39f8))
* MCTUNE-2960 - cbsId added to implementation.user.getParentForCBS.sql ([81b1c9e](https://git.softwaregroup.com/ut5/ut-customer/commit/81b1c9e))
* MCTUNE-3031 ([8f21f4d](https://git.softwaregroup.com/ut5/ut-customer/commit/8f21f4d))
* UATMC-262 Customer accounts ([df6fb49](https://git.softwaregroup.com/ut5/ut-customer/commit/df6fb49))


### Features

* MCTUNE-3099 - add country code in customer.get ([cc20b21](https://git.softwaregroup.com/ut5/ut-customer/commit/cc20b21))



<a name="6.14.1"></a>
## [6.14.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.14.0...v6.14.1) (2017-06-20)



<a name="6.14.0"></a>
# [6.14.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.13.3...v6.14.0) (2017-06-20)


### Bug Fixes

* create stored procedure for enable/disable MC ([84d114d](https://git.softwaregroup.com/ut5/ut-customer/commit/84d114d))
* UIS-2548: fix linting ([5d5901e](https://git.softwaregroup.com/ut5/ut-customer/commit/5d5901e))
* UIS-2548: refactor KYC management to use the new BusinessUnits component ([44ecc70](https://git.softwaregroup.com/ut5/ut-customer/commit/44ecc70))
* UIS-2548: revert the previously used business unit component for KYC ([917f972](https://git.softwaregroup.com/ut5/ut-customer/commit/917f972))


### Features

* UIS-2548: allow the BusinessUnit container to accept and render a 'hint' property ([cf00b3d](https://git.softwaregroup.com/ut5/ut-customer/commit/cf00b3d))



<a name="6.13.3"></a>
## [6.13.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.13.2...v6.13.3) (2017-06-19)



<a name="6.13.2"></a>
## [6.13.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.13.1...v6.13.2) (2017-06-12)


### Bug Fixes

* resolve the referral date issue ([db61378](https://git.softwaregroup.com/ut5/ut-customer/commit/db61378))
* vb1 ([79e98eb](https://git.softwaregroup.com/ut5/ut-customer/commit/79e98eb))



<a name="6.13.1"></a>
## [6.13.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.12.3...v6.13.1) (2017-06-06)


### Bug Fixes

* rename constraint on order not to be duplicated ([228875d](https://git.softwaregroup.com/ut5/ut-customer/commit/228875d))
* UIS-2732 fetch order ([e21f520](https://git.softwaregroup.com/ut5/ut-customer/commit/e21f520))



<a name="6.12.3"></a>
## [6.12.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.12.2...v6.12.3) (2017-06-01)


### Bug Fixes

* change file order to avoid port sql retries ([19416b8](https://git.softwaregroup.com/ut5/ut-customer/commit/19416b8))
* resolve hardcode dependency ABT-1277 ([44ed053](https://git.softwaregroup.com/ut5/ut-customer/commit/44ed053))
* UIS-2757 ([756377e](https://git.softwaregroup.com/ut5/ut-customer/commit/756377e))



<a name="6.12.2"></a>
## [6.12.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.12.1...v6.12.2) (2017-05-31)


### Bug Fixes

* fix phoneNumber joi validation ([10aff22](https://git.softwaregroup.com/ut5/ut-customer/commit/10aff22))
* UATMC-262 Customer accounts ([8fe1513](https://git.softwaregroup.com/ut5/ut-customer/commit/8fe1513))



<a name="6.12.1"></a>
## [6.12.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.12.0...v6.12.1) (2017-05-25)



<a name="6.12.0"></a>
# [6.12.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.11.5...v6.12.0) (2017-05-25)


### Bug Fixes

* ABT-815 fix uploading file to work on browsers like IE and Edge ([539ba3c](https://git.softwaregroup.com/ut5/ut-customer/commit/539ba3c))
* ABT-815 fix validation for description to be the same as in add ([c6d346f](https://git.softwaregroup.com/ut5/ut-customer/commit/c6d346f))
* ABT-815 minor improvements ([444fb95](https://git.softwaregroup.com/ut5/ut-customer/commit/444fb95))
* issue with kyc edit ([5c41c5c](https://git.softwaregroup.com/ut5/ut-customer/commit/5c41c5c))
* Revert unicode regex validation ([25ccbf9](https://git.softwaregroup.com/ut5/ut-customer/commit/25ccbf9))
* UIS-2658 pass kycConditionAttributeId back to the server on edit ([71ad28c](https://git.softwaregroup.com/ut5/ut-customer/commit/71ad28c))


### Features

*  improve integration with the documents tab ([db1dd4d](https://git.softwaregroup.com/ut5/ut-customer/commit/db1dd4d))
* ABT-815 add action for new document and default state ([4af4968](https://git.softwaregroup.com/ut5/ut-customer/commit/4af4968))
* ABT-815 add functionality to delete document ([807535a](https://git.softwaregroup.com/ut5/ut-customer/commit/807535a))
* ABT-815 add permissions ([995cedc](https://git.softwaregroup.com/ut5/ut-customer/commit/995cedc))
* ABT-815 add test data ([76d31f0](https://git.softwaregroup.com/ut5/ut-customer/commit/76d31f0))
* ABT-815 change params passed to documents tab container ([b32f58f](https://git.softwaregroup.com/ut5/ut-customer/commit/b32f58f))
* ABT-815 integrating the documents tab ([2fe7f6c](https://git.softwaregroup.com/ut5/ut-customer/commit/2fe7f6c))
* ABT-815 pass new documents to the component ([2409c5f](https://git.softwaregroup.com/ut5/ut-customer/commit/2409c5f))
* ABT-815 reset the document tab's state when create or edit customer ([3d9b791](https://git.softwaregroup.com/ut5/ut-customer/commit/3d9b791))
* add attachment and order id ([0433bd5](https://git.softwaregroup.com/ut5/ut-customer/commit/0433bd5))
* add procedures for kyc calculation ([057874c](https://git.softwaregroup.com/ut5/ut-customer/commit/057874c))
* UIS-2683 remoce specific MC stored procedure ([f328991](https://git.softwaregroup.com/ut5/ut-customer/commit/f328991))



<a name="6.11.5"></a>
## [6.11.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.11.4...v6.11.5) (2017-05-17)



<a name="6.11.4"></a>
## [6.11.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.11.3...v6.11.4) (2017-05-17)


### Bug Fixes

* ABT-1213 sort order ([080c44a](https://git.softwaregroup.com/ut5/ut-customer/commit/080c44a))
* ABT-1213 sorting ([bb26c0c](https://git.softwaregroup.com/ut5/ut-customer/commit/bb26c0c))



<a name="6.11.3"></a>
## [6.11.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.11.2...v6.11.3) (2017-05-17)



<a name="6.11.2"></a>
## [6.11.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.11.1...v6.11.2) (2017-05-17)



<a name="6.11.1"></a>
## [6.11.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.11.0...v6.11.1) (2017-05-17)


### Bug Fixes

* fix tables order ([c8f2d23](https://git.softwaregroup.com/ut5/ut-customer/commit/c8f2d23))
* reorder ([4e57b7a](https://git.softwaregroup.com/ut5/ut-customer/commit/4e57b7a))
* UIS-2557 drop function customer.organizationsVisibleFor if it is with wrong type ([4a73ec1](https://git.softwaregroup.com/ut5/ut-customer/commit/4a73ec1))



<a name="6.11.0"></a>
# [6.11.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.10.6...v6.11.0) (2017-05-17)


### Bug Fixes

* MCTUNE-2599 - Test fix ([2517ab6](https://git.softwaregroup.com/ut5/ut-customer/commit/2517ab6))
* repeating columns ([954676c](https://git.softwaregroup.com/ut5/ut-customer/commit/954676c))


### Features

* return parents in a columns ([a3b1b94](https://git.softwaregroup.com/ut5/ut-customer/commit/a3b1b94))
* SP for search Bus an its parents by string ([d5916aa](https://git.softwaregroup.com/ut5/ut-customer/commit/d5916aa))



<a name="6.10.6"></a>
## [6.10.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.10.5...v6.10.6) (2017-05-16)


### Bug Fixes

* remove implementation function ([13790c2](https://git.softwaregroup.com/ut5/ut-customer/commit/13790c2))



<a name="6.10.5"></a>
## [6.10.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.10.4...v6.10.5) (2017-05-16)


### Bug Fixes

* UIS-2557 fix to return values if actorId is organization ([0b4dc70](https://git.softwaregroup.com/ut5/ut-customer/commit/0b4dc70))



<a name="6.10.4"></a>
## [6.10.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.10.3...v6.10.4) (2017-05-16)


### Bug Fixes

* MCTUNE-2550 - Microcred external index ([a6da782](https://git.softwaregroup.com/ut5/ut-customer/commit/a6da782))
* MCTUNE-2550 - Microcred external index ([d638038](https://git.softwaregroup.com/ut5/ut-customer/commit/d638038))
* UIS-2558 - Microcred external index ([be214c1](https://git.softwaregroup.com/ut5/ut-customer/commit/be214c1))



<a name="6.10.3"></a>
## [6.10.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.10.2...v6.10.3) (2017-05-16)


### Bug Fixes

* UIS-2558 - Microcred external index ([9cb0625](https://git.softwaregroup.com/ut5/ut-customer/commit/9cb0625))
* UIS-2558 - Microcred external index ([b493f24](https://git.softwaregroup.com/ut5/ut-customer/commit/b493f24))



<a name="6.10.2"></a>
## [6.10.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.10.1...v6.10.2) (2017-05-15)


### Bug Fixes

* add in procedure organization.addApproved [@actorId](https://github.com/actorId) and [@meta](https://github.com/meta) in call procedure [customer].[organizationHierarchyFlat.rebuild] ([463c14d](https://git.softwaregroup.com/ut5/ut-customer/commit/463c14d))
* delete procedure customer.selfAdd ([8df0fb5](https://git.softwaregroup.com/ut5/ut-customer/commit/8df0fb5))
* fixes for referrals to work on existing DB ([aa69e04](https://git.softwaregroup.com/ut5/ut-customer/commit/aa69e04))
* seed for referral status seed ([34211bf](https://git.softwaregroup.com/ut5/ut-customer/commit/34211bf))



<a name="6.10.1"></a>
## [6.10.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.10.0...v6.10.1) (2017-05-12)


### Bug Fixes

* test for self registration ([255512f](https://git.softwaregroup.com/ut5/ut-customer/commit/255512f))



<a name="6.10.0"></a>
# [6.10.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.9.8...v6.10.0) (2017-05-12)


### Bug Fixes

* ABT-1256 get number with phone prefix ([86df9bc](https://git.softwaregroup.com/ut5/ut-customer/commit/86df9bc))
* ABT-1256 return object, not array ([fb5ed0b](https://git.softwaregroup.com/ut5/ut-customer/commit/fb5ed0b))
* self add procedure ([a0e18ce](https://git.softwaregroup.com/ut5/ut-customer/commit/a0e18ce))
* self add procedure ([d153b54](https://git.softwaregroup.com/ut5/ut-customer/commit/d153b54))
* UIS-2557 added predicate in where clause ([4af54ab](https://git.softwaregroup.com/ut5/ut-customer/commit/4af54ab))
* update procedure ([4fe43f9](https://git.softwaregroup.com/ut5/ut-customer/commit/4fe43f9))
* update procedure self add ([969aa60](https://git.softwaregroup.com/ut5/ut-customer/commit/969aa60))
* version bump ([becfdce](https://git.softwaregroup.com/ut5/ut-customer/commit/becfdce))
* version bump ([3a80fba](https://git.softwaregroup.com/ut5/ut-customer/commit/3a80fba))


### Features

* ABT-1256 add prefix in resultSet ([ebbfb1f](https://git.softwaregroup.com/ut5/ut-customer/commit/ebbfb1f))
* ABT-1256 search customer by phone with country prefix ([50a10ec](https://git.softwaregroup.com/ut5/ut-customer/commit/50a10ec))
* ABT-1385 Add PhoneNumber as filter ([217b8d2](https://git.softwaregroup.com/ut5/ut-customer/commit/217b8d2))
* add maker/checker sps ([36991d4](https://git.softwaregroup.com/ut5/ut-customer/commit/36991d4))
* correct referral grid alignment ([d7b0881](https://git.softwaregroup.com/ut5/ut-customer/commit/d7b0881))
* fix db review comments ([f32a536](https://git.softwaregroup.com/ut5/ut-customer/commit/f32a536))
* fix review comments ([f2f56dc](https://git.softwaregroup.com/ut5/ut-customer/commit/f2f56dc))
* fix review comments ([9dffdc5](https://git.softwaregroup.com/ut5/ut-customer/commit/9dffdc5))
* fix review comments ([fc6f6ed](https://git.softwaregroup.com/ut5/ut-customer/commit/fc6f6ed))
* fix review comments ([eaae154](https://git.softwaregroup.com/ut5/ut-customer/commit/eaae154))
* fix review comments ([b9ce19a](https://git.softwaregroup.com/ut5/ut-customer/commit/b9ce19a))
* fix review comments ([c39c33e](https://git.softwaregroup.com/ut5/ut-customer/commit/c39c33e))
* Fix review comments ([20c21df](https://git.softwaregroup.com/ut5/ut-customer/commit/20c21df))
* implement status-action logic ([8c8bbfd](https://git.softwaregroup.com/ut5/ut-customer/commit/8c8bbfd))
* merge with ABT-1034 ([3813cb9](https://git.softwaregroup.com/ut5/ut-customer/commit/3813cb9))
* new SP to get customer id by phone number ([bfde099](https://git.softwaregroup.com/ut5/ut-customer/commit/bfde099))
* redesign referral sp ([72d6970](https://git.softwaregroup.com/ut5/ut-customer/commit/72d6970))
* remove m/c filter ([f333088](https://git.softwaregroup.com/ut5/ut-customer/commit/f333088))
* resolve customerNumber mismatch issue ([c80851f](https://git.softwaregroup.com/ut5/ut-customer/commit/c80851f))
* UIS-2557 transform customer hierarchy from graph to relation ([aabf559](https://git.softwaregroup.com/ut5/ut-customer/commit/aabf559))
* update referral date when checker approve it ([8ce7c65](https://git.softwaregroup.com/ut5/ut-customer/commit/8ce7c65))



<a name="6.9.8"></a>
## [6.9.8](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.9.7...v6.9.8) (2017-05-04)


### Bug Fixes

* version bump ([b58e4e2](https://git.softwaregroup.com/ut5/ut-customer/commit/b58e4e2))
* version bump ([cc4ef33](https://git.softwaregroup.com/ut5/ut-customer/commit/cc4ef33))



<a name="6.9.7"></a>
## [6.9.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.9.6...v6.9.7) (2017-05-03)



<a name="6.9.6"></a>
## [6.9.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.9.5...v6.9.6) (2017-05-03)


### Bug Fixes

* ABT-1295 ([055e37c](https://git.softwaregroup.com/ut5/ut-customer/commit/055e37c))



<a name="6.9.5"></a>
## [6.9.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.9.4...v6.9.5) (2017-05-03)


### Bug Fixes

* add in result set in person column placeOfBirth and nationalId ([9adf872](https://git.softwaregroup.com/ut5/ut-customer/commit/9adf872))
* date Of Birth ([6f7db04](https://git.softwaregroup.com/ut5/ut-customer/commit/6f7db04))



<a name="6.9.4"></a>
## [6.9.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.9.3...v6.9.4) (2017-05-02)



<a name="6.9.3"></a>
## [6.9.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.9.2...v6.9.3) (2017-05-01)


### Bug Fixes

* ABT-1254 show attributes used in conditions as checked ([93223e6](https://git.softwaregroup.com/ut5/ut-customer/commit/93223e6))
* ABT-748 add secondary document; comment category since it is still unclear ([67cb2db](https://git.softwaregroup.com/ut5/ut-customer/commit/67cb2db))



<a name="6.9.2"></a>
## [6.9.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.9.1...v6.9.2) (2017-04-28)


### Bug Fixes

* MCTUNE-2809 Enroll a client with error - the fingers are registered for the client ([c535522](https://git.softwaregroup.com/ut5/ut-customer/commit/c535522))
* MCTUNE-2809 Enroll a client with error - the fingers are registered for the client ([703d2e9](https://git.softwaregroup.com/ut5/ut-customer/commit/703d2e9))
* MCTUNE-2809 externalCredentials.check moved to ut-customer ([c7b66fc](https://git.softwaregroup.com/ut5/ut-customer/commit/c7b66fc))
* MCTUNE-2836 - error message when removing customer nationallity fixed & message map changed. ([e37ab15](https://git.softwaregroup.com/ut5/ut-customer/commit/e37ab15))



<a name="6.9.1"></a>
## [6.9.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.9.0...v6.9.1) (2017-04-27)



<a name="6.9.0"></a>
# [6.9.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.8.2...v6.9.0) (2017-04-27)


### Bug Fixes

* adding comments ([dbfc6a1](https://git.softwaregroup.com/ut5/ut-customer/commit/dbfc6a1))
* MCTUNE-2550 - fix pulse create ([f0ecf72](https://git.softwaregroup.com/ut5/ut-customer/commit/f0ecf72))


### Features

* add linkable columns ([29586fa](https://git.softwaregroup.com/ut5/ut-customer/commit/29586fa))
* resolve linting errors ([414d3c3](https://git.softwaregroup.com/ut5/ut-customer/commit/414d3c3))
* resolve linting errors ([eca54b2](https://git.softwaregroup.com/ut5/ut-customer/commit/eca54b2))
* ui changes ABT-1034 ([867ffde](https://git.softwaregroup.com/ut5/ut-customer/commit/867ffde))



<a name="6.8.2"></a>
## [6.8.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.8.1...v6.8.2) (2017-04-26)


### Bug Fixes

* MCTUNE-2550 - pulse ([9021d27](https://git.softwaregroup.com/ut5/ut-customer/commit/9021d27))



<a name="6.8.1"></a>
## [6.8.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.8.0...v6.8.1) (2017-04-26)


### Bug Fixes

* MCTUNE-2550 - merging ([d7930df](https://git.softwaregroup.com/ut5/ut-customer/commit/d7930df))



<a name="6.8.0"></a>
# [6.8.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.7.4...v6.8.0) (2017-04-25)


### Bug Fixes

* MCTUNE-2550 - merging ([5e68ff8](https://git.softwaregroup.com/ut5/ut-customer/commit/5e68ff8))


### Features

* resolve AQA comments on referral add ([e3d4b69](https://git.softwaregroup.com/ut5/ut-customer/commit/e3d4b69))



<a name="6.7.4"></a>
## [6.7.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.7.3...v6.7.4) (2017-04-25)



<a name="6.7.3"></a>
## [6.7.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.7.2...v6.7.3) (2017-04-25)


### Bug Fixes

* test ([d1d493a](https://git.softwaregroup.com/ut5/ut-customer/commit/d1d493a))



<a name="6.7.2"></a>
## [6.7.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.7.1...v6.7.2) (2017-04-25)


### Bug Fixes

* customer.addIdentity ([45ea7cf](https://git.softwaregroup.com/ut5/ut-customer/commit/45ea7cf))



<a name="6.7.1"></a>
## [6.7.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.7.0...v6.7.1) (2017-04-24)



<a name="6.7.0"></a>
# [6.7.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.6.2...v6.7.0) (2017-04-24)


### Bug Fixes

* add customer.get in procedure add and edit ([3711e8c](https://git.softwaregroup.com/ut5/ut-customer/commit/3711e8c))
* add validations for customer.customer.get ([6c43e37](https://git.softwaregroup.com/ut5/ut-customer/commit/6c43e37))
* customer.fetch validations - params.paging ([b1994f0](https://git.softwaregroup.com/ut5/ut-customer/commit/b1994f0))
* output ([0a09f0a](https://git.softwaregroup.com/ut5/ut-customer/commit/0a09f0a))
* output ([8ad655f](https://git.softwaregroup.com/ut5/ut-customer/commit/8ad655f))
* update ([e31b790](https://git.softwaregroup.com/ut5/ut-customer/commit/e31b790))
* update result set ([47aeb70](https://git.softwaregroup.com/ut5/ut-customer/commit/47aeb70))


### Features

* UIS-2262: Fix crop styles ([5ade8f4](https://git.softwaregroup.com/ut5/ut-customer/commit/5ade8f4))



<a name="6.6.2"></a>
## [6.6.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.6.1...v6.6.2) (2017-04-21)


### Bug Fixes

* ABT-1058 tests ([f129623](https://git.softwaregroup.com/ut5/ut-customer/commit/f129623))
* ABT-1058 tests ([0014124](https://git.softwaregroup.com/ut5/ut-customer/commit/0014124))



<a name="6.6.1"></a>
## [6.6.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.6.0...v6.6.1) (2017-04-20)


### Bug Fixes

* MCTUNE-2559 StateId added for mobile purposes ([1e8d779](https://git.softwaregroup.com/ut5/ut-customer/commit/1e8d779))
* set isPrimary = 0 in inserted ([5bd540a](https://git.softwaregroup.com/ut5/ut-customer/commit/5bd540a))
* set statusId = approved in inserted ([e202c92](https://git.softwaregroup.com/ut5/ut-customer/commit/e202c92))



<a name="6.6.0"></a>
# [6.6.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.5.0...v6.6.0) (2017-04-19)


### Bug Fixes

* MCTUNE-2599 - UI Move ([c5092c2](https://git.softwaregroup.com/ut5/ut-customer/commit/c5092c2))


### Features

* function for depth check ([86eba21](https://git.softwaregroup.com/ut5/ut-customer/commit/86eba21))



<a name="6.5.0"></a>
# [6.5.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.4.0...v6.5.0) (2017-04-19)


### Bug Fixes

* MCTUNE-2431 - Account Get action and Transfer tab fixes ([dc02404](https://git.softwaregroup.com/ut5/ut-customer/commit/dc02404))
* MCTUNE-2431 - Account selection ([21d9d8c](https://git.softwaregroup.com/ut5/ut-customer/commit/21d9d8c))
* MCTUNE-2431 - Account switching and tab switching fix. ([4cd67b0](https://git.softwaregroup.com/ut5/ut-customer/commit/4cd67b0))
* MCTUNE-2431 - add close modal function ([59b37eb](https://git.softwaregroup.com/ut5/ut-customer/commit/59b37eb))
* MCTUNE-2431 - All Deposit forms ([41d20b0](https://git.softwaregroup.com/ut5/ut-customer/commit/41d20b0))
* MCTUNE-2431 - creat new modal for transaction ([2f8dc4e](https://git.softwaregroup.com/ut5/ut-customer/commit/2f8dc4e))
* MCTUNE-2431 - Deposit - Validate Phase ([43c93d5](https://git.softwaregroup.com/ut5/ut-customer/commit/43c93d5))
* MCTUNE-2431 - Deposit component split and optimizations ([42c6598](https://git.softwaregroup.com/ut5/ut-customer/commit/42c6598))
* MCTUNE-2431 - Deposit fixes ([75aa461](https://git.softwaregroup.com/ut5/ut-customer/commit/75aa461))
* MCTUNE-2431 - Deposit styles ([eb52503](https://git.softwaregroup.com/ut5/ut-customer/commit/eb52503))
* MCTUNE-2431 - Deposit tab ([35de663](https://git.softwaregroup.com/ut5/ut-customer/commit/35de663))
* MCTUNE-2431 - Deposit tab - frame ([02763a9](https://git.softwaregroup.com/ut5/ut-customer/commit/02763a9))
* MCTUNE-2431 - Deposit tab box, and tab switching. ([9ec846e](https://git.softwaregroup.com/ut5/ut-customer/commit/9ec846e))
* MCTUNE-2431 - Deposit Validate Phase Table Misaligned ([866b283](https://git.softwaregroup.com/ut5/ut-customer/commit/866b283))
* MCTUNE-2431 - Dropdown for account switching ([ae4813d](https://git.softwaregroup.com/ut5/ut-customer/commit/ae4813d))
* MCTUNE-2431 - edit transaction buttons ([2c17375](https://git.softwaregroup.com/ut5/ut-customer/commit/2c17375))
* MCTUNE-2431 - Fix all tab buttons opening deposit ([425da7d](https://git.softwaregroup.com/ut5/ut-customer/commit/425da7d))
* MCTUNE-2431 - Fixed Phone Number and Done By fields missing ([dc6c4eb](https://git.softwaregroup.com/ut5/ut-customer/commit/dc6c4eb))
* MCTUNE-2431 - General fixes ([18f6dc7](https://git.softwaregroup.com/ut5/ut-customer/commit/18f6dc7))
* MCTUNE-2431 - Missing comma ([9bae178](https://git.softwaregroup.com/ut5/ut-customer/commit/9bae178))
* MCTUNE-2431 - Phase changing ([752a34d](https://git.softwaregroup.com/ut5/ut-customer/commit/752a34d))
* MCTUNE-2431 - Transfer skeleton ([77e1381](https://git.softwaregroup.com/ut5/ut-customer/commit/77e1381))
* MCTUNE-2431 - Transfer Tab actions wired, mostly ready ([898d27a](https://git.softwaregroup.com/ut5/ut-customer/commit/898d27a))
* MCTUNE-2431 - Transfer tab search improved ([5a93977](https://git.softwaregroup.com/ut5/ut-customer/commit/5a93977))
* MCTUNE-2431 - Validate table wired with actions ([080beb4](https://git.softwaregroup.com/ut5/ut-customer/commit/080beb4))
* MCTUNE-2431 - Withdraw tab start ([2c1d267](https://git.softwaregroup.com/ut5/ut-customer/commit/2c1d267))
* MCTUNE-2592 - remove delete photo functionality ([2da4a8b](https://git.softwaregroup.com/ut5/ut-customer/commit/2da4a8b))
* MCTUNE-2599 - Goodbye ([5a14b57](https://git.softwaregroup.com/ut5/ut-customer/commit/5a14b57))
* MCTUNE-2599 - Moved LoanApplicationWidget to impl UI. ([fbb87fe](https://git.softwaregroup.com/ut5/ut-customer/commit/fbb87fe))


### Features

* MCTUNE-2431 - add buttons on modal ([9e459d2](https://git.softwaregroup.com/ut5/ut-customer/commit/9e459d2))
* MCTUNE-2431 - create transaction widget ([43f5e72](https://git.softwaregroup.com/ut5/ut-customer/commit/43f5e72))
* MCTUNE-2431 - Field validation moved to modal components ([c9f5bc3](https://git.softwaregroup.com/ut5/ut-customer/commit/c9f5bc3))
* MCTUNE-2431 - Fixed contentdata being lost when going back ([fb94b52](https://git.softwaregroup.com/ut5/ut-customer/commit/fb94b52))
* MCTUNE-2431 - General improvements and default states + Validation Table ([7639381](https://git.softwaregroup.com/ut5/ut-customer/commit/7639381))
* MCTUNE-2431 - General improvements and fixes ([342b9db](https://git.softwaregroup.com/ut5/ut-customer/commit/342b9db))
* MCTUNE-2431 - include fees component ([e1f0d3e](https://git.softwaregroup.com/ut5/ut-customer/commit/e1f0d3e))
* MCTUNE-2431 - Lint errors ([3b18591](https://git.softwaregroup.com/ut5/ut-customer/commit/3b18591))
* MCTUNE-2431 - New modular structure ([15fcb77](https://git.softwaregroup.com/ut5/ut-customer/commit/15fcb77))
* MCTUNE-2431 - Pay tab and general fixes ([496fa55](https://git.softwaregroup.com/ut5/ut-customer/commit/496fa55))
* MCTUNE-2431 - State and tab changes for Deposit ([28da5c1](https://git.softwaregroup.com/ut5/ut-customer/commit/28da5c1))
* MCTUNE-2431 - Transfer Tab ([ae793e6](https://git.softwaregroup.com/ut5/ut-customer/commit/ae793e6))
* MCTUNE-2431 - Validation table ([f219fb8](https://git.softwaregroup.com/ut5/ut-customer/commit/f219fb8))
* MCTUNE-2431 - ValidationTable remake and Transfer Tab fixes ([7b160f0](https://git.softwaregroup.com/ut5/ut-customer/commit/7b160f0))
* MCTUNE-2431 - Withdraw and Transfer tabs ([898976f](https://git.softwaregroup.com/ut5/ut-customer/commit/898976f))
* MCTUNE-2431 - Withdraw form switching ([c9ae0c2](https://git.softwaregroup.com/ut5/ut-customer/commit/c9ae0c2))
* MCTUNE-2599 - Moved MC UI to Implementation ([47c0cb0](https://git.softwaregroup.com/ut5/ut-customer/commit/47c0cb0))
* MCTUNE-2599 - UI moved to impl fixes. ([2ae273e](https://git.softwaregroup.com/ut5/ut-customer/commit/2ae273e))



<a name="6.4.0"></a>
# [6.4.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.3.6...v6.4.0) (2017-04-13)


### Bug Fixes

* MCTUNE-2697 ([cbe71c0](https://git.softwaregroup.com/ut5/ut-customer/commit/cbe71c0))
* MCTUNE-2697 - Implement loan.nanoLoanEligibility.sync ([bb0bc26](https://git.softwaregroup.com/ut5/ut-customer/commit/bb0bc26))


### Features

* MCTUNE-2697 Nanoloan sync ([872a004](https://git.softwaregroup.com/ut5/ut-customer/commit/872a004))



<a name="6.3.6"></a>
## [6.3.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.3.5...v6.3.6) (2017-04-13)


### Bug Fixes

* ABT-874 resolve referral management bugs ([66eeb78](https://git.softwaregroup.com/ut5/ut-customer/commit/66eeb78))
* ABT-968 move customerCategory seed to impl ([0a9f83c](https://git.softwaregroup.com/ut5/ut-customer/commit/0a9f83c))
* MCTUNE-2697 - Implement loan.nanoLoanEligibility.sync ([a34d655](https://git.softwaregroup.com/ut5/ut-customer/commit/a34d655))
* MCTUNE-2764 NanoLoans eligibility problems fix ([5cbbd79](https://git.softwaregroup.com/ut5/ut-customer/commit/5cbbd79))
* resolve bugs on referral management screen ([496fdf7](https://git.softwaregroup.com/ut5/ut-customer/commit/496fdf7))
* resolve linting error ([d2c774d](https://git.softwaregroup.com/ut5/ut-customer/commit/d2c774d))
* resolve linting errors ([9dc08e3](https://git.softwaregroup.com/ut5/ut-customer/commit/9dc08e3))
* UATMC-201 - able to delete a picture ([267743f](https://git.softwaregroup.com/ut5/ut-customer/commit/267743f))



<a name="6.3.5"></a>
## [6.3.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.3.4...v6.3.5) (2017-04-12)


### Bug Fixes

* org delete validations ([f205f4a](https://git.softwaregroup.com/ut5/ut-customer/commit/f205f4a))



<a name="6.3.4"></a>
## [6.3.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.3.3...v6.3.4) (2017-04-12)


### Bug Fixes

* comment out more tests which fail on jenkins ([b72f9a2](https://git.softwaregroup.com/ut5/ut-customer/commit/b72f9a2))



<a name="6.3.3"></a>
## [6.3.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.3.2...v6.3.3) (2017-04-12)



<a name="6.3.2"></a>
## [6.3.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.3.1...v6.3.2) (2017-04-12)


### Bug Fixes

* MCTUNE-2755 Senegal offline sync ([43f1609](https://git.softwaregroup.com/ut5/ut-customer/commit/43f1609))
* update procedure - add column for addressZone ([b83321a](https://git.softwaregroup.com/ut5/ut-customer/commit/b83321a))



<a name="6.3.1"></a>
## [6.3.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.3.0...v6.3.1) (2017-04-12)



<a name="6.3.0"></a>
# [6.3.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.2.2...v6.3.0) (2017-04-12)


### Bug Fixes

* add column for addressZoneId in prcedure get customer ([8410c03](https://git.softwaregroup.com/ut5/ut-customer/commit/8410c03))
* add column in result set ([7b90569](https://git.softwaregroup.com/ut5/ut-customer/commit/7b90569))
* add column in result set ([7a53492](https://git.softwaregroup.com/ut5/ut-customer/commit/7a53492))
* joi validations added for swagger api documentation ([5d1a07d](https://git.softwaregroup.com/ut5/ut-customer/commit/5d1a07d))
* update procedure ([8b633b1](https://git.softwaregroup.com/ut5/ut-customer/commit/8b633b1))
* update procedure customer fetch order by ([46c8feb](https://git.softwaregroup.com/ut5/ut-customer/commit/46c8feb))
* update procedure customer.get ([aaf3f4c](https://git.softwaregroup.com/ut5/ut-customer/commit/aaf3f4c))
* update procedure replace "*" with column name ([620106e](https://git.softwaregroup.com/ut5/ut-customer/commit/620106e))
* update test ([c3a6e91](https://git.softwaregroup.com/ut5/ut-customer/commit/c3a6e91))


### Features

* new columns and filters for the API ([b475a58](https://git.softwaregroup.com/ut5/ut-customer/commit/b475a58))
* UIS-1821 add referral expire method ([c1c4871](https://git.softwaregroup.com/ut5/ut-customer/commit/c1c4871))
* update in kyc add ([ed788d3](https://git.softwaregroup.com/ut5/ut-customer/commit/ed788d3))
* update the referral expire sp ([6b9ecd8](https://git.softwaregroup.com/ut5/ut-customer/commit/6b9ecd8))



<a name="6.2.2"></a>
## [6.2.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.2.1...v6.2.2) (2017-04-06)


### Bug Fixes

* delete column ([99cc621](https://git.softwaregroup.com/ut5/ut-customer/commit/99cc621))



<a name="6.2.1"></a>
## [6.2.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.2.0...v6.2.1) (2017-04-06)


### Bug Fixes

* drop column description ([4862e99](https://git.softwaregroup.com/ut5/ut-customer/commit/4862e99))
* update procedure ([99f47b8](https://git.softwaregroup.com/ut5/ut-customer/commit/99f47b8))



<a name="6.2.0"></a>
# [6.2.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.1.2...v6.2.0) (2017-04-06)


### Features

* add column description ([3edbede](https://git.softwaregroup.com/ut5/ut-customer/commit/3edbede))



<a name="6.1.2"></a>
## [6.1.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.1.1...v6.1.2) (2017-04-05)


### Bug Fixes

* MCTUNE-2678 Observer BUs ordered by dao code ([2fb2e2e](https://git.softwaregroup.com/ut5/ut-customer/commit/2fb2e2e))



<a name="6.1.1"></a>
## [6.1.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.1.0...v6.1.1) (2017-04-05)


### Bug Fixes

* MCTUNE-2550 - refactoring ([b421d7c](https://git.softwaregroup.com/ut5/ut-customer/commit/b421d7c))



<a name="6.1.0"></a>
# [6.1.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.0.4...v6.1.0) (2017-04-04)


### Bug Fixes

* MCTUNE-2550 - refactoring ([7d13398](https://git.softwaregroup.com/ut5/ut-customer/commit/7d13398))
* UIS-1523 add corner case for id with value 0 ([3cb8a50](https://git.softwaregroup.com/ut5/ut-customer/commit/3cb8a50))
* UIS-1523 change button's label for editing to save ([615a1c2](https://git.softwaregroup.com/ut5/ut-customer/commit/615a1c2))
* UIS-1523 clear the state on successful create ([5fc8faf](https://git.softwaregroup.com/ut5/ut-customer/commit/5fc8faf))
* UIS-1523 fix bug freezing the browser and fix warnings in the console ([ef0a6a9](https://git.softwaregroup.com/ut5/ut-customer/commit/ef0a6a9))
* UIS-1523 fix bug looping url when closing the tab ([31dd1e0](https://git.softwaregroup.com/ut5/ut-customer/commit/31dd1e0))
* UIS-1523 fix selected item from the selectdialog ([5ba0d1b](https://git.softwaregroup.com/ut5/ut-customer/commit/5ba0d1b))
* UIS-1523 improve permissions for different roles ([4fbdef3](https://git.softwaregroup.com/ut5/ut-customer/commit/4fbdef3))
* UIS-2193 apply standard buttons for the dialog ([6af948e](https://git.softwaregroup.com/ut5/ut-customer/commit/6af948e))
* UIS-2193 fix delete button configuration and change activate button accordingly ([3f4686b](https://git.softwaregroup.com/ut5/ut-customer/commit/3f4686b))
* UIS-2193 fix permissions for the deactivate button ([3b7b0d2](https://git.softwaregroup.com/ut5/ut-customer/commit/3b7b0d2))


### Features

* MCTUNE-2704 Implement opt-in/out calls to T24 for both TAKA and ALIP ([bad326b](https://git.softwaregroup.com/ut5/ut-customer/commit/bad326b))
* UIS-1523 add basic edit functionality for the general info tab ([427a087](https://git.softwaregroup.com/ut5/ut-customer/commit/427a087))
* UIS-1523 add permissions ([15022a9](https://git.softwaregroup.com/ut5/ut-customer/commit/15022a9))
* UIS-1523 add text in the BU dialog ([abd88e6](https://git.softwaregroup.com/ut5/ut-customer/commit/abd88e6))
* UIS-1523 improve gerenal info editing ([5965ebe](https://git.softwaregroup.com/ut5/ut-customer/commit/5965ebe))
* UIS-1523 initialize the attributes list for editing kyc ([1f24d5b](https://git.softwaregroup.com/ut5/ut-customer/commit/1f24d5b))
* UIS-1523 send to the server the edited kyc ([eef0310](https://git.softwaregroup.com/ut5/ut-customer/commit/eef0310))
* UIS-2103 add check for kyc attributes ([a45ce91](https://git.softwaregroup.com/ut5/ut-customer/commit/a45ce91))
* UIS-2103 add check for organization depth ([f27342a](https://git.softwaregroup.com/ut5/ut-customer/commit/f27342a))
* UIS-2103 check changes for kyc edit ([df87c7c](https://git.softwaregroup.com/ut5/ut-customer/commit/df87c7c))
* UIS-2103 update kyc get result set ([7d93218](https://git.softwaregroup.com/ut5/ut-customer/commit/7d93218))
* UIS-2193 add delete button and fix url for edit button ([a7b7789](https://git.softwaregroup.com/ut5/ut-customer/commit/a7b7789))



<a name="6.0.4"></a>
## [6.0.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.0.3...v6.0.4) (2017-04-04)


### Bug Fixes

* move functions in user module ([75a7221](https://git.softwaregroup.com/ut5/ut-customer/commit/75a7221))



<a name="6.0.3"></a>
## [6.0.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.0.2...v6.0.3) (2017-04-03)


### Bug Fixes

* MCTUNE-2688 Send sms after T24 baobab account is created ([c1a9c80](https://git.softwaregroup.com/ut5/ut-customer/commit/c1a9c80))



<a name="6.0.2"></a>
## [6.0.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.0.1...v6.0.2) (2017-04-03)


### Bug Fixes

* MCTUNE-2550 - package.json ([b85af17](https://git.softwaregroup.com/ut5/ut-customer/commit/b85af17))



<a name="6.0.1"></a>
## [6.0.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v6.0.0...v6.0.1) (2017-04-03)


### Bug Fixes

* dependencies ([63b8c8a](https://git.softwaregroup.com/ut5/ut-customer/commit/63b8c8a))



<a name="6.0.0"></a>
# [6.0.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.61.3...v6.0.0) (2017-04-03)


### Bug Fixes

* dependencies ([76bf15f](https://git.softwaregroup.com/ut5/ut-customer/commit/76bf15f))
* MCTUNE-2470 Avatar missing for client from Pulse ([e863b16](https://git.softwaregroup.com/ut5/ut-customer/commit/e863b16))
* MCTUNE-2678 Dao code added for observer list ([25fcc7e](https://git.softwaregroup.com/ut5/ut-customer/commit/25fcc7e))


### BREAKING CHANGES

* module default export is a standard object, not only the schema



<a name="5.61.3"></a>
## [5.61.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.61.2...v5.61.3) (2017-03-30)


### Bug Fixes

* MCTUNE-2550 - package.json ([0e0752c](https://git.softwaregroup.com/ut5/ut-customer/commit/0e0752c))



<a name="5.61.2"></a>
## [5.61.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.61.1...v5.61.2) (2017-03-29)


### Bug Fixes

* MCTUNE-2550 - removed code ([7c98fdb](https://git.softwaregroup.com/ut5/ut-customer/commit/7c98fdb))



<a name="5.61.1"></a>
## [5.61.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.61.0...v5.61.1) (2017-03-29)


### Bug Fixes

* MCTUNE-2550 - package.json ([7fb539e](https://git.softwaregroup.com/ut5/ut-customer/commit/7fb539e))



<a name="5.61.0"></a>
# [5.61.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.60.0...v5.61.0) (2017-03-29)


### Features

* UIS-2103 fix alter issues ([f23effe](https://git.softwaregroup.com/ut5/ut-customer/commit/f23effe))



<a name="5.60.0"></a>
# [5.60.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.59.1...v5.60.0) (2017-03-29)


### Bug Fixes

* replace pagingTT ([6f0443c](https://git.softwaregroup.com/ut5/ut-customer/commit/6f0443c))
* UIS-1521 do not call the server when clearing the selected BU ([0cf8822](https://git.softwaregroup.com/ut5/ut-customer/commit/0cf8822))
* UIS-1523 fix bug with changing the tabs and updating their titles ([95dfbda](https://git.softwaregroup.com/ut5/ut-customer/commit/95dfbda))
* UIS-1523 fix some warnings in the console ([9c40014](https://git.softwaregroup.com/ut5/ut-customer/commit/9c40014))
* UIS-1523 fix some warnings in the console ([0ca05ea](https://git.softwaregroup.com/ut5/ut-customer/commit/0ca05ea))


### Features

* add in actorProperty ([c4acf2e](https://git.softwaregroup.com/ut5/ut-customer/commit/c4acf2e))
* changes in tables, sps and new SPs ([51692b2](https://git.softwaregroup.com/ut5/ut-customer/commit/51692b2))
* SPs for KYC ([f6be6f2](https://git.softwaregroup.com/ut5/ut-customer/commit/f6be6f2))
* UIS-1521 add KYC listing page ([7ac6aa8](https://git.softwaregroup.com/ut5/ut-customer/commit/7ac6aa8))
* UIS-1521 add permissions for different actions ([b35f115](https://git.softwaregroup.com/ut5/ut-customer/commit/b35f115))
* UIS-1521 display customer types from the store for the dropdown ([4561002](https://git.softwaregroup.com/ut5/ut-customer/commit/4561002))
* UIS-1521 display dialog when creating new kyc level ([515a0ed](https://git.softwaregroup.com/ut5/ut-customer/commit/515a0ed))
* UIS-1521 get dynamically customer types ([ffa15a6](https://git.softwaregroup.com/ut5/ut-customer/commit/ffa15a6))
* UIS-1521 hide pagination when no grid data and other code fixes ([e687624](https://git.softwaregroup.com/ut5/ut-customer/commit/e687624))
* UIS-1521 improve pagination ([960bdb0](https://git.softwaregroup.com/ut5/ut-customer/commit/960bdb0))
* UIS-1521 improve the UI and implement the changing status action ([548f8e0](https://git.softwaregroup.com/ut5/ut-customer/commit/548f8e0))
* UIS-1521 pass correct params to the server for the filters ([52dce7e](https://git.softwaregroup.com/ut5/ut-customer/commit/52dce7e))
* UIS-1521 separate the reducers and routes for the admin ([8dae3c3](https://git.softwaregroup.com/ut5/ut-customer/commit/8dae3c3))
* UIS-1523 add attributes validation dialog and some interactions in it ([889d253](https://git.softwaregroup.com/ut5/ut-customer/commit/889d253))
* UIS-1523 add basic layout for kyc create ([6abd855](https://git.softwaregroup.com/ut5/ut-customer/commit/6abd855))
* UIS-1523 add basic structure and add reducers ([32a329e](https://git.softwaregroup.com/ut5/ut-customer/commit/32a329e))
* UIS-1523 add components for the general info tab ([2cfe97a](https://git.softwaregroup.com/ut5/ut-customer/commit/2cfe97a))
* UIS-1523 add confirm dialog before removing an attribute ([45ca620](https://git.softwaregroup.com/ut5/ut-customer/commit/45ca620))
* UIS-1523 add dummy joi validations for the new procedures ([a94d285](https://git.softwaregroup.com/ut5/ut-customer/commit/a94d285))
* UIS-1523 add dummy validation for a procedure ([966834c](https://git.softwaregroup.com/ut5/ut-customer/commit/966834c))
* UIS-1523 add validations for the attributes tab ([80d1124](https://git.softwaregroup.com/ut5/ut-customer/commit/80d1124))
* UIS-1523 add validations for the general info tab ([06542ff](https://git.softwaregroup.com/ut5/ut-customer/commit/06542ff))
* UIS-1523 check main conditions ([53de3a7](https://git.softwaregroup.com/ut5/ut-customer/commit/53de3a7))
* UIS-1523 create kyc ([8c6980c](https://git.softwaregroup.com/ut5/ut-customer/commit/8c6980c))
* UIS-1523 display saving dialog when saving ([44eb663](https://git.softwaregroup.com/ut5/ut-customer/commit/44eb663))
* UIS-1523 fetch and store attributes for different customer types ([02d6f74](https://git.softwaregroup.com/ut5/ut-customer/commit/02d6f74))
* UIS-1523 fetch attributes list and display basic layout for the attributes tab ([5459c8e](https://git.softwaregroup.com/ut5/ut-customer/commit/5459c8e))
* UIS-1523 fetch business units from which to select ([232e38c](https://git.softwaregroup.com/ut5/ut-customer/commit/232e38c))
* UIS-1523 fetch kyc levels ([329a6eb](https://git.softwaregroup.com/ut5/ut-customer/commit/329a6eb))
* UIS-1523 filter which attributes can be added for validation ([301ea97](https://git.softwaregroup.com/ut5/ut-customer/commit/301ea97))
* UIS-1523 improve kyc level validation and editing selected BU ([98e33cb](https://git.softwaregroup.com/ut5/ut-customer/commit/98e33cb))
* UIS-1523 init and dispose the create object in the store ([ad5de1a](https://git.softwaregroup.com/ut5/ut-customer/commit/ad5de1a))
* UIS-1523 list checked attributes ([561f2d9](https://git.softwaregroup.com/ut5/ut-customer/commit/561f2d9))
* UIS-1523 make pretty the url for the create page ([8a73390](https://git.softwaregroup.com/ut5/ut-customer/commit/8a73390))
* UIS-1523 make pretty url for editing kyc ([b99521a](https://git.softwaregroup.com/ut5/ut-customer/commit/b99521a))
* UIS-1523 map customer type label to id ([f20316c](https://git.softwaregroup.com/ut5/ut-customer/commit/f20316c))
* UIS-1523 open dialog for selecting BUs ([28c773a](https://git.softwaregroup.com/ut5/ut-customer/commit/28c773a))
* UIS-1523 present the attributes in the dialog ([debc567](https://git.softwaregroup.com/ut5/ut-customer/commit/debc567))
* UIS-1523 remove attribute from the dialog ([442c870](https://git.softwaregroup.com/ut5/ut-customer/commit/442c870))
* UIS-1523 replace reactstrap with our layout components ([38d17e1](https://git.softwaregroup.com/ut5/ut-customer/commit/38d17e1))
* UIS-1523 select business unit ([2b7f07a](https://git.softwaregroup.com/ut5/ut-customer/commit/2b7f07a))
* UIS-1523 update and view validations for the attributes ([c5dde5b](https://git.softwaregroup.com/ut5/ut-customer/commit/c5dde5b))
* UIS-1523 update header title and tab title for the different create types ([7bf57fb](https://git.softwaregroup.com/ut5/ut-customer/commit/7bf57fb))
* UIS-1523 update some of the labels ([dfcca5a](https://git.softwaregroup.com/ut5/ut-customer/commit/dfcca5a))
* UIS-1528 add check for kyc description ([b2e78da](https://git.softwaregroup.com/ut5/ut-customer/commit/b2e78da))
* UIS-1528 add check for mandatory kyc fields ([76a51b1](https://git.softwaregroup.com/ut5/ut-customer/commit/76a51b1))
* UIS-1528 change column type ([b2204b6](https://git.softwaregroup.com/ut5/ut-customer/commit/b2204b6))
* UIS-1528 change get for create ([548e64d](https://git.softwaregroup.com/ut5/ut-customer/commit/548e64d))
* UIS-1528 change procedure name ([ac42faa](https://git.softwaregroup.com/ut5/ut-customer/commit/ac42faa))
* UIS-1528 check for missing attributes ([1352ed8](https://git.softwaregroup.com/ut5/ut-customer/commit/1352ed8))
* UIS-1528 delete procedure added, alter table ([90333e5](https://git.softwaregroup.com/ut5/ut-customer/commit/90333e5))
* UIS-1528 edit kyc.get result set ([8e64e55](https://git.softwaregroup.com/ut5/ut-customer/commit/8e64e55))
* UIS-1528 fetch get changes and new table for kyc attributes ([5509da4](https://git.softwaregroup.com/ut5/ut-customer/commit/5509da4))
* UIS-1528 kyc attribute procedure change ([5eeef54](https://git.softwaregroup.com/ut5/ut-customer/commit/5eeef54))
* UIS-1528 kyc fetch and table change ([21c3759](https://git.softwaregroup.com/ut5/ut-customer/commit/21c3759))
* UIS-1528 kyc table change, remove kyc and customer type from seed ([8330095](https://git.softwaregroup.com/ut5/ut-customer/commit/8330095))
* UIS-1528 new column in kyc attribute table ([20902a2](https://git.softwaregroup.com/ut5/ut-customer/commit/20902a2))
* UIS-1528 procedure for attributes list ([6e21e01](https://git.softwaregroup.com/ut5/ut-customer/commit/6e21e01))
* UIS-1528 remove checks for delete deactivate ([84605f2](https://git.softwaregroup.com/ut5/ut-customer/commit/84605f2))
* UIS-1528 remove kyc from seed ([94a9097](https://git.softwaregroup.com/ut5/ut-customer/commit/94a9097))
* UIS-1528 remove redundant sorting ([97ebf77](https://git.softwaregroup.com/ut5/ut-customer/commit/97ebf77))
* UIS-1528 result set updated ([a6fb887](https://git.softwaregroup.com/ut5/ut-customer/commit/a6fb887))
* UIS-1528 table change procedures add ([cbcb5fd](https://git.softwaregroup.com/ut5/ut-customer/commit/cbcb5fd))
* UIS-1528 update fetch procedure ([d1c592a](https://git.softwaregroup.com/ut5/ut-customer/commit/d1c592a))
* UIS-1532 change in kyc edit sp ([b63e77a](https://git.softwaregroup.com/ut5/ut-customer/commit/b63e77a))
* UIS-1532 new procedure for organization list ([bb251a9](https://git.softwaregroup.com/ut5/ut-customer/commit/bb251a9))
* UIS-1532 update fetch and get ([263f03e](https://git.softwaregroup.com/ut5/ut-customer/commit/263f03e))
* UIS-2103 add constraint in kyc condition table ([68c02f3](https://git.softwaregroup.com/ut5/ut-customer/commit/68c02f3))



<a name="5.59.1"></a>
## [5.59.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.59.0...v5.59.1) (2017-03-28)


### Bug Fixes

* UATMC-171 Tune/LOAN V1 | Application : Creation (MG) ([0b1a28b](https://git.softwaregroup.com/ut5/ut-customer/commit/0b1a28b))



<a name="5.59.0"></a>
# [5.59.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.58.3...v5.59.0) (2017-03-28)


### Bug Fixes

* Android check added ([b6347df](https://git.softwaregroup.com/ut5/ut-customer/commit/b6347df))
* MCTUNE-2624 reports pagination ([0c6c22c](https://git.softwaregroup.com/ut5/ut-customer/commit/0c6c22c))
* rename tables according their order of creation ([2812525](https://git.softwaregroup.com/ut5/ut-customer/commit/2812525))
* standard module export ([df2e7da](https://git.softwaregroup.com/ut5/ut-customer/commit/df2e7da))
* standard module export ([38b7ec4](https://git.softwaregroup.com/ut5/ut-customer/commit/38b7ec4))
* standard structure ([068216a](https://git.softwaregroup.com/ut5/ut-customer/commit/068216a))


### Features

* MCTUNE-2608 & MCTUNE-2609 Responsive app ([8c65438](https://git.softwaregroup.com/ut5/ut-customer/commit/8c65438))
* UIS-1022: Fix dialog buttons ([133ebe5](https://git.softwaregroup.com/ut5/ut-customer/commit/133ebe5))
* UIS-1022: Fix use photo without crop ([3bb050c](https://git.softwaregroup.com/ut5/ut-customer/commit/3bb050c))



<a name="5.58.0"></a>
# [5.58.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.57.7...v5.58.0) (2017-03-24)


### Bug Fixes

* MCTUNE-2476 - limit the level depth of branches ([f40e1b4](https://git.softwaregroup.com/ut5/ut-customer/commit/f40e1b4))
* uat-257 rename variable ([cf08ee6](https://git.softwaregroup.com/ut5/ut-customer/commit/cf08ee6))
* UATMC-257 bio issue for Madagascar ([bbfce5e](https://git.softwaregroup.com/ut5/ut-customer/commit/bbfce5e))


### Features

* add column in table person and fix joi validation ([a26dd29](https://git.softwaregroup.com/ut5/ut-customer/commit/a26dd29))
* add new column in table address ([faaabe5](https://git.softwaregroup.com/ut5/ut-customer/commit/faaabe5))
* Clearing new referral profile ([2bd840a](https://git.softwaregroup.com/ut5/ut-customer/commit/2bd840a))
* fix customer number null issue ([e2382fd](https://git.softwaregroup.com/ut5/ut-customer/commit/e2382fd))
* fix db review comments ([46e8f0c](https://git.softwaregroup.com/ut5/ut-customer/commit/46e8f0c))
* fix review comments ([c35f256](https://git.softwaregroup.com/ut5/ut-customer/commit/c35f256))
* fix Tanya review comments ([01c8fc4](https://git.softwaregroup.com/ut5/ut-customer/commit/01c8fc4))
* Fix Tanya review comments ([9c00d2a](https://git.softwaregroup.com/ut5/ut-customer/commit/9c00d2a))
* fixing review comments ([2302b07](https://git.softwaregroup.com/ut5/ut-customer/commit/2302b07))
* handle null exception while approve referral changes ([d7ef4ce](https://git.softwaregroup.com/ut5/ut-customer/commit/d7ef4ce))
* incremet ut-tools verson ([afe8023](https://git.softwaregroup.com/ut5/ut-customer/commit/afe8023))
* made tanya review comment changes ([503ccf9](https://git.softwaregroup.com/ut5/ut-customer/commit/503ccf9))
* Modify schema ([41f2adb](https://git.softwaregroup.com/ut5/ut-customer/commit/41f2adb))
* Modify SPs ([d8d910a](https://git.softwaregroup.com/ut5/ut-customer/commit/d8d910a))
* remove unwanted files ([34d8750](https://git.softwaregroup.com/ut5/ut-customer/commit/34d8750))
* rename lastupdated to updatedOn ([04227fc](https://git.softwaregroup.com/ut5/ut-customer/commit/04227fc))
* renmaing referral.list to referral.fetch ([cc26dc8](https://git.softwaregroup.com/ut5/ut-customer/commit/cc26dc8))
* resolve linting errors ([d0172ed](https://git.softwaregroup.com/ut5/ut-customer/commit/d0172ed))
* resolve linting errors ([847681f](https://git.softwaregroup.com/ut5/ut-customer/commit/847681f))
* UIS-1496 fix referral date validation ([281363c](https://git.softwaregroup.com/ut5/ut-customer/commit/281363c))
* UIS-1496 fix review comments ([b5ee5c8](https://git.softwaregroup.com/ut5/ut-customer/commit/b5ee5c8))
* UIS-1496 made DB review comment changes ([ccb7b4e](https://git.softwaregroup.com/ut5/ut-customer/commit/ccb7b4e))
* UIS-1496 made FE review comment changes ([ca237b0](https://git.softwaregroup.com/ut5/ut-customer/commit/ca237b0))
* UIS-1496 resolve linting errors ([67b85b2](https://git.softwaregroup.com/ut5/ut-customer/commit/67b85b2))
* UIS-1496. FE changes that belongs to Tanya review comments. ([3bac617](https://git.softwaregroup.com/ut5/ut-customer/commit/3bac617))
* UIS-1820 add msisdn ([a6b4f26](https://git.softwaregroup.com/ut5/ut-customer/commit/a6b4f26))
* update referral updatedBy while approving the referral changes ([39e64b9](https://git.softwaregroup.com/ut5/ut-customer/commit/39e64b9))



<a name="5.57.7"></a>
## [5.57.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.57.6...v5.57.7) (2017-03-22)


### Bug Fixes

* UATMC-86 list of records by default ([3cd64d9](https://git.softwaregroup.com/ut5/ut-customer/commit/3cd64d9))



<a name="5.57.6"></a>
## [5.57.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.57.5...v5.57.6) (2017-03-22)


### Bug Fixes

* MCTUNE-1061 Check for invalid boundaries ([41d740a](https://git.softwaregroup.com/ut5/ut-customer/commit/41d740a))
* MCTUNE-2577 Make method: customer.cbs.activity to return currency ([c7d57ef](https://git.softwaregroup.com/ut5/ut-customer/commit/c7d57ef))
* MCTUNE-2603 - package.json ([675dce9](https://git.softwaregroup.com/ut5/ut-customer/commit/675dce9))
* MCTUNE-2603 - package.json ([733168f](https://git.softwaregroup.com/ut5/ut-customer/commit/733168f))
* udpate procedure cistomer add person ([bc0ff55](https://git.softwaregroup.com/ut5/ut-customer/commit/bc0ff55))
* update KYC ([5ce788a](https://git.softwaregroup.com/ut5/ut-customer/commit/5ce788a))
* update KYC in procedure customer add person ([7817863](https://git.softwaregroup.com/ut5/ut-customer/commit/7817863))
* update procedure customer get ([a1bdd48](https://git.softwaregroup.com/ut5/ut-customer/commit/a1bdd48))



<a name="5.57.5"></a>
## [5.57.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.57.4...v5.57.5) (2017-03-21)


### Bug Fixes

* MCTUNE-2603 - package.json ([88c8c9f](https://git.softwaregroup.com/ut5/ut-customer/commit/88c8c9f))



<a name="5.57.4"></a>
## [5.57.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.57.3...v5.57.4) (2017-03-21)


### Bug Fixes

* MCTUNE-2607 Customer create test fix ([18ad4c8](https://git.softwaregroup.com/ut5/ut-customer/commit/18ad4c8))



<a name="5.57.3"></a>
## [5.57.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.57.2...v5.57.3) (2017-03-21)


### Bug Fixes

* update procedure ([c53ef8f](https://git.softwaregroup.com/ut5/ut-customer/commit/c53ef8f))



<a name="5.57.2"></a>
## [5.57.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.57.1...v5.57.2) (2017-03-20)


### Bug Fixes

* insert attachment ([122a25a](https://git.softwaregroup.com/ut5/ut-customer/commit/122a25a))
* remove warnings ([c0ea40c](https://git.softwaregroup.com/ut5/ut-customer/commit/c0ea40c))
* saving uploaded attachment ([fc5dece](https://git.softwaregroup.com/ut5/ut-customer/commit/fc5dece))
* update alter ([692bf3f](https://git.softwaregroup.com/ut5/ut-customer/commit/692bf3f))
* update alter and create table ([441f28f](https://git.softwaregroup.com/ut5/ut-customer/commit/441f28f))
* update alter table ([f509aa1](https://git.softwaregroup.com/ut5/ut-customer/commit/f509aa1))
* update alter table ([c67cbfd](https://git.softwaregroup.com/ut5/ut-customer/commit/c67cbfd))
* update alter table ([cf73fe3](https://git.softwaregroup.com/ut5/ut-customer/commit/cf73fe3))
* update alter table ([2c9c712](https://git.softwaregroup.com/ut5/ut-customer/commit/2c9c712))
* update alter table ([3ea9355](https://git.softwaregroup.com/ut5/ut-customer/commit/3ea9355))



<a name="5.57.1"></a>
## [5.57.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.57.0...v5.57.1) (2017-03-20)


### Bug Fixes

* account problem cards ([c87561b](https://git.softwaregroup.com/ut5/ut-customer/commit/c87561b))



<a name="5.57.0"></a>
# [5.57.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.56.0...v5.57.0) (2017-03-20)


### Bug Fixes

* document add for customer ([aa7fb85](https://git.softwaregroup.com/ut5/ut-customer/commit/aa7fb85))
* feat-UIS-968 upload file, delete file, edit file ([0ba184a](https://git.softwaregroup.com/ut5/ut-customer/commit/0ba184a))
* MCTUNE-2171 User shouldn’t be able to create another application when an application in Disbursed on hold ([c7986b1](https://git.softwaregroup.com/ut5/ut-customer/commit/c7986b1))
* MCTUNE-2252 - merging and package.json ([946e240](https://git.softwaregroup.com/ut5/ut-customer/commit/946e240))
* MCTUNE-2561 validations failed when customer is created from Pulse ([7ed529e](https://git.softwaregroup.com/ut5/ut-customer/commit/7ed529e))
* update alter table ([7594e4d](https://git.softwaregroup.com/ut5/ut-customer/commit/7594e4d))
* update and add now procedure ([7eaf8a3](https://git.softwaregroup.com/ut5/ut-customer/commit/7eaf8a3))
* update name and order column ([b1481d1](https://git.softwaregroup.com/ut5/ut-customer/commit/b1481d1))
* update parameters ([6cac75d](https://git.softwaregroup.com/ut5/ut-customer/commit/6cac75d))
* update procedure ([ec66cf9](https://git.softwaregroup.com/ut5/ut-customer/commit/ec66cf9))
* update procedure ([94b6976](https://git.softwaregroup.com/ut5/ut-customer/commit/94b6976))
* update procedure ([6879292](https://git.softwaregroup.com/ut5/ut-customer/commit/6879292))
* update procedure ([b041301](https://git.softwaregroup.com/ut5/ut-customer/commit/b041301))
* update procedure ([baeb60d](https://git.softwaregroup.com/ut5/ut-customer/commit/baeb60d))
* update procedure ([055feed](https://git.softwaregroup.com/ut5/ut-customer/commit/055feed))
* update procedure customer.customer.edit ([ffdab2f](https://git.softwaregroup.com/ut5/ut-customer/commit/ffdab2f))


### Features

* UIS-1022: Add icons ([68f5490](https://git.softwaregroup.com/ut5/ut-customer/commit/68f5490))
* UIS-1022: Add plus icon ([5735498](https://git.softwaregroup.com/ut5/ut-customer/commit/5735498))
* update column name ([7579214](https://git.softwaregroup.com/ut5/ut-customer/commit/7579214))



<a name="5.56.0"></a>
# [5.56.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.55.3...v5.56.0) (2017-03-17)


### Bug Fixes

* MCTUNE-2252 - merging and package.json ([774ebe2](https://git.softwaregroup.com/ut5/ut-customer/commit/774ebe2))
* MCTUNE-2252 - merging and package.json ([668a403](https://git.softwaregroup.com/ut5/ut-customer/commit/668a403))


### Features

* create procedure for customerType ([63cd5aa](https://git.softwaregroup.com/ut5/ut-customer/commit/63cd5aa))
* UIS-1022 ([56658fa](https://git.softwaregroup.com/ut5/ut-customer/commit/56658fa))
* UIS-1022: Disable crop for images with aspect ratio 4/3 in take photo mode ([0850994](https://git.softwaregroup.com/ut5/ut-customer/commit/0850994))
* UIS-1022: Fix crop in take photo ([c54646a](https://git.softwaregroup.com/ut5/ut-customer/commit/c54646a))
* UIS-1022: Fix crop in take photo ([40ef775](https://git.softwaregroup.com/ut5/ut-customer/commit/40ef775))
* UIs-1022: Fix disabled file upload button and show file details popup ([9baba47](https://git.softwaregroup.com/ut5/ut-customer/commit/9baba47))
* UIS-1022: Fix preview size ([6d4c640](https://git.softwaregroup.com/ut5/ut-customer/commit/6d4c640))
* UIS-1022: Merge develop ([6c1d0fd](https://git.softwaregroup.com/ut5/ut-customer/commit/6c1d0fd))



<a name="5.55.3"></a>
## [5.55.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.55.2...v5.55.3) (2017-03-17)


### Bug Fixes

* MCTUNE-2550 - Immutable login fixes ([16d13a4](https://git.softwaregroup.com/ut5/ut-customer/commit/16d13a4))



<a name="5.55.2"></a>
## [5.55.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.55.1...v5.55.2) (2017-03-17)


### Bug Fixes

* MCTUNE-2252 Automation test for customer.customerCreate ([80b1887](https://git.softwaregroup.com/ut5/ut-customer/commit/80b1887))
* MCTUNE-2553 fix column order ([07a0b1b](https://git.softwaregroup.com/ut5/ut-customer/commit/07a0b1b))



<a name="5.55.1"></a>
## [5.55.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.55.0...v5.55.1) (2017-03-16)



<a name="5.55.0"></a>
# [5.55.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.54.1...v5.55.0) (2017-03-16)


### Bug Fixes

* MCTUNE-2104 Search style fix ([75b00af](https://git.softwaregroup.com/ut5/ut-customer/commit/75b00af))


### Features

* UIS-1834 remove redundant columns for time ([678d7e8](https://git.softwaregroup.com/ut5/ut-customer/commit/678d7e8))



<a name="5.54.1"></a>
## [5.54.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.54.0...v5.54.1) (2017-03-14)


### Bug Fixes

* MCTUNE-2104 - package.json ([dcf6d8d](https://git.softwaregroup.com/ut5/ut-customer/commit/dcf6d8d))
* MCTUNE-2474 fix lint error ([a695dc4](https://git.softwaregroup.com/ut5/ut-customer/commit/a695dc4))
* UIS-968 ([13605b0](https://git.softwaregroup.com/ut5/ut-customer/commit/13605b0))
* UIS-968 ([53a0b67](https://git.softwaregroup.com/ut5/ut-customer/commit/53a0b67))



<a name="5.54.0"></a>
# [5.54.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.53.2...v5.54.0) (2017-03-14)


### Features

* UIS-1022: Fix disabled button style and popup header ([9d9b689](https://git.softwaregroup.com/ut5/ut-customer/commit/9d9b689))
* UIS-968 connect primary document as document order ([69af1b2](https://git.softwaregroup.com/ut5/ut-customer/commit/69af1b2))
* UIS-968 set primary document in customer.document.setPrimary ([d92edd8](https://git.softwaregroup.com/ut5/ut-customer/commit/d92edd8))
* UIS-968 update attachment ([90cf1a7](https://git.softwaregroup.com/ut5/ut-customer/commit/90cf1a7))
* UIS-968 upload large files ([8f19ebc](https://git.softwaregroup.com/ut5/ut-customer/commit/8f19ebc))
* UIS-968: Fix reducers ([3df907d](https://git.softwaregroup.com/ut5/ut-customer/commit/3df907d))



<a name="5.53.2"></a>
## [5.53.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.53.1...v5.53.2) (2017-03-10)


### Bug Fixes

* alter table ([acc07d2](https://git.softwaregroup.com/ut5/ut-customer/commit/acc07d2))
* alter table ([35bec59](https://git.softwaregroup.com/ut5/ut-customer/commit/35bec59))



<a name="5.53.1"></a>
## [5.53.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.53.0...v5.53.1) (2017-03-10)


### Bug Fixes

* joi validations for edit ([eee9121](https://git.softwaregroup.com/ut5/ut-customer/commit/eee9121))
* update procedure ([299d639](https://git.softwaregroup.com/ut5/ut-customer/commit/299d639))
* update procedure ([d8caa19](https://git.softwaregroup.com/ut5/ut-customer/commit/d8caa19))



<a name="5.53.0"></a>
# [5.53.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.52.0...v5.53.0) (2017-03-10)


### Features

* update table column ([d3f1d31](https://git.softwaregroup.com/ut5/ut-customer/commit/d3f1d31))



<a name="5.52.0"></a>
# [5.52.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.51.0...v5.52.0) (2017-03-10)


### Features

* add table and add column ([4770e85](https://git.softwaregroup.com/ut5/ut-customer/commit/4770e85))
* add to procedure column documentOrder ([c202ba9](https://git.softwaregroup.com/ut5/ut-customer/commit/c202ba9))
* add to procedure column documentOrder ([07c161f](https://git.softwaregroup.com/ut5/ut-customer/commit/07c161f))
* add to procedure column documentOrder ([d6cf623](https://git.softwaregroup.com/ut5/ut-customer/commit/d6cf623))
* add to procedure column documentOrder ([f839bd3](https://git.softwaregroup.com/ut5/ut-customer/commit/f839bd3))
* formating procedure ([70494b8](https://git.softwaregroup.com/ut5/ut-customer/commit/70494b8))
* update alter ([274e10b](https://git.softwaregroup.com/ut5/ut-customer/commit/274e10b))
* update alter ([ba74859](https://git.softwaregroup.com/ut5/ut-customer/commit/ba74859))
* update and create procedure. Update and create table and update alter table. ([1d7b977](https://git.softwaregroup.com/ut5/ut-customer/commit/1d7b977))
* update name procedure ([c8a7bae](https://git.softwaregroup.com/ut5/ut-customer/commit/c8a7bae))
* update procedure ([d839377](https://git.softwaregroup.com/ut5/ut-customer/commit/d839377))
* update procedure ([f917d6a](https://git.softwaregroup.com/ut5/ut-customer/commit/f917d6a))
* update procedure ([83bc8b5](https://git.softwaregroup.com/ut5/ut-customer/commit/83bc8b5))
* update procedure ([9032d99](https://git.softwaregroup.com/ut5/ut-customer/commit/9032d99))
* update procedure ([ecb5ee0](https://git.softwaregroup.com/ut5/ut-customer/commit/ecb5ee0))
* update procedure ([9753bd7](https://git.softwaregroup.com/ut5/ut-customer/commit/9753bd7))
* update procedure ([3f76a35](https://git.softwaregroup.com/ut5/ut-customer/commit/3f76a35))
* update procedure ([43bb529](https://git.softwaregroup.com/ut5/ut-customer/commit/43bb529))
* update procedure and table ([6742b8a](https://git.softwaregroup.com/ut5/ut-customer/commit/6742b8a))
* update procedure self add ([0389d2b](https://git.softwaregroup.com/ut5/ut-customer/commit/0389d2b))
* update table marital status ([f2daead](https://git.softwaregroup.com/ut5/ut-customer/commit/f2daead))



<a name="5.51.0"></a>
# [5.51.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.50.0...v5.51.0) (2017-03-10)


### Bug Fixes

* UIS-1524 add BU modal refactor ([8bfcfa4](https://git.softwaregroup.com/ut5/ut-customer/commit/8bfcfa4))
* UIS-1524 add customer kyc fetch joi validations ([3afe691](https://git.softwaregroup.com/ut5/ut-customer/commit/3afe691))
* UIS-1524 add joi validations ([4fbf638](https://git.softwaregroup.com/ut5/ut-customer/commit/4fbf638))
* UIS-1524 add joi validations ([e866571](https://git.softwaregroup.com/ut5/ut-customer/commit/e866571))
* UIS-1524 add val to index ([e8c9b57](https://git.softwaregroup.com/ut5/ut-customer/commit/e8c9b57))
* **customerType:** UIS-1527 add unique constraint ([3d98de0](https://git.softwaregroup.com/ut5/ut-customer/commit/3d98de0))
* UIS-1524 fix lint errors ([5e81a23](https://git.softwaregroup.com/ut5/ut-customer/commit/5e81a23))
* UIS-1524 successful create product ([53fbd56](https://git.softwaregroup.com/ut5/ut-customer/commit/53fbd56))


### Features

* **kyc.fetch:** UIS-1527 new SP ([db0379f](https://git.softwaregroup.com/ut5/ut-customer/commit/db0379f))
* UIS-1022: Connect UI with BE changes ([4d21256](https://git.softwaregroup.com/ut5/ut-customer/commit/4d21256))
* UIS-1022: Fix PhotoPreview opacity inheritance ([7a86d08](https://git.softwaregroup.com/ut5/ut-customer/commit/7a86d08))
* UIS-1022: Fix styles ([b54292c](https://git.softwaregroup.com/ut5/ut-customer/commit/b54292c))
* UIS-1022: Fix styles and move crop and change buttons to footer ([ea26444](https://git.softwaregroup.com/ut5/ut-customer/commit/ea26444))
* UIS-1022: Fix styles and move crop and change buttons to footer ([d45b4c1](https://git.softwaregroup.com/ut5/ut-customer/commit/d45b4c1))
* UIS-1022: Move crop slider to the right ([32029cd](https://git.softwaregroup.com/ut5/ut-customer/commit/32029cd))
* UIS-1022: Remove TakePhoto component ([fd5b104](https://git.softwaregroup.com/ut5/ut-customer/commit/fd5b104))
* UIS-1527 customerCategory.fetch ([6f04517](https://git.softwaregroup.com/ut5/ut-customer/commit/6f04517))



<a name="5.50.0"></a>
# [5.50.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.49.4...v5.50.0) (2017-03-09)


### Bug Fixes

* MCTUNE-2470 Avatar missing for client from Pulse ([452ef40](https://git.softwaregroup.com/ut5/ut-customer/commit/452ef40))
* MCTUNE-2473 T24 field error validation message ([69f2b50](https://git.softwaregroup.com/ut5/ut-customer/commit/69f2b50))


### Features

* MCTUNE-2478 Add business unit ddl for observers ([4dc895b](https://git.softwaregroup.com/ut5/ut-customer/commit/4dc895b))



<a name="5.49.4"></a>
## [5.49.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.49.3...v5.49.4) (2017-03-09)



<a name="5.49.3"></a>
## [5.49.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.49.2...v5.49.3) (2017-03-09)


### Bug Fixes

* dependencies ([8a9d473](https://git.softwaregroup.com/ut5/ut-customer/commit/8a9d473))



<a name="5.49.2"></a>
## [5.49.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.49.1...v5.49.2) (2017-03-08)



<a name="5.49.1"></a>
## [5.49.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.49.0...v5.49.1) (2017-03-08)


### Bug Fixes

* UIS-1263 rename SP to organization.delete ([90b5127](https://git.softwaregroup.com/ut5/ut-customer/commit/90b5127))



<a name="5.49.0"></a>
# [5.49.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.48.1...v5.49.0) (2017-03-08)


### Bug Fixes

* dependencies ([1cfcda4](https://git.softwaregroup.com/ut5/ut-customer/commit/1cfcda4))
* UIS-1263 add check for BU recursion ([c76d06d](https://git.softwaregroup.com/ut5/ut-customer/commit/c76d06d))
* UIS-1263 add check for invalid parent ([b80d4c6](https://git.softwaregroup.com/ut5/ut-customer/commit/b80d4c6))
* UIS-1263 add error for locking locked BU ([fb46bd7](https://git.softwaregroup.com/ut5/ut-customer/commit/fb46bd7))
* UIS-1263 add errors for status check ([7dd4d87](https://git.softwaregroup.com/ut5/ut-customer/commit/7dd4d87))
* UIS-1263 add filter by statusId ([2178a56](https://git.softwaregroup.com/ut5/ut-customer/commit/2178a56))
* UIS-1263 change SP name to organization.delete ([429821d](https://git.softwaregroup.com/ut5/ut-customer/commit/429821d))
* UIS-1263 check for invalid parent ([82905f3](https://git.softwaregroup.com/ut5/ut-customer/commit/82905f3))
* UIS-1263 delete BU ([48eb69f](https://git.softwaregroup.com/ut5/ut-customer/commit/48eb69f))
* UIS-1263 edit parents ([b34d013](https://git.softwaregroup.com/ut5/ut-customer/commit/b34d013))
* UIS-1263 error for invalid status ([7aa75ff](https://git.softwaregroup.com/ut5/ut-customer/commit/7aa75ff))
* UIS-1263 fetch parents ([34f0435](https://git.softwaregroup.com/ut5/ut-customer/commit/34f0435))
* UIS-1263 get new BUs ([87a2919](https://git.softwaregroup.com/ut5/ut-customer/commit/87a2919))
* UIS-1263 lock BU ([fe87189](https://git.softwaregroup.com/ut5/ut-customer/commit/fe87189))
* UIS-1263 lock locked BU ([1089785](https://git.softwaregroup.com/ut5/ut-customer/commit/1089785))
* UIS-1263 lock tests error ([59a3860](https://git.softwaregroup.com/ut5/ut-customer/commit/59a3860))
* UIS-1263 parents unapproved ([bd3d633](https://git.softwaregroup.com/ut5/ut-customer/commit/bd3d633))
* UIS-1263 raise error delete of deleted ([c65cabe](https://git.softwaregroup.com/ut5/ut-customer/commit/c65cabe))
* UIS-1263 remove account ([0a8a3bf](https://git.softwaregroup.com/ut5/ut-customer/commit/0a8a3bf))
* UIS-1263 remove, discard, reject ([500139c](https://git.softwaregroup.com/ut5/ut-customer/commit/500139c))
* **organization.approve:** UIS-1263 check for edit ([046c42f](https://git.softwaregroup.com/ut5/ut-customer/commit/046c42f))
* UIS-1263 return visible disabled organizations ([463a422](https://git.softwaregroup.com/ut5/ut-customer/commit/463a422))
* UIS-1263 set actorId ([af09e36](https://git.softwaregroup.com/ut5/ut-customer/commit/af09e36))
* UIS-1263 transactions ([386e74a](https://git.softwaregroup.com/ut5/ut-customer/commit/386e74a))
* **organization.approve:** UIS-1263 left from user ([62f5de4](https://git.softwaregroup.com/ut5/ut-customer/commit/62f5de4))
* **organization.fetch:** UIS-1263 distinct visibleFor + added comments ([0c0550b](https://git.softwaregroup.com/ut5/ut-customer/commit/0c0550b))
* **organization.fetch:** UIS-1263 parent name ([8593b27](https://git.softwaregroup.com/ut5/ut-customer/commit/8593b27))
* **organization.get:** UIS-1263 remove deleted phones from resultset ([4c671a5](https://git.softwaregroup.com/ut5/ut-customer/commit/4c671a5))
* **organization.lock:** UIS-1263 add record in unapproved table ([a913990](https://git.softwaregroup.com/ut5/ut-customer/commit/a913990))
* **organization.reject:** UIS-1263 update statusId ([fddaaab](https://git.softwaregroup.com/ut5/ut-customer/commit/fddaaab))


### Features

* add middlename at the end ([b3c25a5](https://git.softwaregroup.com/ut5/ut-customer/commit/b3c25a5))
* remove insert into person ([810fe7e](https://git.softwaregroup.com/ut5/ut-customer/commit/810fe7e))
* UIS-1022 Style crop and preview ([8c7a165](https://git.softwaregroup.com/ut5/ut-customer/commit/8c7a165))
* UIS-1022: Add file accept types and fix buttons in retake mode and buttons opacity in photo preview ([dad7681](https://git.softwaregroup.com/ut5/ut-customer/commit/dad7681))
* UIS-1022: Add proper scaling to all previews ([444b593](https://git.softwaregroup.com/ut5/ut-customer/commit/444b593))
* UIS-1022: Add tooltip logic ([b9cb6d8](https://git.softwaregroup.com/ut5/ut-customer/commit/b9cb6d8))
* UIS-1022: Add tooltip to ID photo ([49ba931](https://git.softwaregroup.com/ut5/ut-customer/commit/49ba931))
* UIS-1022: Add tooltp logic ([f2dc4d4](https://git.softwaregroup.com/ut5/ut-customer/commit/f2dc4d4))
* UIS-1022: Fix crop when changing image ([b3ec49b](https://git.softwaregroup.com/ut5/ut-customer/commit/b3ec49b))
* UIS-1022: Fix file deletion ([94ffccc](https://git.softwaregroup.com/ut5/ut-customer/commit/94ffccc))
* UIS-1022: Fix lint ([2bb1631](https://git.softwaregroup.com/ut5/ut-customer/commit/2bb1631))
* UIS-1022: Implement crop ([9450141](https://git.softwaregroup.com/ut5/ut-customer/commit/9450141))
* UIS-1022: Refactor passing props to components ([5c140c5](https://git.softwaregroup.com/ut5/ut-customer/commit/5c140c5))
* UIS-1022: Refactor PhotoContainer ([a08d707](https://git.softwaregroup.com/ut5/ut-customer/commit/a08d707))
* UIS-1022: Show crop result ([fa1764a](https://git.softwaregroup.com/ut5/ut-customer/commit/fa1764a))
* UIS-1204: fix identity config inputs and add a sidenote ([080b7d9](https://git.softwaregroup.com/ut5/ut-customer/commit/080b7d9))
* UIS-1263 new table and SPs ([28917df](https://git.softwaregroup.com/ut5/ut-customer/commit/28917df))
* UIS-1263 refine unapproved logic ([5993296](https://git.softwaregroup.com/ut5/ut-customer/commit/5993296))
* UIS-1601: implement general info layout ([db78b85](https://git.softwaregroup.com/ut5/ut-customer/commit/db78b85))
* UIS-968 add documentId in customer.customer.get and update countryId in customer.customer.edit ([411a9f1](https://git.softwaregroup.com/ut5/ut-customer/commit/411a9f1))
* UIS-968 add middleName column; modify customer.get to return middle name and save the document in customer.customer.add ([f162276](https://git.softwaregroup.com/ut5/ut-customer/commit/f162276))
* UIS-968 change fields to be consistent with db ([779090d](https://git.softwaregroup.com/ut5/ut-customer/commit/779090d))
* UIS-968 fix tests ([928a1db](https://git.softwaregroup.com/ut5/ut-customer/commit/928a1db))
* UIS-968 fix warnings in console; ([43589e3](https://git.softwaregroup.com/ut5/ut-customer/commit/43589e3))
* UIS-968 joi validations; fix reducers structure ([5c0c031](https://git.softwaregroup.com/ut5/ut-customer/commit/5c0c031))
* UIS-968 refactor grid to be consistent with user module ([fdb1b95](https://git.softwaregroup.com/ut5/ut-customer/commit/fdb1b95))
* UIS-968 return attachmentId and documentId for primaryDocument and profile photo ([2299cdc](https://git.softwaregroup.com/ut5/ut-customer/commit/2299cdc))
* UIS-968 save document attachments ([5337a22](https://git.softwaregroup.com/ut5/ut-customer/commit/5337a22))
* UIS-968 set primary document ([bd6dcac](https://git.softwaregroup.com/ut5/ut-customer/commit/bd6dcac))
* UIS-968 update labels; fix aside width ([bc40c86](https://git.softwaregroup.com/ut5/ut-customer/commit/bc40c86))



<a name="5.48.1"></a>
## [5.48.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.48.0...v5.48.1) (2017-03-06)



<a name="5.48.0"></a>
# [5.48.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.47.0...v5.48.0) (2017-03-02)


### Bug Fixes

* tests and errors ([576f3ef](https://git.softwaregroup.com/ut5/ut-customer/commit/576f3ef))
* UIS-1653 move TabContainer to ut-front-react ([b830d99](https://git.softwaregroup.com/ut5/ut-customer/commit/b830d99))
* UIS-1653 move TabContainer to ut-front-react ([0ef2ff0](https://git.softwaregroup.com/ut5/ut-customer/commit/0ef2ff0))
* UIS-1653 move TabContainer to ut-front-react ([b158209](https://git.softwaregroup.com/ut5/ut-customer/commit/b158209))


### Features

* UIS-1204: add titles to content boxes ([51db838](https://git.softwaregroup.com/ut5/ut-customer/commit/51db838))
* UIS-1204: fix identity tab layout being broken after refactoring ([00d37b2](https://git.softwaregroup.com/ut5/ut-customer/commit/00d37b2))
* UIS-1204: fix lint ([7e22262](https://git.softwaregroup.com/ut5/ut-customer/commit/7e22262))
* UIS-1661 add list of secret questions as response in selfregistration ([a392deb](https://git.softwaregroup.com/ut5/ut-customer/commit/a392deb))



<a name="5.47.0"></a>
# [5.47.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.46.4...v5.47.0) (2017-02-28)


### Bug Fixes

* MCTUNE-2104 - merging ([2374aa1](https://git.softwaregroup.com/ut5/ut-customer/commit/2374aa1))
* MCTUNE-2427 not necessary error ([b034d72](https://git.softwaregroup.com/ut5/ut-customer/commit/b034d72))
* MCTUNE-2429 -2440 Missing dao, organizationId & stateId no client creation ([c49af49](https://git.softwaregroup.com/ut5/ut-customer/commit/c49af49))
* UIS-1204 fix tests ([dc19d5f](https://git.softwaregroup.com/ut5/ut-customer/commit/dc19d5f))


### Features

* add procedure customer.customer.edit ([90d9e0a](https://git.softwaregroup.com/ut5/ut-customer/commit/90d9e0a))
* get customer organization ([3e273e4](https://git.softwaregroup.com/ut5/ut-customer/commit/3e273e4))
* get customer organization ([f47fa7d](https://git.softwaregroup.com/ut5/ut-customer/commit/f47fa7d))
* UIS-1204: add action buttons to edit page ([4ddc694](https://git.softwaregroup.com/ut5/ut-customer/commit/4ddc694))
* UIS-1204: add titledContentBox component to customer/components ([3265392](https://git.softwaregroup.com/ut5/ut-customer/commit/3265392))
* UIS-1204: change identity tab layout ([4be0fba](https://git.softwaregroup.com/ut5/ut-customer/commit/4be0fba))
* UIS-1204: connect close button for edit and create pages ([40bc6cb](https://git.softwaregroup.com/ut5/ut-customer/commit/40bc6cb))
* UIS-1204: implement edit and create ([6b9f715](https://git.softwaregroup.com/ut5/ut-customer/commit/6b9f715))
* UIS-1270: refactor tab file structure ([6887ade](https://git.softwaregroup.com/ut5/ut-customer/commit/6887ade))
* UIS-959 add imei error message ([ae09a4b](https://git.softwaregroup.com/ut5/ut-customer/commit/ae09a4b))
* UIS-968 add option to save customer; fix add custome ([5465654](https://git.softwaregroup.com/ut5/ut-customer/commit/5465654))
* UIS-968 fix lint errors ([9c433c0](https://git.softwaregroup.com/ut5/ut-customer/commit/9c433c0))
* UIS-968 fix tests ([271f596](https://git.softwaregroup.com/ut5/ut-customer/commit/271f596))
* update error in procedure self registration and errors.js ([b34def0](https://git.softwaregroup.com/ut5/ut-customer/commit/b34def0))
* update error message ([3fd3f60](https://git.softwaregroup.com/ut5/ut-customer/commit/3fd3f60))
* update procedure ([38bfc2e](https://git.softwaregroup.com/ut5/ut-customer/commit/38bfc2e))
* update procedure ([60e6376](https://git.softwaregroup.com/ut5/ut-customer/commit/60e6376))
* update procedure customer fetch ([b606c3b](https://git.softwaregroup.com/ut5/ut-customer/commit/b606c3b))
* update procedure customer self add ([7c06aa9](https://git.softwaregroup.com/ut5/ut-customer/commit/7c06aa9))
* update procedure customer self add ([8a0b5a7](https://git.softwaregroup.com/ut5/ut-customer/commit/8a0b5a7))
* update procedure customer.customer.get ([b843cde](https://git.softwaregroup.com/ut5/ut-customer/commit/b843cde))
* update procedure customer.customer.get ([c409a86](https://git.softwaregroup.com/ut5/ut-customer/commit/c409a86))
* update store procedure for add self registration customer. Added error for dublication imei ([cafaa5d](https://git.softwaregroup.com/ut5/ut-customer/commit/cafaa5d))
* update store procedure for add self registration customer. Added error for dublication imei ([5b0ba51](https://git.softwaregroup.com/ut5/ut-customer/commit/5b0ba51))
* update store procedure for add self registration customer. Added error for dublication imei ([749cc13](https://git.softwaregroup.com/ut5/ut-customer/commit/749cc13))



<a name="5.46.4"></a>
## [5.46.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.46.3...v5.46.4) (2017-02-24)


### Bug Fixes

* MCTUNE-2408 MCTUNE-2409 T24 fields errors ([573f48e](https://git.softwaregroup.com/ut5/ut-customer/commit/573f48e))



<a name="5.46.3"></a>
## [5.46.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.46.2...v5.46.3) (2017-02-24)



<a name="5.46.2"></a>
## [5.46.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.46.1...v5.46.2) (2017-02-24)


### Bug Fixes

* MCTUNE-2104 - fixed console + package.json ([7d816ad](https://git.softwaregroup.com/ut5/ut-customer/commit/7d816ad))



<a name="5.46.1"></a>
## [5.46.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.46.0...v5.46.1) (2017-02-23)



<a name="5.46.0"></a>
# [5.46.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.45.2...v5.46.0) (2017-02-23)


### Features

* UIS-1022: Add action buttons icons ([63ec11a](https://git.softwaregroup.com/ut5/ut-customer/commit/63ec11a))
* UIS-1022: Add file to FileDetails ([e6d2d04](https://git.softwaregroup.com/ut5/ut-customer/commit/e6d2d04))
* UIS-1022: Add image preview action btns ([04e8b08](https://git.softwaregroup.com/ut5/ut-customer/commit/04e8b08))
* UIS-1022: Add missing proptypes to Identity tab ([d74f996](https://git.softwaregroup.com/ut5/ut-customer/commit/d74f996))
* UIS-1022: Add photo preview ([91a797e](https://git.softwaregroup.com/ut5/ut-customer/commit/91a797e))
* UIS-1022: Add PropTypes ([f17d01d](https://git.softwaregroup.com/ut5/ut-customer/commit/f17d01d))
* UIS-1022: Change buttons config ([a2772c0](https://git.softwaregroup.com/ut5/ut-customer/commit/a2772c0))
* UIS-1022: Change images config ([35ec22f](https://git.softwaregroup.com/ut5/ut-customer/commit/35ec22f))
* UIS-1022: Fix lint ([6786449](https://git.softwaregroup.com/ut5/ut-customer/commit/6786449))
* UIS-1022: Fix styles in IDentity tab ([1d76553](https://git.softwaregroup.com/ut5/ut-customer/commit/1d76553))
* UIS-1022: Implement FileDetails design ([f46ae3d](https://git.softwaregroup.com/ut5/ut-customer/commit/f46ae3d))
* UIS-1022: Implement images preview and style initial view in popup ([f988f60](https://git.softwaregroup.com/ut5/ut-customer/commit/f988f60))
* UIS-1022: Implement popup flow with change and retake ([01f6cbe](https://git.softwaregroup.com/ut5/ut-customer/commit/01f6cbe))
* UIS-1022: Implement setActiveTab ([6ba7a85](https://git.softwaregroup.com/ut5/ut-customer/commit/6ba7a85))
* UIS-1022: Implement take screenshot ([248c11c](https://git.softwaregroup.com/ut5/ut-customer/commit/248c11c))
* UIS-1022: Move popup state to DocumentUpload component ([7f9421f](https://git.softwaregroup.com/ut5/ut-customer/commit/7f9421f))
* UIS-1022: Refactor AddFIleButton ([01f022e](https://git.softwaregroup.com/ut5/ut-customer/commit/01f022e))
* UIS-1022: Refactor document upload flow; move documentUpload reducer ([5af9465](https://git.softwaregroup.com/ut5/ut-customer/commit/5af9465))
* UIS-1022: Remove mode and id from actions and action creators ([cfc8d01](https://git.softwaregroup.com/ut5/ut-customer/commit/cfc8d01))
* UIS-1022: Remove old DocumentUpload component ([c312574](https://git.softwaregroup.com/ut5/ut-customer/commit/c312574))
* UIS-1022: Style file preview ([7eacda0](https://git.softwaregroup.com/ut5/ut-customer/commit/7eacda0))
* update procedure ([a6433e7](https://git.softwaregroup.com/ut5/ut-customer/commit/a6433e7))



<a name="5.45.2"></a>
## [5.45.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.45.1...v5.45.2) (2017-02-23)



<a name="5.45.1"></a>
## [5.45.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.45.0...v5.45.1) (2017-02-23)



<a name="5.45.0"></a>
# [5.45.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.44.0...v5.45.0) (2017-02-23)


### Bug Fixes

* MCTUNE-2370 Refused by PM LA is considered running ([1b122fc](https://git.softwaregroup.com/ut5/ut-customer/commit/1b122fc))


### Features

* UIS-959 add actorId to the response ([f7c11e0](https://git.softwaregroup.com/ut5/ut-customer/commit/f7c11e0))



<a name="5.44.0"></a>
# [5.44.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.43.2...v5.44.0) (2017-02-22)


### Bug Fixes

* remove select from SP and add policyId in joi validations ([ffd849a](https://git.softwaregroup.com/ut5/ut-customer/commit/ffd849a))


### Features

* UIS-1204: fetch identity tab dropdown data from database ([1e1ee64](https://git.softwaregroup.com/ut5/ut-customer/commit/1e1ee64))
* UIS-1204: get dropdown data to reducers ([ad25dfb](https://git.softwaregroup.com/ut5/ut-customer/commit/ad25dfb))
* UIS-1204: refactor dropdown reducers ([38eaa01](https://git.softwaregroup.com/ut5/ut-customer/commit/38eaa01))
* UIS-1204: remove input validations ([b195eaa](https://git.softwaregroup.com/ut5/ut-customer/commit/b195eaa))
* update procedure ([1e24b75](https://git.softwaregroup.com/ut5/ut-customer/commit/1e24b75))
* update procedure for self registration ([c2f4552](https://git.softwaregroup.com/ut5/ut-customer/commit/c2f4552))



<a name="5.43.2"></a>
## [5.43.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.43.1...v5.43.2) (2017-02-22)


### Bug Fixes

* MCTUNE-2104 - removed unneccessary stuff ([f57c70d](https://git.softwaregroup.com/ut5/ut-customer/commit/f57c70d))



<a name="5.43.1"></a>
## [5.43.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.43.0...v5.43.1) (2017-02-22)



<a name="5.43.0"></a>
# [5.43.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.42.0...v5.43.0) (2017-02-21)


### Bug Fixes

* UIS-1005 public route is now exposed at /selfregister and add parameters about customer device ([6b62b2a](https://git.softwaregroup.com/ut5/ut-customer/commit/6b62b2a))
* UIS-1010 remove country code as required ([b7e2a8c](https://git.softwaregroup.com/ut5/ut-customer/commit/b7e2a8c))


### Features

* add stored procedure ([e59e9cd](https://git.softwaregroup.com/ut5/ut-customer/commit/e59e9cd))
* expose service for selfregister and add joi validations ([5cbfccb](https://git.softwaregroup.com/ut5/ut-customer/commit/5cbfccb))
* UIS-1005 fix tests and add self registration validations ([9b2aef9](https://git.softwaregroup.com/ut5/ut-customer/commit/9b2aef9))
* UIS-1005 set validations in folder ([0e00422](https://git.softwaregroup.com/ut5/ut-customer/commit/0e00422))
* UIS-1204: add validations to create mode ([350c9f6](https://git.softwaregroup.com/ut5/ut-customer/commit/350c9f6))
* UIS-1204: fix input validations ([0badd9a](https://git.softwaregroup.com/ut5/ut-customer/commit/0badd9a))
* UIS-1204: Fix phone and mail inputs to be disabled for edit mode ([9b56be4](https://git.softwaregroup.com/ut5/ut-customer/commit/9b56be4))
* UIS-1204: fix tab validations ([f08a1e3](https://git.softwaregroup.com/ut5/ut-customer/commit/f08a1e3))
* UIS-959 update version of ut-core ([f98f5de](https://git.softwaregroup.com/ut5/ut-customer/commit/f98f5de))
* update procedure ([bda67af](https://git.softwaregroup.com/ut5/ut-customer/commit/bda67af))
* update procedure ([18fefc4](https://git.softwaregroup.com/ut5/ut-customer/commit/18fefc4))
* update procedure ([d80e5b5](https://git.softwaregroup.com/ut5/ut-customer/commit/d80e5b5))
* update procedure ([782bf19](https://git.softwaregroup.com/ut5/ut-customer/commit/782bf19))
* update procedure ([6f685c5](https://git.softwaregroup.com/ut5/ut-customer/commit/6f685c5))
* update procedure ([ca55341](https://git.softwaregroup.com/ut5/ut-customer/commit/ca55341))
* update procedure ([5e0e490](https://git.softwaregroup.com/ut5/ut-customer/commit/5e0e490))
* update procedure ([de956ee](https://git.softwaregroup.com/ut5/ut-customer/commit/de956ee))
* update procedure ([eec2535](https://git.softwaregroup.com/ut5/ut-customer/commit/eec2535))
* update procedure ([be0de4d](https://git.softwaregroup.com/ut5/ut-customer/commit/be0de4d))
* update procedure ([1d6137a](https://git.softwaregroup.com/ut5/ut-customer/commit/1d6137a))
* update procedure ([fdab464](https://git.softwaregroup.com/ut5/ut-customer/commit/fdab464))
* update procedure ([c6b86a9](https://git.softwaregroup.com/ut5/ut-customer/commit/c6b86a9))
* update procedure ([67f10d8](https://git.softwaregroup.com/ut5/ut-customer/commit/67f10d8))
* update procedure ([9d65923](https://git.softwaregroup.com/ut5/ut-customer/commit/9d65923))
* update procedure ([b6018ff](https://git.softwaregroup.com/ut5/ut-customer/commit/b6018ff))
* update procedure ([3378a61](https://git.softwaregroup.com/ut5/ut-customer/commit/3378a61))
* update procedure ([c081fec](https://git.softwaregroup.com/ut5/ut-customer/commit/c081fec))
* update procedure ([a9f6f00](https://git.softwaregroup.com/ut5/ut-customer/commit/a9f6f00))
* update procedure ([c414b35](https://git.softwaregroup.com/ut5/ut-customer/commit/c414b35))
* update procedure ([8abe931](https://git.softwaregroup.com/ut5/ut-customer/commit/8abe931))
* update procedure ([517df50](https://git.softwaregroup.com/ut5/ut-customer/commit/517df50))
* update procedure ([d4caafc](https://git.softwaregroup.com/ut5/ut-customer/commit/d4caafc))



<a name="5.42.0"></a>
# [5.42.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.41.1...v5.42.0) (2017-02-17)


### Features

* add new int column in customerType table ([f5fd3b9](https://git.softwaregroup.com/ut5/ut-customer/commit/f5fd3b9))
* UIS-1204: fix config file ([d55985e](https://git.softwaregroup.com/ut5/ut-customer/commit/d55985e))
* UIS-1204: fix lint ([ab7e8e7](https://git.softwaregroup.com/ut5/ut-customer/commit/ab7e8e7))
* UIS-1204: implement create and edit to identity tab ([28d316f](https://git.softwaregroup.com/ut5/ut-customer/commit/28d316f))
* UIS-1204: set edit and create reducers ([067dcfd](https://git.softwaregroup.com/ut5/ut-customer/commit/067dcfd))



<a name="5.41.1"></a>
## [5.41.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.41.0...v5.41.1) (2017-02-17)


### Bug Fixes

* MCTUNE-2104 - pacakge.json ([cfcac1d](https://git.softwaregroup.com/ut5/ut-customer/commit/cfcac1d))



<a name="5.41.0"></a>
# [5.41.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.40.6...v5.41.0) (2017-02-16)


### Features

* 1022: Extract DocumentUpload container ([f97bd65](https://git.softwaregroup.com/ut5/ut-customer/commit/f97bd65))
* UIS-1022: Add DocumentPreview ([bcd6f17](https://git.softwaregroup.com/ut5/ut-customer/commit/bcd6f17))
* UIS-1022: Add dropdown and description logic ([47de240](https://git.softwaregroup.com/ut5/ut-customer/commit/47de240))
* UIS-1022: Add React webcam ([dd9e9eb](https://git.softwaregroup.com/ut5/ut-customer/commit/dd9e9eb))
* UIS-1022: Fix file upload popup initial view design ([71db44b](https://git.softwaregroup.com/ut5/ut-customer/commit/71db44b))
* UIS-1022: Fix footer proptype ([5490612](https://git.softwaregroup.com/ut5/ut-customer/commit/5490612))
* UIS-1022: Fix lint ([f923a56](https://git.softwaregroup.com/ut5/ut-customer/commit/f923a56))
* UIS-1022: Implement change photo from preview screen ([a9af95b](https://git.softwaregroup.com/ut5/ut-customer/commit/a9af95b))
* UIS-1022: Implement onImageClick and refactor ImagesContainer ([183078c](https://git.softwaregroup.com/ut5/ut-customer/commit/183078c))
* UIS-1022: Implement read file ([b96baca](https://git.softwaregroup.com/ut5/ut-customer/commit/b96baca))
* UIS-1022: Implement retakePhoto ([132c2f1](https://git.softwaregroup.com/ut5/ut-customer/commit/132c2f1))
* UIS-1022: Implement sceen switch ([c524f18](https://git.softwaregroup.com/ut5/ut-customer/commit/c524f18))
* UIS-1022: Move AddFileButton to ut-customer; Remove unnecessary dirs ([efbe453](https://git.softwaregroup.com/ut5/ut-customer/commit/efbe453))
* UIS-1022: Show preview ([3fc6ac1](https://git.softwaregroup.com/ut5/ut-customer/commit/3fc6ac1))
* UIS-1204: Add create and edit reducer default state ([08007cc](https://git.softwaregroup.com/ut5/ut-customer/commit/08007cc))
* UIS-1204: add inputs to identity tab ([c1155ec](https://git.softwaregroup.com/ut5/ut-customer/commit/c1155ec))
* UIS-1204: fix lint ([5342154](https://git.softwaregroup.com/ut5/ut-customer/commit/5342154))



<a name="5.40.6"></a>
## [5.40.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.40.5...v5.40.6) (2017-02-15)


### Bug Fixes

* **account sync:** update accountName ([5858a2a](https://git.softwaregroup.com/ut5/ut-customer/commit/5858a2a))
* MCTUNE-2195 - Adding columns, ID and Loan process ([fd427c2](https://git.softwaregroup.com/ut5/ut-customer/commit/fd427c2))



<a name="5.40.5"></a>
## [5.40.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.40.4...v5.40.5) (2017-02-14)



<a name="5.40.4"></a>
## [5.40.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.40.3...v5.40.4) (2017-02-14)



<a name="5.40.3"></a>
## [5.40.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.40.2...v5.40.3) (2017-02-14)



<a name="5.40.2"></a>
## [5.40.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.40.1...v5.40.2) (2017-02-14)



<a name="5.40.1"></a>
## [5.40.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.40.0...v5.40.1) (2017-02-14)


### Bug Fixes

* add account to customer add method ([ac6b7a6](https://git.softwaregroup.com/ut5/ut-customer/commit/ac6b7a6))
* add phone to customer add ([7aa2730](https://git.softwaregroup.com/ut5/ut-customer/commit/7aa2730))



<a name="5.40.0"></a>
# [5.40.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.39.0...v5.40.0) (2017-02-10)


### Bug Fixes

* MCTUNE-2147 - ([65272de](https://git.softwaregroup.com/ut5/ut-customer/commit/65272de))
* MCTUNE-2148 ([25d4024](https://git.softwaregroup.com/ut5/ut-customer/commit/25d4024))
* MCTUNE-2210 - Customer Search Test ([4df0dc2](https://git.softwaregroup.com/ut5/ut-customer/commit/4df0dc2))
* MCTUNE-2215 Phone fields missing after file update ([e395238](https://git.softwaregroup.com/ut5/ut-customer/commit/e395238))
* Searching for a customer now calls loan.customer.search ([356cd6d](https://git.softwaregroup.com/ut5/ut-customer/commit/356cd6d))
* typo ([fe4a4dc](https://git.softwaregroup.com/ut5/ut-customer/commit/fe4a4dc))
* Validiation document.add reverted ([fc8550c](https://git.softwaregroup.com/ut5/ut-customer/commit/fc8550c))


### Features

* UIS-1020: connect edit customer page ([426dba5](https://git.softwaregroup.com/ut5/ut-customer/commit/426dba5))
* UIS-1022: Add images ([6fc6d99](https://git.softwaregroup.com/ut5/ut-customer/commit/6fc6d99))
* UIS-1022: Add primary buttons ([bb3300b](https://git.softwaregroup.com/ut5/ut-customer/commit/bb3300b))
* UIS-1022: Connect RepacePhotoPopup with Identity tab; implement add photo buttons design ([6c6cf6d](https://git.softwaregroup.com/ut5/ut-customer/commit/6c6cf6d))
* UIS-1022: Fix FileReader ([cac8747](https://git.softwaregroup.com/ut5/ut-customer/commit/cac8747))
* UIS-1022: Move FileUpload component and FilePreview component to ut-front-react ([d288bd6](https://git.softwaregroup.com/ut5/ut-customer/commit/d288bd6))
* UIS-1022: Setup Identity tab structure ([373f956](https://git.softwaregroup.com/ut5/ut-customer/commit/373f956))



<a name="5.39.0"></a>
# [5.39.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.38.6...v5.39.0) (2017-02-09)


### Bug Fixes

* Removed loan dependency from customer.customer.search ([0f2514b](https://git.softwaregroup.com/ut5/ut-customer/commit/0f2514b))


### Features

* UIS-1019: add edit page to customers ([b84e99a](https://git.softwaregroup.com/ut5/ut-customer/commit/b84e99a))
* UIS-1019: add Home screen in pages ([c8a76a7](https://git.softwaregroup.com/ut5/ut-customer/commit/c8a76a7))
* UIS-1019: add material ui to package.json ([73187bc](https://git.softwaregroup.com/ut5/ut-customer/commit/73187bc))
* UIS-1019: add reducers.js and actions.js to customers grid ([d0ed50d](https://git.softwaregroup.com/ut5/ut-customer/commit/d0ed50d))
* UIS-1019: add StatusDialog component ([96747cb](https://git.softwaregroup.com/ut5/ut-customer/commit/96747cb))
* UIS-1019: add tabContainer component to customer ([8649c74](https://git.softwaregroup.com/ut5/ut-customer/commit/8649c74))
* UIS-1019: fix edit and create for customer grid ([3d727f8](https://git.softwaregroup.com/ut5/ut-customer/commit/3d727f8))
* UIS-1019: fix lint ([9b3a7bd](https://git.softwaregroup.com/ut5/ut-customer/commit/9b3a7bd))
* UIS-1181: add customer tabs ([d37ffd6](https://git.softwaregroup.com/ut5/ut-customer/commit/d37ffd6))
* UIS-1181: add tabs to edit page ([d09b8db](https://git.softwaregroup.com/ut5/ut-customer/commit/d09b8db))
* UIS-1181: delete config.js ([1cf4066](https://git.softwaregroup.com/ut5/ut-customer/commit/1cf4066))
* UIS-1181: Setup Identity tab ([c2d6e78](https://git.softwaregroup.com/ut5/ut-customer/commit/c2d6e78))



<a name="5.38.6"></a>
## [5.38.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.38.5...v5.38.6) (2017-02-08)


### Bug Fixes

* MCTUNE-2104 - test ([9c2f194](https://git.softwaregroup.com/ut5/ut-customer/commit/9c2f194))



<a name="5.38.5"></a>
## [5.38.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.38.4...v5.38.5) (2017-02-07)


### Bug Fixes

* MCTUNE-2104 - package.json ([1557f31](https://git.softwaregroup.com/ut5/ut-customer/commit/1557f31))



<a name="5.38.4"></a>
## [5.38.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.38.3...v5.38.4) (2017-02-07)


### Bug Fixes

* MCTUNE-2104 - fix tests ([b775c0e](https://git.softwaregroup.com/ut5/ut-customer/commit/b775c0e))



<a name="5.38.3"></a>
## [5.38.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.38.2...v5.38.3) (2017-02-06)



<a name="5.38.2"></a>
## [5.38.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.38.1...v5.38.2) (2017-02-06)


### Bug Fixes

* MCTUNE-2104 - reverted customer.customer.add ([b742a40](https://git.softwaregroup.com/ut5/ut-customer/commit/b742a40))
* MCTUNE-2104 - validation fix ([ce0b963](https://git.softwaregroup.com/ut5/ut-customer/commit/ce0b963))



<a name="5.38.1"></a>
## [5.38.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.38.0...v5.38.1) (2017-02-06)


### Bug Fixes

* **MCTUNE-1842:** The user should not view a widget with enrolled fingerprint templates of any customer when the user session expired ([3d3bc42](https://git.softwaregroup.com/ut5/ut-customer/commit/3d3bc42))
* **MCTUNE-2202:** When enroll a client, the status isLocked in the DB is not updated when the user blocked client file ([17dd7a9](https://git.softwaregroup.com/ut5/ut-customer/commit/17dd7a9))



<a name="5.38.0"></a>
# [5.38.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.37.0...v5.38.0) (2017-02-05)


### Features

* dependencies ([ea898ad](https://git.softwaregroup.com/ut5/ut-customer/commit/ea898ad))



<a name="5.37.0"></a>
# [5.37.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.36.2...v5.37.0) (2017-02-03)


### Features

* update fetch procedure ([760c69d](https://git.softwaregroup.com/ut5/ut-customer/commit/760c69d))



<a name="5.36.2"></a>
## [5.36.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.36.1...v5.36.2) (2017-02-02)


### Bug Fixes

* **@@TTRANCOUNT check:** in catch block ([10b4016](https://git.softwaregroup.com/ut5/ut-customer/commit/10b4016))



<a name="5.36.1"></a>
## [5.36.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.36.0...v5.36.1) (2017-02-02)



<a name="5.36.0"></a>
# [5.36.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.35.1...v5.36.0) (2017-02-02)


### Bug Fixes

* MCTUNE-2104 ([e43f2a5](https://git.softwaregroup.com/ut5/ut-customer/commit/e43f2a5))


### Features

* update fetch procedure ([3aa599f](https://git.softwaregroup.com/ut5/ut-customer/commit/3aa599f))
* update fetch procedure ([b00975b](https://git.softwaregroup.com/ut5/ut-customer/commit/b00975b))



<a name="5.35.1"></a>
## [5.35.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.35.0...v5.35.1) (2017-02-02)


### Bug Fixes

* MCTUNE-2104 - validation ([45962b3](https://git.softwaregroup.com/ut5/ut-customer/commit/45962b3))



<a name="5.35.0"></a>
# [5.35.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.34.1...v5.35.0) (2017-02-01)


### Features

*  update alter table ([b80233e](https://git.softwaregroup.com/ut5/ut-customer/commit/b80233e))
*  update alter table ([c01ca7e](https://git.softwaregroup.com/ut5/ut-customer/commit/c01ca7e))
*  update alter table ([5738d46](https://git.softwaregroup.com/ut5/ut-customer/commit/5738d46))



<a name="5.34.1"></a>
## [5.34.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.34.0...v5.34.1) (2017-02-01)


### Bug Fixes

* MCTUNE-2104 - removed key ([19bd04e](https://git.softwaregroup.com/ut5/ut-customer/commit/19bd04e))



<a name="5.34.0"></a>
# [5.34.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.33.2...v5.34.0) (2017-02-01)


### Bug Fixes

* **MCTUNE-1952:** When the user delete enrolled fingers of customer from UT4 ([7f60577](https://git.softwaregroup.com/ut5/ut-customer/commit/7f60577))


### Features

* add unique index ukCustomerNumberCountry in table [customer].[customer] ([3f854ea](https://git.softwaregroup.com/ut5/ut-customer/commit/3f854ea))



<a name="5.33.2"></a>
## [5.33.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.33.1...v5.33.2) (2017-02-01)



<a name="5.33.1"></a>
## [5.33.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.33.0...v5.33.1) (2017-02-01)


### Bug Fixes

* MCTUNE-2191 ([30505be](https://git.softwaregroup.com/ut5/ut-customer/commit/30505be))



<a name="5.33.0"></a>
# [5.33.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.32.9...v5.33.0) (2017-02-01)


### Bug Fixes

* return original procedure ([e95a46a](https://git.softwaregroup.com/ut5/ut-customer/commit/e95a46a))
* **MCTUNE-2182:** Make service which lock and unlcok client file ([e9b9d97](https://git.softwaregroup.com/ut5/ut-customer/commit/e9b9d97))


### Features

* add customers grid ([5a780d7](https://git.softwaregroup.com/ut5/ut-customer/commit/5a780d7))
* add parameter in procedure customer.customer.fetch for documentTypeId ([f69ec1e](https://git.softwaregroup.com/ut5/ut-customer/commit/f69ec1e))
* delete procedure ([79db2bd](https://git.softwaregroup.com/ut5/ut-customer/commit/79db2bd))
* rename file ([65f6120](https://git.softwaregroup.com/ut5/ut-customer/commit/65f6120))
* rename file ([d83af1d](https://git.softwaregroup.com/ut5/ut-customer/commit/d83af1d))
* rename procedure ([21a1aa3](https://git.softwaregroup.com/ut5/ut-customer/commit/21a1aa3))
* UIS-693 add new routes file for ut-customer ([98e6f63](https://git.softwaregroup.com/ut5/ut-customer/commit/98e6f63))
* UIS-693: add AdvancedPagination component ([bf2f508](https://git.softwaregroup.com/ut5/ut-customer/commit/bf2f508))
* UIS-693: add ByStatus filter to customers grid ([83ada5b](https://git.softwaregroup.com/ut5/ut-customer/commit/83ada5b))
* UIS-693: add Clear directory in Filters ([c70d25b](https://git.softwaregroup.com/ut5/ut-customer/commit/c70d25b))
* UIS-693: add clear filter component ([2efdf6b](https://git.softwaregroup.com/ut5/ut-customer/commit/2efdf6b))
* UIS-693: add clear filters to customers grid ([a81c298](https://git.softwaregroup.com/ut5/ut-customer/commit/a81c298))
* UIS-693: add filter By Type to customers grid ([280d1a0](https://git.softwaregroup.com/ut5/ut-customer/commit/280d1a0))
* UIS-693: add pagination to customers grid ([94bfdbc](https://git.softwaregroup.com/ut5/ut-customer/commit/94bfdbc))
* UIS-693: add search filter to customers grid ([4ff8319](https://git.softwaregroup.com/ut5/ut-customer/commit/4ff8319))
* UIS-693: add sorting to customers grid ([6367c3c](https://git.softwaregroup.com/ut5/ut-customer/commit/6367c3c))
* UIS-693: add Toggle Column Visibility to customers grid ([c9edcd9](https://git.softwaregroup.com/ut5/ut-customer/commit/c9edcd9))
* UIS-693: add values to filter ([4d92899](https://git.softwaregroup.com/ut5/ut-customer/commit/4d92899))
* UIS-693: display pagination in customers grid ([849399f](https://git.softwaregroup.com/ut5/ut-customer/commit/849399f))
* UIS-693: fix clearFilter ([63a2f21](https://git.softwaregroup.com/ut5/ut-customer/commit/63a2f21))
* UIS-693: fix customer.fetch joi validation ([adc52ec](https://git.softwaregroup.com/ut5/ut-customer/commit/adc52ec))
* UIS-693: fix joi ([1a29450](https://git.softwaregroup.com/ut5/ut-customer/commit/1a29450))
* UIS-693: fix joi validations ([417282d](https://git.softwaregroup.com/ut5/ut-customer/commit/417282d))
* UIS-693: fix lint ([5ccfaa2](https://git.softwaregroup.com/ut5/ut-customer/commit/5ccfaa2))
* UIS-693: fix pagination params in joi validation ([dded265](https://git.softwaregroup.com/ut5/ut-customer/commit/dded265))
* UIS-693: fix sql ([6202a20](https://git.softwaregroup.com/ut5/ut-customer/commit/6202a20))
* UIS-693: update ut-tools in package.json ([89b9c26](https://git.softwaregroup.com/ut5/ut-customer/commit/89b9c26))
* update procedure ([cdb3735](https://git.softwaregroup.com/ut5/ut-customer/commit/cdb3735))
* update procedure ([22e1255](https://git.softwaregroup.com/ut5/ut-customer/commit/22e1255))
* update procedure ([1b79e14](https://git.softwaregroup.com/ut5/ut-customer/commit/1b79e14))
* update procedure ([06ea97b](https://git.softwaregroup.com/ut5/ut-customer/commit/06ea97b))
* update procedure ([483d479](https://git.softwaregroup.com/ut5/ut-customer/commit/483d479))
* update procedure ([0ce4ca9](https://git.softwaregroup.com/ut5/ut-customer/commit/0ce4ca9))
* update procedure ([f3d27d1](https://git.softwaregroup.com/ut5/ut-customer/commit/f3d27d1))
* update procedure ([73648db](https://git.softwaregroup.com/ut5/ut-customer/commit/73648db))
* update procedure ([885ffab](https://git.softwaregroup.com/ut5/ut-customer/commit/885ffab))
* update procedure ([a44afad](https://git.softwaregroup.com/ut5/ut-customer/commit/a44afad))
* update procedure ([010fd2d](https://git.softwaregroup.com/ut5/ut-customer/commit/010fd2d))
* update procedure ([f9a1ad9](https://git.softwaregroup.com/ut5/ut-customer/commit/f9a1ad9))
* update procedure customer.customer.fetch ([2edc5a1](https://git.softwaregroup.com/ut5/ut-customer/commit/2edc5a1))
* update procedure customer.customer.fetch and create TT table ([b6e034e](https://git.softwaregroup.com/ut5/ut-customer/commit/b6e034e))
* update procedure customer.customer.fetch and create TT table ([781673f](https://git.softwaregroup.com/ut5/ut-customer/commit/781673f))
* update procedure customerstatus and customer.type fetch ([e431588](https://git.softwaregroup.com/ut5/ut-customer/commit/e431588))



<a name="5.32.9"></a>
## [5.32.9](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.32.8...v5.32.9) (2017-01-31)


### Bug Fixes

* MCTUNE-2104 - permssion ([22f4b3f](https://git.softwaregroup.com/ut5/ut-customer/commit/22f4b3f))



<a name="5.32.8"></a>
## [5.32.8](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.32.7...v5.32.8) (2017-01-31)


### Bug Fixes

* MCTUNE-2104 - added view AccountType ([b85d4b5](https://git.softwaregroup.com/ut5/ut-customer/commit/b85d4b5))



<a name="5.32.7"></a>
## [5.32.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.32.6...v5.32.7) (2017-01-30)



<a name="5.32.6"></a>
## [5.32.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.32.5...v5.32.6) (2017-01-30)


### Bug Fixes

* MCTUNE-2104 - package.json ([802692a](https://git.softwaregroup.com/ut5/ut-customer/commit/802692a))



<a name="5.32.5"></a>
## [5.32.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.32.4...v5.32.5) (2017-01-30)


### Bug Fixes

* **MCTUNE-1844:** Restriction for password are not working ([2e719ca](https://git.softwaregroup.com/ut5/ut-customer/commit/2e719ca))
* MCTUNE-2104 Removed a warning ([e0259b2](https://git.softwaregroup.com/ut5/ut-customer/commit/e0259b2))



<a name="5.32.4"></a>
## [5.32.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.32.3...v5.32.4) (2017-01-30)


### Bug Fixes

* MCTUNE-2169 ([9034a8f](https://git.softwaregroup.com/ut5/ut-customer/commit/9034a8f))
* MCTUNE-2173 ([d80ac29](https://git.softwaregroup.com/ut5/ut-customer/commit/d80ac29))
* MCTUNE-2175 ([459fdfc](https://git.softwaregroup.com/ut5/ut-customer/commit/459fdfc))



<a name="5.32.3"></a>
## [5.32.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.32.2...v5.32.3) (2017-01-27)


### Bug Fixes

* ut-tools version ([9dfaba1](https://git.softwaregroup.com/ut5/ut-customer/commit/9dfaba1))



<a name="5.32.2"></a>
## [5.32.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.32.1...v5.32.2) (2017-01-27)


### Bug Fixes

* package.json ([a9b6474](https://git.softwaregroup.com/ut5/ut-customer/commit/a9b6474))
* UIS-748 tests add role isEnables=0 ([2ef86ad](https://git.softwaregroup.com/ut5/ut-customer/commit/2ef86ad))
* **MCTUNE-2094:**  When the user enter amount less ot greater than the allowed amount a message appears but the min/max amount are not correct ([848ae75](https://git.softwaregroup.com/ut5/ut-customer/commit/848ae75))



<a name="5.32.1"></a>
## [5.32.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.32.0...v5.32.1) (2017-01-26)


### Bug Fixes

* MCTUNE-2104: Input component minor fixes ([f63da96](https://git.softwaregroup.com/ut5/ut-customer/commit/f63da96))
* **MCTUNE-1844:** Restriction for password are not working when change password from TuneIn ([b02d92e](https://git.softwaregroup.com/ut5/ut-customer/commit/b02d92e))



<a name="5.32.0"></a>
# [5.32.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.17...v5.32.0) (2017-01-25)


### Bug Fixes

* **MCTUNE-1699:** EnrolBio - Capture client bio information ([1f65d25](https://git.softwaregroup.com/ut5/ut-customer/commit/1f65d25))
* MCTUNE-2104 ([15b406c](https://git.softwaregroup.com/ut5/ut-customer/commit/15b406c))
* MCTUNE-2104 - countryId ([deaac5e](https://git.softwaregroup.com/ut5/ut-customer/commit/deaac5e))
* MCTUNE-2104 - translation ([e0336a2](https://git.softwaregroup.com/ut5/ut-customer/commit/e0336a2))


### Features

* MCTUNE-2118 ([214effa](https://git.softwaregroup.com/ut5/ut-customer/commit/214effa))



<a name="5.31.17"></a>
## [5.31.17](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.16...v5.31.17) (2017-01-24)


### Bug Fixes

* MCTUNE-2104 - fix bio ([e15ab02](https://git.softwaregroup.com/ut5/ut-customer/commit/e15ab02))
* MCTUNE-2104 - package.json ([7608936](https://git.softwaregroup.com/ut5/ut-customer/commit/7608936))



<a name="5.31.16"></a>
## [5.31.16](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.15...v5.31.16) (2017-01-24)


### Bug Fixes

* MCTUNE-2104 - hidden check bio func ([0d8346e](https://git.softwaregroup.com/ut5/ut-customer/commit/0d8346e))



<a name="5.31.15"></a>
## [5.31.15](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.14...v5.31.15) (2017-01-24)


### Bug Fixes

* **MCTUNE-1952:** When the user delete enrolled fingers of customer from UT4, they are not deleted in UT5 ([6d3a31e](https://git.softwaregroup.com/ut5/ut-customer/commit/6d3a31e))
* MCTUNE-2104 - DataList back from time ([aa6f102](https://git.softwaregroup.com/ut5/ut-customer/commit/aa6f102))
* UIS-311 linting ([970cbb3](https://git.softwaregroup.com/ut5/ut-customer/commit/970cbb3))
* UIS-311 package.json ut-tools version ([5dc373e](https://git.softwaregroup.com/ut5/ut-customer/commit/5dc373e))
* UIS-311 tests ([858bb78](https://git.softwaregroup.com/ut5/ut-customer/commit/858bb78))
* UIS-311 tests and SPs ([24a9062](https://git.softwaregroup.com/ut5/ut-customer/commit/24a9062))



<a name="5.31.14"></a>
## [5.31.14](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.13...v5.31.14) (2017-01-23)


### Bug Fixes

* MCTUNE-2104 - package.json ([655ce9e](https://git.softwaregroup.com/ut5/ut-customer/commit/655ce9e))



<a name="5.31.13"></a>
## [5.31.13](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.12...v5.31.13) (2017-01-19)


### Bug Fixes

* MCTUNE-2101 - LoanApplicationWidget's Modal now scrolls vertically ([9578530](https://git.softwaregroup.com/ut5/ut-customer/commit/9578530))
* **MCTUNE-2102:** History of app in Client file: after page reload there is missing App.type ([9bce811](https://git.softwaregroup.com/ut5/ut-customer/commit/9bce811))
* MCTUNE-2104 - remove icons from here and move them to impl ([48dbc06](https://git.softwaregroup.com/ut5/ut-customer/commit/48dbc06))
* MCTUNE-2114 - Errors persisting through change ([34def0d](https://git.softwaregroup.com/ut5/ut-customer/commit/34def0d))



<a name="5.31.12"></a>
## [5.31.12](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.11...v5.31.12) (2017-01-18)


### Bug Fixes

* MCTUNE-2104 - merging ([e89be1c](https://git.softwaregroup.com/ut5/ut-customer/commit/e89be1c))



<a name="5.31.11"></a>
## [5.31.11](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.10...v5.31.11) (2017-01-18)


### Bug Fixes

* MCTUNE-2104 - var instead of let ([e627a4d](https://git.softwaregroup.com/ut5/ut-customer/commit/e627a4d))



<a name="5.31.10"></a>
## [5.31.10](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.9...v5.31.10) (2017-01-18)


### Bug Fixes

* **MCTUNE-1606:** Enroll customer: when the fingers already exist for any client, should be displayed the customer number of the matched customer ([ac7f978](https://git.softwaregroup.com/ut5/ut-customer/commit/ac7f978))
* **MCTUNE-1606:** fix lint errors ([e829e60](https://git.softwaregroup.com/ut5/ut-customer/commit/e829e60))
* MCTUNE-2104 - merging ([e0a92a5](https://git.softwaregroup.com/ut5/ut-customer/commit/e0a92a5))
* **MCTUNE-1844:** Restriction for password are not working when change password from TuneIn ([ea7ccb7](https://git.softwaregroup.com/ut5/ut-customer/commit/ea7ccb7))
* **MCTUNE-2062:** If the customer has kycId level = 0, the kyc length should not be removed ([5d4e6b9](https://git.softwaregroup.com/ut5/ut-customer/commit/5d4e6b9))



<a name="5.31.9"></a>
## [5.31.9](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.8...v5.31.9) (2017-01-17)


### Bug Fixes

* **clean up alter scripts:** remove ([b3b4aea](https://git.softwaregroup.com/ut5/ut-customer/commit/b3b4aea))
* **MCTUNE-2062:** If the customer has kycId level = 0, the kyc length should not be removed ([3d92d3f](https://git.softwaregroup.com/ut5/ut-customer/commit/3d92d3f))



<a name="5.31.8"></a>
## [5.31.8](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.7...v5.31.8) (2017-01-13)



<a name="5.31.7"></a>
## [5.31.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.6...v5.31.7) (2017-01-11)



<a name="5.31.6"></a>
## [5.31.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.5...v5.31.6) (2017-01-10)



<a name="5.31.5"></a>
## [5.31.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.4...v5.31.5) (2017-01-09)



<a name="5.31.4"></a>
## [5.31.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.3...v5.31.4) (2017-01-06)


### Bug Fixes

* **MCTUNE-1941:** When the user search for a customer, the search results and files to validate appears incorrectly ([3874dd0](https://git.softwaregroup.com/ut5/ut-customer/commit/3874dd0))



<a name="5.31.3"></a>
## [5.31.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.2...v5.31.3) (2017-01-06)



<a name="5.31.2"></a>
## [5.31.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.1...v5.31.2) (2017-01-06)



<a name="5.31.1"></a>
## [5.31.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.31.0...v5.31.1) (2017-01-05)


### Bug Fixes

* lint ([f899dd1](https://git.softwaregroup.com/ut5/ut-customer/commit/f899dd1))
* tests ([b8d01f0](https://git.softwaregroup.com/ut5/ut-customer/commit/b8d01f0))



<a name="5.31.0"></a>
# [5.31.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.30.5...v5.31.0) (2017-01-05)


### Bug Fixes

* **MCTUNE-1958:** Uploaded prospect client missig after sync ([7069eeb](https://git.softwaregroup.com/ut5/ut-customer/commit/7069eeb))


### Features

* UIS-614 add isPrimary for email ([d6fdc31](https://git.softwaregroup.com/ut5/ut-customer/commit/d6fdc31))



<a name="5.30.5"></a>
## [5.30.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.30.4...v5.30.5) (2016-12-29)


### Bug Fixes

* **MCTUNE-1935:** When the user enters '%' character in the search line in console an error ([b21ea1f](https://git.softwaregroup.com/ut5/ut-customer/commit/b21ea1f))
* **MCTUNE-1939:** error appears when back office see customer file ([c10dc98](https://git.softwaregroup.com/ut5/ut-customer/commit/c10dc98))



<a name="5.30.4"></a>
## [5.30.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.30.3...v5.30.4) (2016-12-23)



<a name="5.30.3"></a>
## [5.30.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.30.2...v5.30.3) (2016-12-23)


### Bug Fixes

* UIS-487 ([869be4b](https://git.softwaregroup.com/ut5/ut-customer/commit/869be4b))
* versions bump ([0928f5c](https://git.softwaregroup.com/ut5/ut-customer/commit/0928f5c))



<a name="5.30.2"></a>
## [5.30.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.30.1...v5.30.2) (2016-12-23)



<a name="5.30.1"></a>
## [5.30.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.40...v5.30.1) (2016-12-21)


### Bug Fixes

* **mctune-1889:** When the user enters some characters in the search line, an error 404 appears ([8867650](https://git.softwaregroup.com/ut5/ut-customer/commit/8867650))



<a name="5.29.40"></a>
## [5.29.40](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.39...v5.29.40) (2016-12-20)


### Bug Fixes

* deps versions bump ([9f3e327](https://git.softwaregroup.com/ut5/ut-customer/commit/9f3e327))
* **customer sync:** update their applications organizationId ([0f3fb9d](https://git.softwaregroup.com/ut5/ut-customer/commit/0f3fb9d))
* **MCTUNE-1270: PM Phone validate permissions:** Added check for the new permissions customer.phone.webValidate ([52e3a90](https://git.softwaregroup.com/ut5/ut-customer/commit/52e3a90))
* **MCTUNE-1485:** fix the menu in search result ([1108ee7](https://git.softwaregroup.com/ut5/ut-customer/commit/1108ee7))
* **MCTUNE-1704:** Crop function non available when i upload a document on tune IN V1 ([7da3e9a](https://git.softwaregroup.com/ut5/ut-customer/commit/7da3e9a))



<a name="5.29.25"></a>
## [5.29.25](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.24...v5.29.25) (2016-12-05)


### Bug Fixes

* **customer sync:** industry and sector ([1f0db1c](https://git.softwaregroup.com/ut5/ut-customer/commit/1f0db1c))
* **modifications:** sector and industry ([1ae0d74](https://git.softwaregroup.com/ut5/ut-customer/commit/1ae0d74))
* **sector and industry:** create views ([7751fb1](https://git.softwaregroup.com/ut5/ut-customer/commit/7751fb1))



<a name="5.29.39"></a>
## [5.29.39](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.38...v5.29.39) (2016-12-19)


### Bug Fixes

* **mctune-1878:** Consult previous ELF from client file ([2537214](https://git.softwaregroup.com/ut5/ut-customer/commit/2537214))



<a name="5.29.38"></a>
## [5.29.38](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.37...v5.29.38) (2016-12-15)



<a name="5.29.37"></a>
## [5.29.37](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.36...v5.29.37) (2016-12-12)



<a name="5.29.36"></a>
## [5.29.36](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.35...v5.29.36) (2016-12-12)



<a name="5.29.35"></a>
## [5.29.35](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.34...v5.29.35) (2016-12-08)



### Bug Fixes

* **MCTUNE-1704:** Crop function non available when i upload a document on tune IN V1 ([644e45d](https://git.softwaregroup.com/ut5/ut-customer/commit/644e45d))



<a name="5.29.34"></a>
## [5.29.34](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.33...v5.29.34) (2016-12-08)



<a name="5.29.33"></a>
## [5.29.33](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.32...v5.29.33) (2016-12-08)



### Bug Fixes

* **MCTUNE-1485:** fix the menu in search result ([e9aded3](https://git.softwaregroup.com/ut5/ut-customer/commit/e9aded3))



<a name="5.29.32"></a>
## [5.29.32](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.31...v5.29.32) (2016-12-07)



<a name="5.29.31"></a>
## [5.29.31](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.30...v5.29.31) (2016-12-07)


### Bug Fixes

* **mctune-1689:** When validate phone from web, there is request to T24. ([fb1116a](https://git.softwaregroup.com/ut5/ut-customer/commit/fb1116a))



<a name="5.29.30"></a>
## [5.29.30](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.29...v5.29.30) (2016-12-07)



<a name="5.29.29"></a>
## [5.29.29](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.28...v5.29.29) (2016-12-06)



<a name="5.29.28"></a>
## [5.29.28](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.27...v5.29.28) (2016-12-06)



<a name="5.29.27"></a>
## [5.29.27](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.26...v5.29.27) (2016-12-06)



<a name="5.29.26"></a>
## [5.29.26](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.24...v5.29.26) (2016-12-06)

<a name="5.29.24"></a>
## [5.29.24](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.23...v5.29.24) (2016-12-01)


### Bug Fixes

* **account sync:** fix actorId ([65ec4b9](https://git.softwaregroup.com/ut5/ut-customer/commit/65ec4b9))



<a name="5.29.23"></a>
## [5.29.23](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.22...v5.29.23) (2016-12-01)


### Bug Fixes

* **sync:** accounts and customer typo ([d0db430](https://git.softwaregroup.com/ut5/ut-customer/commit/d0db430))



<a name="5.29.22"></a>
## [5.29.22](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.21...v5.29.22) (2016-12-01)


### Bug Fixes

* **customer:** sync ([7bf5646](https://git.softwaregroup.com/ut5/ut-customer/commit/7bf5646))



<a name="5.29.21"></a>
## [5.29.21](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.20...v5.29.21) (2016-12-01)



<a name="5.29.20"></a>
## [5.29.20](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.19...v5.29.20) (2016-11-30)


### Bug Fixes

* **account:** sync ([4358c2d](https://git.softwaregroup.com/ut5/ut-customer/commit/4358c2d))
* **account:** sync ([61c009c](https://git.softwaregroup.com/ut5/ut-customer/commit/61c009c))
* MCTUNE-1563 delete roles relations of deleted BUs ([7138511](https://git.softwaregroup.com/ut5/ut-customer/commit/7138511))



<a name="5.29.19"></a>
## [5.29.19](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.18...v5.29.19) (2016-11-29)



<a name="5.29.18"></a>
## [5.29.18](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.17...v5.29.18) (2016-11-29)


### Bug Fixes

* **industry and sector:** add to itemName ([c8e90b2](https://git.softwaregroup.com/ut5/ut-customer/commit/c8e90b2))
* **MCTUNE-1545:** Bad request when the user send empty request for otp code ([68762e3](https://git.softwaregroup.com/ut5/ut-customer/commit/68762e3))
* **synchronization:** account ([40fcb1b](https://git.softwaregroup.com/ut5/ut-customer/commit/40fcb1b))



<a name="5.29.17"></a>
## [5.29.17](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.16...v5.29.17) (2016-11-28)



<a name="5.29.16"></a>
## [5.29.16](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.15...v5.29.16) (2016-11-28)



<a name="5.29.15"></a>
## [5.29.15](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.14...v5.29.15) (2016-11-28)



<a name="5.29.14"></a>
## [5.29.14](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.13...v5.29.14) (2016-11-26)


### Bug Fixes

* change params to payload ([07eb0d3](https://git.softwaregroup.com/ut5/ut-customer/commit/07eb0d3))



<a name="5.29.13"></a>
## [5.29.13](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.12...v5.29.13) (2016-11-25)


### Bug Fixes

* **MCTUNE-1321:** Change nomenclatures filtration on all front-ends ([81cfa63](https://git.softwaregroup.com/ut5/ut-customer/commit/81cfa63))



<a name="5.29.12"></a>
## [5.29.12](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.11...v5.29.12) (2016-11-25)


### Bug Fixes

* boolean ([38f17ad](https://git.softwaregroup.com/ut5/ut-customer/commit/38f17ad))



<a name="5.29.11"></a>
## [5.29.11](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.10...v5.29.11) (2016-11-25)



<a name="5.29.10"></a>
## [5.29.10](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.9...v5.29.10) (2016-11-24)


### Bug Fixes

* move static resources to core ([57421b9](https://git.softwaregroup.com/ut5/ut-customer/commit/57421b9))
* translation fetch ([ed00547](https://git.softwaregroup.com/ut5/ut-customer/commit/ed00547))
* versions bump ([435a99d](https://git.softwaregroup.com/ut5/ut-customer/commit/435a99d))



<a name="5.29.9"></a>
## [5.29.9](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.8...v5.29.9) (2016-11-23)


### Bug Fixes

* UIS-351: add joi validation required for proper data fetching ([1083a73](https://git.softwaregroup.com/ut5/ut-customer/commit/1083a73))



<a name="5.29.8"></a>
## [5.29.8](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.7...v5.29.8) (2016-11-23)



<a name="5.29.7"></a>
## [5.29.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.6...v5.29.7) (2016-11-23)



<a name="5.29.6"></a>
## [5.29.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.5...v5.29.6) (2016-11-22)


### Bug Fixes

* **accounts and country:** changes ([bff7858](https://git.softwaregroup.com/ut5/ut-customer/commit/bff7858))
* **add scripts:** alter scripts ([131765a](https://git.softwaregroup.com/ut5/ut-customer/commit/131765a))
* **country id:** add ([cb8939e](https://git.softwaregroup.com/ut5/ut-customer/commit/cb8939e))
* **COUNTRY_ID:** Nomenclatures ([8aa108e](https://git.softwaregroup.com/ut5/ut-customer/commit/8aa108e))
* **remove systemDate:** country ([6e6a565](https://git.softwaregroup.com/ut5/ut-customer/commit/6e6a565))



<a name="5.29.5"></a>
## [5.29.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.4...v5.29.5) (2016-11-22)



<a name="5.29.4"></a>
## [5.29.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.3...v5.29.4) (2016-11-21)


### Bug Fixes

* test.customer.addOrganization ([c581397](https://git.softwaregroup.com/ut5/ut-customer/commit/c581397))
* **validations:** lockUnlockOrganization ([e1d6f7c](https://git.softwaregroup.com/ut5/ut-customer/commit/e1d6f7c))



<a name="5.29.3"></a>
## [5.29.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.2...v5.29.3) (2016-11-21)



<a name="5.29.2"></a>
## [5.29.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.1...v5.29.2) (2016-11-18)


### Bug Fixes

* **customer sync:** update DAO if changed ([bc3065e](https://git.softwaregroup.com/ut5/ut-customer/commit/bc3065e))
* MCTUNE-1078 ([28ce5ac](https://git.softwaregroup.com/ut5/ut-customer/commit/28ce5ac))
* MCTUNE-1312 ([b67f10d](https://git.softwaregroup.com/ut5/ut-customer/commit/b67f10d))
* validations ([3f3b84b](https://git.softwaregroup.com/ut5/ut-customer/commit/3f3b84b))
* **MCTUNE-1203:** Create LA: zero is displayed when there is no PMs to which to assign the LA ([aa7b48e](https://git.softwaregroup.com/ut5/ut-customer/commit/aa7b48e))
* **MCTUNE-1385:** When user is from Microcred and Senegal, cannot create Loan application ([f04e847](https://git.softwaregroup.com/ut5/ut-customer/commit/f04e847))



<a name="5.29.1"></a>
## [5.29.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.29.0...v5.29.1) (2016-11-14)


### Bug Fixes

* **MCTUNE-1340:** HTTP error when try to change expiry date in client file ([fdb6094](https://git.softwaregroup.com/ut5/ut-customer/commit/fdb6094))
* busines units fix ([a436791](https://git.softwaregroup.com/ut5/ut-customer/commit/a436791))



<a name="5.29.0"></a>
# [5.29.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.28.0...v5.29.0) (2016-11-14)


### Bug Fixes

* AS resultSetName ([b085443](https://git.softwaregroup.com/ut5/ut-customer/commit/b085443))


### Features

* add result set name ([c84e0ad](https://git.softwaregroup.com/ut5/ut-customer/commit/c84e0ad))



<a name="5.28.0"></a>
# [5.28.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.27.3...v5.28.0) (2016-11-11)


### Bug Fixes

* MCTUNE-1332 ([54bd3e7](https://git.softwaregroup.com/ut5/ut-customer/commit/54bd3e7))


### Features

* new sp that list all organization ([998fd20](https://git.softwaregroup.com/ut5/ut-customer/commit/998fd20))



<a name="5.27.3"></a>
## [5.27.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.27.2...v5.27.3) (2016-11-10)



<a name="5.27.2"></a>
## [5.27.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.27.1...v5.27.2) (2016-11-09)



<a name="5.27.1"></a>
## [5.27.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.27.0...v5.27.1) (2016-11-09)



<a name="5.27.0"></a>
# [5.27.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.12...v5.27.0) (2016-11-08)


### Features

* new flag ([c42a621](https://git.softwaregroup.com/ut5/ut-customer/commit/c42a621))
* new function ([e3cfee0](https://git.softwaregroup.com/ut5/ut-customer/commit/e3cfee0))
* new function ([8289371](https://git.softwaregroup.com/ut5/ut-customer/commit/8289371))
* UIS-187 ([1a9ce4f](https://git.softwaregroup.com/ut5/ut-customer/commit/1a9ce4f))
* working with organization as actor ([dd70869](https://git.softwaregroup.com/ut5/ut-customer/commit/dd70869))



<a name="5.26.12"></a>
## [5.26.12](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.11...v5.26.12) (2016-11-08)



<a name="5.26.11"></a>
## [5.26.11](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.10...v5.26.11) (2016-11-08)



<a name="5.26.10"></a>
## [5.26.10](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.9...v5.26.10) (2016-11-07)


### Bug Fixes

* joiValidations and tests ([56f9e59](https://git.softwaregroup.com/ut5/ut-customer/commit/56f9e59))
* **synchronization:** empty address ([8a8ea00](https://git.softwaregroup.com/ut5/ut-customer/commit/8a8ea00))



<a name="5.26.9"></a>
## [5.26.9](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.8...v5.26.9) (2016-11-03)


### Bug Fixes

* **gps coordinates:** convert to varchar because of the rounding ([d7e0f7c](https://git.softwaregroup.com/ut5/ut-customer/commit/d7e0f7c))
* **MCTUNE-992:** Reworked dynamic dispatch ([b802f6c](https://git.softwaregroup.com/ut5/ut-customer/commit/b802f6c))
* **synchronization:** accounts and customers ([6b33d9c](https://git.softwaregroup.com/ut5/ut-customer/commit/6b33d9c))



<a name="5.26.8"></a>
## [5.26.8](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.7...v5.26.8) (2016-11-02)


### Bug Fixes

* MCTUNE-1013 ([c33cb8e](https://git.softwaregroup.com/ut5/ut-customer/commit/c33cb8e))



<a name="5.26.7"></a>
## [5.26.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.6...v5.26.7) (2016-11-02)


### Bug Fixes

* **MCTUNE-992:** Handle T24 dynamically ([bb0e538](https://git.softwaregroup.com/ut5/ut-customer/commit/bb0e538))



<a name="5.26.6"></a>
## [5.26.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.5...v5.26.6) (2016-10-31)



<a name="5.26.5"></a>
## [5.26.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.4...v5.26.5) (2016-10-31)


### Bug Fixes

* MCTUNE-1062 ([55abf09](https://git.softwaregroup.com/ut5/ut-customer/commit/55abf09))
* MCTUNE-1078 ([2bdf884](https://git.softwaregroup.com/ut5/ut-customer/commit/2bdf884))



<a name="5.26.4"></a>
## [5.26.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.3...v5.26.4) (2016-10-31)



<a name="5.26.3"></a>
## [5.26.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.2...v5.26.3) (2016-10-28)



<a name="5.26.2"></a>
## [5.26.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.1...v5.26.2) (2016-10-28)



<a name="5.26.1"></a>
## [5.26.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.26.0...v5.26.1) (2016-10-27)



<a name="5.26.0"></a>
# [5.26.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.25.6...v5.26.0) (2016-10-27)


### Features

* MCTUNE-1078 ([9928951](https://git.softwaregroup.com/ut5/ut-customer/commit/9928951))



<a name="5.25.6"></a>
## [5.25.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.25.5...v5.25.6) (2016-10-26)



<a name="5.25.5"></a>
## [5.25.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.25.4...v5.25.5) (2016-10-26)



<a name="5.25.4"></a>
## [5.25.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.25.3...v5.25.4) (2016-10-26)



<a name="5.25.3"></a>
## [5.25.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.25.2...v5.25.3) (2016-10-25)


### Bug Fixes

* **MCTUNE-1104:** T24 customer.update - save lat/long for home & business ([023b6e0](https://git.softwaregroup.com/ut5/ut-customer/commit/023b6e0))



<a name="5.25.2"></a>
## [5.25.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.25.1...v5.25.2) (2016-10-21)



<a name="5.25.1"></a>
## [5.25.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.25.0...v5.25.1) (2016-10-20)



<a name="5.25.0"></a>
# [5.25.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.24.1...v5.25.0) (2016-10-20)


### Features

* **systemDate:** add system date from T24 ([c862d87](https://git.softwaregroup.com/ut5/ut-customer/commit/c862d87))



<a name="5.24.1"></a>
## [5.24.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.24.0...v5.24.1) (2016-10-19)


### Bug Fixes

* MCTUNE-1024 BU search ([a92f78c](https://git.softwaregroup.com/ut5/ut-customer/commit/a92f78c))
* MCTUNE-1024 not return selected parent in search result ([e5b7aa8](https://git.softwaregroup.com/ut5/ut-customer/commit/e5b7aa8))



<a name="5.24.0"></a>
# [5.24.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.23.10...v5.24.0) (2016-10-17)


### Features

* **new function:** returns parent organizations ([cbb4bab](https://git.softwaregroup.com/ut5/ut-customer/commit/cbb4bab))



<a name="5.23.10"></a>
## [5.23.10](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.23.9...v5.23.10) (2016-10-17)


### Bug Fixes

* lint ([74eefda](https://git.softwaregroup.com/ut5/ut-customer/commit/74eefda))



<a name="5.23.9"></a>
## [5.23.9](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.23.8...v5.23.9) (2016-10-13)



<a name="5.23.8"></a>
## [5.23.8](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.23.7...v5.23.8) (2016-10-12)



<a name="5.23.7"></a>
## [5.23.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.23.6...v5.23.7) (2016-10-10)



<a name="5.23.6"></a>
## [5.23.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.23.5...v5.23.6) (2016-10-10)


### Bug Fixes

* MCTUNE-1001 ([5973ef7](https://git.softwaregroup.com/ut5/ut-customer/commit/5973ef7))



<a name="5.23.5"></a>
## [5.23.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.23.4...v5.23.5) (2016-10-10)



<a name="5.23.4"></a>
## [5.23.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.23.3...v5.23.4) (2016-10-07)


### Bug Fixes

* MCTUNE-1001 ([2886dd6](https://git.softwaregroup.com/ut5/ut-customer/commit/2886dd6))



<a name="5.23.3"></a>
## [5.23.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.23.2...v5.23.3) (2016-10-06)



<a name="5.23.2"></a>
## [5.23.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.23.1...v5.23.2) (2016-10-05)


### Bug Fixes

* **MCTUNE-801:** fix size ([17c1616](https://git.softwaregroup.com/ut5/ut-customer/commit/17c1616))
* **MCTUNE-927:** add vectorized icons ([c462ae0](https://git.softwaregroup.com/ut5/ut-customer/commit/c462ae0))
* change icon ([6717878](https://git.softwaregroup.com/ut5/ut-customer/commit/6717878))
* modal icons ([bef82fe](https://git.softwaregroup.com/ut5/ut-customer/commit/bef82fe))



<a name="5.23.1"></a>
## [5.23.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.23.0...v5.23.1) (2016-10-04)



<a name="5.23.0"></a>
# [5.23.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.22.7...v5.23.0) (2016-10-04)


### Features

* **customer address:** add lat and lng in update SP ([31ef2d5](https://git.softwaregroup.com/ut5/ut-customer/commit/31ef2d5))



<a name="5.22.7"></a>
## [5.22.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.22.6...v5.22.7) (2016-10-03)


### Bug Fixes

* MCTUNE-1001 ([690f832](https://git.softwaregroup.com/ut5/ut-customer/commit/690f832))
* MCTUNE-974 ([706ca06](https://git.softwaregroup.com/ut5/ut-customer/commit/706ca06))



<a name="5.22.6"></a>
## [5.22.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.22.5...v5.22.6) (2016-10-03)



<a name="5.22.5"></a>
## [5.22.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.22.4...v5.22.5) (2016-09-30)


### Bug Fixes

* **account.add:** insert missing fields ([fa367ab](https://git.softwaregroup.com/ut5/ut-customer/commit/fa367ab))



<a name="5.22.4"></a>
## [5.22.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.22.3...v5.22.4) (2016-09-30)


### Bug Fixes

* a bug ([8dc6566](https://git.softwaregroup.com/ut5/ut-customer/commit/8dc6566))



<a name="5.22.3"></a>
## [5.22.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.22.2...v5.22.3) (2016-09-27)



<a name="5.22.2"></a>
## [5.22.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.22.1...v5.22.2) (2016-09-27)


### Bug Fixes

* **MCTUNE-800:** fix dropdown styles in update status dropdown ([c910613](https://git.softwaregroup.com/ut5/ut-customer/commit/c910613))
* **MCTUNE-801:** bio registration fingerprint icons should be with equal height ([5eeb1b5](https://git.softwaregroup.com/ut5/ut-customer/commit/5eeb1b5))
* **MCTUNE-802:** styles and refactor ([2597ed7](https://git.softwaregroup.com/ut5/ut-customer/commit/2597ed7))
* **MCTUNE-803:** fit uploaded picture ([7bf0072](https://git.softwaregroup.com/ut5/ut-customer/commit/7bf0072))
* **MCTUNE-805:** tab screen UI ([c79bd53](https://git.softwaregroup.com/ut5/ut-customer/commit/c79bd53))
* **MCTUNE-805:** tab screen UI (filter component consistency) ([f0dd606](https://git.softwaregroup.com/ut5/ut-customer/commit/f0dd606))
* **MCTUNE-806:** tab numbers styling ([f8c8ea1](https://git.softwaregroup.com/ut5/ut-customer/commit/f8c8ea1))
* clear unused bio registration icon ([f7645f7](https://git.softwaregroup.com/ut5/ut-customer/commit/f7645f7))
* upload screens and styles ([4747339](https://git.softwaregroup.com/ut5/ut-customer/commit/4747339))
* **MCTUNE-807:** menu card should not move when we scroll down ([70e6917](https://git.softwaregroup.com/ut5/ut-customer/commit/70e6917))
* **MCTUNE-808:** action buttons must have grey background ([7e5ddd1](https://git.softwaregroup.com/ut5/ut-customer/commit/7e5ddd1))



<a name="5.22.1"></a>
## [5.22.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.22.0...v5.22.1) (2016-09-27)


### Bug Fixes

* forntend deps ([f6e35c2](https://git.softwaregroup.com/ut5/ut-customer/commit/f6e35c2))



<a name="5.22.0"></a>
# [5.22.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.17...v5.22.0) (2016-09-27)


### Features

* MCTUNE-371 ([f4c71e3](https://git.softwaregroup.com/ut5/ut-customer/commit/f4c71e3))



<a name="5.21.17"></a>
## [5.21.17](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.16...v5.21.17) (2016-09-26)


### Bug Fixes

* **report.run:** MCTUNE-886 change sort field  name ([4722a75](https://git.softwaregroup.com/ut5/ut-customer/commit/4722a75))



<a name="5.21.16"></a>
## [5.21.16](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.15...v5.21.16) (2016-09-21)



<a name="5.21.15"></a>
## [5.21.15](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.14...v5.21.15) (2016-09-21)


### Bug Fixes

* revert to previous code that has borders ([d6dacf0](https://git.softwaregroup.com/ut5/ut-customer/commit/d6dacf0))
* version bump ([5073fda](https://git.softwaregroup.com/ut5/ut-customer/commit/5073fda))



<a name="5.21.14"></a>
## [5.21.14](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.13...v5.21.14) (2016-09-20)



<a name="5.21.13"></a>
## [5.21.13](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.12...v5.21.13) (2016-09-20)


### Bug Fixes

* **organization.add/edit:** set default role to null ([b075aef](https://git.softwaregroup.com/ut5/ut-customer/commit/b075aef))
* **person.editUnapproved:** change check order ([50effc8](https://git.softwaregroup.com/ut5/ut-customer/commit/50effc8))
* **person.editUnapproved:** re-edit functionality ([b499afc](https://git.softwaregroup.com/ut5/ut-customer/commit/b499afc))



<a name="5.21.12"></a>
## [5.21.12](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.11...v5.21.12) (2016-09-19)


### Bug Fixes

* **MCTUNE-797:** Reset password improvement ([4341ff1](https://git.softwaregroup.com/ut5/ut-customer/commit/4341ff1))



<a name="5.21.11"></a>
## [5.21.11](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.10...v5.21.11) (2016-09-19)


### Bug Fixes

* MCTUNE 513 ([fa8a9b3](https://git.softwaregroup.com/ut5/ut-customer/commit/fa8a9b3))



<a name="5.21.10"></a>
## [5.21.10](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.9...v5.21.10) (2016-09-16)


### Bug Fixes

* fix customer.otp.check to approve phone conditionally ([9feb4d8](https://git.softwaregroup.com/ut5/ut-customer/commit/9feb4d8))



<a name="5.21.9"></a>
## [5.21.9](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.8...v5.21.9) (2016-09-12)



<a name="5.21.8"></a>
## [5.21.8](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.7...v5.21.8) (2016-09-09)


### Bug Fixes

* MCTUNE-730 ([4b17d60](https://git.softwaregroup.com/ut5/ut-customer/commit/4b17d60))



<a name="5.21.7"></a>
## [5.21.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.6...v5.21.7) (2016-09-08)


### Bug Fixes

* do not return filename when user have no image ([3f1573f](https://git.softwaregroup.com/ut5/ut-customer/commit/3f1573f))



<a name="5.21.6"></a>
## [5.21.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.5...v5.21.6) (2016-09-08)



<a name="5.21.5"></a>
## [5.21.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.4...v5.21.5) (2016-09-08)



<a name="5.21.4"></a>
## [5.21.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.3...v5.21.4) (2016-09-08)


### Bug Fixes

* Properly display loan application state if it is evaluated. ([5b10b0c](https://git.softwaregroup.com/ut5/ut-customer/commit/5b10b0c))



<a name="5.21.3"></a>
## [5.21.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.2...v5.21.3) (2016-09-07)


### Bug Fixes

* **MCTUNE-706:** Expiry date: Today date option: does not show the correct  current date ([41f2cd4](https://git.softwaregroup.com/ut5/ut-customer/commit/41f2cd4))
* clear comments ([3339277](https://git.softwaregroup.com/ut5/ut-customer/commit/3339277))



<a name="5.21.2"></a>
## [5.21.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.1...v5.21.2) (2016-09-07)



<a name="5.21.1"></a>
## [5.21.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.21.0...v5.21.1) (2016-09-07)



<a name="5.21.0"></a>
# [5.21.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.20.6...v5.21.0) (2016-09-02)


### Features

* UIS-125 ([8bce182](https://git.softwaregroup.com/ut5/ut-customer/commit/8bce182))



<a name="5.20.6"></a>
## [5.20.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.20.5...v5.20.6) (2016-09-02)


### Bug Fixes

* change loan application displayed status according to the application step ([05757a2](https://git.softwaregroup.com/ut5/ut-customer/commit/05757a2))
* MCTUNE-697. Change for customer display name in last step of loan creation ([e3edc11](https://git.softwaregroup.com/ut5/ut-customer/commit/e3edc11))



<a name="5.20.5"></a>
## [5.20.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.20.4...v5.20.5) (2016-09-02)



<a name="5.20.4"></a>
## [5.20.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.20.3...v5.20.4) (2016-09-01)


### Bug Fixes

* MCTUNE-657 ([62b0a55](https://git.softwaregroup.com/ut5/ut-customer/commit/62b0a55))



<a name="5.20.3"></a>
## [5.20.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.20.2...v5.20.3) (2016-09-01)



<a name="5.20.2"></a>
## [5.20.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.20.1...v5.20.2) (2016-08-31)


### Bug Fixes

* **person.editUnapproved:** check only if edited person > 1 ([8cef43e](https://git.softwaregroup.com/ut5/ut-customer/commit/8cef43e))



<a name="5.20.1"></a>
## [5.20.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.20.0...v5.20.1) (2016-08-31)



<a name="5.20.0"></a>
# [5.20.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.19.0...v5.20.0) (2016-08-30)


### Features

* new functions, used for MCTUNE-504 and MCTUNE-503 ([1a2c6c4](https://git.softwaregroup.com/ut5/ut-customer/commit/1a2c6c4))



<a name="5.19.0"></a>
# [5.19.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.18.4...v5.19.0) (2016-08-30)


### Bug Fixes

* delete of unapproved properties of person ([b1058f0](https://git.softwaregroup.com/ut5/ut-customer/commit/b1058f0))
* move unapproved functions to user due to project start sequence issues ([0d5fe90](https://git.softwaregroup.com/ut5/ut-customer/commit/0d5fe90))
* re-edit functionality ([42b9fe4](https://git.softwaregroup.com/ut5/ut-customer/commit/42b9fe4))
* removed fake actorId and history tables ([df5bb79](https://git.softwaregroup.com/ut5/ut-customer/commit/df5bb79))


### Features

* add edit of rejected users functionality ([082bfe8](https://git.softwaregroup.com/ut5/ut-customer/commit/082bfe8))
* **phone.edit:** re-edit functionality ([61fabeb](https://git.softwaregroup.com/ut5/ut-customer/commit/61fabeb))
* add organizationsVisibleForUnapproved ([903f308](https://git.softwaregroup.com/ut5/ut-customer/commit/903f308))
* add SPs for unapproved data ([2736d6d](https://git.softwaregroup.com/ut5/ut-customer/commit/2736d6d))
* add unapproved and history tables ([b2fbb1a](https://git.softwaregroup.com/ut5/ut-customer/commit/b2fbb1a))
* set DEFAULT SYSDATETIMEOFFSET() ([2b431da](https://git.softwaregroup.com/ut5/ut-customer/commit/2b431da))



<a name="5.18.4"></a>
## [5.18.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.18.3...v5.18.4) (2016-08-30)


### Bug Fixes

* **report.run:** take language from user session, not meta ([36efa86](https://git.softwaregroup.com/ut5/ut-customer/commit/36efa86))



<a name="5.18.3"></a>
## [5.18.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.18.2...v5.18.3) (2016-08-26)


### Bug Fixes

* MCTUNE-653 ([906cada](https://git.softwaregroup.com/ut5/ut-customer/commit/906cada))



<a name="5.18.2"></a>
## [5.18.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.18.1...v5.18.2) (2016-08-26)


### Bug Fixes

* MCTUNE-513 ([dd63186](https://git.softwaregroup.com/ut5/ut-customer/commit/dd63186))
* MCTUNE-513 ([4c32403](https://git.softwaregroup.com/ut5/ut-customer/commit/4c32403))
* MCTUNE-513 ([61e50e7](https://git.softwaregroup.com/ut5/ut-customer/commit/61e50e7))



<a name="5.18.1"></a>
## [5.18.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.18.0...v5.18.1) (2016-08-26)


### Bug Fixes

* added timezone to activityReposrt run & activationReport run ([db77667](https://git.softwaregroup.com/ut5/ut-customer/commit/db77667))



<a name="5.18.0"></a>
# [5.18.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.17.1...v5.18.0) (2016-08-26)


### Bug Fixes

* MCTUNE-510 ([563988a](https://git.softwaregroup.com/ut5/ut-customer/commit/563988a))


### Features

* balance by sms ([6900f5b](https://git.softwaregroup.com/ut5/ut-customer/commit/6900f5b))
* get customer by phone ([baef6ac](https://git.softwaregroup.com/ut5/ut-customer/commit/baef6ac))



<a name="5.17.1"></a>
## [5.17.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.17.0...v5.17.1) (2016-08-26)



<a name="5.17.0"></a>
# [5.17.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.16.1...v5.17.0) (2016-08-26)


### Features

* MCTUNE-617 ([7e85b5f](https://git.softwaregroup.com/ut5/ut-customer/commit/7e85b5f))



<a name="5.16.1"></a>
## [5.16.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.16.0...v5.16.1) (2016-08-26)



<a name="5.16.0"></a>
# [5.16.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.12...v5.16.0) (2016-08-26)


### Features

* **new column:** add column udf ([8bdb01c](https://git.softwaregroup.com/ut5/ut-customer/commit/8bdb01c))



<a name="5.15.12"></a>
## [5.15.12](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.11...v5.15.12) (2016-08-25)



<a name="5.15.11"></a>
## [5.15.11](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.10...v5.15.11) (2016-08-25)


### Bug Fixes

* MCTUNE-626. Change header text for already submitted loan application popup ([4ff5de1](https://git.softwaregroup.com/ut5/ut-customer/commit/4ff5de1))



<a name="5.15.10"></a>
## [5.15.10](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.9...v5.15.10) (2016-08-25)


### Bug Fixes

* MCTUNE-618. Display loan application state in info popup for already existing application ([08a66f6](https://git.softwaregroup.com/ut5/ut-customer/commit/08a66f6))



<a name="5.15.9"></a>
## [5.15.9](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.8...v5.15.9) (2016-08-25)


### Bug Fixes

* MCTUNE-619. User will not be able to create more loan applications for the same customer if the customer has loan application that is not assigned ([eeb8ef3](https://git.softwaregroup.com/ut5/ut-customer/commit/eeb8ef3))



<a name="5.15.8"></a>
## [5.15.8](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.7...v5.15.8) (2016-08-25)


### Bug Fixes

* MCTUNE-604 on block ([9b456eb](https://git.softwaregroup.com/ut5/ut-customer/commit/9b456eb))



<a name="5.15.7"></a>
## [5.15.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.6...v5.15.7) (2016-08-25)


### Bug Fixes

* MCTUNE-438 ([ee4b71d](https://git.softwaregroup.com/ut5/ut-customer/commit/ee4b71d))



<a name="5.15.6"></a>
## [5.15.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.5...v5.15.6) (2016-08-23)


### Bug Fixes

* MCTUNE-604 ([3854aa6](https://git.softwaregroup.com/ut5/ut-customer/commit/3854aa6))



<a name="5.15.5"></a>
## [5.15.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.4...v5.15.5) (2016-08-23)



<a name="5.15.4"></a>
## [5.15.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.3...v5.15.4) (2016-08-23)



<a name="5.15.3"></a>
## [5.15.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.2...v5.15.3) (2016-08-22)


### Bug Fixes

* MCTUNE-488. Change popup widget heading for new loan application ([a7c7a10](https://git.softwaregroup.com/ut5/ut-customer/commit/a7c7a10))



<a name="5.15.2"></a>
## [5.15.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.1...v5.15.2) (2016-08-22)


### Bug Fixes

* MCTUNE-487. Add text wrap for customer name field in new application window ([36f5cbf](https://git.softwaregroup.com/ut5/ut-customer/commit/36f5cbf))



<a name="5.15.1"></a>
## [5.15.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.15.0...v5.15.1) (2016-08-22)


### Bug Fixes

* **customer/organization.fetch:** change default page size ([6a29817](https://git.softwaregroup.com/ut5/ut-customer/commit/6a29817))



<a name="5.15.0"></a>
# [5.15.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.14.0...v5.15.0) (2016-08-19)


### Bug Fixes

* **customer:** alter lat and lng columns ([3b3ca44](https://git.softwaregroup.com/ut5/ut-customer/commit/3b3ca44))


### Features

* **customer:** new columns ([df7f627](https://git.softwaregroup.com/ut5/ut-customer/commit/df7f627))



<a name="5.14.0"></a>
# [5.14.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.13.1...v5.14.0) (2016-08-19)


### Features

* new function that returns branches for the logged user ([54e3b7a](https://git.softwaregroup.com/ut5/ut-customer/commit/54e3b7a))



<a name="5.13.1"></a>
## [5.13.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.13.0...v5.13.1) (2016-08-19)


### Bug Fixes

* typo ([40991cf](https://git.softwaregroup.com/ut5/ut-customer/commit/40991cf))



<a name="5.13.0"></a>
# [5.13.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.12.0...v5.13.0) (2016-08-19)


### Bug Fixes

* add customer.organization.remove.cannotDelete.organizations in error.js, update errors for deleteOrganization ([d6bc861](https://git.softwaregroup.com/ut5/ut-customer/commit/d6bc861))
* add customer.organization.remove.cannotDelete.organizations in error.js, update errors for deleteOrganization ([b3c23ce](https://git.softwaregroup.com/ut5/ut-customer/commit/b3c23ce))


### Features

* UIS-35 ([72f72a1](https://git.softwaregroup.com/ut5/ut-customer/commit/72f72a1))
* UIS-35 ([92c6f4e](https://git.softwaregroup.com/ut5/ut-customer/commit/92c6f4e))



<a name="5.12.0"></a>
# [5.12.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.11.3...v5.12.0) (2016-08-19)


### Features

* new function that returns the visible branches for the logged user ([1faf4c4](https://git.softwaregroup.com/ut5/ut-customer/commit/1faf4c4))



<a name="5.11.3"></a>
## [5.11.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.11.2...v5.11.3) (2016-08-19)


### Bug Fixes

* **activationReport.run:** actionStatus change ([2aadc35](https://git.softwaregroup.com/ut5/ut-customer/commit/2aadc35))
* **report.run:** change actionId, add date and time ([d486d92](https://git.softwaregroup.com/ut5/ut-customer/commit/d486d92))
* **report.run:** date and time formats ([390d9df](https://git.softwaregroup.com/ut5/ut-customer/commit/390d9df))



<a name="5.11.2"></a>
## [5.11.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.11.1...v5.11.2) (2016-08-17)



<a name="5.11.1"></a>
## [5.11.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.11.0...v5.11.1) (2016-08-17)


### Bug Fixes

* **MCTUNE-451:** default placeOfBirth validations ([d64cb67](https://git.softwaregroup.com/ut5/ut-customer/commit/d64cb67))



<a name="5.11.0"></a>
# [5.11.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.10.0...v5.11.0) (2016-08-16)


### Bug Fixes

* add stateList param to customer.customer.search ([4e5df4b](https://git.softwaregroup.com/ut5/ut-customer/commit/4e5df4b))


### Features

* **customer.search:** added status filter ([9557c8f](https://git.softwaregroup.com/ut5/ut-customer/commit/9557c8f))



<a name="5.10.0"></a>
# [5.10.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.9.5...v5.10.0) (2016-08-16)


### Bug Fixes

* fix jsx-quotes due to eslint bug ([839b154](https://git.softwaregroup.com/ut5/ut-customer/commit/839b154))
* get Accordion component from ut-front-react ([c56e9c6](https://git.softwaregroup.com/ut5/ut-customer/commit/c56e9c6))
* refactor ClientCard component ([708a20c](https://git.softwaregroup.com/ut5/ut-customer/commit/708a20c))


### Features

* refactor ClientSummary component to take config data ([a6ca4d6](https://git.softwaregroup.com/ut5/ut-customer/commit/a6ca4d6))



<a name="5.9.5"></a>
## [5.9.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.9.4...v5.9.5) (2016-08-16)



<a name="5.9.4"></a>
## [5.9.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.9.3...v5.9.4) (2016-08-16)


### Bug Fixes

* linting ([075f85f](https://git.softwaregroup.com/ut5/ut-customer/commit/075f85f))
* spaces validation ([e892164](https://git.softwaregroup.com/ut5/ut-customer/commit/e892164))



<a name="5.9.3"></a>
## [5.9.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.9.2...v5.9.3) (2016-08-16)


### Bug Fixes

* MCTUNE-471 - Customer: Blocked tab - the text of label for blocked reasons in wrong ([ce511eb](https://git.softwaregroup.com/ut5/ut-customer/commit/ce511eb))
* missing countryId ([2860fc0](https://git.softwaregroup.com/ut5/ut-customer/commit/2860fc0))



<a name="5.9.2"></a>
## [5.9.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.9.1...v5.9.2) (2016-08-12)



<a name="5.9.1"></a>
## [5.9.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.9.0...v5.9.1) (2016-08-12)


### Bug Fixes

* **MCTUNE-451:** add additional validation logic for placeOfBirth ([4fb1d1d](https://git.softwaregroup.com/ut5/ut-customer/commit/4fb1d1d))



<a name="5.9.0"></a>
# [5.9.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.8.0...v5.9.0) (2016-08-12)


### Features

* UIS-90 ([3959492](https://git.softwaregroup.com/ut5/ut-customer/commit/3959492))



<a name="5.8.0"></a>
# [5.8.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.7.4...v5.8.0) (2016-08-12)


### Features

* UIS-91 ([34093cc](https://git.softwaregroup.com/ut5/ut-customer/commit/34093cc))



<a name="5.7.4"></a>
## [5.7.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.7.3...v5.7.4) (2016-08-12)


### Bug Fixes

* MCTUNE-434 - [GSD:MC]: As a user and when i block a client, i should select blocking reasons. ([a853d4c](https://git.softwaregroup.com/ut5/ut-customer/commit/a853d4c))
* **customer.search:** multiple rows for 1 customer MCTUNE-447 ([c609a65](https://git.softwaregroup.com/ut5/ut-customer/commit/c609a65))
* **MCTUNE-451:** Client file: missing validation for Address field, Place of birth, First name, Last name - error 't24.validation.filed' appears, when try to validate client file ([bd61954](https://git.softwaregroup.com/ut5/ut-customer/commit/bd61954))



<a name="5.7.3"></a>
## [5.7.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.7.2...v5.7.3) (2016-08-11)


### Bug Fixes

* MCTUNE-434 - [GSD:MC]: As a user and when i block a client, i should select blocking reasons. ([fed3bb1](https://git.softwaregroup.com/ut5/ut-customer/commit/fed3bb1))



<a name="5.7.2"></a>
## [5.7.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.7.1...v5.7.2) (2016-08-11)


### Bug Fixes

* **activity-report:** Add data to activity report. ([a487f71](https://git.softwaregroup.com/ut5/ut-customer/commit/a487f71))
* **activity-report:** Add data to activity report. ([7f8abf6](https://git.softwaregroup.com/ut5/ut-customer/commit/7f8abf6))
* **T24:** Post date now containing hour:minute. ([3512fbe](https://git.softwaregroup.com/ut5/ut-customer/commit/3512fbe))



<a name="5.7.1"></a>
## [5.7.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.7.0...v5.7.1) (2016-08-10)


### Bug Fixes

* **activityReport.add:** join on primary phone ([b8100a4](https://git.softwaregroup.com/ut5/ut-customer/commit/b8100a4))
* magic search to work only for approved phones ([3bf9ca6](https://git.softwaregroup.com/ut5/ut-customer/commit/3bf9ca6))



<a name="5.7.0"></a>
# [5.7.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.6.2...v5.7.0) (2016-08-10)


### Bug Fixes

* MCTUNE-359 ([f61afb5](https://git.softwaregroup.com/ut5/ut-customer/commit/f61afb5))
* MCTUNE-374 ([4165174](https://git.softwaregroup.com/ut5/ut-customer/commit/4165174))
* optimization and change in search logic - now searches only in approved phones ([333d498](https://git.softwaregroup.com/ut5/ut-customer/commit/333d498))
* paginagion bug ([9a952fb](https://git.softwaregroup.com/ut5/ut-customer/commit/9a952fb))
* second CTE declare in customer search ([94f8b13](https://git.softwaregroup.com/ut5/ut-customer/commit/94f8b13))
* state reset action ([3e3022d](https://git.softwaregroup.com/ut5/ut-customer/commit/3e3022d))
* **report.run:** convert date as varchar ([f64d901](https://git.softwaregroup.com/ut5/ut-customer/commit/f64d901))
* version bump ([38aa5ef](https://git.softwaregroup.com/ut5/ut-customer/commit/38aa5ef))


### Features

* new SP - for the activation report ([07c3bd9](https://git.softwaregroup.com/ut5/ut-customer/commit/07c3bd9))
* **report.run:** added pagination, MCTUNE-302 ([03e689f](https://git.softwaregroup.com/ut5/ut-customer/commit/03e689f))
* **report.run:** added sorting ([70c235a](https://git.softwaregroup.com/ut5/ut-customer/commit/70c235a))



<a name="5.6.2"></a>
## [5.6.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.6.1...v5.6.2) (2016-08-05)


### Bug Fixes

* remove alter table and not null ([46cd368](https://git.softwaregroup.com/ut5/ut-customer/commit/46cd368))



<a name="5.6.1"></a>
## [5.6.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.6.0...v5.6.1) (2016-08-05)


### Bug Fixes

* rename according to convention ([e350718](https://git.softwaregroup.com/ut5/ut-customer/commit/e350718))



<a name="5.6.0"></a>
# [5.6.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.5.2...v5.6.0) (2016-08-04)


### Bug Fixes

* add result set name ([e9ad2fa](https://git.softwaregroup.com/ut5/ut-customer/commit/e9ad2fa))
* fix loan.item.fetch according to the new api ([f7253b5](https://git.softwaregroup.com/ut5/ut-customer/commit/f7253b5))
* sort and fix performance ([e098016](https://git.softwaregroup.com/ut5/ut-customer/commit/e098016))


### Features

* activity report ([ce168b5](https://git.softwaregroup.com/ut5/ut-customer/commit/ce168b5))
* **loan:** Migration ([91e23c0](https://git.softwaregroup.com/ut5/ut-customer/commit/91e23c0))



<a name="5.5.2"></a>
## [5.5.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.5.1...v5.5.2) (2016-08-03)


### Bug Fixes

* UIS-65 ([cb82879](https://git.softwaregroup.com/ut5/ut-customer/commit/cb82879))
* **customer-activity:** Add account name to balance and mini statement. ([477ec0b](https://git.softwaregroup.com/ut5/ut-customer/commit/477ec0b))



<a name="5.5.1"></a>
## [5.5.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.5.0...v5.5.1) (2016-08-02)


### Bug Fixes

* failing tests ([41a84bd](https://git.softwaregroup.com/ut5/ut-customer/commit/41a84bd))



<a name="5.5.0"></a>
# [5.5.0](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.13...v5.5.0) (2016-08-02)


### Bug Fixes

* change assignTo to assignedTo according to technical specification ([f7c765c](https://git.softwaregroup.com/ut5/ut-customer/commit/f7c765c))
* failing tests ([f18c619](https://git.softwaregroup.com/ut5/ut-customer/commit/f18c619))
* fix customer files agencies filtering and display ([538c8e0](https://git.softwaregroup.com/ut5/ut-customer/commit/538c8e0))
* new way to get by DAO ([15bdba0](https://git.softwaregroup.com/ut5/ut-customer/commit/15bdba0))
* performance fix ([e81b195](https://git.softwaregroup.com/ut5/ut-customer/commit/e81b195))
* remove account adding in organization ([3f16fe2](https://git.softwaregroup.com/ut5/ut-customer/commit/3f16fe2))
* remove componentShouldUpdate logic in order to provide possibility for bio scanning retrying and cancellation ([417115b](https://git.softwaregroup.com/ut5/ut-customer/commit/417115b))
* **customer.account:** fix column order ([a906919](https://git.softwaregroup.com/ut5/ut-customer/commit/a906919))
* rename customer file to be after organization ([178263d](https://git.softwaregroup.com/ut5/ut-customer/commit/178263d))
* return according DAO ([0681140](https://git.softwaregroup.com/ut5/ut-customer/commit/0681140))
* typo ([6209aff](https://git.softwaregroup.com/ut5/ut-customer/commit/6209aff))
* when existing DB with data ([2b4db60](https://git.softwaregroup.com/ut5/ut-customer/commit/2b4db60))


### Features

* activity report ([16a14e3](https://git.softwaregroup.com/ut5/ut-customer/commit/16a14e3))
* **customer account and accountType:** add new columns ([944402b](https://git.softwaregroup.com/ut5/ut-customer/commit/944402b))
* add DAO as id in customer table ([958e749](https://git.softwaregroup.com/ut5/ut-customer/commit/958e749))
* new way customer to DAO ([a45a184](https://git.softwaregroup.com/ut5/ut-customer/commit/a45a184))
* return according DAO ([a2ad370](https://git.softwaregroup.com/ut5/ut-customer/commit/a2ad370))
* return according DAOs of the logged user ([f53fc7e](https://git.softwaregroup.com/ut5/ut-customer/commit/f53fc7e))



<a name="5.4.13"></a>
## [5.4.13](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.12...v5.4.13) (2016-07-29)


### Bug Fixes

* fix dev dependencies ([d644501](https://git.softwaregroup.com/ut5/ut-customer/commit/d644501))
* spelling mistake and changes in activity report ([fa3924d](https://git.softwaregroup.com/ut5/ut-customer/commit/fa3924d))



<a name="5.4.12"></a>
## [5.4.12](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.11...v5.4.12) (2016-07-26)


### Bug Fixes

* **activity-report:** Fix a column name ([79c43b4](https://git.softwaregroup.com/ut5/ut-customer/commit/79c43b4))
* **sql:** Make exec [core].[error] uppercase so ut-port-sql replace it. ([b33986f](https://git.softwaregroup.com/ut5/ut-customer/commit/b33986f))



<a name="5.4.11"></a>
## [5.4.11](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.10...v5.4.11) (2016-07-25)


### Bug Fixes

* fix phone validation to use Symbols as actions ([ff8bf0f](https://git.softwaregroup.com/ut5/ut-customer/commit/ff8bf0f))
* isolate otp sending/checking logic to PhoneNumberValidator component instead of it's wrapper for modularity ([55aab7e](https://git.softwaregroup.com/ut5/ut-customer/commit/55aab7e))
* js warnings ([b24a9f0](https://git.softwaregroup.com/ut5/ut-customer/commit/b24a9f0))
* UIS-34 ([59f2842](https://git.softwaregroup.com/ut5/ut-customer/commit/59f2842))
* UIS-34 - redux namespacing isolation ([4acbd43](https://git.softwaregroup.com/ut5/ut-customer/commit/4acbd43))
* **address.add/edit:** add/edit address city ([45be7b9](https://git.softwaregroup.com/ut5/ut-customer/commit/45be7b9))
* **MCTUNE-282:** Missing validation for ID number filed ([0c6595f](https://git.softwaregroup.com/ut5/ut-customer/commit/0c6595f))
* **MCTUNE-296:** Search results - the user should not be able to select left/right arrows when he is on the first/last page ([0daad4e](https://git.softwaregroup.com/ut5/ut-customer/commit/0daad4e))


### Features

* activity report for Baobab ([0d71b48](https://git.softwaregroup.com/ut5/ut-customer/commit/0d71b48))
* add infoToolTip icon in storybook ([221836c](https://git.softwaregroup.com/ut5/ut-customer/commit/221836c))



<a name="5.4.10"></a>
## [5.4.10](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.9...v5.4.10) (2016-07-20)


### Bug Fixes

* **MCTUNE-281:** Validate phone number message ([ebe5772](https://git.softwaregroup.com/ut5/ut-customer/commit/ebe5772))
* **MCTUNE-282:** Missing validation for ID number filed ([cbc7d3a](https://git.softwaregroup.com/ut5/ut-customer/commit/cbc7d3a))



<a name="5.4.9"></a>
## [5.4.9](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.8...v5.4.9) (2016-07-19)


### Bug Fixes

* **MCTUNE-276:** Missing validation for fields: Date of birth and Expiry date ([754e423](https://git.softwaregroup.com/ut5/ut-customer/commit/754e423))
* **phone:** isPrimary - default(0) ([2d44481](https://git.softwaregroup.com/ut5/ut-customer/commit/2d44481))
* **phone.edit:** edit isPrimary ([01be554](https://git.softwaregroup.com/ut5/ut-customer/commit/01be554))


### Features

* **phone:** added column isPrimary - for otp ([58507d0](https://git.softwaregroup.com/ut5/ut-customer/commit/58507d0))



<a name="5.4.8"></a>
## [5.4.8](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.7...v5.4.8) (2016-07-19)


### Bug Fixes

* **MCTUNE-250:** Due to lack of validation for phone number field, the client file cannot be valdiated ([a9967eb](https://git.softwaregroup.com/ut5/ut-customer/commit/a9967eb))
* **organization.edit:** edit countryId ([b9953da](https://git.softwaregroup.com/ut5/ut-customer/commit/b9953da))
* components css validation ([c291d5d](https://git.softwaregroup.com/ut5/ut-customer/commit/c291d5d))
* global css validation ([8048137](https://git.softwaregroup.com/ut5/ut-customer/commit/8048137))
* not correct return ([93ba58a](https://git.softwaregroup.com/ut5/ut-customer/commit/93ba58a))
* performance ([268ac77](https://git.softwaregroup.com/ut5/ut-customer/commit/268ac77))



<a name="5.4.7"></a>
## [5.4.7](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.6...v5.4.7) (2016-07-18)



<a name="5.4.6"></a>
## [5.4.6](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.5...v5.4.6) (2016-07-18)


### Bug Fixes

* **mno.fetch:** fetch mnos relevant to the BUs of the user ([74a12a1](https://git.softwaregroup.com/ut5/ut-customer/commit/74a12a1))
* **mno.fetch:** removed BUs filter until implemented ([cd27552](https://git.softwaregroup.com/ut5/ut-customer/commit/cd27552))


### Features

* format phone number ([6ad45a0](https://git.softwaregroup.com/ut5/ut-customer/commit/6ad45a0))
* **customer.organization:** added column countryId ([d2f214b](https://git.softwaregroup.com/ut5/ut-customer/commit/d2f214b))



<a name="5.4.5"></a>
## [5.4.5](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.4...v5.4.5) (2016-07-15)


### Bug Fixes

* bugfix_MCTUNE-264 Rejection Reasons don't show in the Rejected screen ([0115bd7](https://git.softwaregroup.com/ut5/ut-customer/commit/0115bd7))


### Features

* give control over params and result properties to module's validation schema ([56ce4fa](https://git.softwaregroup.com/ut5/ut-customer/commit/56ce4fa))
* simplify validation declaration ([7a893be](https://git.softwaregroup.com/ut5/ut-customer/commit/7a893be))



<a name="5.4.4"></a>
## [5.4.4](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.3...v5.4.4) (2016-07-14)


### Bug Fixes

* bump reactstrap dependenvy ([e0cbce0](https://git.softwaregroup.com/ut5/ut-customer/commit/e0cbce0))



<a name="5.4.3"></a>
## [5.4.3](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.2...v5.4.3) (2016-07-14)


### Bug Fixes

* improve validations ([11961f3](https://git.softwaregroup.com/ut5/ut-customer/commit/11961f3))


### Features

* customers have rights for their own details ([e3b0d9e](https://git.softwaregroup.com/ut5/ut-customer/commit/e3b0d9e))



<a name="5.4.2"></a>
## [5.4.2](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.4.1...v5.4.2) (2016-07-14)


### Bug Fixes

* **MCTUNE-241:** Error 403 in Customer Management module ([d149517](https://git.softwaregroup.com/ut5/ut-customer/commit/d149517))
* bugfix_MCTUNE-255 ([8f59f4f](https://git.softwaregroup.com/ut5/ut-customer/commit/8f59f4f))
* MCTUNE-227 ([9f95c2e](https://git.softwaregroup.com/ut5/ut-customer/commit/9f95c2e))
* MCTUNE-250 ([1f3e4b3](https://git.softwaregroup.com/ut5/ut-customer/commit/1f3e4b3))
* MCTUNE-258 ([3a557a7](https://git.softwaregroup.com/ut5/ut-customer/commit/3a557a7))
* MCTUNE-258 (2nd attempt) ([1fa1a93](https://git.softwaregroup.com/ut5/ut-customer/commit/1fa1a93))


### Features

* add new parameter for phone ([7e20b5c](https://git.softwaregroup.com/ut5/ut-customer/commit/7e20b5c))



<a name="5.4.1"></a>
## [5.4.1](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.83...v5.4.1) (2016-07-11)


### Bug Fixes

* **MCTUNE-222:** Use a procedure that returns single result for OTP check. ([1792916](https://git.softwaregroup.com/ut5/ut-customer/commit/1792916))
* **MCTUNE:241:** Error 403 in Customer Management module ([83fbae4](https://git.softwaregroup.com/ut5/ut-customer/commit/83fbae4))
* fix linting ([0fd5a6e](https://git.softwaregroup.com/ut5/ut-customer/commit/0fd5a6e))


### Features

* upgrade dependencies ([fe8fbfd](https://git.softwaregroup.com/ut5/ut-customer/commit/fe8fbfd))



<a name="5.3.83"></a>
## [5.3.83](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.82...v5.3.83) (2016-07-08)


### Bug Fixes

* lint ([8137c10](https://git.softwaregroup.com/ut5/ut-customer/commit/8137c10))
* remove number formats in settings screen for next build ([1f1b259](https://git.softwaregroup.com/ut5/ut-customer/commit/1f1b259))
* **MCTUNE-228:** Make OTP to send SMS based on the MNO. ([fef81ba](https://git.softwaregroup.com/ut5/ut-customer/commit/fef81ba))
* **phone.update:** add mnoId ([db70ec3](https://git.softwaregroup.com/ut5/ut-customer/commit/db70ec3))



<a name="5.3.82"></a>
## [5.3.82](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.81...v5.3.82) (2016-07-08)


### Bug Fixes

* **phone.add:** add mnoId ([15f763e](https://git.softwaregroup.com/ut5/ut-customer/commit/15f763e))



<a name="5.3.81"></a>
## [5.3.81](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.80...v5.3.81) (2016-07-08)


### Bug Fixes

* add localization for calendar in idField ([d9d5268](https://git.softwaregroup.com/ut5/ut-customer/commit/d9d5268))
* **phone.edit:** input actorId ([2a83470](https://git.softwaregroup.com/ut5/ut-customer/commit/2a83470))
* localize calendar in idField component ([4d98a7a](https://git.softwaregroup.com/ut5/ut-customer/commit/4d98a7a))


### Features

* add localisation settings in settings page ([a83dd54](https://git.softwaregroup.com/ut5/ut-customer/commit/a83dd54))
* add mno in case a new phone is added in process of validation ([e52b58b](https://git.softwaregroup.com/ut5/ut-customer/commit/e52b58b))
* add MNO key for phone validator ([3e4ad06](https://git.softwaregroup.com/ut5/ut-customer/commit/3e4ad06))
* new tables and columns ([9d4c6f9](https://git.softwaregroup.com/ut5/ut-customer/commit/9d4c6f9))
* retunr mno ([d157965](https://git.softwaregroup.com/ut5/ut-customer/commit/d157965))
* return mno ([95499a6](https://git.softwaregroup.com/ut5/ut-customer/commit/95499a6))
* return mno for the country in which is the selected customer ([1300891](https://git.softwaregroup.com/ut5/ut-customer/commit/1300891))



<a name="5.3.80"></a>
## [5.3.80](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.79...v5.3.80) (2016-07-06)



<a name="5.3.79"></a>
## [5.3.79](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.78...v5.3.79) (2016-07-06)


### Bug Fixes

* improve performance in clientFiles when fetching data ([a36aa6b](https://git.softwaregroup.com/ut5/ut-customer/commit/a36aa6b))
* unify centralized loading and error popups ([78b5772](https://git.softwaregroup.com/ut5/ut-customer/commit/78b5772))


### Features

* check for the nationality ([8e97e69](https://git.softwaregroup.com/ut5/ut-customer/commit/8e97e69))



<a name="5.3.78"></a>
## [5.3.78](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.77...v5.3.78) (2016-06-30)


### Bug Fixes

* fix ID photo upload ([19c3b0a](https://git.softwaregroup.com/ut5/ut-customer/commit/19c3b0a))


### Features

* move header container from ut-customer to impl for reuse ([8705a26](https://git.softwaregroup.com/ut5/ut-customer/commit/8705a26))



<a name="5.3.77"></a>
## [5.3.77](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.76...v5.3.77) (2016-06-29)


### Bug Fixes

* MCTUNE-101 ([7040529](https://git.softwaregroup.com/ut5/ut-customer/commit/7040529))



<a name="5.3.76"></a>
## [5.3.76](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.75...v5.3.76) (2016-06-29)


### Bug Fixes

* change phonemodel and computermodel to nvarchar ([b385d24](https://git.softwaregroup.com/ut5/ut-customer/commit/b385d24))
* fix attachment upload when document already exists but has no attachment ([8c781fe](https://git.softwaregroup.com/ut5/ut-customer/commit/8c781fe))
* fix bio login failure bug ([07f002f](https://git.softwaregroup.com/ut5/ut-customer/commit/07f002f))
* fix calls when adding new document or address when updating client file ([ac37fac](https://git.softwaregroup.com/ut5/ut-customer/commit/ac37fac))
* fix customer.file.update to add new id_card document ([a52b776](https://git.softwaregroup.com/ut5/ut-customer/commit/a52b776))
* implement the correct usage of checkPermission ([45f74ac](https://git.softwaregroup.com/ut5/ut-customer/commit/45f74ac))
* move some icons to upload component ([0e91564](https://git.softwaregroup.com/ut5/ut-customer/commit/0e91564))
* prepare router for modular implementation ([989c658](https://git.softwaregroup.com/ut5/ut-customer/commit/989c658))
* prepare routing ([9d7e811](https://git.softwaregroup.com/ut5/ut-customer/commit/9d7e811))
* refactoring and url prettifying ([79f3e7f](https://git.softwaregroup.com/ut5/ut-customer/commit/79f3e7f))
* **MCTUNE-216:** Wrong text is displayed for already enrolled customer in Fingerprints field ([66a1f32](https://git.softwaregroup.com/ut5/ut-customer/commit/66a1f32))
* **MCTUNE-217:** In the Calendar box Today button does not work ([3c73aa7](https://git.softwaregroup.com/ut5/ut-customer/commit/3c73aa7))
* **organization.add:** check for disabled organizations ([3e29a8a](https://git.softwaregroup.com/ut5/ut-customer/commit/3e29a8a))
* refactoring to adopt loan module integration ([16c4a10](https://git.softwaregroup.com/ut5/ut-customer/commit/16c4a10))
* remove dependency to ut-front ([ddd916e](https://git.softwaregroup.com/ut5/ut-customer/commit/ddd916e))
* remove empty css ([f45169b](https://git.softwaregroup.com/ut5/ut-customer/commit/f45169b))
* store attachments before calling customer.attachment.add ([da8f9f8](https://git.softwaregroup.com/ut5/ut-customer/commit/da8f9f8))
* user friendly fingerprint indexes displayed ([4c872f7](https://git.softwaregroup.com/ut5/ut-customer/commit/4c872f7))


### Features

* add attachment to existing document ([417e49d](https://git.softwaregroup.com/ut5/ut-customer/commit/417e49d))
* add customer app wrapping component to implement custom logic on high level ([94eb6bd](https://git.softwaregroup.com/ut5/ut-customer/commit/94eb6bd))
* add new icons and change up pink arrow in dropdown ([2486ead](https://git.softwaregroup.com/ut5/ut-customer/commit/2486ead))
* new column country code ([cdfadc2](https://git.softwaregroup.com/ut5/ut-customer/commit/cdfadc2))



<a name="5.3.75"></a>
## [5.3.75](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.74...v5.3.75) (2016-06-24)


### Bug Fixes

* **MCTUNE-193:** Nationality field - missing validation ([191436c](https://git.softwaregroup.com/ut5/ut-customer/commit/191436c))
* change error message ([da1fe61](https://git.softwaregroup.com/ut5/ut-customer/commit/da1fe61))
* **MCTUNE-200:** When bio login failed and click on try again, cannot print finger again. ([b401dbb](https://git.softwaregroup.com/ut5/ut-customer/commit/b401dbb))
* get only enabled ([f5a8aea](https://git.softwaregroup.com/ut5/ut-customer/commit/f5a8aea))
* revert nationality dropdown in idField ([be0af5d](https://git.softwaregroup.com/ut5/ut-customer/commit/be0af5d))
* **MCTUNE-201:** not appropriate message when enroll a different fingers ([d3bd030](https://git.softwaregroup.com/ut5/ut-customer/commit/d3bd030))
* **organization.lock:** input isEnabled ([9a0547b](https://git.softwaregroup.com/ut5/ut-customer/commit/9a0547b))
* **organization.remove:** check for roles visibleFor ([6db55ef](https://git.softwaregroup.com/ut5/ut-customer/commit/6db55ef))



<a name="5.3.74"></a>
## [5.3.74](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.73...v5.3.74) (2016-06-23)


### Bug Fixes

* missing rollback ([6db6896](https://git.softwaregroup.com/ut5/ut-customer/commit/6db6896))



<a name="5.3.73"></a>
## [5.3.73](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.72...v5.3.73) (2016-06-23)


### Bug Fixes

* error message ([a6e863a](https://git.softwaregroup.com/ut5/ut-customer/commit/a6e863a))
* **MCTUNE-168:** Rejected tab screen - Agency text does not appear ([8c84ece](https://git.softwaregroup.com/ut5/ut-customer/commit/8c84ece))
* **MCTUNE-178:** Wrong text for proof of residency, signature, profile picture appears on the right side of the screen ([d9b6913](https://git.softwaregroup.com/ut5/ut-customer/commit/d9b6913))
* quick fix to initialize password or bio login screen depending on login policy ([3d5b990](https://git.softwaregroup.com/ut5/ut-customer/commit/3d5b990))
* **MCTUNE-183:** Can validate a phone number with fewer characters ([187c7fb](https://git.softwaregroup.com/ut5/ut-customer/commit/187c7fb))


### Features

* changes in lock and delete ([1c4766c](https://git.softwaregroup.com/ut5/ut-customer/commit/1c4766c))



<a name="5.3.72"></a>
## [5.3.72](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.71...v5.3.72) (2016-06-23)


### Bug Fixes

* MCTUNE-101 ([729dc64](https://git.softwaregroup.com/ut5/ut-customer/commit/729dc64))



<a name="5.3.71"></a>
## [5.3.71](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.70...v5.3.71) (2016-06-22)


### Bug Fixes

* force logout when wrong session ([d3631fc](https://git.softwaregroup.com/ut5/ut-customer/commit/d3631fc))
* **MCTUNE-162:** Bio enrollment drop down menu - does not work ([38f7071](https://git.softwaregroup.com/ut5/ut-customer/commit/38f7071))
* **t24:** Add BIO.ENROL.STAT field based of current enrolment status. ([1eb8161](https://git.softwaregroup.com/ut5/ut-customer/commit/1eb8161))
* **t24:** Blocking customer now update changed customer fields in T24 (just like approve). Block and approve (unblock) also update field BLOCKED field alongside POSTING.RESTRICT field. ([4c57182](https://git.softwaregroup.com/ut5/ut-customer/commit/4c57182))



<a name="5.3.70"></a>
## [5.3.70](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.69...v5.3.70) (2016-06-22)


### Bug Fixes

* **MCTUNE-156:** In Customer Settings when you have more than one role selected, you see doubled the same permissions ([bc157dd](https://git.softwaregroup.com/ut5/ut-customer/commit/bc157dd))



<a name="5.3.69"></a>
## [5.3.69](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.68...v5.3.69) (2016-06-22)


### Bug Fixes

* add regex validation when validating phone number ([97da3a1](https://git.softwaregroup.com/ut5/ut-customer/commit/97da3a1))
* bug fix MCTUNE-168 ([8496312](https://git.softwaregroup.com/ut5/ut-customer/commit/8496312))
* hide button when phone validation fails in phoneValidator component ([5eefa21](https://git.softwaregroup.com/ut5/ut-customer/commit/5eefa21))
* prevent sending invalid date in idField ([7c08b9a](https://git.softwaregroup.com/ut5/ut-customer/commit/7c08b9a))
* **MCTUNE-166:** error when enroll a fingerprint ([a443f18](https://git.softwaregroup.com/ut5/ut-customer/commit/a443f18))


### Features

* add simple validation for changing password ([d7843ca](https://git.softwaregroup.com/ut5/ut-customer/commit/d7843ca))
* **organization.get:** added cbs name ([05f4e95](https://git.softwaregroup.com/ut5/ut-customer/commit/05f4e95))



<a name="5.3.68"></a>
## [5.3.68](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.67...v5.3.68) (2016-06-21)


### Bug Fixes

* fix mozilla specific styles ([4862e93](https://git.softwaregroup.com/ut5/ut-customer/commit/4862e93))
* move temporary bio login solution from ut-identity to implementation ([d56f0dc](https://git.softwaregroup.com/ut5/ut-customer/commit/d56f0dc))


### Features

* add validation styles to the input component ([acf5a64](https://git.softwaregroup.com/ut5/ut-customer/commit/acf5a64))
* remove useless dependecy from storybook ([f393e10](https://git.softwaregroup.com/ut5/ut-customer/commit/f393e10))



<a name="5.3.67"></a>
## [5.3.67](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.66...v5.3.67) (2016-06-21)


### Bug Fixes

* **MCTUNE-95:** Mozilla Firefox - edit ID information fields - OK button did not work ([8da9ff6](https://git.softwaregroup.com/ut5/ut-customer/commit/8da9ff6))
* fix broken plugin styles by showing 'today' link ([95f6897](https://git.softwaregroup.com/ut5/ut-customer/commit/95f6897))
* improve error handling when clientFile number in url is wrong ([213dbf9](https://git.softwaregroup.com/ut5/ut-customer/commit/213dbf9))
* pagination fixes ([d41236d](https://git.softwaregroup.com/ut5/ut-customer/commit/d41236d))
* show 404 when clientFile number in url is wrong ([616518f](https://git.softwaregroup.com/ut5/ut-customer/commit/616518f))



<a name="5.3.66"></a>
## [5.3.66](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.65...v5.3.66) (2016-06-20)


### Bug Fixes

* add missing traslations ([3197713](https://git.softwaregroup.com/ut5/ut-customer/commit/3197713))
* add translations in bio registration module ([e44b00d](https://git.softwaregroup.com/ut5/ut-customer/commit/e44b00d))
* transalte only enabled itemNames ([82c49a9](https://git.softwaregroup.com/ut5/ut-customer/commit/82c49a9))
* value to string ([03eade1](https://git.softwaregroup.com/ut5/ut-customer/commit/03eade1))


### Features

* refactor language change to use new procedure ([0b64b68](https://git.softwaregroup.com/ut5/ut-customer/commit/0b64b68))
* use new procedure to change language ([2491d1b](https://git.softwaregroup.com/ut5/ut-customer/commit/2491d1b))



<a name="5.3.65"></a>
## [5.3.65](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.64...v5.3.65) (2016-06-20)


### Bug Fixes

* add arrow for up state for the dropdown menu ([71913e1](https://git.softwaregroup.com/ut5/ut-customer/commit/71913e1))
* add dynamical information to settings screen ([9e0b1c0](https://git.softwaregroup.com/ut5/ut-customer/commit/9e0b1c0))
* add phoneModel and computeModel ([872198e](https://git.softwaregroup.com/ut5/ut-customer/commit/872198e))
* bug with Cyrillic ([0e1780d](https://git.softwaregroup.com/ut5/ut-customer/commit/0e1780d))
* bump react-dropzone version ([65c14c3](https://git.softwaregroup.com/ut5/ut-customer/commit/65c14c3))
* cbs/country refactoring ([78c3445](https://git.softwaregroup.com/ut5/ut-customer/commit/78c3445))
* fix login logic ([1549402](https://git.softwaregroup.com/ut5/ut-customer/commit/1549402))
* format date when read only (MCTUNE-148) ([64eff40](https://git.softwaregroup.com/ut5/ut-customer/commit/64eff40))
* list permissions in settings screen ([1c1a023](https://git.softwaregroup.com/ut5/ut-customer/commit/1c1a023))
* login logic and front-end permissions refining ([6fcdb4a](https://git.softwaregroup.com/ut5/ut-customer/commit/6fcdb4a))
* no need to drop db ([40d39a4](https://git.softwaregroup.com/ut5/ut-customer/commit/40d39a4))
* optimization ([3d2d60c](https://git.softwaregroup.com/ut5/ut-customer/commit/3d2d60c))
* phone validation prefix correct handling ([d6251ac](https://git.softwaregroup.com/ut5/ut-customer/commit/d6251ac))
* remove bio from customer and add to user ([a604fa8](https://git.softwaregroup.com/ut5/ut-customer/commit/a604fa8))
* searchResults bug storing old search criteria ([84fecce](https://git.softwaregroup.com/ut5/ut-customer/commit/84fecce))
* upload the selected image not the previously canceled one (MCTUNE-122,MCTUNE-121) ([628dae7](https://git.softwaregroup.com/ut5/ut-customer/commit/628dae7))
* **customer:** Add phonePrefix to customer ([57b8b84](https://git.softwaregroup.com/ut5/ut-customer/commit/57b8b84))
* **MCTUNE-138:** After re-search - shows results from the last clicked page, not from the start page ([c479296](https://git.softwaregroup.com/ut5/ut-customer/commit/c479296))
* **person:** save phone and computer model ([f0bd2cb](https://git.softwaregroup.com/ut5/ut-customer/commit/f0bd2cb))
* **t24:** Add approved phone to T24 CONF.TEL.NO field. ([30b8bbc](https://git.softwaregroup.com/ut5/ut-customer/commit/30b8bbc))
* **t24:** Add bio field to BIO.ENROLL.FLAG and BIO.ENROLL.DATE. ([a1759fa](https://git.softwaregroup.com/ut5/ut-customer/commit/a1759fa))
* **t24:** Make customer update and block to work with multiple T24. ([b5bd346](https://git.softwaregroup.com/ut5/ut-customer/commit/b5bd346))


### Features

* add country.fetch and country.get ([7ee0dae](https://git.softwaregroup.com/ut5/ut-customer/commit/7ee0dae))
* cache the loader for uploading images ([9427e9f](https://git.softwaregroup.com/ut5/ut-customer/commit/9427e9f))



<a name="5.3.64"></a>
## [5.3.64](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.63...v5.3.64) (2016-06-17)


### Bug Fixes

* add cbsystem ([3cec741](https://git.softwaregroup.com/ut5/ut-customer/commit/3cec741))
* bio enrolment fixes ([43a628c](https://git.softwaregroup.com/ut5/ut-customer/commit/43a628c))
* bug change customer state when validating phone ([e3604f1](https://git.softwaregroup.com/ut5/ut-customer/commit/e3604f1))
* don't reset tab when unmounting files to approve grid ([6eb969a](https://git.softwaregroup.com/ut5/ut-customer/commit/6eb969a))
* hover styles on idField ([4cf5995](https://git.softwaregroup.com/ut5/ut-customer/commit/4cf5995))
* kyc labels ([9d3d140](https://git.softwaregroup.com/ut5/ut-customer/commit/9d3d140))
* reset bioRegistration button ([c972540](https://git.softwaregroup.com/ut5/ut-customer/commit/c972540))
* set allowed filetypes to be: jpg,jpeg,png for file upload (MCTUNE-122) ([445b0d0](https://git.softwaregroup.com/ut5/ut-customer/commit/445b0d0))
* **MCTUNE-135:** update customer state when validating phone and refetch customer file data ([3f97274](https://git.softwaregroup.com/ut5/ut-customer/commit/3f97274))



<a name="5.3.63"></a>
## [5.3.63](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.62...v5.3.63) (2016-06-16)


### Bug Fixes

* display current user's names in settings page (MCTUNE-116) ([6411dc0](https://git.softwaregroup.com/ut5/ut-customer/commit/6411dc0))
* fix bug input changing caret in some conditions ([da6a152](https://git.softwaregroup.com/ut5/ut-customer/commit/da6a152))
* improve front end permissions handling ([8e600ef](https://git.softwaregroup.com/ut5/ut-customer/commit/8e600ef))
* remove check for customer.file.getCount ([3048864](https://git.softwaregroup.com/ut5/ut-customer/commit/3048864))


### Features

* add permissions to front-end ([b5bbc67](https://git.softwaregroup.com/ut5/ut-customer/commit/b5bbc67))
* back button ignores subpages for clientfile ([dc6d021](https://git.softwaregroup.com/ut5/ut-customer/commit/dc6d021))
* more front-end restrictions related to permissions ([cd9d8a0](https://git.softwaregroup.com/ut5/ut-customer/commit/cd9d8a0))



<a name="5.3.62"></a>
## [5.3.62](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.61...v5.3.62) (2016-06-16)


### Bug Fixes

* address column ([6e4a72d](https://git.softwaregroup.com/ut5/ut-customer/commit/6e4a72d))
* fix reset on bioRegistration ([04b754b](https://git.softwaregroup.com/ut5/ut-customer/commit/04b754b))
* lint ([fcca427](https://git.softwaregroup.com/ut5/ut-customer/commit/fcca427))
* remove microcred branch creation from module seed ([7b39665](https://git.softwaregroup.com/ut5/ut-customer/commit/7b39665))


### Features

* add new translations ([9a605dd](https://git.softwaregroup.com/ut5/ut-customer/commit/9a605dd))



<a name="5.3.61"></a>
## [5.3.61](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.60...v5.3.61) (2016-06-16)



<a name="5.3.60"></a>
## [5.3.60](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.59...v5.3.60) (2016-06-16)


### Bug Fixes

* createdBy field ([1331c96](https://git.softwaregroup.com/ut5/ut-customer/commit/1331c96))
* phoneValidator when adding new phonenumber bug ([1c7c711](https://git.softwaregroup.com/ut5/ut-customer/commit/1c7c711))


### Features

* improve error handling on a global level ([623d7d1](https://git.softwaregroup.com/ut5/ut-customer/commit/623d7d1))



<a name="5.3.59"></a>
## [5.3.59](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.58...v5.3.59) (2016-06-15)


### Bug Fixes

* **t24:** Fix phone number field to allow multiple phone numbers. ([434efa0](https://git.softwaregroup.com/ut5/ut-customer/commit/434efa0))


### Features

* put order of the phones - personal, home, work ([b7723a4](https://git.softwaregroup.com/ut5/ut-customer/commit/b7723a4))



<a name="5.3.58"></a>
## [5.3.58](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.57...v5.3.58) (2016-06-15)


### Bug Fixes

* crashing pages ([dba049c](https://git.softwaregroup.com/ut5/ut-customer/commit/dba049c))



<a name="5.3.57"></a>
## [5.3.57](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.56...v5.3.57) (2016-06-15)


### Features

* add new step for preview selected image ([02906c4](https://git.softwaregroup.com/ut5/ut-customer/commit/02906c4))



<a name="5.3.56"></a>
## [5.3.56](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.55...v5.3.56) (2016-06-15)


### Bug Fixes

* add translations to all components ([891159b](https://git.softwaregroup.com/ut5/ut-customer/commit/891159b))
* translations texts ([95ee263](https://git.softwaregroup.com/ut5/ut-customer/commit/95ee263))



<a name="5.3.55"></a>
## [5.3.55](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.54...v5.3.55) (2016-06-15)


### Bug Fixes

* bug fix jira: MCTUNE-89 ([e9ffadc](https://git.softwaregroup.com/ut5/ut-customer/commit/e9ffadc))
* bug with id number in search reslts ([57d0fea](https://git.softwaregroup.com/ut5/ut-customer/commit/57d0fea))
* changePassword in settings page bug displaying old password value ([d0f6980](https://git.softwaregroup.com/ut5/ut-customer/commit/d0f6980))
* **t24:** Fix some field mapping on T24 ([43e2ea3](https://git.softwaregroup.com/ut5/ut-customer/commit/43e2ea3))
* disable bio registration if customer has no customerNumber ([15188c4](https://git.softwaregroup.com/ut5/ut-customer/commit/15188c4))
* hide buttons when uploadProgress in upload component ([ab38c97](https://git.softwaregroup.com/ut5/ut-customer/commit/ab38c97))
* hide customer number if not available ([ff8bbae](https://git.softwaregroup.com/ut5/ut-customer/commit/ff8bbae))
* refactor upload ([95ec039](https://git.softwaregroup.com/ut5/ut-customer/commit/95ec039))
* when return from crop step hide the crop functionality ([080d77e](https://git.softwaregroup.com/ut5/ut-customer/commit/080d77e))


### Features

* add new customer categories used in madagascar ([7653b69](https://git.softwaregroup.com/ut5/ut-customer/commit/7653b69))
* get screenshot with higher dimensions ([9217f9d](https://git.softwaregroup.com/ut5/ut-customer/commit/9217f9d))
* if address type is not passed put as default "home" ([a98bceb](https://git.softwaregroup.com/ut5/ut-customer/commit/a98bceb))
* return only first phone and address ([c00d832](https://git.softwaregroup.com/ut5/ut-customer/commit/c00d832))
* set max width to the image from the webcam ([8b624c0](https://git.softwaregroup.com/ut5/ut-customer/commit/8b624c0))



<a name="5.3.54"></a>
## [5.3.54](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.53...v5.3.54) (2016-06-15)


### Bug Fixes

* phoneValidator bug when change to new customer old data is displayed ([57b7e48](https://git.softwaregroup.com/ut5/ut-customer/commit/57b7e48))



<a name="5.3.53"></a>
## [5.3.53](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.52...v5.3.53) (2016-06-15)


### Bug Fixes

* comment t24 communication upon customer file approval/block until finishing integration ([933fdd6](https://git.softwaregroup.com/ut5/ut-customer/commit/933fdd6))
* fix aligning in firefox ([fb91cfe](https://git.softwaregroup.com/ut5/ut-customer/commit/fb91cfe))
* in adding and in search to return one phone ([95bd912](https://git.softwaregroup.com/ut5/ut-customer/commit/95bd912))
* login submit when no password ([4068ae2](https://git.softwaregroup.com/ut5/ut-customer/commit/4068ae2))
* refresh clientfiles count when changing the page ([b3691c6](https://git.softwaregroup.com/ut5/ut-customer/commit/b3691c6))


### Features

* add id card ([9b99771](https://git.softwaregroup.com/ut5/ut-customer/commit/9b99771))
* add udf when adding new ([4abba90](https://git.softwaregroup.com/ut5/ut-customer/commit/4abba90))
* change login title ([ae10a66](https://git.softwaregroup.com/ut5/ut-customer/commit/ae10a66))



<a name="5.3.52"></a>
## [5.3.52](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.51...v5.3.52) (2016-06-15)


### Bug Fixes

* fix freezing page when click on image upload ([e3ec062](https://git.softwaregroup.com/ut5/ut-customer/commit/e3ec062))



<a name="5.3.51"></a>
## [5.3.51](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.50...v5.3.51) (2016-06-14)


### Bug Fixes

* bug when language is not loading after login ([95aa567](https://git.softwaregroup.com/ut5/ut-customer/commit/95aa567))
* client files grid agency filter ([1ae42be](https://git.softwaregroup.com/ut5/ut-customer/commit/1ae42be))
* date format in clientFiles ([ce1643a](https://git.softwaregroup.com/ut5/ut-customer/commit/ce1643a))
* datePicker styles in idField component ([c5fb5b0](https://git.softwaregroup.com/ut5/ut-customer/commit/c5fb5b0))
* display bio error message from scanner server ([b19a164](https://git.softwaregroup.com/ut5/ut-customer/commit/b19a164))
* escape press on datePicker in idField component ([995a011](https://git.softwaregroup.com/ut5/ut-customer/commit/995a011))
* idField date to depend on locale ([84a5155](https://git.softwaregroup.com/ut5/ut-customer/commit/84a5155))
* **t24-integration:** Finish the T24 integration for update and block based on simple logic (without timeout guarantee). ([ad8ef45](https://git.softwaregroup.com/ut5/ut-customer/commit/ad8ef45))
* reset search params when changing tab in clientFiles and fix translations ([7b92014](https://git.softwaregroup.com/ut5/ut-customer/commit/7b92014))
* select only one file for upload ([d7883ae](https://git.softwaregroup.com/ut5/ut-customer/commit/d7883ae))
* **organization.graphFetch:** deleted organizations ([2ef8ec1](https://git.softwaregroup.com/ut5/ut-customer/commit/2ef8ec1))
* small changes to customer.customer.fetch ([9e23d0c](https://git.softwaregroup.com/ut5/ut-customer/commit/9e23d0c))
* stateCount in clientFiles ([492e1b5](https://git.softwaregroup.com/ut5/ut-customer/commit/492e1b5))


### Features

* **customer.fetch:** show customer state count ([13010b8](https://git.softwaregroup.com/ut5/ut-customer/commit/13010b8))
* add phone when edit ([ac6d26e](https://git.softwaregroup.com/ut5/ut-customer/commit/ac6d26e))
* clear input after searching ([b611ad4](https://git.softwaregroup.com/ut5/ut-customer/commit/b611ad4))



<a name="5.3.50"></a>
## [5.3.50](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.49...v5.3.50) (2016-06-10)


### Bug Fixes

* lint ([ce87edd](https://git.softwaregroup.com/ut5/ut-customer/commit/ce87edd))


### Features

* change primary language from settings page ([7ea6682](https://git.softwaregroup.com/ut5/ut-customer/commit/7ea6682))



<a name="5.3.49"></a>
## [5.3.49](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.48...v5.3.49) (2016-06-10)


### Bug Fixes

* **customer.organization:** changed primaryLanguage column type&name ([df84a65](https://git.softwaregroup.com/ut5/ut-customer/commit/df84a65))
* **organization.get:** return parent id ([bf7ef88](https://git.softwaregroup.com/ut5/ut-customer/commit/bf7ef88))
* **phone-validation:** Update and validate the phone number. ([132ee63](https://git.softwaregroup.com/ut5/ut-customer/commit/132ee63))
* add phoneID prop to phoneValidation request ([c8577a1](https://git.softwaregroup.com/ut5/ut-customer/commit/c8577a1))
* **t24:** Fix date convertion for Date objects and fix T24 version. ([cfee690](https://git.softwaregroup.com/ut5/ut-customer/commit/cfee690))
* add autofocus on phoneNumberValidator component screens ([4cf4aad](https://git.softwaregroup.com/ut5/ut-customer/commit/4cf4aad))
* bio enrollment and phone validation fixes ([b57b31c](https://git.softwaregroup.com/ut5/ut-customer/commit/b57b31c))
* bio enrollment integration ([ce4a1ba](https://git.softwaregroup.com/ut5/ut-customer/commit/ce4a1ba))
* bug in idField when gender is empty ([86bac1b](https://git.softwaregroup.com/ut5/ut-customer/commit/86bac1b))
* bug when adding ([dfe5238](https://git.softwaregroup.com/ut5/ut-customer/commit/dfe5238))
* client side sorting in clientFiles ([73e7fa5](https://git.softwaregroup.com/ut5/ut-customer/commit/73e7fa5))
* **t24-date-convert:** Parse any recognizable by Date constructor date. ([670b1ae](https://git.softwaregroup.com/ut5/ut-customer/commit/670b1ae))
* **ui-clientFile:** Use update SP result containing non-array version of customer ([c71a2db](https://git.softwaregroup.com/ut5/ut-customer/commit/c71a2db))
* improve bio registration popup ([da98e03](https://git.softwaregroup.com/ut5/ut-customer/commit/da98e03))
* load global css and local css with hash in storybook ([7d3b6ca](https://git.softwaregroup.com/ut5/ut-customer/commit/7d3b6ca))
* phone number to be clickable ([8e6b8bf](https://git.softwaregroup.com/ut5/ut-customer/commit/8e6b8bf))
* refactor Bio modal ([758ef71](https://git.softwaregroup.com/ut5/ut-customer/commit/758ef71))
* show only one arrow in dataGrid when sorting ([2a56c61](https://git.softwaregroup.com/ut5/ut-customer/commit/2a56c61))
* sorting and filtering in flientFiles ([4aa1343](https://git.softwaregroup.com/ut5/ut-customer/commit/4aa1343))
* submit when empty in idField component ([ac94554](https://git.softwaregroup.com/ut5/ut-customer/commit/ac94554))


### Features

* add calendar component and use it in the form ([9da4d3a](https://git.softwaregroup.com/ut5/ut-customer/commit/9da4d3a))
* add code for some very long values ([7318c65](https://git.softwaregroup.com/ut5/ut-customer/commit/7318c65))
* add select filter in the datagrid ([b16f412](https://git.softwaregroup.com/ut5/ut-customer/commit/b16f412))
* add simple bio check procedure to verify if customers is bio enrolled ([e3d41df](https://git.softwaregroup.com/ut5/ut-customer/commit/e3d41df))
* fix translation text ([ad07a41](https://git.softwaregroup.com/ut5/ut-customer/commit/ad07a41))
* new filters and adds sorting ([bb64b2c](https://git.softwaregroup.com/ut5/ut-customer/commit/bb64b2c))
* new SP for phone validation ([541ddb6](https://git.softwaregroup.com/ut5/ut-customer/commit/541ddb6))
* prepare customer.bio.add and customer.bio.check APIs ([76d7f8a](https://git.softwaregroup.com/ut5/ut-customer/commit/76d7f8a))
* return that is single result ([16efde8](https://git.softwaregroup.com/ut5/ut-customer/commit/16efde8))
* set autofocus to the login steps ([8c07dd8](https://git.softwaregroup.com/ut5/ut-customer/commit/8c07dd8))
* **organization.fetch:** return parent info ([24fc71c](https://git.softwaregroup.com/ut5/ut-customer/commit/24fc71c))



<a name="5.3.48"></a>
## [5.3.48](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.47...v5.3.48) (2016-06-10)


### Bug Fixes

* **Item translation:** load translations only if login is successful ([2b35281](https://git.softwaregroup.com/ut5/ut-customer/commit/2b35281))
* **Item translations:** check for translations only after login ([ca43cf3](https://git.softwaregroup.com/ut5/ut-customer/commit/ca43cf3))
* lint ([00af6cb](https://git.softwaregroup.com/ut5/ut-customer/commit/00af6cb))


### Features

* **Item translations:** load primary language from database and translate UI interface ([4d5144b](https://git.softwaregroup.com/ut5/ut-customer/commit/4d5144b))
* get primary language id from identity.check response ([518876a](https://git.softwaregroup.com/ut5/ut-customer/commit/518876a))



<a name="5.3.47"></a>
## [5.3.47](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.46...v5.3.47) (2016-06-09)


### Bug Fixes

* add autofocus on phoneNumberValidator component screens ([0684d9c](https://git.softwaregroup.com/ut5/ut-customer/commit/0684d9c))
* **customer.organization:** changed primaryLanguage column type&name ([34fa479](https://git.softwaregroup.com/ut5/ut-customer/commit/34fa479))
* add dependencies ([d4a4639](https://git.softwaregroup.com/ut5/ut-customer/commit/d4a4639))
* **phone-validation:** Update and validate the phone number. ([c4ad34a](https://git.softwaregroup.com/ut5/ut-customer/commit/c4ad34a))
* add phoneID prop to phoneValidation request ([ab0a3e8](https://git.softwaregroup.com/ut5/ut-customer/commit/ab0a3e8))
* client side sorting in clientFiles ([a2d8f59](https://git.softwaregroup.com/ut5/ut-customer/commit/a2d8f59))
* improve bio registration popup ([ed61c4d](https://git.softwaregroup.com/ut5/ut-customer/commit/ed61c4d))
* load global css and local css with hash in storybook ([657dfb8](https://git.softwaregroup.com/ut5/ut-customer/commit/657dfb8))
* phone number to be clickable ([0d019a9](https://git.softwaregroup.com/ut5/ut-customer/commit/0d019a9))
* refactor Bio modal ([b5d39eb](https://git.softwaregroup.com/ut5/ut-customer/commit/b5d39eb))
* show only one arrow in dataGrid when sorting ([71cb78f](https://git.softwaregroup.com/ut5/ut-customer/commit/71cb78f))
* submit when empty in idField component ([9be1c2c](https://git.softwaregroup.com/ut5/ut-customer/commit/9be1c2c))


### Features

* add calendar component and use it in the form ([8593da9](https://git.softwaregroup.com/ut5/ut-customer/commit/8593da9))
* add code for some very long values ([28e964b](https://git.softwaregroup.com/ut5/ut-customer/commit/28e964b))
* add select filter in the datagrid ([6acc4a4](https://git.softwaregroup.com/ut5/ut-customer/commit/6acc4a4))
* add simple bio check procedure to verify if customers is bio enrolled ([57d4c9e](https://git.softwaregroup.com/ut5/ut-customer/commit/57d4c9e))
* fix translation text ([2976cf2](https://git.softwaregroup.com/ut5/ut-customer/commit/2976cf2))
* new filters and adds sorting ([d689159](https://git.softwaregroup.com/ut5/ut-customer/commit/d689159))
* new SP for phone validation ([3670847](https://git.softwaregroup.com/ut5/ut-customer/commit/3670847))
* prepare customer.bio.add and customer.bio.check APIs ([d08500c](https://git.softwaregroup.com/ut5/ut-customer/commit/d08500c))
* set autofocus to the login steps ([fe78c3f](https://git.softwaregroup.com/ut5/ut-customer/commit/fe78c3f))



<a name="5.3.46"></a>
## [5.3.46](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.45...v5.3.46) (2016-06-08)


### Bug Fixes

* update dependencies ([8e53b20](https://git.softwaregroup.com/ut5/ut-customer/commit/8e53b20))
* upgrade lodash ([0fd0e36](https://git.softwaregroup.com/ut5/ut-customer/commit/0fd0e36))



<a name="5.3.45"></a>
## [5.3.45](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.44...v5.3.45) (2016-06-07)


### Bug Fixes

* correct spacing between items ([1150f73](https://git.softwaregroup.com/ut5/ut-customer/commit/1150f73))
* improve phone validator behavior plus refactoring ([3c9f09f](https://git.softwaregroup.com/ut5/ut-customer/commit/3c9f09f))
* move script logic to module ([073733d](https://git.softwaregroup.com/ut5/ut-customer/commit/073733d))
* show searchResultText component when searching instead of text ([58c8faa](https://git.softwaregroup.com/ut5/ut-customer/commit/58c8faa))
* tabset in clientFiles and show header in grid when no results ([8bd0448](https://git.softwaregroup.com/ut5/ut-customer/commit/8bd0448))
* **organization.edit:** transaction ([d0884b6](https://git.softwaregroup.com/ut5/ut-customer/commit/d0884b6))
* **person.edit:** edit all fields ([f7a49bb](https://git.softwaregroup.com/ut5/ut-customer/commit/f7a49bb))


### Features

* add croppie css ([0a22c44](https://git.softwaregroup.com/ut5/ut-customer/commit/0a22c44))
* optimize to call one SP ([00a90de](https://git.softwaregroup.com/ut5/ut-customer/commit/00a90de))



<a name="5.3.44"></a>
## [5.3.44](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.43...v5.3.44) (2016-06-07)


### Bug Fixes

* bug fixing ([736c937](https://git.softwaregroup.com/ut5/ut-customer/commit/736c937))
* fix bug when there is no phone in client file and display kyc value ([0645af4](https://git.softwaregroup.com/ut5/ut-customer/commit/0645af4))
* fix customer files screen logic ([7c929a3](https://git.softwaregroup.com/ut5/ut-customer/commit/7c929a3))
* fix customer rejecting functionality and improve dataGrid ([fd8481f](https://git.softwaregroup.com/ut5/ut-customer/commit/fd8481f))
* fix document add status and display images in grid ([47e3dfc](https://git.softwaregroup.com/ut5/ut-customer/commit/47e3dfc))
* fix phone validation and integrate with ut-alert and db ([184009f](https://git.softwaregroup.com/ut5/ut-customer/commit/184009f))
* remove default value for photo in clientCard ([1a4ea33](https://git.softwaregroup.com/ut5/ut-customer/commit/1a4ea33))
* revert profile photo in clientCard ([b6183b0](https://git.softwaregroup.com/ut5/ut-customer/commit/b6183b0))
* show profile photo in clientCard ([c849efc](https://git.softwaregroup.com/ut5/ut-customer/commit/c849efc))
* style idField component when input is required ([53234de](https://git.softwaregroup.com/ut5/ut-customer/commit/53234de))


### Features

* add kycValue in the result ([31ec6de](https://git.softwaregroup.com/ut5/ut-customer/commit/31ec6de))
* add searchResultsText component ([75e0434](https://git.softwaregroup.com/ut5/ut-customer/commit/75e0434))
* change Kyc LEvel and set default values in create tables ([562aa13](https://git.softwaregroup.com/ut5/ut-customer/commit/562aa13))
* improve the select component with option component ([d93e04b](https://git.softwaregroup.com/ut5/ut-customer/commit/d93e04b))
* improve translation ([46ba72b](https://git.softwaregroup.com/ut5/ut-customer/commit/46ba72b))
* split client files into tabset with 3 tabs and 3 configurable grids ([5f433ca](https://git.softwaregroup.com/ut5/ut-customer/commit/5f433ca))
* style the select for bio registration modal ([1540512](https://git.softwaregroup.com/ut5/ut-customer/commit/1540512))
* **i18n:** Load translations from database ([4c60275](https://git.softwaregroup.com/ut5/ut-customer/commit/4c60275))



<a name="5.3.43"></a>
## [5.3.43](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.42...v5.3.43) (2016-06-03)


### Bug Fixes

* add required in IdField component and fix styles for dropdownMenu component ([57aa593](https://git.softwaregroup.com/ut5/ut-customer/commit/57aa593))
* bug fixing ([fc27f39](https://git.softwaregroup.com/ut5/ut-customer/commit/fc27f39))
* fix lint errors ([8ebaf7a](https://git.softwaregroup.com/ut5/ut-customer/commit/8ebaf7a))
* fix the right function to loggin in the storybook ([94927d9](https://git.softwaregroup.com/ut5/ut-customer/commit/94927d9))


### Features

* improve translation ([0f1ede6](https://git.softwaregroup.com/ut5/ut-customer/commit/0f1ede6))



<a name="5.3.42"></a>
## [5.3.42](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.41...v5.3.42) (2016-06-02)


### Bug Fixes

* dropdownmenu styles and line-height in header ([2675121](https://git.softwaregroup.com/ut5/ut-customer/commit/2675121))
* prepare db/t24 logic combination ([bf78861](https://git.softwaregroup.com/ut5/ut-customer/commit/bf78861))
* revert the loader because not all styles must apply to it ([534bbb3](https://git.softwaregroup.com/ut5/ut-customer/commit/534bbb3))


### Features

* change in permissions ([a9a8665](https://git.softwaregroup.com/ut5/ut-customer/commit/a9a8665))
* translate label in en ([11e5e58](https://git.softwaregroup.com/ut5/ut-customer/commit/11e5e58))



<a name="5.3.41"></a>
## [5.3.41](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.39...v5.3.41) (2016-06-02)


### Bug Fixes

* change the z-index for the sidebar ([fb2a9db](https://git.softwaregroup.com/ut5/ut-customer/commit/fb2a9db))
* dropdownmenu icon styles ([7a0ab37](https://git.softwaregroup.com/ut5/ut-customer/commit/7a0ab37))
* improve styles for DropDownMenu component and add text in Text component ([3e3c925](https://git.softwaregroup.com/ut5/ut-customer/commit/3e3c925))
* reasign phonenumber when re-showing phone validation modal ([778d67a](https://git.softwaregroup.com/ut5/ut-customer/commit/778d67a))
* refactor DropDownMenu component and add it to clientFile page ([7b60b31](https://git.softwaregroup.com/ut5/ut-customer/commit/7b60b31))


### Features

* add arrow for hover state on row in the datagrid ([4deb470](https://git.softwaregroup.com/ut5/ut-customer/commit/4deb470))
* add Microcred branch ([763bcca](https://git.softwaregroup.com/ut5/ut-customer/commit/763bcca))
* change camera icon ([6df8e7b](https://git.softwaregroup.com/ut5/ut-customer/commit/6df8e7b))



<a name="5.3.40"></a>
## [5.3.40](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.39...v5.3.40) (2016-06-02)


### Bug Fixes

* dropdownmenu icon styles ([7a0ab37](https://git.softwaregroup.com/ut5/ut-customer/commit/7a0ab37))
* improve styles for DropDownMenu component and add text in Text component ([3e3c925](https://git.softwaregroup.com/ut5/ut-customer/commit/3e3c925))
* refactor DropDownMenu component and add it to clientFile page ([7b60b31](https://git.softwaregroup.com/ut5/ut-customer/commit/7b60b31))



<a name="5.3.39"></a>
## [5.3.39](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.38...v5.3.39) (2016-06-02)


### Bug Fixes

* added auditlog ([29ba5d1](https://git.softwaregroup.com/ut5/ut-customer/commit/29ba5d1))



<a name="5.3.38"></a>
## [5.3.38](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.37...v5.3.38) (2016-06-02)


### Bug Fixes

* added XML param ([07ccfe0](https://git.softwaregroup.com/ut5/ut-customer/commit/07ccfe0))
* better error handling in master reducer ([715ef63](https://git.softwaregroup.com/ut5/ut-customer/commit/715ef63))
* **Upload:** not showing error in console anymore ([d656a6a](https://git.softwaregroup.com/ut5/ut-customer/commit/d656a6a))
* clientFile reducer refactoring ([c35de96](https://git.softwaregroup.com/ut5/ut-customer/commit/c35de96))
* refactor phoneValidatorComponent and encapsulate logic within the component for reusability and ease of maintenance ([8c9223b](https://git.softwaregroup.com/ut5/ut-customer/commit/8c9223b))


### Features

* add required option for input component ([6ba7d32](https://git.softwaregroup.com/ut5/ut-customer/commit/6ba7d32))
* due to parser limitations add values for isEnablad and IsDeleted  fields ([474a6d2](https://git.softwaregroup.com/ut5/ut-customer/commit/474a6d2))
* hide very long menu items ([33e6387](https://git.softwaregroup.com/ut5/ut-customer/commit/33e6387))



<a name="5.3.37"></a>
## [5.3.37](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.36...v5.3.37) (2016-06-01)


### Bug Fixes

* added error return ([f689df0](https://git.softwaregroup.com/ut5/ut-customer/commit/f689df0))
* centralized error messages received from backend and other fixes ([d7d7a5e](https://git.softwaregroup.com/ut5/ut-customer/commit/d7d7a5e))
* change buttons on Otp login depending on input ([d9fe3e2](https://git.softwaregroup.com/ut5/ut-customer/commit/d9fe3e2))
* error in browser when changing login step ([d8362f5](https://git.softwaregroup.com/ut5/ut-customer/commit/d8362f5))
* logout when multiple simultaneous login with hte same user ([3198553](https://git.softwaregroup.com/ut5/ut-customer/commit/3198553))
* postFix styles in sidebar component ([77a29e9](https://git.softwaregroup.com/ut5/ut-customer/commit/77a29e9))
* translations ([58ad921](https://git.softwaregroup.com/ut5/ut-customer/commit/58ad921))
* unsupported actor type ([03e54c1](https://git.softwaregroup.com/ut5/ut-customer/commit/03e54c1))
* update enabled ([1bf2cc9](https://git.softwaregroup.com/ut5/ut-customer/commit/1bf2cc9))
* wrap all text in text component ([c0d0150](https://git.softwaregroup.com/ut5/ut-customer/commit/c0d0150))


### Features

* add the same css loader for storybook as in the implementaion ([aa48b8e](https://git.softwaregroup.com/ut5/ut-customer/commit/aa48b8e))
* display error messages for login in modal ([0b91ce5](https://git.softwaregroup.com/ut5/ut-customer/commit/0b91ce5))
* improve styles for messages in the modal component ([601cc9a](https://git.softwaregroup.com/ut5/ut-customer/commit/601cc9a))
* set EN as default language ([c7088de](https://git.softwaregroup.com/ut5/ut-customer/commit/c7088de))
* style page 404 according to the design ([712fcff](https://git.softwaregroup.com/ut5/ut-customer/commit/712fcff))



<a name="5.3.36"></a>
## [5.3.36](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.35...v5.3.36) (2016-05-31)


### Bug Fixes

* set react version to 15.1.0 ([366c34f](https://git.softwaregroup.com/ut5/ut-customer/commit/366c34f))



<a name="5.3.35"></a>
## [5.3.35](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.34...v5.3.35) (2016-05-31)


### Bug Fixes

* customer, organization TT ([5f13a2b](https://git.softwaregroup.com/ut5/ut-customer/commit/5f13a2b))
* **all SPs:** security check ([c22d06b](https://git.softwaregroup.com/ut5/ut-customer/commit/c22d06b))
* add custom404 page, fix login ([6b9bd24](https://git.softwaregroup.com/ut5/ut-customer/commit/6b9bd24))
* add document ([d24f85c](https://git.softwaregroup.com/ut5/ut-customer/commit/d24f85c))
* alter table ([baa9635](https://git.softwaregroup.com/ut5/ut-customer/commit/baa9635))
* change rights ([df547fc](https://git.softwaregroup.com/ut5/ut-customer/commit/df547fc))
* client files page ([c83091a](https://git.softwaregroup.com/ut5/ut-customer/commit/c83091a))
* remove label component translation ([0afab5a](https://git.softwaregroup.com/ut5/ut-customer/commit/0afab5a))
* remove unused import ([6f41f2b](https://git.softwaregroup.com/ut5/ut-customer/commit/6f41f2b))
* revert to previous ([4ba0e5b](https://git.softwaregroup.com/ut5/ut-customer/commit/4ba0e5b))
* translatiions ([895803a](https://git.softwaregroup.com/ut5/ut-customer/commit/895803a))
* translations ([2f18b9c](https://git.softwaregroup.com/ut5/ut-customer/commit/2f18b9c))


### Features

* add document ([0e36c58](https://git.softwaregroup.com/ut5/ut-customer/commit/0e36c58))
* **organization,person:** new columns - isDeleted,isEnabled ([b63cb69](https://git.softwaregroup.com/ut5/ut-customer/commit/b63cb69))
* change pencil icon with image from internet ([c2c1a12](https://git.softwaregroup.com/ut5/ut-customer/commit/c2c1a12))
* change text for choosing language ([f9c78f1](https://git.softwaregroup.com/ut5/ut-customer/commit/f9c78f1))
* hide lock session link from dropdown menu ([c5bb644](https://git.softwaregroup.com/ut5/ut-customer/commit/c5bb644))
* hide lock session link from dropdown menu ([1df4177](https://git.softwaregroup.com/ut5/ut-customer/commit/1df4177))
* new param ([ff18c4c](https://git.softwaregroup.com/ut5/ut-customer/commit/ff18c4c))



<a name="5.3.34"></a>
## [5.3.34](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.33...v5.3.34) (2016-05-30)


### Bug Fixes

* customer.customer.fetch improvements ([b1685a7](https://git.softwaregroup.com/ut5/ut-customer/commit/b1685a7))
* fix close button for closing search results ([0ed25d2](https://git.softwaregroup.com/ut5/ut-customer/commit/0ed25d2))
* fix customer.customer.fetch logic and dataGrid component ([5319af3](https://git.softwaregroup.com/ut5/ut-customer/commit/5319af3))
* fix not overriding classes bug for pagination ([d572ac3](https://git.softwaregroup.com/ut5/ut-customer/commit/d572ac3))
* language should not be set inside application ([05c522d](https://git.softwaregroup.com/ut5/ut-customer/commit/05c522d))
* translations ([248268f](https://git.softwaregroup.com/ut5/ut-customer/commit/248268f))


### Features

* **organization.edit:** edit roles & parents ([3188d2e](https://git.softwaregroup.com/ut5/ut-customer/commit/3188d2e))
* move pagination to the bottom and style no results page ([8d32f24](https://git.softwaregroup.com/ut5/ut-customer/commit/8d32f24))
* replace image with the new one and adjust css styles ([0675e7a](https://git.softwaregroup.com/ut5/ut-customer/commit/0675e7a))
* style the pagination according to the design ([3deec2e](https://git.softwaregroup.com/ut5/ut-customer/commit/3deec2e))



<a name="5.3.33"></a>
## [5.3.33](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.32...v5.3.33) (2016-05-30)


### Bug Fixes

* add texts in Text component and change some text in english ([32e909f](https://git.softwaregroup.com/ut5/ut-customer/commit/32e909f))
* return correct results by state ([7890467](https://git.softwaregroup.com/ut5/ut-customer/commit/7890467))
* texts to be in english ([fd519a7](https://git.softwaregroup.com/ut5/ut-customer/commit/fd519a7))
* valdiation for button to prevent errors in browser ([3d67220](https://git.softwaregroup.com/ut5/ut-customer/commit/3d67220))


### Features

* add errorModal component to storybook and add improvements to it ([1f905db](https://git.softwaregroup.com/ut5/ut-customer/commit/1f905db))
* add number of pending client files and other improvements ([6322c7c](https://git.softwaregroup.com/ut5/ut-customer/commit/6322c7c))



<a name="5.3.32"></a>
## [5.3.32](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.31...v5.3.32) (2016-05-30)


### Bug Fixes

* add hover icons to dropdownmenu items ([61ea77a](https://git.softwaregroup.com/ut5/ut-customer/commit/61ea77a))
* **file.get:** fixed [@meta](https://github.com/meta) ([e578797](https://git.softwaregroup.com/ut5/ut-customer/commit/e578797))
* blur on tab and escape press ([3211ba0](https://git.softwaregroup.com/ut5/ut-customer/commit/3211ba0))
* error because of using ref ([5c91d5c](https://git.softwaregroup.com/ut5/ut-customer/commit/5c91d5c))
* fix correct styles for dropdown arrow ([f3204eb](https://git.softwaregroup.com/ut5/ut-customer/commit/f3204eb))
* fropdownMenu in storybook ([72c4220](https://git.softwaregroup.com/ut5/ut-customer/commit/72c4220))
* hide cookie check error and fix customer search grid ([0555ff6](https://git.softwaregroup.com/ut5/ut-customer/commit/0555ff6))
* IdFIeld component to have submit button ([07e1108](https://git.softwaregroup.com/ut5/ut-customer/commit/07e1108))
* **address.edit:** changed logic ([d84ccad](https://git.softwaregroup.com/ut5/ut-customer/commit/d84ccad))
* include % in security checks ([0b20f51](https://git.softwaregroup.com/ut5/ut-customer/commit/0b20f51))
* linting ([2c347b7](https://git.softwaregroup.com/ut5/ut-customer/commit/2c347b7))
* new column was added in table type but not in the table ([60128ac](https://git.softwaregroup.com/ut5/ut-customer/commit/60128ac))
* pass $meta when calling linkedSP internally ([c8e6243](https://git.softwaregroup.com/ut5/ut-customer/commit/c8e6243))
* phoneNumberValidator small fixes plus ValueRow conditional behavior ([5229495](https://git.softwaregroup.com/ut5/ut-customer/commit/5229495))


### Features

* **all SPs:** added security checks ([b71c947](https://git.softwaregroup.com/ut5/ut-customer/commit/b71c947))
* add dropdown menu icons ([405f583](https://git.softwaregroup.com/ut5/ut-customer/commit/405f583))
* add tabIndex for header ([a380a5a](https://git.softwaregroup.com/ut5/ut-customer/commit/a380a5a))
* change close button ([49ca2e6](https://git.softwaregroup.com/ut5/ut-customer/commit/49ca2e6))
* change default user image ([6d5e10e](https://git.softwaregroup.com/ut5/ut-customer/commit/6d5e10e))
* display pop up error when you have no permissions to search ([cd8c3db](https://git.softwaregroup.com/ut5/ut-customer/commit/cd8c3db))
* remove hover state for clientcard status ([18c61c7](https://git.softwaregroup.com/ut5/ut-customer/commit/18c61c7))
* remove tabIndex for items that are not prioritized ([a1cbbca](https://git.softwaregroup.com/ut5/ut-customer/commit/a1cbbca))
* restructuring ([63a8adf](https://git.softwaregroup.com/ut5/ut-customer/commit/63a8adf))
* restructuring part2 ([75ac8e5](https://git.softwaregroup.com/ut5/ut-customer/commit/75ac8e5))



<a name="5.3.31"></a>
## [5.3.31](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.30...v5.3.31) (2016-05-25)


### Bug Fixes

* add blur to IdField after submit and add comments ([43b7fc3](https://git.softwaregroup.com/ut5/ut-customer/commit/43b7fc3))
* add favicon ([3bcaac6](https://git.softwaregroup.com/ut5/ut-customer/commit/3bcaac6))
* add visibility to parents ([aeb817e](https://git.softwaregroup.com/ut5/ut-customer/commit/aeb817e))
* displayed date in IdField component ([4c04af8](https://git.softwaregroup.com/ut5/ut-customer/commit/4c04af8))
* fix infinite loop bug ([5b937b7](https://git.softwaregroup.com/ut5/ut-customer/commit/5b937b7))
* fix min height for modal dialogs ([6896497](https://git.softwaregroup.com/ut5/ut-customer/commit/6896497))
* fix missing reset styles ([d774d6d](https://git.softwaregroup.com/ut5/ut-customer/commit/d774d6d))
* fix styles for buttons and remove unused types ([7f0c55d](https://git.softwaregroup.com/ut5/ut-customer/commit/7f0c55d))
* fix styles for selected menu item ([30e97cc](https://git.softwaregroup.com/ut5/ut-customer/commit/30e97cc))
* fix styles for selected menu item ([c3d8aad](https://git.softwaregroup.com/ut5/ut-customer/commit/c3d8aad))
* fix typo to_complete state should actually be pending ([b4bc460](https://git.softwaregroup.com/ut5/ut-customer/commit/b4bc460))
* IdField to be text dropdown or date ([29bdce3](https://git.softwaregroup.com/ut5/ut-customer/commit/29bdce3))
* improve login and cookiecheck logic ([28912da](https://git.softwaregroup.com/ut5/ut-customer/commit/28912da))
* improve reducers performance and page loading experience ([1973b07](https://git.softwaregroup.com/ut5/ut-customer/commit/1973b07))
* pagination fixes ([e9de009](https://git.softwaregroup.com/ut5/ut-customer/commit/e9de009))
* remove sax dependency as XML parsing algorithm has been moved to SQL port ([bf27b50](https://git.softwaregroup.com/ut5/ut-customer/commit/bf27b50))
* remove xml parsing as it is now integrated into SQL port ([e5a3429](https://git.softwaregroup.com/ut5/ut-customer/commit/e5a3429))
* **customer.search:** back to magic search only ([a93a29a](https://git.softwaregroup.com/ut5/ut-customer/commit/a93a29a))
* slight refactoring ([7d44897](https://git.softwaregroup.com/ut5/ut-customer/commit/7d44897))
* some dialogs use button type that is not allowed ([96f4396](https://git.softwaregroup.com/ut5/ut-customer/commit/96f4396))
* styling ([dbb77c8](https://git.softwaregroup.com/ut5/ut-customer/commit/dbb77c8))
* typo ([49aaf2a](https://git.softwaregroup.com/ut5/ut-customer/commit/49aaf2a))
* update clientFile state ([9e53a41](https://git.softwaregroup.com/ut5/ut-customer/commit/9e53a41))
* upload text to be in Text component ([a505433](https://git.softwaregroup.com/ut5/ut-customer/commit/a505433))


### Features

* add classes for uppercase ([62de9e5](https://git.softwaregroup.com/ut5/ut-customer/commit/62de9e5))
* add classes for uppercase ([68d8ee6](https://git.softwaregroup.com/ut5/ut-customer/commit/68d8ee6))
* add clinet file rejection reasons ([6914e24](https://git.softwaregroup.com/ut5/ut-customer/commit/6914e24))
* add code to not add styles or classes to text component ([fc82881](https://git.softwaregroup.com/ut5/ut-customer/commit/fc82881))
* add new button types ([e8ddff2](https://git.softwaregroup.com/ut5/ut-customer/commit/e8ddff2))
* add udf fields for customer and phone ([2d98482](https://git.softwaregroup.com/ut5/ut-customer/commit/2d98482))
* change icon for accordion ([55f583b](https://git.softwaregroup.com/ut5/ut-customer/commit/55f583b))
* **addDescription:** add column description ([05d9bc4](https://git.softwaregroup.com/ut5/ut-customer/commit/05d9bc4))
* change the correct icon for dropdown menu ([21d84dc](https://git.softwaregroup.com/ut5/ut-customer/commit/21d84dc))
* change the structure of udf fields ([bdaa90d](https://git.softwaregroup.com/ut5/ut-customer/commit/bdaa90d))
* embed fonts with webpack ([b6210f0](https://git.softwaregroup.com/ut5/ut-customer/commit/b6210f0))
* make the header to be fixed ([c9b984c](https://git.softwaregroup.com/ut5/ut-customer/commit/c9b984c))
* refactor close button for modals ([1b3c369](https://git.softwaregroup.com/ut5/ut-customer/commit/1b3c369))
* remove unused icon ([bb506d9](https://git.softwaregroup.com/ut5/ut-customer/commit/bb506d9))
* wrap all text in text component and fix proptypes ([463726f](https://git.softwaregroup.com/ut5/ut-customer/commit/463726f))
* wrap all text in text component and fix proptypes ([abc6c61](https://git.softwaregroup.com/ut5/ut-customer/commit/abc6c61))
* wrap all text in text component and fix proptypes ([309dbbd](https://git.softwaregroup.com/ut5/ut-customer/commit/309dbbd))
* wrap all text in text component and fix proptypes ([b52f679](https://git.softwaregroup.com/ut5/ut-customer/commit/b52f679))
* wrap text with text component and fix proptypes ([5d86e63](https://git.softwaregroup.com/ut5/ut-customer/commit/5d86e63))
* **customer.fetch:** added filter by parameters ([404f0bb](https://git.softwaregroup.com/ut5/ut-customer/commit/404f0bb))
* **customer.search:** separated magic & non-magic search ([81ac4c2](https://git.softwaregroup.com/ut5/ut-customer/commit/81ac4c2))



<a name="5.3.30"></a>
## [5.3.30](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.29...v5.3.30) (2016-05-19)


### Bug Fixes

* bug- clientPreview nationalId should actually be ID card number ([f4784cd](https://git.softwaregroup.com/ut5/ut-customer/commit/f4784cd))
* filter ([ed495b8](https://git.softwaregroup.com/ut5/ut-customer/commit/ed495b8))
* fix annoying 'key' warning ([7f60d85](https://git.softwaregroup.com/ut5/ut-customer/commit/7f60d85))
* fix bug for displaying scroll for resolution 1280 ([8f1543d](https://git.softwaregroup.com/ut5/ut-customer/commit/8f1543d))
* fix customer.document.add request params ([21c5353](https://git.softwaregroup.com/ut5/ut-customer/commit/21c5353))
* improvements ([bdb1bc4](https://git.softwaregroup.com/ut5/ut-customer/commit/bdb1bc4))
* letter spacing styles in phoneValidator component ([4e679ad](https://git.softwaregroup.com/ut5/ut-customer/commit/4e679ad))
* persist documentId ([593e7a3](https://git.softwaregroup.com/ut5/ut-customer/commit/593e7a3))
* refactor code handling clientFile update ([5c7b009](https://git.softwaregroup.com/ut5/ut-customer/commit/5c7b009))
* restructuring and backend communication improvements ([dccb290](https://git.softwaregroup.com/ut5/ut-customer/commit/dccb290))


### Features

* add text component ([8936465](https://git.softwaregroup.com/ut5/ut-customer/commit/8936465))
* extend input component to accept node for placeholder ([8fc05b8](https://git.softwaregroup.com/ut5/ut-customer/commit/8fc05b8))
* improve logic for styles' width for the input with static placeholder ([d0ab885](https://git.softwaregroup.com/ut5/ut-customer/commit/d0ab885))
* style validate phone steps and components ([1cd388f](https://git.softwaregroup.com/ut5/ut-customer/commit/1cd388f))
* **addDocumentUpdate:** add to exec document.document.update ([d6024c7](https://git.softwaregroup.com/ut5/ut-customer/commit/d6024c7))
* **attachementUpdate:** some changes ([4e312ca](https://git.softwaregroup.com/ut5/ut-customer/commit/4e312ca))
* **customerFileUpdateStatus:** some changes ([e7af43e](https://git.softwaregroup.com/ut5/ut-customer/commit/e7af43e))
* **documentTT:** add documentTT ([b7f7ebc](https://git.softwaregroup.com/ut5/ut-customer/commit/b7f7ebc))
* **file.updateState:** add to update document.OldValues ([e7873b4](https://git.softwaregroup.com/ut5/ut-customer/commit/e7873b4))
* wrap all text with text component ([5167a5c](https://git.softwaregroup.com/ut5/ut-customer/commit/5167a5c))
* wrap placeholder in text component ([903218e](https://git.softwaregroup.com/ut5/ut-customer/commit/903218e))



<a name="5.3.29"></a>
## [5.3.29](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.28...v5.3.29) (2016-05-17)


### Bug Fixes

* add default type of button component ([6664795](https://git.softwaregroup.com/ut5/ut-customer/commit/6664795))
* add fingerPrint image to Login component ([543f329](https://git.softwaregroup.com/ut5/ut-customer/commit/543f329))
* add missing properties to the instances of Button component ([694085e](https://git.softwaregroup.com/ut5/ut-customer/commit/694085e))
* add rejecter component to clientFile ([8b918ed](https://git.softwaregroup.com/ut5/ut-customer/commit/8b918ed))
* backend communication ([8a131c2](https://git.softwaregroup.com/ut5/ut-customer/commit/8a131c2))
* fix bug in aligning for smaller resolutions ([ceb6683](https://git.softwaregroup.com/ut5/ut-customer/commit/ceb6683))
* login logic ([9d3f495](https://git.softwaregroup.com/ut5/ut-customer/commit/9d3f495))
* phone validation in storybook ([e1769d1](https://git.softwaregroup.com/ut5/ut-customer/commit/e1769d1))
* possible multiple parents ([c30de75](https://git.softwaregroup.com/ut5/ut-customer/commit/c30de75))
* relative path to images ([f38f414](https://git.softwaregroup.com/ut5/ut-customer/commit/f38f414))
* rename phoneNumber to phoneNumbervalidator ([5245a69](https://git.softwaregroup.com/ut5/ut-customer/commit/5245a69))
* small changes ([7f53bdd](https://git.softwaregroup.com/ut5/ut-customer/commit/7f53bdd))
* small refactoring ([2f7af1b](https://git.softwaregroup.com/ut5/ut-customer/commit/2f7af1b))
* styles on bioRegistration ([32ab1a3](https://git.softwaregroup.com/ut5/ut-customer/commit/32ab1a3))
* submit on enter press on some components ([3462149](https://git.softwaregroup.com/ut5/ut-customer/commit/3462149))
* xml parsing and improvements ([6fb8f6f](https://git.softwaregroup.com/ut5/ut-customer/commit/6fb8f6f))


### Features

* **customer.file.updateState:** initial version of customer.file.UpdateState ([b0be20a](https://git.softwaregroup.com/ut5/ut-customer/commit/b0be20a))
* add fingerprint images ([386a1e3](https://git.softwaregroup.com/ut5/ut-customer/commit/386a1e3))
* add original camera images ([602a68c](https://git.softwaregroup.com/ut5/ut-customer/commit/602a68c))
* add styles for static input placeholder ([ea4e9ef](https://git.softwaregroup.com/ut5/ut-customer/commit/ea4e9ef))
* change default profile image ([bf97ac0](https://git.softwaregroup.com/ut5/ut-customer/commit/bf97ac0))
* new SP that returns business units ([fe6d881](https://git.softwaregroup.com/ut5/ut-customer/commit/fe6d881))
* wrap some document procedures in customer module to implement custom login ([51fdced](https://git.softwaregroup.com/ut5/ut-customer/commit/51fdced))



<a name="5.3.28"></a>
## [5.3.28](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.27...v5.3.28) (2016-05-16)


### Bug Fixes

* add form component and change usage of Button component ([1ef7cc6](https://git.softwaregroup.com/ut5/ut-customer/commit/1ef7cc6))
* enable submit with enter press in phoneValidation component ([77cf0d3](https://git.softwaregroup.com/ut5/ut-customer/commit/77cf0d3))
* lint errors ([c21225f](https://git.softwaregroup.com/ut5/ut-customer/commit/c21225f))


### Features

* **Upload:** add medium attachment id ([cd1c5cd](https://git.softwaregroup.com/ut5/ut-customer/commit/cd1c5cd))
* allow non-magic search ([cd2966e](https://git.softwaregroup.com/ut5/ut-customer/commit/cd2966e))



<a name="5.3.27"></a>
## [5.3.27](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.26...v5.3.27) (2016-05-15)


### Bug Fixes

* **BioRegistration:** fix lint error ([4627ea9](https://git.softwaregroup.com/ut5/ut-customer/commit/4627ea9))
* storybook remote ([3c6ddc6](https://git.softwaregroup.com/ut5/ut-customer/commit/3c6ddc6))


### Features

* **BioRegistration:** call method bio.add on finish step ([f5cd70e](https://git.softwaregroup.com/ut5/ut-customer/commit/f5cd70e))



<a name="5.3.26"></a>
## [5.3.26](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.25...v5.3.26) (2016-05-14)


### Bug Fixes

* refactoring ([ea34ce8](https://git.softwaregroup.com/ut5/ut-customer/commit/ea34ce8))
* remove symbols from merge ([da6bda3](https://git.softwaregroup.com/ut5/ut-customer/commit/da6bda3))


### Features

* **customerChanges:** changes in customer structure ([7881cc3](https://git.softwaregroup.com/ut5/ut-customer/commit/7881cc3))
* **customerFileUpdate:** initial version of customer.file.update ([4bff90c](https://git.softwaregroup.com/ut5/ut-customer/commit/4bff90c))
* **oldValues:** rewrite and add oldValues in necessary procedures ([cc5b2c0](https://git.softwaregroup.com/ut5/ut-customer/commit/cc5b2c0))
* new columns for migration ([ef23437](https://git.softwaregroup.com/ut5/ut-customer/commit/ef23437))



<a name="5.3.25"></a>
## [5.3.25](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.24...v5.3.25) (2016-05-11)


### Bug Fixes

* customer.customer.search resultsetName ([dbc8052](https://git.softwaregroup.com/ut5/ut-customer/commit/dbc8052))


### Features

* **oldValues:** add oldValues in customer tables and some small changes ([64f42af](https://git.softwaregroup.com/ut5/ut-customer/commit/64f42af))



<a name="5.3.24"></a>
## [5.3.24](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.23...v5.3.24) (2016-05-11)


### Bug Fixes

* vhange the phone type - from home to personal ([dbf0cd7](https://git.softwaregroup.com/ut5/ut-customer/commit/dbf0cd7))



<a name="5.3.23"></a>
## [5.3.23](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.22...v5.3.23) (2016-05-11)


### Features

* **column:** added bioid column ([9bc8255](https://git.softwaregroup.com/ut5/ut-customer/commit/9bc8255))



<a name="5.3.22"></a>
## [5.3.22](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.21...v5.3.22) (2016-05-10)


### Bug Fixes

* **customerProcedures:** rename procedure name without []([e482b32](https://git.softwaregroup.com/ut5/ut-customer/commit/e482b32))


### Features

* **fileGet:** initial version([c593773](https://git.softwaregroup.com/ut5/ut-customer/commit/c593773))



<a name="5.3.21"></a>
## [5.3.21](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.20...v5.3.21) (2016-05-09)


### Bug Fixes

* customer.address.add([381b718](https://git.softwaregroup.com/ut5/ut-customer/commit/381b718))


### Features

* add the new fields for the organization([71866f3](https://git.softwaregroup.com/ut5/ut-customer/commit/71866f3))



<a name="5.3.20"></a>
## [5.3.20](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.19...v5.3.20) (2016-05-05)


### Bug Fixes

* customer.customer.add([83e1a6b](https://git.softwaregroup.com/ut5/ut-customer/commit/83e1a6b))



<a name="5.3.19"></a>
## [5.3.19](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.18...v5.3.19) (2016-05-05)


### Bug Fixes

* remove savepoint([d980fdf](https://git.softwaregroup.com/ut5/ut-customer/commit/d980fdf))
* **fixResultSet:** fix problem in customer.add([97f41d2](https://git.softwaregroup.com/ut5/ut-customer/commit/97f41d2))



<a name="5.3.18"></a>
## [5.3.18](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.17...v5.3.18) (2016-04-28)


### Features

* **addAgencyName:** add condition to select Agency name([7b460df](https://git.softwaregroup.com/ut5/ut-customer/commit/7b460df))
* **changeComments:** change comments([d1be431](https://git.softwaregroup.com/ut5/ut-customer/commit/d1be431))
* **customerFetch:** implemented customer.customer.fetch according to the FSD([99b04fc](https://git.softwaregroup.com/ut5/ut-customer/commit/99b04fc))
* **smallChange:** remove []([4fddbe7](https://git.softwaregroup.com/ut5/ut-customer/commit/4fddbe7))



<a name="5.3.17"></a>
## [5.3.17](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.16...v5.3.17) (2016-04-22)


### Features

* add path of the profile picture in the result ([55531d7](https://git.softwaregroup.com/ut5/ut-customer/commit/55531d7))



<a name="5.3.16"></a>
## [5.3.16](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.15...v5.3.16) (2016-04-22)


### Bug Fixes

* typo ([e4e00fe](https://git.softwaregroup.com/ut5/ut-customer/commit/e4e00fe))

### Features

* add in second result set information for the paging ([f7d4edf](https://git.softwaregroup.com/ut5/ut-customer/commit/f7d4edf))
* upgrade react ([d162d6b](https://git.softwaregroup.com/ut5/ut-customer/commit/d162d6b))
* **customerGet:** small changes in customer.get ([4f8adae](https://git.softwaregroup.com/ut5/ut-customer/commit/4f8adae))
* **modifCustomerGet:** add comments in customer.customer.get ([b1dca33](https://git.softwaregroup.com/ut5/ut-customer/commit/b1dca33))
* **modifCustomerGet:** modif customer.customer.get according to the FSD ([494ca90](https://git.softwaregroup.com/ut5/ut-customer/commit/494ca90))
* **modifDocumentSize:** documentsize = default ([0e6c265](https://git.softwaregroup.com/ut5/ut-customer/commit/0e6c265))



<a name="5.3.15"></a>
## [5.3.15](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.14...v5.3.15) (2016-04-15)


### Features

* add Gitlab-ci and Jenkins scripts ([2d8a298](https://git.softwaregroup.com/ut5/ut-customer/commit/2d8a298))



<a name="5.3.14"></a>
## [5.3.14](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.13...v5.3.14) (2016-04-09)




<a name="5.3.13"></a>
## [5.3.13](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.12...v5.3.13) (2016-04-05)




<a name="5.3.12"></a>
## [5.3.12](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.11...v5.3.12) (2016-04-05)


### Bug Fixes

* add customerNumber to customer.customer table ([2fbf6f5](https://git.softwaregroup.com/ut5/ut-customer/commit/2fbf6f5))
* add status constraint ([d976adf](https://git.softwaregroup.com/ut5/ut-customer/commit/d976adf))
* add statuses to different entities ([6f4ae3c](https://git.softwaregroup.com/ut5/ut-customer/commit/6f4ae3c))
* change customer.joint.add similarly to customer.organization.add ([c6102ab](https://git.softwaregroup.com/ut5/ut-customer/commit/c6102ab))
* change kycId from varchar to smallint for easier integration with frontend ([4ac5d83](https://git.softwaregroup.com/ut5/ut-customer/commit/4ac5d83))
* customer.customer.add fixes ([d454ceb](https://git.softwaregroup.com/ut5/ut-customer/commit/d454ceb))
* fix customer.customer.edit and customer.customer.update ([bee66ff](https://git.softwaregroup.com/ut5/ut-customer/commit/bee66ff))
* fix customer.organization.add method ([92ba9f1](https://git.softwaregroup.com/ut5/ut-customer/commit/92ba9f1))
* fix vPersonCustomer ([5ba72fc](https://git.softwaregroup.com/ut5/ut-customer/commit/5ba72fc))
* improve customer.customer.* stored procedures ([f582a42](https://git.softwaregroup.com/ut5/ut-customer/commit/f582a42))
* refactoring plus adding a column updatedBy in customer.customer tabl;e ([42517ac](https://git.softwaregroup.com/ut5/ut-customer/commit/42517ac))
* small bug fix ([7b00513](https://git.softwaregroup.com/ut5/ut-customer/commit/7b00513))
* small changes ([44419c9](https://git.softwaregroup.com/ut5/ut-customer/commit/44419c9))
* transform arrays to objects for some methods on demand ([b1b4227](https://git.softwaregroup.com/ut5/ut-customer/commit/b1b4227))
* typo ([b9db76a](https://git.softwaregroup.com/ut5/ut-customer/commit/b9db76a))

### Features

* add 'createdBy' to customer.customer table ([ba0d65f](https://git.softwaregroup.com/ut5/ut-customer/commit/ba0d65f))
* add creationDate and lastUpdated columns to customer.customer table ([cf4cdf2](https://git.softwaregroup.com/ut5/ut-customer/commit/cf4cdf2))
* add state and kyc for customers ([2f00c3e](https://git.softwaregroup.com/ut5/ut-customer/commit/2f00c3e))
* create customer.vPersonCustomer ([6239b3f](https://git.softwaregroup.com/ut5/ut-customer/commit/6239b3f))



<a name="5.3.11"></a>
## [5.3.11](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.10...v5.3.11) (2016-04-05)


### Features

* update ut-error dependency ([b71c90a](https://git.softwaregroup.com/ut5/ut-customer/commit/b71c90a))



<a name="5.3.10"></a>
## [5.3.10](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.9...v5.3.10) (2016-03-31)


### Bug Fixes

* use constant dependencies ([43c4c87](https://git.softwaregroup.com/ut5/ut-customer/commit/43c4c87))



<a name="5.3.9"></a>
## [5.3.9](https://git.softwaregroup.com/ut5/ut-customer/compare/v5.3.7...v5.3.9) (2016-03-30)


### Bug Fixes

* switch to nexus ([e41262d](https://git.softwaregroup.com/ut5/ut-customer/commit/e41262d))

### Features

* ut-tools upgrade ([9eb0a1e](https://git.softwaregroup.com/ut5/ut-customer/commit/9eb0a1e))


