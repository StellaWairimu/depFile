module.exports = gridStyle => ({
    CustomerReport: require('./customerCreation').default(gridStyle)
});
