import { filterElementTypes } from 'ut-front-react/components/GridToolBox/types';
import reportStyle from '../../assets/static/css/reportStyle.css';
import style from './style.css';

const startDate = new Date();
startDate.setHours(0);
startDate.setMinutes(0);
startDate.setSeconds(0);
startDate.setMilliseconds(0);

const endDate = new Date();
endDate.setHours(23);
endDate.setMinutes(59);
endDate.setSeconds(59);
endDate.setMilliseconds(999);

export default (gridStyle) => ({
    title: 'Customer Registration Report',
    export: {
        method: 'customer.customer.getRegistrationReport',
        resultsetName: 'customers',
        maxSize: 20000
    },
    grid: {
        fields: [
            { name: 'createdOn', title: 'Date' },
            { name: 'agentName', title: 'Agent Name' },
            { name: 'agentType', title: 'Agent Type' },
            { name: 'memberName', title: 'Customer Name' },
            // { name: 'accountNumber', title: 'Account Number' },
            { name: 'phoneNumber', title: 'Mobile Number' },
            { name: 'status', title: 'Status' }
        ],
        allowColumnConfig: true,
        method: 'customer.customer.getRegistrationReport',
        resultsetName: 'customers',
        rowStyleField: 'style',
        externalStyle: {...reportStyle, ...gridStyle, ...style}
    },
    toolbox: {
        showAdvanced: true,
        maxVisibleInputs: 5,
        filterAutoFetch: false
    },
    filters: [
        {
            labelFrom: 'Date from',
            labelTo: 'Date to',
            nameMap: { from: 'startDate', to: 'endDate' },
            type: filterElementTypes.dateTimePickerBetween,
            timeFormat: 'HH:mm',
            dateFormat: 'YYYY-MM-DD',
            defaultValue: {
                from: startDate,
                to: endDate
            }
        },
        {   name: 'agent',
            label: 'Agent',
            placeholder: 'Agent',
            type: filterElementTypes.searchBox
        },
        {
            type: filterElementTypes.clear, validateFilter: false
        },
        {
            type: filterElementTypes.searchBtn, validateFilter: false
        }
    ],
    order: {
        single: true,
        by: []
    },
    pagination: {
        visiblePages: 10,
        pageSize: 25
    }
});
