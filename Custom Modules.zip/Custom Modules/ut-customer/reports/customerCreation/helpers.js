const {formatNumber} = require('../common');

module.exports = {
    staticResources: [
        {rel: 'stylesheet', type: 'text/css', href: '/s/ut-transfer/repository/css/reportStyle.css'}
    ],
    transformCellValue: (value, field, data, isHeader) => {
        const classnames = [];

        switch (field.name) {
            case 'agentName':
            case 'agentType':
            case 'memberName':
            // case 'accountNumber':
            case 'createdOn':
            case 'phoneNumber':
            case 'status':
                break;
            default:
                if (!isHeader) {
                    value = formatNumber(value);
                    classnames.push('textColorBlue');
                }
                classnames.push('rightAlign');
                break;
        }

        return {
            value,
            classnames
        };
    }
};
